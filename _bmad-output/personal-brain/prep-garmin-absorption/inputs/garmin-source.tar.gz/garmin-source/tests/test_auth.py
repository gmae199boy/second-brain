"""최초 로그인(`auth.login`·`garmin-pipeline login`): tokenstore 준비, `auth_event`, 종료 코드,
사유 출력, 명령 로그, 비밀번호 위생."""

import builtins
import contextlib
import fcntl
import getpass
import json
import logging
import logging.handlers
import os
import re
import sqlite3
import stat
import sys
import time
from collections.abc import Callable, Iterator
from datetime import UTC, datetime, timedelta
from pathlib import Path

import garminconnect
import pytest
import schema_version
from garmin_fakes import (
    FAKE_TOKEN_PAYLOAD,
    GOOD_MFA_CODE,
    ScriptedPrompts,
    StubLoginClient,
)

from garmin_pipeline import auth, cli, config, dates, garmin, store

ROOT = Path(__file__).resolve().parents[1]
AuthError = garminconnect.GarminConnectAuthenticationError
ConnError = garminconnect.GarminConnectConnectionError
TooMany = garminconnect.GarminConnectTooManyRequestsError

# 서울 2026-10-16 10:00.
NOW = datetime(2026, 10, 16, 1, 0, tzinfo=UTC)
NOW_MS = int(NOW.timestamp() * 1000)
TODAY = "2026-10-16"

EMAIL = "runner-51af@example.com"
PASSWORD = "pw-e83c-battery-staple"
TOKEN_FILENAME = "garmin_tokens.json"
LOG_LINE = re.compile(
    r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3})Z (INFO|WARNING|ERROR) garmin_pipeline\."
)


@pytest.fixture(autouse=True)
def clock(monkeypatch: pytest.MonkeyPatch) -> Callable[[datetime], None]:
    """`dates._utc_now`를 `NOW`로 고정하고, 다른 시각으로 바꾸는 함수를 준다."""

    def set_now(moment: datetime) -> None:
        monkeypatch.setattr(dates, "_utc_now", lambda: moment)

    set_now(NOW)
    return set_now


@pytest.fixture
def make_cfg(write_config: Callable[..., Path]) -> Callable[..., config.Config]:
    """`write_config`로 쓴 설정을 읽는다. tokenstore(`tmp_path/tokens`)는 만들지 않는다."""

    def make(**overrides: object) -> config.Config:
        return config.load(write_config(**{"lock_wait_seconds": 0, **overrides}))

    return make


@pytest.fixture
def cfg(make_cfg: Callable[..., config.Config]) -> config.Config:
    return make_cfg()


@pytest.fixture
def login_stubs(
    monkeypatch: pytest.MonkeyPatch,
) -> Callable[..., list[StubLoginClient]]:
    """`garmin._new_client`를 `StubLoginClient(**kwargs)` 생성으로 바꾸고 만든 목록을 준다."""

    def install(**kwargs: object) -> list[StubLoginClient]:
        created: list[StubLoginClient] = []

        def new_client() -> StubLoginClient:
            client = StubLoginClient(**kwargs)  # type: ignore[arg-type]
            created.append(client)
            return client

        monkeypatch.setattr(garmin, "_new_client", new_client)
        return created

    return install


@pytest.fixture
def library_logger_state() -> Iterator[tuple[bool, int, list[logging.Handler]]]:
    """`garminconnect` 로거의 전파·수준·처리기를 기록하고, 테스트가 끝나면 되돌린다."""
    library = logging.getLogger("garminconnect")
    saved = (library.propagate, library.level, list(library.handlers))
    yield saved
    library.propagate = saved[0]
    library.setLevel(saved[1])
    library.handlers[:] = saved[2]


def _prompts(*codes: str | BaseException, **kwargs: object) -> ScriptedPrompts:
    return ScriptedPrompts(EMAIL, PASSWORD, codes, **kwargs)  # type: ignore[arg-type]


def _token_path(cfg: config.Config) -> Path:
    return cfg.tokenstore / TOKEN_FILENAME


def _auth_events(cfg: config.Config) -> list[tuple[int, str, int]]:
    conn = sqlite3.connect(cfg.db_path)
    try:
        return conn.execute(
            "SELECT id, local_date, logged_in_at FROM auth_event ORDER BY id"
        ).fetchall()
    finally:
        conn.close()


def _user_version(cfg: config.Config) -> int:
    conn = sqlite3.connect(cfg.db_path)
    try:
        return conn.execute("PRAGMA user_version").fetchone()[0]
    finally:
        conn.close()


def _mode(path: Path) -> int:
    return stat.S_IMODE(path.stat().st_mode)


def _hold_flock(path: Path) -> int:
    """이 프로세스의 다른 fd로 `path`에 `flock(LOCK_EX)`을 잡는다. 닫으면 풀린다."""
    path.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    fcntl.flock(fd, fcntl.LOCK_EX)
    return fd


def _write_block(cfg: config.Config, local_date: str, reason: str) -> None:
    cfg.tokenstore.mkdir(parents=True, exist_ok=True)
    payload = {"schema_version": 1, "local_date": local_date, "reason": reason}
    (cfg.tokenstore / garmin.BLOCK_FILENAME).write_text(
        json.dumps(payload), encoding="utf-8"
    )


# --- auth.login 정상 경로 -----------------------------------------------------------------


def test_mfa_login_creates_tokenstore_tokens_and_auth_event(
    make_cfg: Callable[..., config.Config],
    login_stubs: Callable[..., list[StubLoginClient]],
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
):
    tokenstore = tmp_path / "home" / "nested" / "tokens"
    cfg = make_cfg(tokenstore=str(tokenstore))
    parent_mode = _mode(tmp_path)
    created = login_stubs()

    assert auth.login(cfg, _prompts(GOOD_MFA_CODE)) == 0

    for path in (tmp_path / "home", tmp_path / "home" / "nested", tokenstore):
        assert _mode(path) == 0o700, path
    assert _mode(tmp_path) == parent_mode
    assert (
        json.loads(_token_path(cfg).read_text(encoding="utf-8")) == FAKE_TOKEN_PAYLOAD
    )
    assert _mode(_token_path(cfg)) == 0o600
    assert _auth_events(cfg) == [(1, TODAY, NOW_MS)]
    assert _user_version(cfg) == schema_version.LATEST
    assert created[0].events == ["login", "resume", "profile", "dump"]
    out, err = capsys.readouterr()
    assert err == ""
    assert str(tokenstore) in out
    assert EMAIL not in out


def test_existing_tokenstore_is_chmod_700(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    cfg.tokenstore.mkdir(mode=0o755)
    os.chmod(cfg.tokenstore, 0o755)
    login_stubs(needs_mfa=False)

    assert auth.login(cfg, _prompts()) == 0

    assert _mode(cfg.tokenstore) == 0o700


def test_login_without_mfa_records_auth_event(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    created = login_stubs(needs_mfa=False)
    prompts = _prompts()

    assert auth.login(cfg, prompts) == 0

    assert prompts.calls == ["credentials"]
    assert created[0].events == ["login", "profile", "dump"]
    assert _auth_events(cfg) == [(1, TODAY, NOW_MS)]


def test_wrong_mfa_twice_then_right_succeeds(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    created = login_stubs()

    assert auth.login(cfg, _prompts("000000", "111111", GOOD_MFA_CODE)) == 0

    assert len(created) == 1
    assert len(created[0].resume_calls) == 3
    assert len(_auth_events(cfg)) == 1


def test_auth_event_date_follows_config_timezone(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    clock: Callable[[datetime], None],
):
    # UTC로는 아직 10월 15일이지만 서울로는 10월 16일 00:30이다.
    moment = datetime(2026, 10, 15, 15, 30, tzinfo=UTC)
    clock(moment)
    login_stubs(needs_mfa=False)

    assert auth.login(cfg, _prompts()) == 0

    assert _auth_events(cfg) == [(1, "2026-10-16", int(moment.timestamp() * 1000))]


@pytest.mark.parametrize(
    "existing",
    [json.dumps({"di_token": "still-valid"}), "{broken"],
    ids=["valid", "broken"],
)
def test_relogin_replaces_tokens_and_adds_second_event(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    clock: Callable[[datetime], None],
    existing: str,
):
    login_stubs(needs_mfa=False)
    assert auth.login(cfg, _prompts()) == 0
    _token_path(cfg).write_text(existing, encoding="utf-8")
    later = NOW + timedelta(hours=1)
    clock(later)
    second = login_stubs(token_payload={"di_token": "second"})

    assert auth.login(cfg, _prompts(GOOD_MFA_CODE)) == 0

    assert len(second[0].login_calls) == 1
    assert json.loads(_token_path(cfg).read_text(encoding="utf-8")) == {
        "di_token": "second"
    }
    assert _auth_events(cfg) == [
        (1, TODAY, NOW_MS),
        (2, TODAY, int(later.timestamp() * 1000)),
    ]


# --- auth.login 실패 경로 -----------------------------------------------------------------


def _assert_failed(
    capsys: pytest.CaptureFixture[str], *fragments: str
) -> tuple[str, str]:
    out, err = capsys.readouterr()
    assert err.startswith("login 실패: ")
    assert err.count("\n") == 1, err
    for fragment in fragments:
        assert fragment in err
    return out, err


def test_three_wrong_mfa_codes_exit_1_without_db(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
):
    login_stubs()

    assert auth.login(cfg, _prompts("000000", "111111", "222222")) == 1

    _assert_failed(capsys, "인증에 실패")
    assert not cfg.db_path.exists()
    assert not _token_path(cfg).exists()


@pytest.mark.parametrize("reason", ["rate_limited", "blocked_403"])
def test_block_today_exits_1_without_prompt_or_client(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
    reason: str,
):
    _write_block(cfg, TODAY, reason)
    created = login_stubs()
    prompts = _prompts(GOOD_MFA_CODE)

    assert auth.login(cfg, prompts) == 1

    _assert_failed(capsys, "당일 차단", reason)
    assert prompts.calls == []
    assert created == []
    assert not cfg.db_path.exists()


@pytest.mark.parametrize(
    ("make_error", "reason", "status"),
    [
        pytest.param(lambda: TooMany("429"), "rate_limited", "429", id="429"),
        pytest.param(
            lambda: ConnError("All login strategies exhausted: API Error 403"),
            "blocked_403",
            "403",
            id="403",
        ),
    ],
)
def test_login_429_403_records_block_and_exits_1(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
    make_error: Callable[[], BaseException],
    reason: str,
    status: str,
):
    login_stubs(login_error=make_error())

    assert auth.login(cfg, _prompts()) == 1

    _assert_failed(capsys, f"HTTP {status}", "당일 차단")
    block = json.loads((cfg.tokenstore / garmin.BLOCK_FILENAME).read_text("utf-8"))
    assert block == {"schema_version": 1, "local_date": TODAY, "reason": reason}
    assert not cfg.db_path.exists()


def test_transient_exits_1(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
):
    login_stubs(login_error=ConnError("API Error 503"))

    assert auth.login(cfg, _prompts()) == 1

    _assert_failed(capsys, "일시적인 오류", "HTTP 503")


def test_session_lock_timeout_exits_1(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
):
    created = login_stubs()
    fd = _hold_flock(cfg.tokenstore / garmin.SESSION_LOCK_FILENAME)
    try:
        assert auth.login(cfg, _prompts()) == 1
    finally:
        os.close(fd)

    _assert_failed(capsys, "다른 명령")
    assert created == []


def test_invalid_block_file_exits_1(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
):
    cfg.tokenstore.mkdir()
    (cfg.tokenstore / garmin.BLOCK_FILENAME).write_text("{oops", encoding="utf-8")
    prompts = _prompts()
    login_stubs()

    assert auth.login(cfg, prompts) == 1

    _assert_failed(capsys, "당일 차단 파일")
    assert prompts.calls == []


@pytest.mark.parametrize(
    ("email", "password", "field"),
    [("", PASSWORD, "이메일"), ("   ", PASSWORD, "이메일"), (EMAIL, "", "비밀번호")],
)
def test_empty_credentials_exit_1_without_client(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
    email: str,
    password: str,
    field: str,
):
    created = login_stubs()

    assert auth.login(cfg, ScriptedPrompts(email, password)) == 1

    _assert_failed(capsys, "입력이 비어 있다", field)
    assert created == []


def test_email_is_stripped(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    created = login_stubs(needs_mfa=False)

    assert auth.login(cfg, ScriptedPrompts(f"  {EMAIL}\n", PASSWORD)) == 0

    assert created[0].login_calls[0]["email"] == EMAIL


def test_empty_mfa_code_exits_1_without_resume(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
):
    created = login_stubs()

    assert auth.login(cfg, _prompts("  ")) == 1

    _assert_failed(capsys, "MFA 코드")
    assert created[0].resume_calls == []
    assert not _token_path(cfg).exists()


@pytest.mark.parametrize("error", [KeyboardInterrupt, EOFError])
@pytest.mark.parametrize("where", ["credentials", "mfa_code"])
def test_cancelled_prompt_exits_1(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
    error: type[BaseException],
    where: str,
):
    login_stubs()
    if where == "credentials":
        prompts = _prompts(credentials_error=error())
    else:
        prompts = _prompts(error())

    assert auth.login(cfg, prompts) == 1

    _assert_failed(capsys, "취소")
    assert not _token_path(cfg).exists()


def test_tokenstore_that_is_a_file_exits_1(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
):
    cfg.tokenstore.write_text("", encoding="utf-8")
    created = login_stubs()
    prompts = _prompts()

    assert auth.login(cfg, prompts) == 1

    _assert_failed(capsys, "tokenstore")
    assert prompts.calls == []
    assert created == []


def test_token_write_failure_exits_1(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
):
    login_stubs(dump_error=PermissionError(13, "Permission denied", "garmin_tokens"))

    assert auth.login(cfg, _prompts(GOOD_MFA_CODE)) == 1

    _assert_failed(capsys, "Permission denied")
    assert not cfg.db_path.exists()


def test_store_lock_timeout_after_tokens_exits_1(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
):
    login_stubs()
    fd = _hold_flock(cfg.data_dir / store.LOCK_FILENAME)
    try:
        assert auth.login(cfg, _prompts(GOOD_MFA_CODE)) == 1
    finally:
        os.close(fd)

    _assert_failed(capsys, "토큰은", "auth_event", "쓰기 락")
    assert _token_path(cfg).is_file()
    assert not cfg.db_path.exists()


def test_unknown_error_propagates_after_logging_its_name(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    caplog: pytest.LogCaptureFixture,
):
    original = TypeError("unexpected keyword secret-8b1f")
    login_stubs(login_error=original)

    with pytest.raises(TypeError) as excinfo:
        auth.login(cfg, _prompts())

    assert excinfo.value is original
    auth_lines = [r for r in caplog.records if r.name == "garmin_pipeline.auth"]
    assert [r.getMessage() for r in auth_lines] == [
        "login 중단(예상하지 못한 오류): stage=login error=TypeError"
    ]
    assert "secret-8b1f" not in caplog.text


@pytest.mark.parametrize("error", [KeyboardInterrupt, EOFError])
def test_cancel_during_record_exits_1(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    caplog: pytest.LogCaptureFixture,
    error: type[BaseException],
):
    login_stubs(needs_mfa=False)

    @contextlib.contextmanager
    def interrupted(cfg: config.Config) -> Iterator[sqlite3.Connection]:
        raise error()
        yield  # pragma: no cover

    monkeypatch.setattr(store, "write_session", interrupted)

    assert auth.login(cfg, _prompts()) == 1

    _assert_failed(capsys, "토큰은", "취소")
    assert _token_path(cfg).is_file()
    messages = [
        r.getMessage() for r in caplog.records if r.name == "garmin_pipeline.auth"
    ]
    assert f"login 실패: stage=record error={error.__name__}" in messages


def test_auth_event_time_is_taken_before_waiting_for_write_lock(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    monkeypatch: pytest.MonkeyPatch,
    clock: Callable[[datetime], None],
):
    login_stubs(needs_mfa=False)
    real_write_session = store.write_session

    def slow_write_session(cfg: config.Config):  # type: ignore[no-untyped-def]
        # 락을 기다리는 동안 날이 바뀌어도 기록은 로그인한 시각이다.
        clock(NOW + timedelta(days=1))
        return real_write_session(cfg)

    monkeypatch.setattr(store, "write_session", slow_write_session)

    assert auth.login(cfg, _prompts()) == 0

    assert _auth_events(cfg) == [(1, TODAY, NOW_MS)]


def test_password_is_passed_through_unstripped(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    created = login_stubs(needs_mfa=False)

    assert auth.login(cfg, ScriptedPrompts(EMAIL, " pw ")) == 0

    assert created[0].login_calls[0]["password"] == " pw "


def test_non_tty_stdin_is_refused_before_prompting(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    created = login_stubs()

    def refuse(*args: object) -> str:
        raise AssertionError("터미널이 아니면 묻지 않는다")

    monkeypatch.setattr(builtins, "input", refuse)
    monkeypatch.setattr(getpass, "getpass", refuse)
    monkeypatch.setattr(sys, "stdin", _Stdin(tty=False))

    assert auth.login(cfg) == 1

    _assert_failed(capsys, "터미널")
    assert created == []
    assert not _token_path(cfg).exists()


# --- cli ----------------------------------------------------------------------------------


class _Stdin:
    """`sys.stdin` 대역. `isatty()`만 쓴다."""

    def __init__(self, *, tty: bool) -> None:
        self._tty = tty

    def isatty(self) -> bool:
        return self._tty


@pytest.fixture
def terminal(monkeypatch: pytest.MonkeyPatch) -> Callable[..., list[str]]:
    """실제 `input`·`getpass.getpass`를 바꿔 차례로 답한다. 받은 프롬프트 문구 목록을 준다."""

    def install(*lines: str, password: str = PASSWORD) -> list[str]:
        asked: list[str] = []
        answers = list(lines)

        def fake_input(prompt: object = "") -> str:
            asked.append(str(prompt))
            return answers.pop(0)

        def fake_getpass(prompt: str = "Password: ", stream: object = None) -> str:
            asked.append(prompt)
            return password

        monkeypatch.setattr(builtins, "input", fake_input)
        monkeypatch.setattr(getpass, "getpass", fake_getpass)
        monkeypatch.setattr(sys, "stdin", _Stdin(tty=True))
        return asked

    return install


def test_cli_login_uses_input_and_getpass(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    terminal: Callable[..., list[str]],
    library_logger_state: tuple[bool, int, list[logging.Handler]],
):
    created = login_stubs()
    asked = terminal(EMAIL, GOOD_MFA_CODE)

    assert cli.main(["login", "--config", str(cfg.path)]) == 0

    assert asked == ["Garmin 이메일: ", "Garmin 비밀번호: ", "Garmin MFA 코드: "]
    assert created[0].login_calls[0]["email"] == EMAIL
    assert created[0].login_calls[0]["password"] == PASSWORD
    assert created[0].resume_calls == [(None, GOOD_MFA_CODE)]
    assert _auth_events(cfg) == [(1, TODAY, NOW_MS)]


def test_cli_login_help_offers_only_config(capsys: pytest.CaptureFixture[str]):
    with pytest.raises(SystemExit) as excinfo:
        cli.main(["login", "--help"])

    assert excinfo.value.code == 0
    out = capsys.readouterr().out
    assert set(re.findall(r"--[a-z][a-z-]*", out)) == {"--help", "--config"}


def test_auth_and_cli_never_read_environment_or_argv_secrets():
    for module in ("auth.py", "cli.py"):
        source = (ROOT / "src" / "garmin_pipeline" / module).read_text("utf-8")
        assert re.search(r"\benviron\b", source) is None
        assert "getenv" not in source
        assert "sys.argv" not in source


@pytest.mark.parametrize("problem", ["missing", "runtime", "bad-key"])
def test_cli_config_error_exits_2(
    write_config: Callable[..., Path],
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
    login_stubs: Callable[..., list[StubLoginClient]],
    problem: str,
):
    created = login_stubs()
    if problem == "missing":
        path = tmp_path / "nowhere.toml"
    elif problem == "runtime":
        path = write_config(environment="runtime")
    else:
        path = write_config(unknown_key=1)

    assert cli.main(["login", "--config", str(path)]) == 2

    assert capsys.readouterr().err.startswith("설정 오류: ")
    assert created == []
    assert not (tmp_path / "data").exists()


def test_cli_login_writes_rotating_utc_log_and_detaches(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    terminal: Callable[..., list[str]],
    library_logger_state: tuple[bool, int, list[logging.Handler]],
):
    package_logger = logging.getLogger("garmin_pipeline")
    level_before = package_logger.level
    handlers_before = list(package_logger.handlers)
    seen: list[logging.Handler] = []

    def observe(name: str) -> None:
        if name == "login":
            seen.extend(
                h
                for h in package_logger.handlers
                if isinstance(h, logging.handlers.RotatingFileHandler)
            )
            logging.getLogger("garminconnect.client").warning("library-line-5e0d")
            logging.getLogger("garminconnect").error("library-line-77aa")

    login_stubs(observe=observe)
    terminal(EMAIL, GOOD_MFA_CODE)
    started = datetime.now(UTC)
    assert not cfg.data_dir.exists()

    assert cli.main(["login", "--config", str(cfg.path)]) == 0

    log_path = cfg.data_dir / "logs" / "login.log"
    assert _mode(cfg.data_dir) == 0o700
    assert _mode(log_path.parent) == 0o700
    (handler,) = seen
    assert handler.baseFilename == str(log_path)
    assert handler.maxBytes == 1024 * 1024
    assert handler.backupCount == 3
    assert handler.formatter is not None
    assert handler.formatter.converter is time.gmtime
    # 명령이 끝나면 처리기를 떼고 닫는다. 로거 상태도 되돌린다.
    assert package_logger.handlers == handlers_before
    assert package_logger.level == level_before
    assert handler.stream is None
    library = logging.getLogger("garminconnect")
    assert (library.propagate, library.level, library.handlers) == library_logger_state

    text = log_path.read_text(encoding="utf-8")
    lines = text.splitlines()
    assert lines
    for line in lines:
        match = LOG_LINE.match(line)
        assert match is not None, line
        stamp = datetime.fromisoformat(match[1]).replace(tzinfo=UTC)
        assert abs(stamp - started) < timedelta(minutes=5), line
    assert "mfa=True" in text
    assert "attempts=1" in text
    assert "stage=record" in text
    assert "library-line" not in text


def test_cli_login_failure_is_logged_with_error_name(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    terminal: Callable[..., list[str]],
    capsys: pytest.CaptureFixture[str],
    library_logger_state: tuple[bool, int, list[logging.Handler]],
):
    login_stubs(login_error=TooMany("429"))
    terminal(EMAIL)

    assert cli.main(["login", "--config", str(cfg.path)]) == 1

    _assert_failed(capsys, "HTTP 429")
    text = (cfg.data_dir / "logs" / "login.log").read_text(encoding="utf-8")
    assert "error=RateLimited" in text
    assert "status=429" in text


def test_cli_log_dir_failure_exits_1(
    make_cfg: Callable[..., config.Config],
    tmp_path: Path,
    login_stubs: Callable[..., list[StubLoginClient]],
    capsys: pytest.CaptureFixture[str],
):
    (tmp_path / "data").write_text("", encoding="utf-8")
    cfg = make_cfg()
    created = login_stubs()

    assert cli.main(["login", "--config", str(cfg.path)]) == 1

    assert capsys.readouterr().err.startswith("login 실패: 로그 파일")
    assert created == []


# --- 비밀번호 위생 ------------------------------------------------------------------------


def test_credentials_never_reach_files_logs_or_output(
    cfg: config.Config,
    tmp_path: Path,
    login_stubs: Callable[..., list[StubLoginClient]],
    terminal: Callable[..., list[str]],
    caplog: pytest.LogCaptureFixture,
    capsys: pytest.CaptureFixture[str],
    library_logger_state: tuple[bool, int, list[logging.Handler]],
):
    caplog.set_level(logging.DEBUG)
    wrong_code, good_code = "640118", "905532"
    secrets = (EMAIL, PASSWORD, wrong_code, good_code)

    def leak(name: str) -> None:
        # 라이브러리가 자기 로거에 비밀을 흘려도 명령 로그·caplog에 닿지 않는다.
        logging.getLogger("garminconnect.client").warning("%s %s", EMAIL, PASSWORD)

    # 1) 틀린 코드 뒤 성공.
    login_stubs(
        mfa_results={
            wrong_code: AuthError(f"MFA failed for {EMAIL}"),
            good_code: None,
        },
        observe=leak,
    )
    terminal(EMAIL, wrong_code, good_code)
    assert cli.main(["login", "--config", str(cfg.path)]) == 0

    # 2) 비밀을 담은 라이브러리 예외로 실패(429 → 당일 차단).
    login_stubs(
        login_error=ConnError(f"API Error 429 - {EMAIL}:{PASSWORD}"), observe=leak
    )
    terminal(EMAIL)
    assert cli.main(["login", "--config", str(cfg.path)]) == 1

    # 3) 같은 날 다시: 차단으로 프롬프트 없이 실패.
    terminal()
    assert cli.main(["login", "--config", str(cfg.path)]) == 1

    out, err = capsys.readouterr()
    log_text = (cfg.data_dir / "logs" / "login.log").read_text(encoding="utf-8")
    assert "Garmin" in log_text
    files = [path for path in tmp_path.rglob("*") if path.is_file()]
    assert any(path.name == TOKEN_FILENAME for path in files)
    assert any(path.name == "garmin.db" for path in files)
    for secret in secrets:
        encoded = secret.encode("utf-8")
        for path in files:
            assert encoded not in path.read_bytes(), (secret, path)
        assert secret not in log_text
        assert secret not in caplog.text
        assert secret not in out
        assert secret not in err
