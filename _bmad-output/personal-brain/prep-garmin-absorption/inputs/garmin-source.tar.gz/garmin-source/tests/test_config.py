"""`config.load`: 탐색 순서, 경로 규칙, 기본값, 검증, tokenstore 심링크, pytest 가드."""

import dataclasses
import os
import subprocess
import sys
import tomllib
from collections.abc import Callable
from datetime import time
from pathlib import Path

import pytest

from garmin_pipeline import config
from garmin_pipeline.config import Config, ConfigError

ROOT = Path(__file__).resolve().parents[1]

WriteConfig = Callable[..., Path]


@pytest.fixture(autouse=True)
def _no_config_env(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv(config.CONFIG_ENV, raising=False)


def _tree(root: Path) -> dict[str, tuple[int, int, int]]:
    """`root` 아래 모든 항목의 (모드, 크기, mtime). atime은 읽기만 해도 바뀌어 뺀다."""
    snapshot = {}
    for path in [root, *root.rglob("*")]:
        info = path.lstat()
        snapshot[str(path.relative_to(root))] = (
            info.st_mode,
            info.st_size,
            info.st_mtime_ns,
        )
    return snapshot


def _load_error(path: Path | str | None = None) -> ConfigError:
    with pytest.raises(ConfigError) as excinfo:
        config.load(path)
    return excinfo.value


# --- 탐색 ---------------------------------------------------------------------


def test_argument_beats_env_beats_cwd(
    tmp_path: Path, write_config: WriteConfig, monkeypatch: pytest.MonkeyPatch
):
    from_arg = write_config(data_dir="from-arg").rename(tmp_path / "arg.toml")
    from_env = write_config(data_dir="from-env").rename(tmp_path / "env.toml")
    write_config(data_dir="from-cwd")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv(config.CONFIG_ENV, str(from_env))

    assert config.load(from_arg).data_dir == tmp_path / "from-arg"
    assert config.load(str(from_arg)).data_dir == tmp_path / "from-arg"
    assert config.load().data_dir == tmp_path / "from-env"

    monkeypatch.delenv(config.CONFIG_ENV)
    assert config.load().data_dir == tmp_path / "from-cwd"


def test_empty_env_counts_as_unset(
    tmp_path: Path, write_config: WriteConfig, monkeypatch: pytest.MonkeyPatch
):
    path = write_config()
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv(config.CONFIG_ENV, "")

    assert config.load().path == path


def test_no_config_anywhere_names_the_tried_path(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.chdir(tmp_path)

    error = _load_error()

    assert error.key is None
    assert str(tmp_path / "config.toml") in str(error)


@pytest.mark.parametrize("source", ["argument", "env"])
def test_missing_chosen_file_does_not_fall_back(
    source: str,
    tmp_path: Path,
    write_config: WriteConfig,
    monkeypatch: pytest.MonkeyPatch,
):
    write_config()  # 현재 폴더에는 config가 있다.
    monkeypatch.chdir(tmp_path)
    missing = tmp_path / "missing.toml"
    if source == "env":
        monkeypatch.setenv(config.CONFIG_ENV, str(missing))

    error = _load_error(missing if source == "argument" else None)

    assert str(missing) in str(error)


@pytest.mark.parametrize(
    "content",
    [b"environment = \n", b'environment = "dev"\nenvironment = "dev"\n', b"\xff\xfe"],
    ids=["no-value", "duplicate-key", "not-utf8"],
)
def test_broken_file_is_config_error(tmp_path: Path, content: bytes):
    path = tmp_path / "config.toml"
    path.write_bytes(content)

    error = _load_error(path)

    assert error.key is None
    assert str(path) in str(error)


def test_unreadable_config_path_is_config_error(tmp_path: Path):
    folder = tmp_path / "config.toml"
    folder.mkdir()

    error = _load_error(folder)

    assert error.key is None
    assert str(folder) in str(error)


# --- 경로 ---------------------------------------------------------------------


def test_relative_paths(
    tmp_path: Path, write_config: WriteConfig, monkeypatch: pytest.MonkeyPatch
):
    folder = tmp_path / "x" / "c"
    folder.mkdir(parents=True)
    path = write_config(
        tokenstore="tok",
        data_dir="d",
        reports_dir="r/out",
        inbox_dir="../in",
    ).rename(folder / "config.toml")
    monkeypatch.chdir(tmp_path)

    # 상대 config 경로는 현재 폴더 기준, config 안의 상대경로는 config 폴더 기준이다.
    cfg = config.load("x/c/config.toml")

    assert cfg.path == path
    assert cfg.tokenstore == folder / "tok"
    assert cfg.data_dir == folder / "d"
    assert cfg.db_path == folder / "d" / "garmin.db"
    assert cfg.reports_dir == folder / "r" / "out"
    # 정규화하지 않는다.
    assert cfg.inbox_dir == folder / ".." / "in"
    assert ".." in cfg.inbox_dir.parts

    monkeypatch.setenv(config.CONFIG_ENV, "x/c/config.toml")
    assert config.load() == cfg


def test_absolute_paths_are_kept(tmp_path: Path, write_config: WriteConfig):
    elsewhere = tmp_path / "elsewhere"

    cfg = config.load(write_config(data_dir=str(elsewhere / "data")))

    assert cfg.data_dir == elsewhere / "data"


def test_load_does_not_touch_filesystem(tmp_path: Path, write_config: WriteConfig):
    path = write_config(
        tokenstore=str(tmp_path / "missing" / "tokens"),
        data_dir="missing/data",
        reports_dir="missing/reports",
        inbox_dir="missing/inbox",
    )
    before = _tree(tmp_path)

    cfg = config.load(path)

    assert _tree(tmp_path) == before
    for missing in (cfg.tokenstore, cfg.data_dir, cfg.reports_dir, cfg.inbox_dir):
        assert not missing.exists()


def test_paths_expand_user_without_resolving(
    tmp_path: Path, write_config: WriteConfig, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setenv("HOME", str(tmp_path / "home"))

    cfg = config.load(write_config(tokenstore="~/a/tokens", data_dir="~/x/../d"))

    assert cfg.tokenstore == Path.home() / "a" / "tokens"
    assert Path.home() == tmp_path / "home"
    assert cfg.data_dir == Path.home() / "x" / ".." / "d"


def test_config_path_expands_user(
    tmp_path: Path, write_config: WriteConfig, monkeypatch: pytest.MonkeyPatch
):
    path = write_config()
    monkeypatch.setenv("HOME", str(tmp_path))

    assert config.load("~/config.toml").path == path


# --- tokenstore ---------------------------------------------------------------


def _symlink_layout(tmp_path: Path, layout: str) -> str:
    real = tmp_path / "real"
    (real / "sub").mkdir(parents=True)
    link = tmp_path / "link"
    match layout:
        case "self":
            link.symlink_to(real)
            return str(link)
        case "parent":
            link.symlink_to(real)
            return str(link / "tokens")
        case "dotdot":
            # 정규화하면 tmp_path/tokens라 심링크가 없지만, 정규화 전 부모 link를 본다.
            link.symlink_to(real / "sub")
            return f"{link}/../tokens"
        case "dangling":
            link.symlink_to(tmp_path / "nowhere")
            return str(link)
    raise AssertionError(layout)


@pytest.mark.parametrize("layout", ["self", "parent", "dotdot", "dangling"])
def test_tokenstore_symlink_is_rejected(
    layout: str, tmp_path: Path, write_config: WriteConfig
):
    path = write_config(tokenstore=_symlink_layout(tmp_path, layout))

    error = _load_error(path)

    assert error.key == "tokenstore"
    assert "tokenstore" in str(error)


def test_uninspectable_tokenstore_parent_is_rejected(
    tmp_path: Path, write_config: WriteConfig
):
    if os.geteuid() == 0:
        pytest.skip("root는 권한과 관계없이 lstat할 수 있다")
    locked = tmp_path / "locked"
    (locked / "inner").mkdir(parents=True)
    path = write_config(tokenstore=str(locked / "inner" / "tokens"))
    locked.chmod(0)
    try:
        error = _load_error(path)
    finally:
        locked.chmod(0o700)

    assert error.key == "tokenstore"
    assert "tokenstore" in str(error)


def test_existing_real_tokenstore_is_accepted(
    tmp_path: Path, write_config: WriteConfig
):
    (tmp_path / "tokens").mkdir()

    assert config.load(write_config()).tokenstore == tmp_path / "tokens"


def test_garmintokens_env_is_ignored(
    tmp_path: Path, write_config: WriteConfig, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setenv("GARMINTOKENS", str(tmp_path / "from-env"))

    assert config.load(write_config()).tokenstore == tmp_path / "tokens"


def test_default_tokenstore_outside_pytest(
    tmp_path: Path, write_config: WriteConfig, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setattr(config, "under_pytest", lambda: False)
    monkeypatch.setenv("HOME", str(tmp_path / "home"))
    monkeypatch.setenv("GARMINTOKENS", str(tmp_path / "from-env"))

    cfg = config.load(write_config(tokenstore=None))

    assert cfg.tokenstore == tmp_path / "home" / ".garmin-pipeline" / "tokens"


# --- 키와 기본값 --------------------------------------------------------------


def test_omitted_keys_get_defaults(tmp_path: Path, write_config: WriteConfig):
    path = write_config()
    assert tomllib.loads(path.read_text(encoding="utf-8")).keys() == {
        "environment",
        "tokenstore",
    }

    cfg = config.load(path)

    assert cfg == Config(
        path=path,
        environment="dev",
        tokenstore=tmp_path / "tokens",
        data_dir=tmp_path / "data",
        reports_dir=tmp_path / "reports",
        inbox_dir=tmp_path / "inbox",
        timezone="Asia/Seoul",
        collect_time=time(11, 0),
        retry_time=time(11, 15),
        report_time=time(11, 30),
        report_wait_minutes=30,
        report_codex_timeout_minutes=20,
        report_model=None,
        report_reasoning_effort="high",
        profile_path=tmp_path / "profile.md",
        date_pause_seconds=5,
        call_pause_min_seconds=1,
        call_pause_max_seconds=2,
        max_dates_per_run=10,
        max_rejected_attempts=3,
        max_consecutive_403=3,
        lock_wait_seconds=60,
        cffi_api_session=False,
    )
    assert cfg.db_path == tmp_path / "data" / "garmin.db"


def test_every_key_is_read(tmp_path: Path, write_config: WriteConfig):
    path = write_config(
        tokenstore="t",
        data_dir="dd",
        reports_dir="rr",
        inbox_dir="ii",
        timezone="UTC",
        collect_time="06:05",
        retry_time="06:20",
        report_time="23:59",
        report_wait_minutes=0,
        report_codex_timeout_minutes=1,
        report_model="some-model",
        report_reasoning_effort="high",
        profile_path=tmp_path / "profile.md",
        date_pause_seconds=0.5,
        call_pause_min_seconds=0,
        call_pause_max_seconds=0,
        max_dates_per_run=3,
        max_rejected_attempts=7,
        max_consecutive_403=8,
        lock_wait_seconds=1.5,
        cffi_api_session=True,
    )

    assert config.load(path) == Config(
        path=path,
        environment="dev",
        tokenstore=tmp_path / "t",
        data_dir=tmp_path / "dd",
        reports_dir=tmp_path / "rr",
        inbox_dir=tmp_path / "ii",
        timezone="UTC",
        collect_time=time(6, 5),
        retry_time=time(6, 20),
        report_time=time(23, 59),
        report_wait_minutes=0,
        report_codex_timeout_minutes=1,
        report_model="some-model",
        report_reasoning_effort="high",
        profile_path=tmp_path / "profile.md",
        date_pause_seconds=0.5,
        call_pause_min_seconds=0,
        call_pause_max_seconds=0,
        max_dates_per_run=3,
        max_rejected_attempts=7,
        max_consecutive_403=8,
        lock_wait_seconds=1.5,
        cffi_api_session=True,
    )


def test_config_is_frozen(write_config: WriteConfig):
    cfg = config.load(write_config())

    with pytest.raises(dataclasses.FrozenInstanceError):
        cfg.data_dir = Path("/elsewhere")  # type: ignore[misc]


@pytest.mark.parametrize("key", ["date_pause_seconds", "lock_wait_seconds"])
@pytest.mark.parametrize("value", [0, 3, 2.5])
def test_seconds_accept_int_and_float(
    key: str, value: float, write_config: WriteConfig
):
    cfg = config.load(write_config(**{key: value}))

    assert getattr(cfg, key) == value


def test_environment_is_required(write_config: WriteConfig):
    error = _load_error(write_config(environment=None))

    assert error.key == "environment"
    assert "environment" in str(error)


@pytest.mark.parametrize(
    ("overrides", "key"),
    [
        pytest.param({"foo": 1}, "foo", id="top-level"),
        pytest.param({"extra": {"value": 1}}, "extra", id="table"),
    ],
)
def test_unknown_key_is_rejected(
    overrides: dict[str, object], key: str, write_config: WriteConfig
):
    error = _load_error(write_config(**overrides))

    assert error.key == key
    assert key in str(error)


@pytest.mark.parametrize(
    ("key", "value"),
    [
        ("max_dates_per_run", "10"),
        ("max_dates_per_run", True),
        ("max_dates_per_run", 10.0),
        ("report_wait_minutes", 1.5),
        ("cffi_api_session", 1),
        ("cffi_api_session", "true"),
        ("environment", 1),
        ("tokenstore", True),
        ("data_dir", 1),
        ("timezone", 9),
        ("timezone", {"name": "UTC"}),
        ("collect_time", 1100),
        ("collect_time", time(11, 0)),
        ("report_model", 4),
        ("date_pause_seconds", True),
        ("lock_wait_seconds", "60"),
    ],
)
def test_wrong_type_is_rejected(key: str, value: object, write_config: WriteConfig):
    error = _load_error(write_config(**{key: value}))

    assert error.key == key
    assert key in str(error)


@pytest.mark.parametrize(
    ("key", "value"),
    [
        ("environment", "prod"),
        ("environment", "Runtime"),
        ("max_dates_per_run", 0),
        ("max_dates_per_run", 2),
        ("max_rejected_attempts", 0),
        ("max_rejected_attempts", -1),
        ("max_consecutive_403", 0),
        ("report_codex_timeout_minutes", 0),
        ("report_wait_minutes", -1),
        ("lock_wait_seconds", -0.5),
        ("date_pause_seconds", -1),
        ("call_pause_min_seconds", -1),
        ("call_pause_max_seconds", -0.1),
        ("date_pause_seconds", float("nan")),
        ("lock_wait_seconds", float("inf")),
        ("collect_time", "11:0"),
        ("collect_time", "1100"),
        ("collect_time", " 11:00"),
        ("collect_time", "１１:００"),
        ("retry_time", "24:00"),
        ("report_time", "11:60"),
        ("report_time", "11:30:00"),
        ("timezone", "Mars/Olympus"),
        ("timezone", ""),
        ("timezone", "../etc/passwd"),
        ("data_dir", ""),
        ("data_dir", " "),
    ],
)
def test_invalid_value_is_rejected(key: str, value: object, write_config: WriteConfig):
    error = _load_error(write_config(**{key: value}))

    assert error.key == key
    assert key in str(error)


def test_call_pause_min_above_max_is_rejected(write_config: WriteConfig):
    error = _load_error(
        write_config(call_pause_min_seconds=3, call_pause_max_seconds=2.5)
    )

    assert error.key == "call_pause_min_seconds"
    assert "call_pause_max_seconds" in str(error)


# --- pytest 가드 --------------------------------------------------------------


def test_under_pytest_inside_pytest():
    assert config.under_pytest()


@pytest.mark.parametrize(
    ("env_set", "module_loaded", "expected"),
    [(True, False, True), (False, True, True), (False, False, False)],
)
def test_under_pytest_signals(
    env_set: bool,
    module_loaded: bool,
    expected: bool,
    monkeypatch: pytest.MonkeyPatch,
):
    if env_set:
        monkeypatch.setenv("PYTEST_CURRENT_TEST", "test_config.py::x (call)")
    else:
        monkeypatch.delenv("PYTEST_CURRENT_TEST", raising=False)
    if not module_loaded:
        monkeypatch.delitem(sys.modules, "pytest")

    result = config.under_pytest()
    monkeypatch.undo()

    assert result is expected


@pytest.mark.parametrize(
    ("overrides", "key"),
    [
        pytest.param({"environment": "runtime"}, "environment", id="runtime"),
        pytest.param({"tokenstore": None}, "tokenstore", id="default-tokenstore"),
    ],
)
def test_pytest_guard_rejects(
    overrides: dict[str, object], key: str, write_config: WriteConfig
):
    error = _load_error(write_config(**overrides))

    assert error.key == key
    assert "pytest" in str(error)


def test_runtime_config_is_allowed_outside_pytest(
    tmp_path: Path, write_config: WriteConfig, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setattr(config, "under_pytest", lambda: False)

    assert config.load(write_config(environment="runtime")).environment == "runtime"


# --- 저장소 루트의 개발용 config.toml ------------------------------------------


def test_repo_config_is_dev_with_default_paths_and_no_tokenstore():
    values = tomllib.loads((ROOT / "config.toml").read_text(encoding="utf-8"))

    assert values == {
        "environment": "dev",
        "data_dir": "data",
        "reports_dir": "reports",
        "inbox_dir": "inbox",
        "report_reasoning_effort": "high",
        "profile_path": "profile.md",
    }


def test_repo_config_loads_outside_pytest(tmp_path: Path):
    probe = (
        "from garmin_pipeline import config\n"
        "cfg = config.load()\n"
        "print(cfg.environment)\n"
        "print(cfg.data_dir)\n"
        "print(cfg.tokenstore)\n"
    )
    unset = {"PYTEST_CURRENT_TEST", config.CONFIG_ENV, "FORCE_COLOR"}
    env = {key: value for key, value in os.environ.items() if key not in unset}
    # 실제 홈 대신 tmp_path를 홈으로 써서 기본 tokenstore 검사를 격리한다.
    env |= {"HOME": str(tmp_path), "NO_COLOR": "1", "PYTHON_COLORS": "0"}

    result = subprocess.run(
        [sys.executable, "-c", probe],
        cwd=ROOT,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.splitlines() == [
        "dev",
        str(ROOT / "data"),
        str(tmp_path / ".garmin-pipeline" / "tokens"),
    ]


def test_repo_config_is_rejected_inside_pytest():
    error = _load_error(ROOT / "config.toml")

    assert error.key == "tokenstore"
