"""`errors`: 닫힌 상태 어휘와 도메인 오류 계층이 아키텍처 spine과 정확히 같다."""

import inspect
from enum import StrEnum

import pytest

from garmin_pipeline import errors

VOCABULARY = {
    "RunStatus": {
        "running",
        "success",
        "partial",
        "rate_limited",
        "blocked_403",
        "auth_failed",
        "error",
        "skipped_blocked",
    },
    "NotifyEvent": {
        "auth_failed",
        "rate_limited",
        "blocked_403",
        "normalize_failed",
        "repeated_partial",
        "error",
        "report_failed",
    },
    "DeliveryKind": {"notify", "report_text", "report_album", "report_document"},
    "DeliveryReason": {
        "network",
        "rate_limited",
        "http_4xx",
        "http_5xx",
        "invalid_config",
        "too_large",
    },
    "AuthFailedReason": {"token_invalid", "privacy_protected"},
    "RunDetail": {
        "transient",
        "rejected",
        "timezone_mismatch",
        "lock_timeout",
        "session_lock_timeout",
        "login_transient",
        "block_file_invalid",
        "abandoned",
        "manual",
    },
    "ReportFailReason": {
        "codex_timeout",
        "codex_failed",
        "output_invalid",
        "skill_failed",
        "write_failed",
    },
}

DOMAIN_ERRORS = {
    "RateLimited",
    "Blocked403",
    "Transient",
    "AuthFailed",
    "Rejected",
    "NoData",
}


def test_module_defines_exactly_the_vocabulary_enums():
    defined = {
        name
        for name, value in vars(errors).items()
        if inspect.isclass(value)
        and issubclass(value, StrEnum)
        and value is not StrEnum
    }

    assert defined == set(VOCABULARY)


@pytest.mark.parametrize("name", sorted(VOCABULARY))
def test_vocabulary_values(name: str):
    vocabulary = getattr(errors, name)

    assert {member.value for member in vocabulary} == VOCABULARY[name]
    # StrEnum이라 저장·비교할 때 값 문자열 그대로 쓴다.
    assert all(member == member.value == str(member) for member in vocabulary)


def test_domain_error_direct_subclasses():
    assert issubclass(errors.DomainError, Exception)
    assert {
        cls.__name__ for cls in errors.DomainError.__subclasses__()
    } == DOMAIN_ERRORS


@pytest.mark.parametrize("reason", sorted(VOCABULARY["AuthFailedReason"]))
def test_auth_failed_keeps_reason(reason: str):
    error = errors.AuthFailed(reason)

    assert error.reason is errors.AuthFailedReason(reason)
    assert str(error) == reason
    assert isinstance(error, errors.DomainError)


def test_auth_failed_accepts_enum_member():
    reason = errors.AuthFailedReason.PRIVACY_PROTECTED

    assert errors.AuthFailed(reason).reason is reason


def test_auth_failed_rejects_unknown_reason():
    with pytest.raises(ValueError):
        errors.AuthFailed("wrong_password")
