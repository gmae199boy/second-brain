"""시험이 기대하는 최신 스키마 버전.

마이그레이션 폴더에서 읽으므로 마이그레이션을 더해도 이 값을 쓰는 시험은 고치지 않는다. 마이그레이션
목록과 번호 자체는 `test_store`가 고정한다.
"""

from garmin_pipeline import store

LATEST = store._latest(store._load_migrations())
