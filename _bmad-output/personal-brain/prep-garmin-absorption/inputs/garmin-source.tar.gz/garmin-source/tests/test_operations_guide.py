"""README `## 운영 안내서`와 상태 확인 SQL(4.8, NFR1·7·11), 개발 환경 세트 fixture 확보 절차(5.3).

14일 무인 운영 자체는 배포 뒤 사람이 안내서의 "14일 운영 점검"으로 확인한다. 여기서는 안내서가 있고 순서와
명령 이름이 실제 CLI와 맞는지, 안내서에 그대로 적은 SQL 세 개가 현재 스키마의 합성 DB에서 기대한 행을 내는지만
고정한다. DB는 `store.write_session`(마이그레이션)으로 tmp에 만들고 `store.read_connection`으로 읽는다.

5.3 절차의 실제 실행(Garmin 호출, 운영 DB 복사, 앱 대조)은 사람이 한다. 여기서는 안내서에 적은 명령과 SQL을
tmp 저장소에서 그대로 돌려 락 확인·백업 복사·세트 확인 SQL이 적은 대로 동작하는지만 본다.
"""

import fcntl
import functools
import json
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import sysconfig
from collections.abc import Callable, Sequence
from datetime import date, timedelta
from pathlib import Path

import pytest

from garmin_pipeline import config, store

ROOT = Path(__file__).resolve().parents[1]
README = ROOT / "README.md"
SCRIPTS = sysconfig.get_path("scripts")
SECTION = "운영 안내서"
SUBSECTIONS = [
    "최초 설정",
    "매일 무엇이 도는가",
    "Telegram 알림 설정",
    "`auth_failed` 알림이 왔을 때",
    "차단(`rate_limited`·`blocked_403`)",
    "의존성 업그레이드",
    "인바디 입력",
    "상태 확인",
    "14일 운영 점검",
    "개발 환경 세트 fixture 확보",
    "재확인 일정",
    "비밀",
]

# README `## 운영 안내서` "상태 확인"에 그대로 적는 SQL이다(이 상수가 원본).
DAILY_SQL = """-- 일별 요약(최근 14일): 실행 순서와 그날 알림
SELECT r.local_date AS day,
       group_concat(r.status || iif(r.detail = '', '', ' ' || r.detail), ' → ' ORDER BY r.started_at, r.id) AS runs,
       (SELECT group_concat(n.event || iif(n.detail = '', '', ' ' || n.detail), ', ' ORDER BY n.at)
          FROM notification n WHERE n.local_date = r.local_date) AS notifications
FROM run r
GROUP BY r.local_date
ORDER BY r.local_date DESC
LIMIT 14;"""

NOTIFICATIONS_SQL = """-- 최근 알림
SELECT local_date, event, detail FROM notification ORDER BY at DESC LIMIT 20;"""

TOKEN_LIFETIME_SQL = """-- 토큰 수명: 로그인마다 다음 로그인 전 첫 token_invalid 실패까지의 일수(NULL이면 다음 로그인 전까지, 또는 지금까지 token_invalid 실패 없음)
WITH a AS (
  SELECT id, local_date, logged_in_at,
         LEAD(logged_in_at) OVER (ORDER BY logged_in_at, id) AS next_at
  FROM auth_event)
SELECT a.local_date AS logged_in,
       min(r.local_date) AS token_failed,
       CAST(julianday(min(r.local_date)) - julianday(a.local_date) AS INTEGER) AS lifetime_days
FROM a LEFT JOIN run r
  ON r.status = 'auth_failed' AND r.detail LIKE 'token_invalid%'
 AND r.started_at > a.logged_in_at
 AND (a.next_at IS NULL OR r.started_at < a.next_at)
GROUP BY a.id
ORDER BY a.logged_in_at;"""

ALL_SQL = (DAILY_SQL, NOTIFICATIONS_SQL, TOKEN_LIFETIME_SQL)

# README "상태 확인"에 그대로 적는 실행 명령이다. `<SQL>` 자리에 위 SQL 하나를 붙인다.
STATUS_RUNNER = """runtime/.venv/bin/python -I -c '
import sqlite3, sys
db = sqlite3.connect("file:runtime/data/garmin.db?mode=ro", uri=True)
for row in db.execute(sys.stdin.read()):
    print(*("" if v is None else v for v in row), sep="|")
' <<'SQL'
<SQL>
SQL"""

# --- 개발 환경 세트 fixture 확보(5.3) -------------------------------------------------------------
# README `### 개발 환경 세트 fixture 확보`에 그대로 적는 명령과 SQL이다(이 상수가 원본).
FIXTURE_SECTION = "개발 환경 세트 fixture 확보"

LOCK_CHECK = """ls runtime/reports/"$(date +%F)".md
runtime/.venv/bin/python -I -c '
from garmin_pipeline import config, store
print(store.write_lock_held(config.load("runtime/config.toml")))
'"""

RUN_COUNT_SQL = "SELECT count(*) FROM run;"

DEV_MOVE = """mkdir data/before-5-3 && for f in garmin.db garmin.db-wal garmin.db-shm; do
  if [ -e "data/$f" ]; then mv -n "data/$f" data/before-5-3/; fi
done"""

DB_BACKUP = """runtime/.venv/bin/python -I -c '
import os, sqlite3, sys
if any(os.path.lexists("data/garmin.db" + s) for s in ("", "-wal", "-shm")):
    sys.exit("data/garmin.db가 이미 있다. 쓰지 않는다(2단계를 먼저 한다)")
src = sqlite3.connect("file:runtime/data/garmin.db?mode=ro", uri=True)
os.close(os.open("data/garmin.db", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600))
dst = sqlite3.connect("data/garmin.db")
src.backup(dst)
dst.close()
src.close()
'"""

DEV_COLLECT = "uv run garmin-pipeline collect --config config.toml --force"

# 개발 DB(`data/garmin.db`)를 읽는 실행 명령. 모양은 "상태 확인"의 `STATUS_RUNNER`와 같다.
DEV_RUNNER = """.venv/bin/python -I -c '
import sqlite3, sys
db = sqlite3.connect("file:data/garmin.db?mode=ro", uri=True)
for row in db.execute(sys.stdin.read()):
    print(*("" if v is None else v for v in row), sep="|")
' <<'SQL'
<SQL>
SQL"""

# 근력 판정은 형식이 맞는 목록에서는 `rawparse._needs_sets`와 같다(`totalSets > 0`이거나 `summarizedExerciseSets`가 비어 있지 않음).
SETS_SQL = """-- 근력 활동의 세트 원문: sets = data·null(NoData)·빈 칸(아직 안 받음), errors = 세트 호출 실패 종류
WITH a AS (
  SELECT substr(j.value ->> '$.startTimeLocal', 1, 10) AS day,
         CAST(j.value ->> '$.activityId' AS TEXT) AS activity_id,
         r.key AS list_key, j.key AS pos
  FROM raw_response r, json_each(r.raw) j
  WHERE r.scope = 'day' AND r.endpoint = 'activities_by_date'
    AND json_type(r.raw) = 'array' AND j.type = 'object'
    AND (coalesce(j.value ->> '$.totalSets', 0) > 0
         OR coalesce(json_array_length(j.value -> '$.summarizedExerciseSets'), 0) > 0))
SELECT a.day, a.activity_id,
       (SELECT iif(s.raw = 'null', 'null', 'data') FROM raw_response s
         WHERE s.scope = 'activity' AND s.endpoint = 'activity_exercise_sets'
           AND s.key = a.activity_id) AS sets,
       (SELECT group_concat(kind, ',') FROM (
          SELECT DISTINCT e.kind FROM fetch_error e
           WHERE e.scope = 'activity' AND e.endpoint = 'activity_exercise_sets'
             AND e.key = a.activity_id
           ORDER BY e.kind)) AS errors
FROM a
ORDER BY a.day DESC, a.list_key DESC, a.pos;"""

CAPTURE = """uv run garmin-pipeline capture-fixtures --config config.toml
uv run garmin-pipeline capture-fixtures --config config.toml --activity-id <id> --activity-id <id>"""

FIXTURE_SH = (
    LOCK_CHECK,
    DEV_MOVE,
    DB_BACKUP,
    DEV_RUNNER,
    CAPTURE,
    "git status --porcelain",
)
FIXTURE_SQL = (RUN_COUNT_SQL, SETS_SQL)

REQUIRED = (
    "login --config runtime/config.toml",
    "scripts/deploy.sh",
    "report_model",
    "auth_failed",
    "token_invalid",
    "privacy_protected",
    "block.json",
    "uv lock --upgrade-package garminconnect",
    "smoke",
    "inbox/inbody/",
    "processed/",
    "unreadable/",
    "2026-11-15",
    "~/.codex/auth.json",
    "codex login status",
)

DAY_MS = 86_400_000
BASE = date(2026, 3, 1)
BASE_MS = 1_772_323_200_000  # 2026-03-01T00:00:00Z


# --- README -------------------------------------------------------------------------------------


@functools.cache
def _readme() -> str:
    return README.read_text(encoding="utf-8")


def _sections(text: str, level: int) -> list[tuple[str, str]]:
    """`level`단계 제목과 그 아래 본문(다음 같은 단계 이상 제목 전까지)을 문서 순서로. 코드 블록 안은 제목이 아니다."""
    sections: list[tuple[str, list[str]]] = []
    current: list[str] | None = None
    fenced = False
    for line in text.split("\n"):
        if line.lstrip().startswith("```"):
            fenced = not fenced
        match = None if fenced else re.match(r"^(#{1,6}) (.+)$", line)
        if match:
            current = None
            if len(match.group(1)) == level:
                sections.append((match.group(2), current := []))
            elif len(match.group(1)) > level and sections:
                current = sections[-1][1]
                current.append(line)
            continue
        if current is not None:
            current.append(line)
    return [(heading, "\n".join(lines)) for heading, lines in sections]


def _guide() -> str:
    sections = dict(_sections(_readme(), 2))
    assert SECTION in sections, f"README에 `## {SECTION}`이 없다"
    return sections[SECTION]


def _subsection(heading: str) -> str:
    sections = dict(_sections(_guide(), 3))
    assert heading in sections, f"`## {SECTION}`에 `### {heading}`이 없다"
    return sections[heading]


@functools.cache
def _help(*args: str) -> subprocess.CompletedProcess[str]:
    script = shutil.which("garmin-pipeline", path=SCRIPTS)
    assert script is not None, (
        f"콘솔 스크립트가 {SCRIPTS}에 없다. `uv sync`를 먼저 실행한다."
    )
    # 도움말 문자열을 비교하므로 argparse(3.14+)의 색 출력을 끈다.
    env = {key: value for key, value in os.environ.items() if key != "FORCE_COLOR"}
    env |= {"NO_COLOR": "1", "PYTHON_COLORS": "0"}
    return subprocess.run(
        [script, *args, "--help"], env=env, capture_output=True, text=True, check=False
    )


def _listed_commands(help_text: str) -> set[str]:
    """argparse 도움말의 하위 명령 목록(`positional arguments` 아래 네 칸 들여쓴 이름)."""
    return set(re.findall(r"^ {4}([a-z][a-z-]*)(?: |$)", help_text, flags=re.MULTILINE))


def test_guide_sits_between_report_and_dependency_contract():
    headings = [heading for heading, _ in _sections(_readme(), 2)]

    assert headings.count(SECTION) == 1
    index = headings.index(SECTION)
    assert headings[index - 1] == "report"
    assert headings[index + 1] == "의존 방향 계약"


def test_guide_subsections_are_in_order():
    assert [heading for heading, _ in _sections(_guide(), 3)] == SUBSECTIONS


@pytest.mark.parametrize("text", REQUIRED)
def test_guide_mentions_required_text(text: str):
    assert text in _guide()


def test_upgrade_steps_are_ordered():
    upgrade = _subsection("의존성 업그레이드")
    positions = [
        upgrade.find(text)
        for text in (
            "uv lock --upgrade-package garminconnect",
            "uv run garmin-pipeline smoke",
            "uv run pytest",
            "scripts/deploy.sh",
        )
    ]

    assert -1 not in positions
    assert positions == sorted(positions)
    assert upgrade.find("uv lock --upgrade-package garminconnect") < upgrade.find(
        "smoke"
    )


def test_guide_runs_sql_readonly_from_stdin():
    # macOS `/usr/bin/sqlite3 -readonly`는 `-wal`·`-shm`이 없는 WAL DB를 열지 못한다. 운영 venv의 Python으로
    # `mode=ro` 연결을 열고 SQL은 표준 입력으로 넘긴다.
    assert f"```sh\n{STATUS_RUNNER}\n```" in _subsection("상태 확인")


@pytest.mark.parametrize("sql", ALL_SQL, ids=["daily", "notifications", "token"])
def test_guide_documents_sql_verbatim(sql: str):
    assert f"```sql\n{sql}\n```" in _subsection("상태 확인")


def test_guide_commands_exist_in_cli_help():
    commands = _listed_commands(_help().stdout)
    assert "login" in commands, "도움말에서 명령 목록을 읽지 못했다"
    mentioned = set(re.findall(r"garmin-pipeline(?![\w-]) +([a-z][a-z-]*)", _guide()))

    assert {"login", "smoke"} <= mentioned
    assert mentioned <= commands


def test_deploy_section_points_to_guide():
    deploy = dict(_sections(_readme(), 2))["배포와 예약"]

    assert "운영 안내서(4.8)" not in deploy
    assert f'"{SECTION}"' in deploy


# --- 상태 확인 SQL -------------------------------------------------------------------------------


@pytest.fixture
def cfg(write_config: Callable[..., Path]) -> config.Config:
    return config.load(write_config())


def _day(offset: int) -> str:
    return (BASE + timedelta(days=offset)).isoformat()


def _at(offset: int, hour: float = 2.0) -> int:
    """`BASE + offset`일의 UTC `hour`시(epoch ms). 11:00 KST는 02:00 UTC다."""
    return BASE_MS + offset * DAY_MS + int(hour * 3_600_000)


def _put(
    cfg: config.Config,
    *,
    runs: Sequence[tuple[str, int, str, str]] = (),
    notifications: Sequence[tuple[str, str, str, int]] = (),
    logins: Sequence[tuple[str, int]] = (),
) -> None:
    """`run(local_date, started_at, status, detail)`·`notification(local_date, event, detail, at)`·
    `auth_event(local_date, logged_in_at)` 행을 넣는다(마이그레이션은 `write_session`이 한다)."""
    with store.write_session(cfg) as conn:
        conn.executemany(
            "INSERT INTO run (local_date, started_at, finished_at, status, detail)"
            " VALUES (?, ?, ? + 60000, ?, ?)",
            [
                (day, started, started, status, detail)
                for day, started, status, detail in runs
            ],
        )
        conn.executemany(
            "INSERT INTO notification (local_date, event, detail, at) VALUES (?, ?, ?, ?)",
            notifications,
        )
        conn.executemany(
            "INSERT INTO auth_event (local_date, logged_in_at) VALUES (?, ?)", logins
        )


def _query(cfg: config.Config, sql: str) -> list[tuple[object, ...]]:
    conn = store.read_connection(cfg)
    try:
        return conn.execute(sql).fetchall()
    finally:
        conn.close()


def test_daily_summary_lists_runs_in_order_with_notifications(cfg: config.Config):
    a, b = _day(0), _day(1)
    # 같은 날 실행은 시각 순으로 잇는다(넣는 순서와 상관없이).
    _put(
        cfg,
        runs=[
            (b, _at(1, 2.25), "success", ""),
            (a, _at(0), "success", ""),
            (b, _at(1), "error", "login_transient"),
        ],
        notifications=[(b, "error", "login_transient", _at(1, 2.1))],
    )

    assert _query(cfg, DAILY_SQL) == [
        (b, "error login_transient → success", "error login_transient"),
        (a, "success", None),
    ]


def test_daily_summary_keeps_latest_fourteen_days(cfg: config.Config):
    _put(cfg, runs=[(_day(i), _at(i), "success", "") for i in range(20)])

    rows = _query(cfg, DAILY_SQL)

    assert [row[0] for row in rows] == [_day(i) for i in range(19, 5, -1)]


def test_notifications_are_listed_newest_first(cfg: config.Config):
    _put(
        cfg,
        notifications=[
            (_day(0), "rate_limited", "", _at(0)),
            (_day(2), "report_failed", "codex_timeout", _at(2, 2.5)),
            (_day(1), "auth_failed", "token_invalid", _at(1)),
        ],
    )

    assert _query(cfg, NOTIFICATIONS_SQL) == [
        (_day(2), "report_failed", "codex_timeout"),
        (_day(1), "auth_failed", "token_invalid"),
        (_day(0), "rate_limited", ""),
    ]


def test_token_lifetime_counts_days_to_first_token_invalid(cfg: config.Config):
    _put(
        cfg,
        logins=[(_day(0), _at(0, 12)), (_day(42), _at(42, 12))],
        runs=[
            (_day(40), _at(40), "auth_failed", "token_invalid"),
            (_day(41), _at(41), "auth_failed", "token_invalid timezone_mismatch"),
            # 비공개 계정은 토큰 수명과 무관하다.
            (_day(50), _at(50), "auth_failed", "privacy_protected"),
            (_day(51), _at(51), "success", ""),
        ],
    )

    assert _query(cfg, TOKEN_LIFETIME_SQL) == [
        (_day(0), _day(40), 40),
        (_day(42), None, None),
    ]


def test_token_lifetime_assigns_failures_to_the_preceding_login(cfg: config.Config):
    _put(
        cfg,
        logins=[(_day(0), _at(0, 12)), (_day(10), _at(10, 12))],
        # 같은 날 로그인 전 실패는 이전 로그인 몫, 로그인 뒤 실패는 다음 로그인 몫이다.
        runs=[
            (_day(10), _at(10), "auth_failed", "token_invalid"),
            (_day(30), _at(30), "auth_failed", "token_invalid"),
        ],
    )

    assert _query(cfg, TOKEN_LIFETIME_SQL) == [
        (_day(0), _day(10), 10),
        (_day(10), _day(30), 20),
    ]


def test_token_lifetime_ignores_failures_after_the_next_login(cfg: config.Config):
    _put(
        cfg,
        logins=[(_day(0), _at(0, 12)), (_day(5), _at(5, 12))],
        runs=[(_day(20), _at(20), "auth_failed", "token_invalid")],
    )

    assert _query(cfg, TOKEN_LIFETIME_SQL) == [
        (_day(0), None, None),
        (_day(5), _day(20), 15),
    ]


@pytest.mark.parametrize("sql", ALL_SQL, ids=["daily", "notifications", "token"])
def test_guide_runner_reads_db_without_wal_sidecars(
    cfg: config.Config, tmp_path: Path, sql: str
):
    # 운영 DB는 파이프라인이 닫을 때 `-wal`·`-shm`을 지운 모양이다. `write_session`이 마지막으로 닫혀 본 파일에
    # 모든 행이 있으므로 본 파일만 복사해 같은 모양을 만든다(`_query`의 읽기 연결이 남긴 사이드카는 따라오지 않는다).
    _put(
        cfg,
        runs=[(_day(0), _at(0), "auth_failed", "token_invalid")],
        notifications=[(_day(0), "auth_failed", "token_invalid", _at(0))],
        logins=[(_day(-30), _at(-30))],
    )
    expected = _query(cfg, sql)
    root = tmp_path / "repo"
    (root / "runtime/data").mkdir(parents=True)
    shutil.copyfile(cfg.db_path, root / "runtime/data/garmin.db")
    command = STATUS_RUNNER.replace("runtime/.venv/bin/python", sys.executable, 1)

    result = subprocess.run(
        ["/bin/sh", "-c", command.replace("<SQL>", sql)],
        cwd=root,
        capture_output=True,
        text=True,
        check=False,
    )

    assert (result.returncode, result.stderr) == (0, "")
    assert result.stdout.splitlines() == [
        "|".join("" if v is None else str(v) for v in row) for row in expected
    ]
    assert len(expected) == 1


# --- 개발 환경 세트 fixture 확보(5.3) -------------------------------------------------------------


def test_fixture_section_points_from_capture_fixtures():
    capture = dict(_sections(_readme(), 2))["capture-fixtures"]

    assert f'"{SECTION}"의 "{FIXTURE_SECTION}"' in capture


@pytest.mark.parametrize("command", FIXTURE_SH)
def test_fixture_section_documents_commands_verbatim(command: str):
    assert f"```sh\n{command}\n```" in _subsection(FIXTURE_SECTION)


@pytest.mark.parametrize("sql", FIXTURE_SQL, ids=["run_count", "sets"])
def test_fixture_section_documents_sql_verbatim(sql: str):
    assert f"```sql\n{sql}\n```" in _subsection(FIXTURE_SECTION)


def test_fixture_steps_are_ordered():
    # epics 5.3: 시작 조건 → 개발 DB 옮김 → 운영 DB 백업 → `collect --force` 두 번(사이에 세트 확인) → capture →
    # 운영 확인 → 앱 대조 기록.
    text = _subsection(FIXTURE_SECTION)
    collect = f"```sh\n{DEV_COLLECT}\n```"
    first = text.find(collect)
    second = text.find(collect, first + 1)
    positions = [
        text.find(LOCK_CHECK),
        text.find(RUN_COUNT_SQL),
        text.find(DEV_MOVE),
        text.find(DB_BACKUP),
        first,
        text.find(SETS_SQL),
        second,
        text.find(CAPTURE),
        text.find("git status --porcelain"),
        text.find("## 사람 확인 기록"),
        text.find("bmad-correct-course"),
    ]

    assert -1 not in positions
    assert positions == sorted(positions)
    assert text.count(collect) == 2


@pytest.mark.parametrize(
    "text",
    ("mode=ro", "Connection.backup", "block.json", "11:30", "FR64", "5.4", "5.10"),
)
def test_fixture_section_mentions_required_text(text: str):
    assert text in _subsection(FIXTURE_SECTION)


def _doc_command(command: str, python: str) -> str:
    """안내서 명령의 Python 경로(`runtime/.venv/bin/python`·`.venv/bin/python`)를 이 시험의 Python으로 바꾼다."""
    assert command.count(python) == 1
    return command.replace(python, sys.executable)


def _run_sh(
    command: str, cwd: Path, env: dict[str, str] | None = None
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["/bin/sh", "-c", command],
        cwd=cwd,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )


def _dump(path: Path) -> tuple[int, list[str]]:
    conn = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True)
    try:
        return conn.execute("PRAGMA user_version").fetchone()[0], list(conn.iterdump())
    finally:
        conn.close()


@pytest.fixture
def repo(cfg: config.Config, tmp_path: Path) -> Path:
    """`runtime/data/garmin.db`(마이그레이션한 합성 DB, 사이드카 없음)와 빈 `data/`가 있는 tmp 저장소."""
    _put(
        cfg,
        runs=[(_day(0), _at(0), "success", ""), (_day(1), _at(1), "partial", "")],
        notifications=[(_day(1), "repeated_partial", "transient=1", _at(1))],
        logins=[(_day(0), _at(0, 12))],
    )
    root = tmp_path / "repo"
    (root / "runtime/data").mkdir(parents=True)
    (root / "data").mkdir()
    shutil.copyfile(cfg.db_path, root / "runtime/data/garmin.db")
    return root


def test_backup_copies_runtime_db_readonly(repo: Path):
    source = repo / "runtime/data/garmin.db"
    before = source.read_bytes()

    result = _run_sh(_doc_command(DB_BACKUP, "runtime/.venv/bin/python"), repo)

    assert (result.returncode, result.stderr) == (0, "")
    assert source.read_bytes() == before
    # 읽기 전용 연결도 빈 `-wal`·`-shm`을 남길 수 있다("상태 확인"과 같다). `-wal`에 쓴 것은 없다.
    wal = source.with_name("garmin.db-wal")
    assert not wal.exists() or wal.stat().st_size == 0
    copied = _dump(repo / "data/garmin.db")
    assert copied == _dump(source)
    assert copied[0] > 0
    assert any(line.startswith('INSERT INTO "run"') for line in copied[1])


@pytest.mark.parametrize("name", ["garmin.db", "garmin.db-wal", "garmin.db-shm"])
def test_backup_refuses_existing_target(repo: Path, name: str):
    target = repo / "data" / name
    target.write_bytes(b"existing dev db")

    result = _run_sh(_doc_command(DB_BACKUP, "runtime/.venv/bin/python"), repo)

    assert result.returncode != 0
    assert result.stderr.splitlines() == [
        "data/garmin.db가 이미 있다. 쓰지 않는다(2단계를 먼저 한다)"
    ]
    assert target.read_bytes() == b"existing dev db"
    assert sorted(p.name for p in (repo / "data").iterdir()) == [name]


def test_dev_move_keeps_previous_db_aside(tmp_path: Path):
    data = tmp_path / "data"
    data.mkdir()
    for name in ("garmin.db", "garmin.db-wal"):
        (data / name).write_text(name, encoding="utf-8")

    first = _run_sh(DEV_MOVE, tmp_path)
    (data / "garmin.db").write_text("new", encoding="utf-8")
    second = _run_sh(DEV_MOVE, tmp_path)

    assert first.returncode == 0
    assert sorted(p.name for p in data.iterdir()) == ["before-5-3", "garmin.db"]
    assert {
        p.name: p.read_text(encoding="utf-8") for p in (data / "before-5-3").iterdir()
    } == {
        "garmin.db": "garmin.db",
        "garmin.db-wal": "garmin.db-wal",
    }
    # 폴더가 이미 있으면 아무것도 옮기지 않는다(이전 백업을 덮지 않는다).
    assert second.returncode != 0
    assert (data / "garmin.db").read_text(encoding="utf-8") == "new"


@pytest.mark.parametrize("held", [True, False])
def test_lock_check_reports_runtime_write_lock(tmp_path: Path, held: bool):
    root = tmp_path / "repo"
    (root / "runtime/data").mkdir(parents=True)
    (root / "runtime/reports").mkdir()
    (root / "runtime/config.toml").write_text(
        f'environment = "runtime"\ntokenstore = "{tmp_path / "tokens"}"\n',
        encoding="utf-8",
    )
    today = subprocess.run(
        ["date", "+%F"], capture_output=True, text=True, check=True
    ).stdout.strip()
    report = f"runtime/reports/{today}.md"
    (root / report).write_text("", encoding="utf-8")
    # pytest 안에서는 runtime config를 거부하므로 하위 프로세스에서는 pytest 표시를 뺀다.
    env = {k: v for k, v in os.environ.items() if k != "PYTEST_CURRENT_TEST"}
    fd = os.open(root / "runtime/data/.write.lock", os.O_RDWR | os.O_CREAT, 0o600)
    try:
        if held:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        result = _run_sh(
            _doc_command(LOCK_CHECK, "runtime/.venv/bin/python"), root, env
        )
    finally:
        os.close(fd)

    assert (result.returncode, result.stderr) == (0, "")
    assert result.stdout.splitlines() == [report, str(held)]


def _activity(activity_id: int, day: int, **fields: object) -> dict[str, object]:
    return {
        "activityId": activity_id,
        "startTimeLocal": f"{_day(day)} 07:00:00",
        **fields,
    }


def test_sets_sql_lists_strength_activities_with_set_state(
    cfg: config.Config, repo: Path
):
    lists = {
        _day(1): [
            _activity(11, 1, totalSets=4),  # 근력, 세트 data
            _activity(12, 1, totalSets=0, summarizedExerciseSets=[]),  # 비근력
            _activity(
                13, 1, summarizedExerciseSets=[{"category": "CURL"}]
            ),  # 근력, null
            _activity(14, 1, totalSets=None, summarizedExerciseSets=None),  # 비근력
            _activity(15, 1),  # 비근력(키 없음)
        ],
        _day(0): [
            _activity(
                21, 0, totalSets=3, summarizedExerciseSets=[{}]
            ),  # 근력, rejected
            _activity(22, 0, totalSets=2),  # 근력, 아직 안 받음
        ],
    }
    raws = [
        ("day", day, "activities_by_date", json.dumps(items))
        for day, items in lists.items()
    ]
    raws += [
        ("day", _day(2), "activities_by_date", "null"),
        ("activity", "11", "activity_exercise_sets", '{"exerciseSets": []}'),
        ("activity", "13", "activity_exercise_sets", "null"),
        ("activity", "12", "activity_details", "{}"),
    ]
    errors = [
        ("21", "activity_exercise_sets", "rejected"),
        ("21", "activity_exercise_sets", "rejected"),
        ("11", "activity_details", "transient"),
    ]
    with store.write_session(cfg) as conn:
        conn.executemany(
            "INSERT INTO raw_response VALUES (?, ?, ?, ?, 0, 0, 'test')", raws
        )
        run_id = conn.execute(
            "INSERT INTO run (local_date, started_at, finished_at, status, detail)"
            " VALUES (?, 0, 1, 'partial', 'rejected=2') RETURNING id",
            (_day(2),),
        ).fetchone()[0]
        conn.executemany(
            "INSERT INTO fetch_error (run_id, scope, key, endpoint, kind, local_date,"
            " occurred_at, error_code) VALUES (?, 'activity', ?, ?, ?, ?, 0, ?)",
            [
                (run_id, key, endpoint, kind, _day(2), kind)
                for key, endpoint, kind in errors
            ],
        )
    shutil.copyfile(cfg.db_path, repo / "data/garmin.db")
    command = _doc_command(DEV_RUNNER, ".venv/bin/python").replace("<SQL>", SETS_SQL)

    result = _run_sh(command, repo)

    assert (result.returncode, result.stderr) == (0, "")
    assert result.stdout.splitlines() == [
        f"{_day(1)}|11|data|",
        f"{_day(1)}|13|null|",
        f"{_day(0)}|21||rejected",
        f"{_day(0)}|22||",
    ]


def test_run_count_sql_counts_runtime_runs(repo: Path):
    command = _doc_command(STATUS_RUNNER, "runtime/.venv/bin/python")

    result = _run_sh(command.replace("<SQL>", RUN_COUNT_SQL), repo)

    assert (result.returncode, result.stderr, result.stdout) == (0, "", "2\n")


def test_telegram_setup_and_delivery_query(write_config):
    text = README.read_text()
    section = text.split("### Telegram 알림 설정", 1)[1].split("### ", 1)[0]
    for required in (
        "BotFather",
        "chat id",
        "telegram.json",
        "install -m 600 /dev/null",
        "@userinfobot",
        "`Id`",
        "심링크",
        "pytest",
        "dev config",
    ):
        assert required in section
    query = "SELECT local_date, kind, event, ok, reason, at FROM delivery ORDER BY at DESC, id DESC LIMIT 20;"
    assert query in section
    with store.write_session(config.load(write_config())) as conn:
        assert conn.execute(query).fetchall() == []
