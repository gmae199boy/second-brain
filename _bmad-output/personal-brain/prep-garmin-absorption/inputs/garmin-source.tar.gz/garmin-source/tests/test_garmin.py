"""Garmin 어댑터: 세션 열기 순서, 세션 락, 당일 차단 파일, 로그인 예외 분류, 데이터 호출과 분류,
연속 403, 호출 간격, 로그 위생, 대역, 대화형 로그인."""

import dataclasses
import fcntl
import importlib.metadata
import inspect
import json
import logging
import os
import signal
import stat
import subprocess
import sys
import textwrap
import threading
import time
from collections.abc import Callable, Iterator
from datetime import UTC, date, datetime
from pathlib import Path
from types import SimpleNamespace

import garminconnect
import garminconnect.client
import pytest
from curl_cffi import requests as cffi_requests
from garmin_fakes import (
    FAKE_DISPLAY_NAME,
    FAKE_TOKEN_PAYLOAD,
    GOOD_MFA_CODE,
    ORIGINAL_API_SESSION,
    FakeGarmin,
    FakeSession,
    GarminTransport,
    ScriptedPrompts,
    StubGarminClient,
    StubLoginClient,
    http_error,
    transport_client,
)

from garmin_pipeline import config, dates, garmin
from garmin_pipeline.errors import (
    AuthFailed,
    AuthFailedReason,
    Blocked403,
    DomainError,
    NoData,
    RateLimited,
    Rejected,
    RunStatus,
    Transient,
)

# requests를 직접 import하지 않고 라이브러리가 쓰는 것을 그대로 쓴다.
library_requests = garminconnect.client.requests
AuthError = garminconnect.GarminConnectAuthenticationError
ConnError = garminconnect.GarminConnectConnectionError
TooMany = garminconnect.GarminConnectTooManyRequestsError

# 서울 2026-10-16 10:00. 모든 테스트의 "오늘"이다.
NOW = datetime(2026, 10, 16, 1, 0, tzinfo=UTC)
TODAY = "2026-10-16"
YESTERDAY = "2026-10-15"

# 다른 프로세스에서 세션 락 파일에 `flock(LOCK_EX)`을 잡고 "held"를 출력한 뒤 stdin 한 줄을
# 받을 때까지 쥔다. Garmin에는 닿지 않는다.
HOLDER = textwrap.dedent(
    """
    import fcntl
    import os
    import sys

    fd = os.open(sys.argv[1], os.O_RDWR | os.O_CREAT, 0o600)
    fcntl.flock(fd, fcntl.LOCK_EX)
    print("held", flush=True)
    sys.stdin.readline()
    """
)

# 라이브러리 seam을 대역으로 바꾼 세션 안에서 오래 사는 손자 프로세스를 `close_fds=False`로
# 띄워 pid를 출력하고, 락을 풀지 않은 채 `os._exit(0)`로 끝난다. 손자가 락 fd를 물려받았다면
# 그 뒤에도 락이 남는다.
SPAWNER = textwrap.dedent(
    """
    import os
    import subprocess
    import sys
    from types import SimpleNamespace

    from garmin_pipeline import config, garmin


    class Stub:
        client = SimpleNamespace(_api_session=None)

        def login(self, tokenstore):
            return None, None


    garmin._new_client = Stub
    cfg = config.load(sys.argv[1])
    with garmin.GarminAdapter(cfg).open_session():
        grandchild = subprocess.Popen(
            [sys.executable, "-c", "import time; time.sleep(60)"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            close_fds=False,
        )
        print(grandchild.pid, flush=True)
        os._exit(0)
    """
)

SECRETS = (
    "secret-token-4f9a",
    "runner@example.com",
    '{"body": "private-response-body"}',
)


class Boom(Exception):
    pass


@pytest.fixture(autouse=True)
def clock(monkeypatch: pytest.MonkeyPatch) -> Callable[[datetime], None]:
    """`dates._utc_now`를 `NOW`로 고정하고, 다른 시각으로 바꾸는 함수를 준다."""

    def set_now(moment: datetime) -> None:
        monkeypatch.setattr(dates, "_utc_now", lambda: moment)

    set_now(NOW)
    return set_now


@pytest.fixture
def make_cfg(
    write_config: Callable[..., Path], tmp_path: Path
) -> Callable[..., config.Config]:
    """`tmp_path/tokens`를 만들고 `write_config`로 쓴 설정을 읽는다."""

    def make(**overrides: object) -> config.Config:
        (tmp_path / "tokens").mkdir(exist_ok=True)
        return config.load(write_config(**overrides))

    return make


@pytest.fixture
def cfg(make_cfg: Callable[..., config.Config]) -> config.Config:
    return make_cfg(lock_wait_seconds=0)


@pytest.fixture
def stubs(monkeypatch: pytest.MonkeyPatch) -> Callable[..., list[StubGarminClient]]:
    """`garmin._new_client`를 `StubGarminClient(**kwargs)` 생성으로 바꾸고 만든 목록을 준다."""

    def install(**kwargs: object) -> list[StubGarminClient]:
        created: list[StubGarminClient] = []

        def new_client() -> StubGarminClient:
            client = StubGarminClient(**kwargs)  # type: ignore[arg-type]
            created.append(client)
            return client

        monkeypatch.setattr(garmin, "_new_client", new_client)
        return created

    return install


@pytest.fixture
def holder() -> Iterator[Callable[[Path], subprocess.Popen[str]]]:
    """락 파일 경로를 받아 그 락을 쥔 하위 프로세스를 띄운다."""
    processes: list[subprocess.Popen[str]] = []

    def start(lock_path: Path) -> subprocess.Popen[str]:
        process = subprocess.Popen(
            [sys.executable, "-c", HOLDER, str(lock_path)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            text=True,
        )
        processes.append(process)
        assert process.stdout is not None
        assert process.stdout.readline() == "held\n"
        return process

    yield start
    for process in processes:
        process.kill()
        process.communicate()


def _lock_path(cfg: config.Config) -> Path:
    return cfg.tokenstore / garmin.SESSION_LOCK_FILENAME


def _block_path(cfg: config.Config) -> Path:
    return cfg.tokenstore / garmin.BLOCK_FILENAME


def _lock_held(cfg: config.Config) -> bool:
    """누군가(이 프로세스의 다른 fd 포함) 세션 락을 쥐고 있으면 참이다."""
    try:
        fd = os.open(_lock_path(cfg), os.O_RDONLY)
    except FileNotFoundError:
        return False
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
        except BlockingIOError:
            return True
        fcntl.flock(fd, fcntl.LOCK_UN)
        return False
    finally:
        os.close(fd)


def _write_block(cfg: config.Config, content: object) -> bytes:
    raw = content if isinstance(content, bytes) else json.dumps(content).encode("utf-8")
    _block_path(cfg).write_bytes(raw)
    return raw


def _block(local_date: str = TODAY, reason: str = "rate_limited") -> dict[str, object]:
    return {"schema_version": 1, "local_date": local_date, "reason": reason}


def _tree(root: Path) -> dict[str, tuple[int, int, int]]:
    """`root` 아래 모든 경로의 (mode, size, mtime_ns). 심링크는 따라가지 않는다."""
    snapshot: dict[str, tuple[int, int, int]] = {}
    for dirpath, dirnames, filenames in os.walk(root):
        for name in [*dirnames, *filenames]:
            path = Path(dirpath, name)
            info = path.lstat()
            snapshot[str(path.relative_to(root))] = (
                info.st_mode,
                info.st_size,
                info.st_mtime_ns,
            )
    return snapshot


def _caused(outer: BaseException, cause: BaseException) -> BaseException:
    outer.__cause__ = cause
    return outer


def _contexted(outer: BaseException, context: BaseException) -> BaseException:
    outer.__context__ = context
    return outer


def _with_response(error: BaseException, status_code: object) -> BaseException:
    error.response = SimpleNamespace(status_code=status_code)  # type: ignore[attr-defined]
    return error


def _cycle() -> BaseException:
    first, second = AuthError("first"), AuthError("second")
    first.__cause__, second.__cause__ = second, first
    return first


# --- 공개 API와 대역 ----------------------------------------------------------------------


def test_public_api_takes_no_credentials():
    parameters = inspect.signature(garmin.GarminAdapter).parameters
    assert list(parameters) == ["cfg", "sleep"]
    assert parameters["sleep"].kind is inspect.Parameter.KEYWORD_ONLY
    assert parameters["sleep"].default is time.sleep
    for port in (garmin.GarminPort, garmin.GarminAdapter):
        assert list(inspect.signature(port.blocked_today).parameters) == ["self"]
        open_parameters = inspect.signature(port.open_session).parameters
        assert list(open_parameters) == ["self", "first_call_endpoints"]
        first_call = open_parameters["first_call_endpoints"]
        assert first_call.kind is inspect.Parameter.KEYWORD_ONLY
        assert first_call.default == ()


def test_adapter_errors_are_outside_domain_errors():
    for error in (
        garmin.SessionLockTimeout,
        garmin.SessionBlocked,
        garmin.BlockFileInvalid,
    ):
        assert issubclass(error, garmin.GarminAdapterError)
    assert issubclass(garmin.GarminAdapterError, Exception)
    assert not issubclass(garmin.GarminAdapterError, DomainError)
    assert garmin.SessionLockTimeout.reason == "session_lock_timeout"

    blocked = garmin.SessionBlocked("blocked_403")

    assert blocked.reason is RunStatus.BLOCKED_403
    assert "blocked_403" in str(blocked)


def test_adapter_and_fake_satisfy_port(cfg: config.Config):
    assert isinstance(garmin.GarminAdapter(cfg), garmin.GarminPort)
    assert isinstance(FakeGarmin(), garmin.GarminPort)


def test_fake_garmin_records_calls():
    fake = FakeGarmin()

    assert fake.blocked_today() is None
    with fake.open_session() as session:
        assert isinstance(session, FakeSession)
        assert isinstance(session, garmin.GarminSession)

    assert fake.calls == ["blocked_today", "open_session", "close_session"]


def test_fake_garmin_injects_block_and_open_error():
    blocked = FakeGarmin(blocked=RunStatus.RATE_LIMITED)

    assert blocked.blocked_today() is RunStatus.RATE_LIMITED
    with pytest.raises(garmin.SessionBlocked) as excinfo, blocked.open_session():
        pytest.fail("차단이면 세션을 열면 안 된다")
    assert excinfo.value.reason is RunStatus.RATE_LIMITED

    failing = FakeGarmin(open_error=Transient("login 단계: HTTP 503"))
    with pytest.raises(Transient), failing.open_session():
        pytest.fail("열기 오류면 블록에 들어가면 안 된다")
    assert failing.calls == ["open_session"]

    broken = FakeGarmin(block_error=garmin.BlockFileInvalid("차단 파일"))
    with pytest.raises(garmin.BlockFileInvalid):
        broken.blocked_today()
    with pytest.raises(garmin.BlockFileInvalid), broken.open_session():
        pytest.fail("깨진 차단 파일이면 세션을 열면 안 된다")
    assert broken.calls == ["blocked_today", "open_session"]


def test_guard_fails_when_seam_is_called():
    with pytest.raises(pytest.fail.Exception, match="_new_client"):
        garmin._new_client()


def test_library_client_has_replaceable_api_session():
    # seam 뒤의 실제 라이브러리 모양(네트워크 없음): cffi 교체가 기대는 속성이 있다.
    client = garminconnect.Garmin()

    assert isinstance(client.client, garminconnect.client.Client)
    assert isinstance(client.client._api_session, library_requests.Session)


def test_library_client_supports_interactive_login():
    # seam 뒤의 실제 라이브러리 모양(네트워크 없음): interactive_login이 기대는 내부가 있다.
    client = garminconnect.Garmin()

    assert client.client._mfa_pending is False
    assert "return_on_mfa" in inspect.signature(client.client.login).parameters
    assert callable(client.resume_login)
    assert callable(client._load_profile_and_settings)
    assert callable(client.client.dump)


# --- 정상 열기 ----------------------------------------------------------------------------


def test_open_session_logs_in_once_and_holds_lock_until_exit(
    cfg: config.Config, stubs: Callable[..., list[StubGarminClient]]
):
    held_at_login: list[bool] = []
    created = stubs(on_login=lambda: held_at_login.append(_lock_held(cfg)))
    adapter = garmin.GarminAdapter(cfg)

    assert adapter.blocked_today() is None
    with adapter.open_session() as session:
        assert isinstance(session, garmin.GarminSession)
        assert _lock_held(cfg) is True

    assert _lock_held(cfg) is False
    assert len(created) == 1
    assert created[0].login_calls == [str(cfg.tokenstore)]
    assert held_at_login == [True]
    assert not _block_path(cfg).exists()
    mode = _lock_path(cfg).stat().st_mode
    assert stat.S_IMODE(mode) == 0o600


def test_exception_in_block_propagates_and_releases_lock(
    cfg: config.Config, stubs: Callable[..., list[StubGarminClient]]
):
    stubs()

    with pytest.raises(Boom), garmin.GarminAdapter(cfg).open_session():
        raise Boom

    assert _lock_held(cfg) is False
    assert not _block_path(cfg).exists()


@pytest.mark.parametrize("enabled", [True, False])
def test_cffi_api_session(
    make_cfg: Callable[..., config.Config],
    stubs: Callable[..., list[StubGarminClient]],
    enabled: bool,
):
    cfg = make_cfg(cffi_api_session=enabled)
    created = stubs()

    with garmin.GarminAdapter(cfg).open_session():
        pass

    (at_login,) = created[0].api_session_at_login
    if enabled:
        assert isinstance(at_login, cffi_requests.Session)
        assert at_login.impersonate == "chrome"
        assert at_login.discard_cookies is True
    else:
        assert at_login is ORIGINAL_API_SESSION


# --- 당일 차단 파일 -----------------------------------------------------------------------


@pytest.mark.parametrize("reason", [RunStatus.RATE_LIMITED, RunStatus.BLOCKED_403])
def test_block_today_skips_login_and_keeps_file(
    cfg: config.Config,
    stubs: Callable[..., list[StubGarminClient]],
    reason: RunStatus,
):
    created = stubs()
    raw = _write_block(cfg, _block(TODAY, reason.value))
    before = _block_path(cfg).stat().st_mtime_ns
    adapter = garmin.GarminAdapter(cfg)

    assert adapter.blocked_today() is reason
    with pytest.raises(garmin.SessionBlocked) as excinfo, adapter.open_session():
        pytest.fail("오늘 차단이면 세션을 열면 안 된다")

    assert excinfo.value.reason is reason
    assert created == []
    assert _block_path(cfg).read_bytes() == raw
    assert _block_path(cfg).stat().st_mtime_ns == before
    assert _lock_held(cfg) is False


def test_today_follows_config_timezone(
    cfg: config.Config,
    stubs: Callable[..., list[StubGarminClient]],
    clock: Callable[[datetime], None],
):
    created = stubs()
    _write_block(cfg, _block(TODAY))
    # UTC로는 아직 10월 15일이지만 서울로는 10월 16일 00:30이다.
    clock(datetime(2026, 10, 15, 15, 30, tzinfo=UTC))
    adapter = garmin.GarminAdapter(cfg)

    assert adapter.blocked_today() is RunStatus.RATE_LIMITED
    with pytest.raises(garmin.SessionBlocked), adapter.open_session():
        pytest.fail("서울 기준 오늘이면 차단이다")
    assert created == []


def test_past_block_is_ignored_and_kept(
    cfg: config.Config, stubs: Callable[..., list[StubGarminClient]]
):
    created = stubs()
    raw = _write_block(cfg, _block(YESTERDAY, "blocked_403"))
    adapter = garmin.GarminAdapter(cfg)

    assert adapter.blocked_today() is None
    with adapter.open_session():
        pass

    assert len(created[0].login_calls) == 1
    assert _block_path(cfg).read_bytes() == raw


@pytest.mark.parametrize(
    "content",
    [
        pytest.param(b"{not json", id="bad-json"),
        pytest.param(b"", id="empty"),
        pytest.param(b"\xff\xfe", id="not-utf8"),
        pytest.param([1, 2], id="not-object"),
        pytest.param({"schema_version": 1, "local_date": TODAY}, id="missing-reason"),
        pytest.param({**_block(), "extra": 1}, id="unknown-key"),
        pytest.param(_block(reason="error"), id="unknown-reason"),
        pytest.param(_block(reason="skipped_blocked"), id="not-a-block-reason"),
        pytest.param({**_block(), "reason": 429}, id="reason-not-string"),
        pytest.param({**_block(), "schema_version": 2}, id="schema-version-2"),
        pytest.param({**_block(), "schema_version": "1"}, id="schema-version-string"),
        pytest.param({**_block(), "schema_version": True}, id="schema-version-bool"),
        pytest.param(_block(local_date="2026-13-01"), id="bad-date"),
        pytest.param(_block(local_date="20261016"), id="compact-date"),
        pytest.param({**_block(), "local_date": None}, id="null-date"),
    ],
)
def test_invalid_block_file_fails_closed(
    cfg: config.Config,
    stubs: Callable[..., list[StubGarminClient]],
    content: object,
):
    created = stubs()
    raw = _write_block(cfg, content)
    adapter = garmin.GarminAdapter(cfg)

    with pytest.raises(garmin.BlockFileInvalid):
        adapter.blocked_today()
    with pytest.raises(garmin.BlockFileInvalid), adapter.open_session():
        pytest.fail("깨진 차단 파일이면 세션을 열면 안 된다")

    assert created == []
    assert _block_path(cfg).read_bytes() == raw
    assert _lock_held(cfg) is False


def test_unreadable_block_path_fails_closed(
    cfg: config.Config, stubs: Callable[..., list[StubGarminClient]]
):
    created = stubs()
    _block_path(cfg).mkdir()

    with pytest.raises(garmin.BlockFileInvalid):
        garmin.GarminAdapter(cfg).blocked_today()
    assert created == []


@pytest.mark.parametrize("state", ["missing", "file"])
def test_tokenstore_not_a_directory_is_token_invalid_and_creates_nothing(
    write_config: Callable[..., Path],
    tmp_path: Path,
    stubs: Callable[..., list[StubGarminClient]],
    state: str,
):
    created = stubs()
    cfg = config.load(write_config(lock_wait_seconds=0))
    if state == "file":
        cfg.tokenstore.write_text("", encoding="utf-8")
    before = _tree(tmp_path)
    adapter = garmin.GarminAdapter(cfg)

    assert adapter.blocked_today() is None
    with pytest.raises(AuthFailed) as excinfo, adapter.open_session():
        pytest.fail("tokenstore가 디렉터리가 아니면 세션을 열면 안 된다")

    assert excinfo.value.reason is AuthFailedReason.TOKEN_INVALID
    assert created == []
    assert _tree(tmp_path) == before


# --- 세션 락 ------------------------------------------------------------------------------


def test_lock_contention_with_other_process_times_out(
    make_cfg: Callable[..., config.Config],
    stubs: Callable[..., list[StubGarminClient]],
    holder: Callable[[Path], subprocess.Popen[str]],
):
    cfg = make_cfg(lock_wait_seconds=0.3)
    created = stubs()
    process = holder(_lock_path(cfg))

    started = time.monotonic()
    with (
        pytest.raises(garmin.SessionLockTimeout) as excinfo,
        garmin.GarminAdapter(cfg).open_session(),
    ):
        pytest.fail("다른 프로세스가 쥔 락을 잡으면 안 된다")
    waited = time.monotonic() - started

    assert waited >= 0.3
    assert str(_lock_path(cfg)) in str(excinfo.value)
    assert "0.3초" in str(excinfo.value)
    assert excinfo.value.reason == "session_lock_timeout"
    assert created == []

    process.communicate("\n", timeout=10)
    assert process.returncode == 0
    assert _lock_held(cfg) is False


def test_zero_wait_tries_once(
    cfg: config.Config,
    stubs: Callable[..., list[StubGarminClient]],
    holder: Callable[[Path], subprocess.Popen[str]],
    monkeypatch: pytest.MonkeyPatch,
):
    created = stubs()
    holder(_lock_path(cfg))
    sleeps: list[float] = []
    monkeypatch.setattr(time, "sleep", sleeps.append)

    with (
        pytest.raises(garmin.SessionLockTimeout, match="0초"),
        garmin.GarminAdapter(cfg).open_session(),
    ):
        pytest.fail("락을 잡으면 안 된다")

    assert sleeps == []
    assert created == []


def test_session_starts_when_holder_releases_within_wait(
    make_cfg: Callable[..., config.Config],
    stubs: Callable[..., list[StubGarminClient]],
):
    cfg = make_cfg(lock_wait_seconds=10)
    created = stubs()
    fd = os.open(_lock_path(cfg), os.O_RDWR | os.O_CREAT, 0o600)
    fcntl.flock(fd, fcntl.LOCK_EX)
    release = threading.Timer(0.3, os.close, args=(fd,))

    started = time.monotonic()
    release.start()
    try:
        with garmin.GarminAdapter(cfg).open_session():
            waited = time.monotonic() - started
    finally:
        release.join()

    assert 0.3 <= waited < 5
    assert len(created[0].login_calls) == 1


def test_nested_open_session_fails_without_waiting(
    make_cfg: Callable[..., config.Config],
    stubs: Callable[..., list[StubGarminClient]],
):
    cfg = make_cfg(lock_wait_seconds=10)
    created = stubs()
    adapter = garmin.GarminAdapter(cfg)

    with adapter.open_session():
        # 실패한 중첩 시도가 바깥 세션의 표시를 지우지 않으므로 두 번째도 바로 실패한다.
        for _ in range(2):
            started = time.monotonic()
            with (
                pytest.raises(RuntimeError, match="중첩"),
                garmin.GarminAdapter(cfg).open_session(),
            ):
                pytest.fail("중첩 세션에 들어가면 안 된다")
            assert time.monotonic() - started < 1
        assert _lock_held(cfg) is True

    assert _lock_held(cfg) is False
    assert len(created) == 1
    with adapter.open_session():
        pass


def test_nested_through_other_path_to_same_lock_fails(
    make_cfg: Callable[..., config.Config],
    stubs: Callable[..., list[StubGarminClient]],
    tmp_path: Path,
):
    cfg = make_cfg(lock_wait_seconds=10)
    stubs()
    # config는 심링크 tokenstore를 거부하므로, 하드 링크된 같은 락 파일로 같은 상황을 만든다.
    other = tmp_path / "other"
    other.mkdir()
    _lock_path(cfg).touch(mode=0o600)
    os.link(_lock_path(cfg), other / garmin.SESSION_LOCK_FILENAME)
    alias = dataclasses.replace(cfg, tokenstore=other)

    with (
        garmin.GarminAdapter(cfg).open_session(),
        pytest.raises(RuntimeError, match="중첩"),
        garmin.GarminAdapter(alias).open_session(),
    ):
        pytest.fail("같은 락 파일이면 중첩이다")


def test_child_process_does_not_inherit_lock(cfg: config.Config):
    process = subprocess.Popen(
        [sys.executable, "-c", SPAWNER, str(cfg.path)],
        stdout=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    with process.stdout:
        line = process.stdout.readline()
    assert process.wait(timeout=30) == 0
    grandchild = int(line)
    try:
        os.kill(grandchild, 0)  # 세션을 연 프로세스는 끝났지만 손자는 아직 살아 있다.
        assert _lock_held(cfg) is False
    finally:
        # 손자는 launchd/init로 넘어갔으므로 여기서는 죽이기만 하고 거두기는 그쪽이 한다.
        try:
            os.kill(grandchild, signal.SIGKILL)
        except ProcessLookupError:
            pass


# --- 로그인 예외 분류 ---------------------------------------------------------------------


CLASSIFICATION = [
    pytest.param(
        lambda: _caused(
            AuthError("Failed to retrieve social profile"),
            ConnError("API Error 403 - Forbidden"),
        ),
        Blocked403,
        "blocked_403",
        id="auth-from-api-error-403",
    ),
    pytest.param(
        lambda: _caused(
            AuthError("Failed to retrieve social profile"),
            ConnError("API Error 429"),
        ),
        RateLimited,
        "rate_limited",
        id="auth-from-api-error-429",
    ),
    pytest.param(
        lambda: TooMany("Too many login attempts."),
        RateLimited,
        "rate_limited",
        id="too-many-requests",
    ),
    pytest.param(
        lambda: _caused(
            AuthError("Failed to retrieve social profile"),
            ConnError("API Error 503 - Service Unavailable"),
        ),
        Transient,
        None,
        id="auth-from-api-error-503",
    ),
    pytest.param(
        lambda: _caused(
            AuthError("Failed to retrieve social profile"),
            library_requests.ConnectionError("Max retries exceeded"),
        ),
        Transient,
        None,
        id="requests-connection-error",
    ),
    pytest.param(
        lambda: _caused(
            AuthError("Failed to retrieve social profile"),
            library_requests.Timeout("Read timed out"),
        ),
        Transient,
        None,
        id="requests-timeout",
    ),
    pytest.param(
        lambda: _caused(
            AuthError("Failed to retrieve social profile"),
            cffi_requests.exceptions.ConnectionError("curl: (7) Failed to connect"),
        ),
        Transient,
        None,
        id="curl-cffi-error",
    ),
    pytest.param(
        lambda: _with_response(ConnError("Login failed"), 429),
        RateLimited,
        "rate_limited",
        id="response-status-429",
    ),
    pytest.param(
        lambda: _caused(
            AuthError("Authentication failed (401 Unauthorized)."),
            library_requests.HTTPError(response=SimpleNamespace(status_code=401)),
        ),
        AuthFailed,
        None,
        id="requests-http-error-401",
    ),
    pytest.param(
        lambda: _caused(
            AuthError("Failed to retrieve social profile"),
            ConnError("API Error 401"),
        ),
        AuthFailed,
        None,
        id="auth-from-api-error-401",
    ),
    pytest.param(
        lambda: _caused(AuthError("Failed"), ConnError("API Error 400")),
        AuthFailed,
        None,
        id="other-4xx",
    ),
    pytest.param(
        lambda: AuthError("Username and password are required"),
        AuthFailed,
        None,
        id="no-cause",
    ),
    pytest.param(
        lambda: _contexted(
            AuthError("Failed to retrieve social profile"),
            ConnError("API Error 403"),
        ),
        Blocked403,
        "blocked_403",
        id="context-only",
    ),
    pytest.param(
        lambda: _caused(
            ConnError("Login failed: HTTP 502"), ConnError("API Error 403")
        ),
        Transient,
        None,
        id="first-status-wins",
    ),
    pytest.param(
        lambda: _caused(
            AuthError("Failed"),
            library_requests.ConnectionError("Error 403 in proxy text"),
        ),
        Transient,
        None,
        id="non-library-message-is-not-parsed",
    ),
    pytest.param(
        lambda: _with_response(ConnError("Login failed"), True),
        AuthFailed,
        None,
        id="bool-status-ignored",
    ),
    pytest.param(
        lambda: FileNotFoundError(2, "No such file"),
        Transient,
        None,
        id="bare-oserror",
    ),
    pytest.param(_cycle, AuthFailed, None, id="cause-cycle"),
]


@pytest.mark.parametrize(("make_error", "expected", "block_reason"), CLASSIFICATION)
def test_login_error_classification(
    cfg: config.Config,
    stubs: Callable[..., list[StubGarminClient]],
    make_error: Callable[[], BaseException],
    expected: type[DomainError],
    block_reason: str | None,
):
    created = stubs(login_error=make_error())

    with pytest.raises(expected) as excinfo, garmin.GarminAdapter(cfg).open_session():
        pytest.fail("로그인이 실패하면 블록에 들어가면 안 된다")

    error = excinfo.value
    assert type(error) is expected
    assert error.__cause__ is None
    assert error.__suppress_context__ is True
    if isinstance(error, AuthFailed):
        assert error.reason is AuthFailedReason.TOKEN_INVALID
    assert len(created[0].login_calls) == 1
    assert _lock_held(cfg) is False
    if block_reason is None:
        assert not _block_path(cfg).exists()
    else:
        assert json.loads(_block_path(cfg).read_text(encoding="utf-8")) == _block(
            TODAY, block_reason
        )
        assert stat.S_IMODE(_block_path(cfg).stat().st_mode) == 0o600
        assert garmin.GarminAdapter(cfg).blocked_today() == block_reason
    # 임시 파일이 남지 않는다.
    assert sorted(path.name for path in cfg.tokenstore.iterdir()) == sorted(
        [garmin.SESSION_LOCK_FILENAME]
        + ([garmin.BLOCK_FILENAME] if block_reason else [])
    )


def test_domain_error_message_has_stage_and_status_only(
    cfg: config.Config, stubs: Callable[..., list[StubGarminClient]]
):
    stubs(login_error=_caused(AuthError("x"), ConnError("API Error 503 - detail")))

    with pytest.raises(Transient) as excinfo, garmin.GarminAdapter(cfg).open_session():
        pass

    assert str(excinfo.value) == "login 단계: HTTP 503"


def test_block_is_written_while_lock_is_held(
    cfg: config.Config,
    stubs: Callable[..., list[StubGarminClient]],
    monkeypatch: pytest.MonkeyPatch,
):
    stubs(login_error=TooMany("Too many"))
    original = garmin._write_block
    held: list[bool] = []

    def write_block(*args: object) -> None:
        held.append(_lock_held(cfg))
        original(*args)  # type: ignore[arg-type]

    monkeypatch.setattr(garmin, "_write_block", write_block)

    with pytest.raises(RateLimited), garmin.GarminAdapter(cfg).open_session():
        pass

    assert held == [True]


def test_rate_limit_replaces_old_block_and_next_open_skips_login(
    cfg: config.Config, stubs: Callable[..., list[StubGarminClient]]
):
    _write_block(cfg, _block(YESTERDAY, "blocked_403"))
    first = stubs(login_error=_caused(AuthError("x"), ConnError("API Error 429")))
    adapter = garmin.GarminAdapter(cfg)

    with pytest.raises(RateLimited), adapter.open_session():
        pass
    assert json.loads(_block_path(cfg).read_text(encoding="utf-8")) == _block(
        TODAY, "rate_limited"
    )

    second = stubs()
    assert adapter.blocked_today() is RunStatus.RATE_LIMITED
    with pytest.raises(garmin.SessionBlocked), adapter.open_session():
        pass
    assert len(first) == 1
    assert second == []


def test_block_write_failure_still_raises_domain_error(
    cfg: config.Config,
    stubs: Callable[..., list[StubGarminClient]],
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
):
    stubs(login_error=_caused(AuthError("x"), ConnError("API Error 403")))

    def fail(*args: object) -> None:
        raise PermissionError(13, "Permission denied")

    monkeypatch.setattr(garmin, "_write_block", fail)

    with pytest.raises(Blocked403), garmin.GarminAdapter(cfg).open_session():
        pass

    assert "errno=13" in caplog.text
    assert _lock_held(cfg) is False


def test_block_write_failure_cleans_temp_file_and_still_raises(
    cfg: config.Config,
    stubs: Callable[..., list[StubGarminClient]],
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
):
    stubs(login_error=_caused(AuthError("x"), ConnError("API Error 429")))

    def fail(*args: object) -> None:
        raise PermissionError(13, "Permission denied")

    # mkstemp로 임시 파일을 만든 뒤 교체 단계에서 실패하게 한다.
    monkeypatch.setattr(os, "replace", fail)

    with pytest.raises(RateLimited), garmin.GarminAdapter(cfg).open_session():
        pass

    assert "errno=13" in caplog.text
    assert not _block_path(cfg).exists()
    assert [path.name for path in cfg.tokenstore.iterdir()] == [
        garmin.SESSION_LOCK_FILENAME
    ]
    assert _lock_held(cfg) is False


def test_written_block_date_follows_config_timezone(
    cfg: config.Config,
    stubs: Callable[..., list[StubGarminClient]],
    clock: Callable[[datetime], None],
):
    # UTC로는 아직 10월 15일이지만 서울로는 10월 16일 00:30이다.
    clock(datetime(2026, 10, 15, 15, 30, tzinfo=UTC))
    stubs(login_error=_caused(AuthError("x"), ConnError("API Error 429")))
    adapter = garmin.GarminAdapter(cfg)

    with pytest.raises(RateLimited), adapter.open_session():
        pass

    written = json.loads(_block_path(cfg).read_text(encoding="utf-8"))
    assert written["local_date"] == "2026-10-16"
    assert adapter.blocked_today() is RunStatus.RATE_LIMITED


def test_unclassified_login_error_propagates(
    cfg: config.Config, stubs: Callable[..., list[StubGarminClient]]
):
    original = TypeError("unexpected keyword")
    stubs(login_error=original)

    with pytest.raises(TypeError) as excinfo, garmin.GarminAdapter(cfg).open_session():
        pass

    assert excinfo.value is original
    assert not _block_path(cfg).exists()
    assert _lock_held(cfg) is False


# --- 로그 위생 ----------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("make_error", "expected"),
    [
        pytest.param(
            lambda: _caused(
                AuthError(f"Failed: token={SECRETS[0]} user={SECRETS[1]}"),
                ConnError(f"API Error 429 - {SECRETS[2]} {SECRETS[1]}"),
            ),
            RateLimited,
            id="rate-limited",
        ),
        pytest.param(
            lambda: _caused(
                AuthError(f"Failed: {SECRETS[1]}"),
                library_requests.ConnectionError(f"{SECRETS[0]} {SECRETS[2]}"),
            ),
            Transient,
            id="transient",
        ),
        pytest.param(
            lambda: AuthError(f"bad token {SECRETS[0]} for {SECRETS[1]}: {SECRETS[2]}"),
            AuthFailed,
            id="auth-failed",
        ),
    ],
)
def test_logs_and_errors_hold_no_library_text(
    cfg: config.Config,
    stubs: Callable[..., list[StubGarminClient]],
    caplog: pytest.LogCaptureFixture,
    make_error: Callable[[], BaseException],
    expected: type[DomainError],
):
    caplog.set_level(logging.DEBUG)
    stubs(login_error=make_error())

    with pytest.raises(expected) as excinfo, garmin.GarminAdapter(cfg).open_session():
        pass

    assert caplog.records, "실패는 로그에 남는다"
    assert all(record.name == "garmin_pipeline.garmin" for record in caplog.records)
    assert expected.__name__ in caplog.text
    for secret in SECRETS:
        assert secret not in caplog.text
        assert secret not in str(excinfo.value)
        assert secret not in repr(excinfo.value)


# --- 데이터 호출 ------------------------------------------------------------------------
# 전송 stub(`GarminTransport`)은 실제 `garminconnect.Garmin()`의 `client.connectapi`만 바꾼다.
# 그래서 라이브러리의 실제 메서드(URL·params)·데코레이터(예외 변환)·재시도가 그대로 돈다.

DAY = date(2026, 10, 15)
D = DAY.isoformat()
ACTIVITY_ID = 21234567890
DN = FAKE_DISPLAY_NAME
ACTIVITIES_PATH = "/activitylist-service/activities/search/activities"

# endpoint → 라이브러리가 부르는 (경로, params). activities_by_date는 첫 페이지 params다.
DAY_REQUESTS: dict[str, tuple[str, dict[str, object] | None]] = {
    "sleep_data": (
        f"/wellness-service/wellness/dailySleepData/{DN}",
        {"date": D, "nonSleepBufferMinutes": 60},
    ),
    "hrv_data": (f"/hrv-service/hrv/{D}", None),
    "rhr_day": (
        f"/userstats-service/wellness/daily/{DN}",
        {"fromDate": D, "untilDate": D, "metricId": 60},
    ),
    "heart_rates": (f"/wellness-service/wellness/dailyHeartRate/{DN}", {"date": D}),
    "stress_data": (f"/wellness-service/wellness/dailyStress/{D}", None),
    "body_battery": (
        "/wellness-service/wellness/bodyBattery/reports/daily",
        {"startDate": D, "endDate": D},
    ),
    "user_summary": (
        f"/usersummary-service/usersummary/daily/{DN}",
        {"calendarDate": D},
    ),
    "training_readiness": (f"/metrics-service/metrics/trainingreadiness/{D}", None),
    "daily_weigh_ins": (f"/weight-service/weight/dayview/{D}", {"includeAll": True}),
    "lifestyle_logging_data": (f"/lifestylelogging-service/dailyLog/{D}", None),
    "activities_by_date": (
        ACTIVITIES_PATH,
        {"startDate": D, "start": "0", "limit": "20", "endDate": D},
    ),
}
ACTIVITY_REQUESTS: dict[str, tuple[str, dict[str, object] | None]] = {
    "activity": (f"/activity-service/activity/{ACTIVITY_ID}", None),
    "activity_details": (
        f"/activity-service/activity/{ACTIVITY_ID}/details",
        {"maxChartSize": "2000", "maxPolylineSize": "4000"},
    ),
    "activity_hr_in_timezones": (
        f"/activity-service/activity/{ACTIVITY_ID}/hrTimeInZones",
        None,
    ),
    "activity_exercise_sets": (
        f"/activity-service/activity/{ACTIVITY_ID}/exerciseSets",
        None,
    ),
}
STRESS_PATH = DAY_REQUESTS["stress_data"][0]
SUMMARY_PATH = DAY_REQUESTS["user_summary"][0]


@pytest.fixture
def transport(monkeypatch: pytest.MonkeyPatch) -> GarminTransport:
    """`garmin._new_client`를 전송 stub을 낀 실제 라이브러리 클라이언트 생성으로 바꾼다."""
    stub = GarminTransport()
    monkeypatch.setattr(garmin, "_new_client", lambda: transport_client(stub))
    return stub


@pytest.fixture
def sleeps() -> list[float]:
    return []


@pytest.fixture
def adapter(cfg: config.Config, sleeps: list[float]) -> garmin.GarminAdapter:
    return garmin.GarminAdapter(cfg, sleep=sleeps.append)


def _fetch(session: garmin.GarminSession, endpoint: str) -> garmin.RawResponse:
    if endpoint in garmin.ACTIVITY_ENDPOINTS:
        return session.fetch_activity(endpoint, ACTIVITY_ID)
    return session.fetch_day(endpoint, DAY)


def _assert_domain(error: BaseException, expected: type[DomainError]) -> None:
    assert type(error) is expected
    assert error.__cause__ is None
    assert error.__suppress_context__ is True


def test_endpoint_lists_and_library_version():
    assert garmin.DAY_ENDPOINTS == tuple(DAY_REQUESTS)
    assert garmin.ACTIVITY_ENDPOINTS == tuple(ACTIVITY_REQUESTS)
    assert garmin.LIBRARY_VERSION == importlib.metadata.version("garminconnect")
    for endpoint in (*garmin.DAY_ENDPOINTS, *garmin.ACTIVITY_ENDPOINTS):
        assert callable(getattr(garminconnect.Garmin, f"get_{endpoint}"))


def test_raw_response_is_frozen():
    raw = garmin.RawResponse("hrv_data", {"a": 1}, "0.3.17")

    with pytest.raises(dataclasses.FrozenInstanceError):
        raw.payload = {}  # type: ignore[misc]


def test_session_protocol_methods():
    for implementation in (garmin.GarminSession, garmin._Session, FakeSession):
        day = inspect.signature(implementation.fetch_day).parameters
        activity = inspect.signature(implementation.fetch_activity).parameters
        assert list(day) == ["self", "endpoint", "day"]
        assert list(activity) == ["self", "endpoint", "activity_id"]


def test_adapter_source_avoids_rewrapping_library_methods():
    source = Path(garmin.__file__).read_text(encoding="utf-8")

    for name in (
        "parse_activity_detail_metrics",
        "get_user_summary",
        "get_heart_rates",
        "retry_attempts",
    ):
        assert name not in source


@pytest.mark.parametrize("endpoint", list(DAY_REQUESTS))
def test_day_endpoint_calls_library_once_and_returns_raw(
    adapter: garmin.GarminAdapter, transport: GarminTransport, endpoint: str
):
    path, params = DAY_REQUESTS[endpoint]
    payload: object = {"calendarDate": D, "secretKeyOrder": [3, 1, 2]}
    if endpoint == "activities_by_date":
        payload = [{"activityId": ACTIVITY_ID}]
        # 라이브러리가 빈 페이지가 나올 때까지 내부에서 페이징한다.
        transport.reply(path, payload, [])
    else:
        transport.reply(path, payload)

    with adapter.open_session() as session:
        raw = session.fetch_day(endpoint, DAY)

    assert raw == garmin.RawResponse(endpoint, payload, garmin.LIBRARY_VERSION)
    if endpoint == "activities_by_date":
        assert transport.calls == [
            (path, params),
            (path, {**params, "start": "20"}),  # type: ignore[dict-item]
        ]
    else:
        assert raw.payload is payload
        assert transport.calls == [(path, params)]


@pytest.mark.parametrize("endpoint", list(ACTIVITY_REQUESTS))
@pytest.mark.parametrize("activity_id", [ACTIVITY_ID, str(ACTIVITY_ID)])
def test_activity_endpoint_calls_library_once_and_returns_raw(
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    endpoint: str,
    activity_id: object,
):
    path, params = ACTIVITY_REQUESTS[endpoint]
    payload = {"activityId": ACTIVITY_ID, "metricDescriptors": []}
    transport.reply(path, payload)

    with adapter.open_session() as session:
        raw = session.fetch_activity(endpoint, activity_id)  # type: ignore[arg-type]

    assert raw.endpoint == endpoint
    assert raw.payload is payload
    assert raw.library_version == garmin.LIBRARY_VERSION
    assert transport.calls == [(path, params)]


def test_activities_by_date_pages_inside_library(
    adapter: garmin.GarminAdapter, transport: GarminTransport
):
    first = [{"activityId": n} for n in range(20)]
    second = [{"activityId": 20}]
    transport.reply(ACTIVITIES_PATH, first, second, [])

    with adapter.open_session() as session:
        raw = session.fetch_day("activities_by_date", DAY)

    assert raw.payload == first + second
    assert [params["start"] for _, params in transport.calls] == ["0", "20", "40"]  # type: ignore[index]


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param({"totalSteps": 1000}, id="plain"),
        pytest.param({"privacyProtected": False, "totalSteps": 1}, id="not-protected"),
        pytest.param({"privacyProtected": "true"}, id="non-bool-flag"),
    ],
)
def test_user_summary_returns_raw_dict(
    adapter: garmin.GarminAdapter, transport: GarminTransport, payload: object
):
    transport.reply(SUMMARY_PATH, payload)

    with adapter.open_session() as session:
        raw = session.fetch_day("user_summary", DAY)

    assert raw.payload is payload


def test_user_summary_privacy_protected_is_auth_failed(
    cfg: config.Config, adapter: garmin.GarminAdapter, transport: GarminTransport
):
    transport.reply(SUMMARY_PATH, {"privacyProtected": True})

    with adapter.open_session() as session:
        with pytest.raises(AuthFailed) as excinfo:
            session.fetch_day("user_summary", DAY)
        # 차단이 아니므로 같은 세션의 다른 호출은 계속 Garmin에 닿는다.
        transport.reply(STRESS_PATH, {"ok": 1})
        assert session.fetch_day("stress_data", DAY).payload == {"ok": 1}

    _assert_domain(excinfo.value, AuthFailed)
    assert excinfo.value.reason is AuthFailedReason.PRIVACY_PROTECTED
    assert not _block_path(cfg).exists()


def test_privacy_flag_only_matters_for_user_summary(
    adapter: garmin.GarminAdapter, transport: GarminTransport
):
    payload = {"privacyProtected": True}
    transport.reply(STRESS_PATH, payload)

    with adapter.open_session() as session:
        assert session.fetch_day("stress_data", DAY).payload is payload


@pytest.mark.parametrize("endpoint", [*DAY_REQUESTS, *ACTIVITY_REQUESTS])
@pytest.mark.parametrize(
    "outcome",
    [
        pytest.param(None, id="none"),
        pytest.param([], id="empty-list"),
        pytest.param({}, id="empty-dict-204"),
        pytest.param(http_error(404), id="http-404"),
    ],
)
def test_empty_response_is_no_data(
    cfg: config.Config,
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    endpoint: str,
    outcome: object,
):
    path = {**DAY_REQUESTS, **ACTIVITY_REQUESTS}[endpoint][0]
    transport.reply(path, outcome)

    with adapter.open_session() as session, pytest.raises(NoData) as excinfo:
        _fetch(session, endpoint)

    _assert_domain(excinfo.value, NoData)
    assert endpoint in str(excinfo.value)
    assert len(transport.calls) == 1
    assert not _block_path(cfg).exists()


# (전송 결과, 도메인 오류, 전송 호출 수, 차단 사유). 전송 결과는 `Client._run_request`가 던지는
# 모양이고, 라이브러리 데코레이터가 실제로 바꾼 예외를 어댑터가 분류한다.
DATA_CLASSIFICATION = [
    pytest.param(http_error(429), RateLimited, 1, "rate_limited", id="http-429"),
    pytest.param(http_error(401), AuthFailed, 1, None, id="http-401"),
    pytest.param(http_error(403), Rejected, 1, None, id="http-403-first"),
    pytest.param(http_error(400, "bad"), Rejected, 1, None, id="http-400"),
    pytest.param(http_error(409), Rejected, 1, None, id="http-409"),
    pytest.param(http_error(503, "down"), Transient, 4, None, id="http-503"),
    pytest.param(http_error(500), Transient, 4, None, id="http-500"),
    pytest.param(
        library_requests.ConnectionError("Max retries exceeded"),
        Transient,
        4,
        None,
        id="requests-connection-error",
    ),
    pytest.param(
        library_requests.Timeout("Read timed out"),
        Transient,
        4,
        None,
        id="requests-timeout",
    ),
    pytest.param(
        cffi_requests.exceptions.ConnectionError("curl: (7) Failed to connect"),
        Transient,
        1,
        None,
        id="curl-cffi-connection-error",
    ),
    pytest.param(
        ValueError("Expecting value: line 1 column 1"),
        Transient,
        1,
        None,
        id="non-json-body",
    ),
    pytest.param(
        ConnError("Display name is not set"), Transient, 4, None, id="no-status"
    ),
]


@pytest.mark.parametrize(
    ("outcome", "expected", "attempts", "block_reason"), DATA_CLASSIFICATION
)
def test_data_error_classification(
    cfg: config.Config,
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    outcome: BaseException,
    expected: type[DomainError],
    attempts: int,
    block_reason: str | None,
):
    transport.reply(STRESS_PATH, outcome)

    with adapter.open_session() as session, pytest.raises(expected) as excinfo:
        session.fetch_day("stress_data", DAY)

    _assert_domain(excinfo.value, expected)
    if isinstance(excinfo.value, AuthFailed):
        assert excinfo.value.reason is AuthFailedReason.TOKEN_INVALID
    assert len(transport.calls) == attempts
    if block_reason is None:
        assert not _block_path(cfg).exists()
    else:
        assert json.loads(_block_path(cfg).read_text(encoding="utf-8")) == _block(
            TODAY, block_reason
        )


@pytest.mark.parametrize(
    ("outcome", "message"),
    [
        pytest.param(http_error(503, "detail"), "stress_data: HTTP 503", id="5xx"),
        pytest.param(http_error(400, "detail"), "stress_data: HTTP 400", id="4xx"),
        pytest.param(http_error(429), "stress_data: HTTP 429", id="429"),
        pytest.param(
            library_requests.ConnectionError("x"),
            "stress_data: 상태 코드 없음",
            id="no-status",
        ),
    ],
)
def test_data_error_message_has_endpoint_and_status_only(
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    outcome: BaseException,
    message: str,
):
    transport.reply(STRESS_PATH, outcome)

    with adapter.open_session() as session, pytest.raises(DomainError) as excinfo:
        session.fetch_day("stress_data", DAY)

    assert str(excinfo.value) == message


def test_unclassified_data_error_propagates(
    monkeypatch: pytest.MonkeyPatch,
    cfg: config.Config,
    adapter: garmin.GarminAdapter,
):
    # display name이 문자열이 아니면 라이브러리의 URL 만들기(quote)가 TypeError를 낸다.
    stub = GarminTransport()
    monkeypatch.setattr(
        garmin, "_new_client", lambda: transport_client(stub, display_name=12345)
    )

    with adapter.open_session() as session, pytest.raises(TypeError) as excinfo:
        session.fetch_day("sleep_data", DAY)

    assert not isinstance(excinfo.value, DomainError)
    assert stub.calls == []
    assert not _block_path(cfg).exists()


def test_library_id_validation_error_propagates(
    adapter: garmin.GarminAdapter, transport: GarminTransport
):
    with adapter.open_session() as session, pytest.raises(ValueError):
        session.fetch_activity("activity", -1)
    assert transport.calls == []


@pytest.mark.parametrize("bad", [datetime(2026, 10, 15, tzinfo=UTC), "2026-10-15"])
def test_fetch_day_requires_plain_date(
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    sleeps: list[float],
    bad: object,
):
    with adapter.open_session() as session, pytest.raises(TypeError):
        session.fetch_day("stress_data", bad)  # type: ignore[arg-type]
    assert transport.calls == []
    assert sleeps == []


@pytest.mark.parametrize(
    ("method", "endpoint"),
    [
        ("fetch_day", "steps_data"),
        ("fetch_day", "activity"),
        ("fetch_day", "get_sleep_data"),
        ("fetch_activity", "sleep_data"),
        ("fetch_activity", "activity_exercise_set"),
    ],
)
def test_unknown_endpoint_is_value_error_without_wait(
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    sleeps: list[float],
    method: str,
    endpoint: str,
):
    key: object = DAY if method == "fetch_day" else ACTIVITY_ID

    with adapter.open_session() as session, pytest.raises(ValueError, match=endpoint):
        getattr(session, method)(endpoint, key)

    assert transport.calls == []
    assert sleeps == []


# --- 당일 차단과 연속 403 ----------------------------------------------------------------


@pytest.mark.parametrize(
    ("outcome", "reason"),
    [
        pytest.param(http_error(429), RunStatus.RATE_LIMITED, id="rate-limited"),
        pytest.param(TooMany("Too many"), RunStatus.RATE_LIMITED, id="too-many"),
    ],
)
def test_rate_limit_blocks_rest_of_session_and_account(
    cfg: config.Config,
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    sleeps: list[float],
    outcome: BaseException,
    reason: RunStatus,
):
    transport.reply(STRESS_PATH, outcome)

    with adapter.open_session() as session:
        with pytest.raises(RateLimited):
            session.fetch_day("stress_data", DAY)
        assert _lock_held(cfg) is True
        calls, waits = len(transport.calls), len(sleeps)
        for endpoint in ("hrv_data", "activity"):
            with pytest.raises(garmin.SessionBlocked) as excinfo:
                _fetch(session, endpoint)
            assert excinfo.value.reason is reason
        assert len(transport.calls) == calls
        assert len(sleeps) == waits

    assert json.loads(_block_path(cfg).read_text(encoding="utf-8")) == _block(
        TODAY, reason.value
    )
    assert adapter.blocked_today() is reason
    with pytest.raises(garmin.SessionBlocked), adapter.open_session():
        pytest.fail("차단이 기록되면 다음 세션은 열리면 안 된다")


def test_three_consecutive_403_become_blocked_403(
    cfg: config.Config,
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    caplog: pytest.LogCaptureFixture,
):
    caplog.set_level(logging.INFO, logger="garmin_pipeline.garmin")
    for endpoint in ("sleep_data", "hrv_data", "rhr_day"):
        transport.reply(DAY_REQUESTS[endpoint][0], http_error(403))

    with adapter.open_session() as session:
        for endpoint in ("sleep_data", "hrv_data"):
            with pytest.raises(Rejected):
                session.fetch_day(endpoint, DAY)
            assert not _block_path(cfg).exists()
        with pytest.raises(Blocked403) as excinfo:
            session.fetch_day("rhr_day", DAY)
        calls = len(transport.calls)
        with pytest.raises(garmin.SessionBlocked) as blocked:
            session.fetch_activity("activity", ACTIVITY_ID)
        assert len(transport.calls) == calls

    _assert_domain(excinfo.value, Blocked403)
    assert str(excinfo.value) == "rhr_day: HTTP 403"
    assert blocked.value.reason is RunStatus.BLOCKED_403
    assert json.loads(_block_path(cfg).read_text(encoding="utf-8")) == _block(
        TODAY, "blocked_403"
    )
    assert "consecutive_403=1" in caplog.text
    assert "consecutive_403=3" in caplog.text
    assert "reason=blocked_403" in caplog.text


@pytest.mark.parametrize(
    "between",
    [
        pytest.param({"ok": 1}, id="success"),
        pytest.param(None, id="no-data"),
        pytest.param(http_error(404), id="http-404"),
        pytest.param(http_error(400), id="other-4xx"),
        pytest.param(http_error(503), id="transient"),
        pytest.param(http_error(401), id="auth-failed"),
    ],
)
def test_other_result_resets_consecutive_403(
    cfg: config.Config,
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    between: object,
):
    transport.reply(STRESS_PATH, http_error(403))
    transport.reply(DAY_REQUESTS["hrv_data"][0], between)

    with adapter.open_session() as session:
        outcomes: list[str] = []
        for endpoint in ("stress_data", "hrv_data", "stress_data", "stress_data"):
            try:
                session.fetch_day(endpoint, DAY)
            except DomainError as error:
                outcomes.append(type(error).__name__)
            else:
                outcomes.append("ok")

    assert outcomes[0] == outcomes[2] == outcomes[3] == "Rejected"
    assert not _block_path(cfg).exists()


def test_unclassified_error_keeps_consecutive_403(
    make_cfg: Callable[..., config.Config], monkeypatch: pytest.MonkeyPatch
):
    cfg = make_cfg(max_consecutive_403=2)
    stub = GarminTransport()
    stub.reply(STRESS_PATH, http_error(403))
    # stress_data는 display name을 쓰지 않고, sleep_data는 라이브러리 안에서(요청 전에) TypeError가
    # 난다. Garmin 응답이 아니므로 연속 403을 늘리지도 되돌리지도 않는다.
    monkeypatch.setattr(
        garmin, "_new_client", lambda: transport_client(stub, display_name=12345)
    )

    with garmin.GarminAdapter(cfg, sleep=lambda _: None).open_session() as session:
        with pytest.raises(Rejected):
            session.fetch_day("stress_data", DAY)
        with pytest.raises(TypeError):
            session.fetch_day("sleep_data", DAY)
        with pytest.raises(Blocked403):
            session.fetch_day("stress_data", DAY)

    assert len(stub.calls) == 2


def test_consecutive_403_is_counted_per_session(
    cfg: config.Config, adapter: garmin.GarminAdapter, transport: GarminTransport
):
    transport.reply(STRESS_PATH, http_error(403))

    for _ in range(2):
        with adapter.open_session() as session:
            for _ in range(2):
                with pytest.raises(Rejected):
                    session.fetch_day("stress_data", DAY)

    assert not _block_path(cfg).exists()


def test_max_consecutive_403_of_one_blocks_first_403(
    make_cfg: Callable[..., config.Config], transport: GarminTransport
):
    cfg = make_cfg(max_consecutive_403=1)
    transport.reply(ACTIVITY_REQUESTS["activity_details"][0], http_error(403))

    with (
        garmin.GarminAdapter(cfg, sleep=lambda _: None).open_session() as session,
        pytest.raises(Blocked403),
    ):
        session.fetch_activity("activity_details", ACTIVITY_ID)

    assert garmin.GarminAdapter(cfg).blocked_today() is RunStatus.BLOCKED_403


SETS = "activity_exercise_sets"
SETS_PATH = ACTIVITY_REQUESTS[SETS][0]


def _outcome(session: garmin.GarminSession, endpoint: str) -> str:
    """호출 하나의 결과 이름(`ok` 또는 도메인 오류 이름)."""
    try:
        _fetch(session, endpoint)
    except DomainError as error:
        return type(error).__name__
    return "ok"


def test_first_call_403_is_rejected_without_promotion(
    cfg: config.Config,
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    caplog: pytest.LogCaptureFixture,
):
    caplog.set_level(logging.INFO, logger="garmin_pipeline.garmin")
    transport.reply(SETS_PATH, http_error(403))

    with adapter.open_session(first_call_endpoints=(SETS,)) as session:
        outcomes = [_outcome(session, SETS) for _ in range(4)]

    assert cfg.max_consecutive_403 == 3
    assert outcomes == ["Rejected"] * 4
    assert [path for path, _ in transport.calls] == [SETS_PATH] * 4
    assert not _block_path(cfg).exists()
    assert adapter.blocked_today() is None
    assert "consecutive_403=1" not in caplog.text
    # 보호 403은 연속 403에 세지 않았음을 로그 필드로 밝힌다.
    assert caplog.text.count("consecutive_403=0 first_call=True") == 4
    assert "first_call=False" not in caplog.text


def test_first_call_403_neither_counts_nor_resets_other_403(
    cfg: config.Config, adapter: garmin.GarminAdapter, transport: GarminTransport
):
    transport.reply(STRESS_PATH, http_error(403))
    transport.reply(SETS_PATH, http_error(403))

    with adapter.open_session(first_call_endpoints=[SETS]) as session:
        outcomes = [
            _outcome(session, endpoint)
            for endpoint in ("stress_data", SETS, "stress_data", "stress_data")
        ]

    assert outcomes == ["Rejected", "Rejected", "Rejected", "Blocked403"]
    assert json.loads(_block_path(cfg).read_text(encoding="utf-8")) == _block(
        TODAY, "blocked_403"
    )


def test_first_call_success_still_resets_consecutive_403(
    cfg: config.Config, adapter: garmin.GarminAdapter, transport: GarminTransport
):
    transport.reply(STRESS_PATH, http_error(403))
    transport.reply(SETS_PATH, {"exerciseSets": [{"setType": "ACTIVE"}]})

    with adapter.open_session(first_call_endpoints={SETS}) as session:
        outcomes = [
            _outcome(session, endpoint)
            for endpoint in ("stress_data", "stress_data", SETS, "stress_data")
        ]
        outcomes.append(_outcome(session, "stress_data"))

    assert outcomes == ["Rejected", "Rejected", "ok", "Rejected", "Rejected"]
    assert not _block_path(cfg).exists()


def test_sets_403_without_protection_is_promoted(
    cfg: config.Config, adapter: garmin.GarminAdapter, transport: GarminTransport
):
    transport.reply(SETS_PATH, http_error(403))

    with adapter.open_session() as session:
        outcomes = [_outcome(session, SETS) for _ in range(3)]

    assert outcomes == ["Rejected", "Rejected", "Blocked403"]
    assert adapter.blocked_today() is RunStatus.BLOCKED_403


@pytest.mark.parametrize(
    "endpoints",
    [("nope",), (SETS, "exercise_sets"), "activity"],
    ids=["unknown", "one-unknown", "bare-string"],
)
def test_unknown_first_call_endpoint_is_value_error_before_lock(
    cfg: config.Config,
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    sleeps: list[float],
    endpoints: object,
):
    with (
        pytest.raises(ValueError, match="모르는 endpoint"),
        adapter.open_session(first_call_endpoints=endpoints),  # type: ignore[arg-type]
    ):
        pytest.fail("모르는 endpoint면 세션이 열리면 안 된다")

    assert not _lock_path(cfg).exists()
    assert transport.calls == []
    assert sleeps == []


def test_first_call_429_still_blocks(
    cfg: config.Config,
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    sleeps: list[float],
):
    transport.reply(SETS_PATH, http_error(429))

    with adapter.open_session(first_call_endpoints=(SETS,)) as session:
        with pytest.raises(RateLimited) as excinfo:
            session.fetch_activity(SETS, ACTIVITY_ID)
        calls = len(transport.calls)
        with pytest.raises(garmin.SessionBlocked):
            session.fetch_activity(SETS, ACTIVITY_ID)
        assert len(transport.calls) == calls

    _assert_domain(excinfo.value, RateLimited)
    assert json.loads(_block_path(cfg).read_text(encoding="utf-8")) == _block(
        TODAY, "rate_limited"
    )


def test_data_block_write_failure_still_raises_and_blocks_session(
    cfg: config.Config,
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
):
    transport.reply(STRESS_PATH, http_error(429))

    def fail(*args: object) -> None:
        raise PermissionError(13, "Permission denied")

    monkeypatch.setattr(garmin, "_write_block", fail)

    with adapter.open_session() as session:
        with pytest.raises(RateLimited):
            session.fetch_day("stress_data", DAY)
        with pytest.raises(garmin.SessionBlocked):
            session.fetch_day("hrv_data", DAY)

    assert "errno=13" in caplog.text
    assert not _block_path(cfg).exists()
    assert len(transport.calls) == 1


def test_data_block_is_written_while_lock_is_held(
    cfg: config.Config,
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    monkeypatch: pytest.MonkeyPatch,
):
    transport.reply(STRESS_PATH, http_error(429))
    original = garmin._write_block
    held: list[bool] = []

    def write_block(*args: object) -> None:
        held.append(_lock_held(cfg))
        original(*args)  # type: ignore[arg-type]

    monkeypatch.setattr(garmin, "_write_block", write_block)

    with adapter.open_session() as session, pytest.raises(RateLimited):
        session.fetch_day("stress_data", DAY)

    assert held == [True]


# --- 호출 간격 ----------------------------------------------------------------------------


def test_pause_before_every_data_call(
    make_cfg: Callable[..., config.Config], transport: GarminTransport
):
    cfg = make_cfg(call_pause_min_seconds=1, call_pause_max_seconds=2)
    pauses: list[tuple[float, int]] = []
    transport.reply(STRESS_PATH, {"ok": 1})
    transport.reply(ACTIVITY_REQUESTS["activity"][0], {"ok": 2})
    adapter = garmin.GarminAdapter(
        cfg, sleep=lambda seconds: pauses.append((seconds, len(transport.calls)))
    )

    with adapter.open_session() as session:
        assert pauses == []  # 로그인 전에는 쉬지 않는다.
        session.fetch_day("stress_data", DAY)
        with pytest.raises(NoData):
            session.fetch_day("hrv_data", DAY)
        session.fetch_activity("activity", ACTIVITY_ID)

    assert len(pauses) == 3
    # 쉰 다음에 Garmin에 닿는다(쉴 때까지의 전송 호출 수가 0, 1, 2).
    assert [calls for _, calls in pauses] == [0, 1, 2]
    assert all(1 <= seconds <= 2 for seconds, _ in pauses)


def test_pause_uses_configured_range(
    make_cfg: Callable[..., config.Config],
    transport: GarminTransport,
    monkeypatch: pytest.MonkeyPatch,
):
    cfg = make_cfg(call_pause_min_seconds=0.5, call_pause_max_seconds=1.5)
    ranges: list[tuple[float, float]] = []

    def uniform(low: float, high: float) -> float:
        ranges.append((low, high))
        return 0.75

    monkeypatch.setattr(garmin.random, "uniform", uniform)
    transport.reply(STRESS_PATH, {"ok": 1})
    pauses: list[float] = []

    with garmin.GarminAdapter(cfg, sleep=pauses.append).open_session() as session:
        session.fetch_day("stress_data", DAY)

    assert ranges == [(0.5, 1.5)]
    assert pauses == [0.75]


def test_library_retries_do_not_use_the_pause(
    adapter: garmin.GarminAdapter, transport: GarminTransport, sleeps: list[float]
):
    transport.reply(STRESS_PATH, http_error(503))

    with adapter.open_session() as session, pytest.raises(Transient):
        session.fetch_day("stress_data", DAY)

    assert len(transport.calls) == 4
    assert len(sleeps) == 1


# --- 데이터 로그 위생 ---------------------------------------------------------------------


@pytest.mark.parametrize(
    ("endpoint", "outcome", "expected"),
    [
        pytest.param(
            "stress_data",
            http_error(400, f"{SECRETS[0]} {SECRETS[1]} {SECRETS[2]}"),
            Rejected,
            id="rejected",
        ),
        pytest.param(
            "stress_data",
            http_error(503, f"{SECRETS[0]} {SECRETS[2]}"),
            Transient,
            id="transient",
        ),
        pytest.param(
            "stress_data",
            library_requests.ConnectionError(f"{SECRETS[1]} {SECRETS[0]}"),
            Transient,
            id="network",
        ),
        pytest.param(
            "stress_data",
            http_error(429, SECRETS[2]),
            RateLimited,
            id="rate-limited",
        ),
        pytest.param(
            "stress_data",
            http_error(401, SECRETS[0]),
            AuthFailed,
            id="auth-failed",
        ),
        pytest.param(
            "user_summary",
            {"privacyProtected": True, "userName": SECRETS[1], "token": SECRETS[0]},
            AuthFailed,
            id="privacy-protected",
        ),
        pytest.param(
            "activity",
            http_error(404, SECRETS[2]),
            NoData,
            id="no-data",
        ),
    ],
)
def test_data_logs_and_errors_hold_no_library_text(
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    caplog: pytest.LogCaptureFixture,
    endpoint: str,
    outcome: object,
    expected: type[DomainError],
):
    caplog.set_level(logging.DEBUG, logger="garmin_pipeline.garmin")
    transport.reply({**DAY_REQUESTS, **ACTIVITY_REQUESTS}[endpoint][0], outcome)

    with adapter.open_session() as session, pytest.raises(expected) as excinfo:
        _fetch(session, endpoint)

    # 라이브러리 자신의 로거(garminconnect)는 범위 밖이다(deferred-work: 1.6 login이 정한다).
    ours = [r for r in caplog.records if r.name == "garmin_pipeline.garmin"]
    assert ours, "실패는 로그에 남는다"
    text = "\n".join(record.getMessage() for record in ours)
    assert expected.__name__ in text
    assert f"endpoint={endpoint}" in text
    for forbidden in (*SECRETS, D, str(ACTIVITY_ID), DN):
        assert forbidden not in text
        assert forbidden not in str(excinfo.value)
        assert forbidden not in repr(excinfo.value)


def test_successful_call_logs_nothing_about_payload(
    adapter: garmin.GarminAdapter,
    transport: GarminTransport,
    caplog: pytest.LogCaptureFixture,
):
    caplog.set_level(logging.DEBUG, logger="garmin_pipeline.garmin")
    transport.reply(STRESS_PATH, {"body": SECRETS[2], "email": SECRETS[1]})

    with adapter.open_session() as session:
        session.fetch_day("stress_data", DAY)

    ours = "\n".join(
        r.getMessage() for r in caplog.records if r.name == "garmin_pipeline.garmin"
    )
    for forbidden in (*SECRETS, D):
        assert forbidden not in ours


# --- FakeGarmin 데이터 대역 ---------------------------------------------------------------


def test_fake_session_returns_injected_payload_and_records_calls():
    payload = {"calendarDate": D}
    rejected = Rejected("activity: HTTP 400")
    fake = FakeGarmin(
        responses={("stress_data", DAY): payload, ("activity", ACTIVITY_ID): rejected}
    )

    with fake.open_session() as session:
        raw = session.fetch_day("stress_data", DAY)
        with pytest.raises(NoData):
            session.fetch_day("hrv_data", DAY)
        with pytest.raises(Rejected) as excinfo:
            session.fetch_activity("activity", ACTIVITY_ID)
        with pytest.raises(ValueError):
            session.fetch_day("nope", DAY)

    assert raw == garmin.RawResponse("stress_data", payload, garmin.LIBRARY_VERSION)
    assert raw.payload is payload
    assert excinfo.value is rejected
    assert fake.calls == [
        "open_session",
        ("stress_data", DAY),
        ("hrv_data", DAY),
        ("activity", ACTIVITY_ID),
        "close_session",
    ]


def test_fake_garmin_records_first_call_endpoints():
    fake = FakeGarmin(responses={(SETS, ACTIVITY_ID): Rejected(f"{SETS}: HTTP 403")})

    with fake.open_session():
        pass
    with fake.open_session(first_call_endpoints=[SETS]) as session:
        # 대역은 연속 403 승격을 흉내 내지 않고 주입한 예외를 그대로 던진다.
        for _ in range(4):
            with pytest.raises(Rejected):
                session.fetch_activity(SETS, ACTIVITY_ID)

    assert fake.first_call_endpoints == [frozenset(), frozenset({SETS})]
    assert fake.blocked is None
    calls = list(fake.calls)
    # 실제 어댑터와 같이 모르는 이름은 기록 없이 `ValueError`다.
    with (
        pytest.raises(ValueError, match="모르는 endpoint"),
        fake.open_session(first_call_endpoints=["nope"]),
    ):
        pytest.fail("모르는 endpoint면 세션이 열리면 안 된다")
    assert fake.calls == calls
    assert len(fake.first_call_endpoints) == 2


@pytest.mark.parametrize(
    ("error", "reason"),
    [
        (RateLimited("stress_data: HTTP 429"), RunStatus.RATE_LIMITED),
        (Blocked403("stress_data: HTTP 403"), RunStatus.BLOCKED_403),
    ],
)
def test_fake_session_mimics_block_file(error: DomainError, reason: RunStatus):
    fake = FakeGarmin(responses={("stress_data", DAY): error})

    with fake.open_session() as session:
        with pytest.raises(type(error)):
            session.fetch_day("stress_data", DAY)
        with pytest.raises(garmin.SessionBlocked) as excinfo:
            session.fetch_activity("activity", ACTIVITY_ID)
        assert excinfo.value.reason is reason

    assert fake.blocked is reason
    assert fake.blocked_today() is reason
    assert ("activity", ACTIVITY_ID) not in fake.calls
    with pytest.raises(garmin.SessionBlocked), fake.open_session():
        pytest.fail("차단 뒤 세션은 열리면 안 된다")


@pytest.mark.parametrize("bad", [datetime(2026, 10, 15, tzinfo=UTC), "2026-10-15"])
def test_fake_session_requires_plain_date(bad: object):
    fake = FakeGarmin(responses={("stress_data", bad): {"ok": 1}})

    with fake.open_session() as session:
        before = list(fake.calls)
        with pytest.raises(TypeError):
            session.fetch_day("stress_data", bad)  # type: ignore[arg-type]
        assert fake.calls == before


def test_fake_session_applies_payload_rules():
    fake = FakeGarmin(
        responses={
            ("stress_data", DAY): [],
            ("user_summary", DAY): {"privacyProtected": True},
            ("activity", ACTIVITY_ID): {},
        }
    )

    with fake.open_session() as session:
        with pytest.raises(NoData):
            session.fetch_day("stress_data", DAY)
        with pytest.raises(AuthFailed) as excinfo:
            session.fetch_day("user_summary", DAY)
        with pytest.raises(NoData):
            session.fetch_activity("activity", ACTIVITY_ID)

    assert excinfo.value.reason is AuthFailedReason.PRIVACY_PROTECTED
    assert fake.blocked is None


def test_transport_client_is_real_library_without_network():
    stub = GarminTransport()
    client = transport_client(stub)

    assert isinstance(client, garminconnect.Garmin)
    assert client.retry_attempts == 3  # 라이브러리 기본값 그대로
    assert client.login("ignored") == (None, None)
    with pytest.raises(garminconnect.GarminConnectNotFoundError):
        client.get_stress_data(D)
    assert stub.calls == [(STRESS_PATH, None)]


# --- 토큰 파일 시각 -----------------------------------------------------------------------

TOKEN_FILENAME = "garmin_tokens.json"
TOKEN_MTIME_NS = 1_791_000_000_123_456_789


def test_token_filename_matches_library(tmp_path: Path):
    assert garmin.TOKEN_FILENAME == TOKEN_FILENAME
    existing = tmp_path / "tokens"
    existing.mkdir()
    for tokenstore in (existing, tmp_path / "not-yet"):
        path = garminconnect.client.token_file_path(str(tokenstore))
        assert path == tokenstore / garmin.TOKEN_FILENAME


def test_token_saved_at_reads_mtime_in_ms_without_reading_content(cfg: config.Config):
    path = cfg.tokenstore / TOKEN_FILENAME
    path.write_bytes(b"{not json")
    os.utime(path, ns=(TOKEN_MTIME_NS, TOKEN_MTIME_NS))

    assert garmin.token_saved_at(cfg) == TOKEN_MTIME_NS // 1_000_000


@pytest.mark.parametrize("state", ["no-file", "no-tokenstore", "tokenstore-is-file"])
def test_token_saved_at_without_file_is_none(cfg: config.Config, state: str):
    if state != "no-file":
        cfg.tokenstore.rmdir()
    if state == "tokenstore-is-file":
        cfg.tokenstore.write_bytes(b"")

    assert garmin.token_saved_at(cfg) is None


@pytest.mark.skipif(os.geteuid() == 0, reason="root는 권한 검사를 건너뛴다")
def test_token_saved_at_unreadable_tokenstore_is_none_with_errno_only(
    cfg: config.Config, caplog: pytest.LogCaptureFixture
):
    caplog.set_level(logging.WARNING, logger="garmin_pipeline")
    (cfg.tokenstore / TOKEN_FILENAME).write_bytes(b"{}")
    cfg.tokenstore.chmod(0)
    try:
        assert garmin.token_saved_at(cfg) is None
    finally:
        cfg.tokenstore.chmod(0o700)

    (record,) = caplog.records
    assert record.getMessage() == "토큰 파일 시각을 읽지 못했다: errno=13"


# --- 대화형 로그인 -------------------------------------------------------------------------
LOGIN_EMAIL = "runner-7c1e@example.com"
LOGIN_PASSWORD = "pw-9d2b-correct-horse"


@pytest.fixture
def login_stubs(
    monkeypatch: pytest.MonkeyPatch,
) -> Callable[..., list[StubLoginClient]]:
    """`garmin._new_client`를 `StubLoginClient(**kwargs)` 생성으로 바꾸고 만든 목록을 준다."""

    def install(**kwargs: object) -> list[StubLoginClient]:
        created: list[StubLoginClient] = []

        def new_client() -> StubLoginClient:
            client = StubLoginClient(**kwargs)  # type: ignore[arg-type]
            created.append(client)
            return client

        monkeypatch.setattr(garmin, "_new_client", new_client)
        return created

    return install


def _prompts(*codes: str | BaseException, **kwargs: object) -> ScriptedPrompts:
    return ScriptedPrompts(LOGIN_EMAIL, LOGIN_PASSWORD, codes, **kwargs)  # type: ignore[arg-type]


def _other_fd_can_lock(cfg: config.Config) -> bool:
    """다른 fd가 세션 락 파일에 `flock(LOCK_EX | LOCK_NB)`을 잡을 수 있으면 참이다(잡았다 푼다)."""
    fd = os.open(_lock_path(cfg), os.O_RDWR | os.O_CREAT, 0o600)
    try:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return False
        fcntl.flock(fd, fcntl.LOCK_UN)
        return True
    finally:
        os.close(fd)


def _token_path(cfg: config.Config) -> Path:
    return cfg.tokenstore / TOKEN_FILENAME


def test_interactive_login_takes_prompts_not_credentials():
    assert list(inspect.signature(garmin.interactive_login).parameters) == [
        "cfg",
        "prompts",
    ]
    for method in (garmin.LoginPrompts.credentials, garmin.LoginPrompts.mfa_code):
        assert list(inspect.signature(method).parameters) == ["self"]
    assert isinstance(_prompts(), garmin.LoginPrompts)
    assert garmin.MFA_MAX_ATTEMPTS == 3

    # 모듈이 정의한 공개 함수·클래스(메서드 포함) 어디에도 비밀번호·이메일 파라미터가 없다.
    names: list[str] = []
    for name, value in vars(garmin).items():
        if (
            name.startswith("_")
            or getattr(value, "__module__", None) != garmin.__name__
        ):
            continue
        functions = [value] if inspect.isfunction(value) else []
        if inspect.isclass(value):
            functions += [f for _, f in inspect.getmembers(value, inspect.isfunction)]
        for function in functions:
            names += list(inspect.signature(function).parameters)
    assert names
    assert not [
        name
        for name in names
        if any(word in name.lower() for word in ("password", "email", "secret"))
    ]


def test_mfa_login_runs_network_under_lock_and_prompts_outside(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    observed: list[tuple[str, bool]] = []
    created = login_stubs(observe=lambda name: observed.append((name, _lock_held(cfg))))
    prompts = _prompts(
        GOOD_MFA_CODE,
        on_prompt=lambda name: observed.append((name, _lock_held(cfg))),
    )

    garmin.interactive_login(cfg, prompts)

    assert observed == [
        ("credentials", False),
        ("login", True),
        ("mfa_code", False),
        ("resume", True),
        ("profile", True),
        ("dump", True),
    ]
    (client,) = created
    assert client.login_calls == [
        {
            "email": LOGIN_EMAIL,
            "password": LOGIN_PASSWORD,
            "prompt_mfa": None,
            "return_on_mfa": True,
        }
    ]
    assert client.resume_calls == [(None, GOOD_MFA_CODE)]
    assert client.dump_calls == [str(cfg.tokenstore)]
    assert (
        json.loads(_token_path(cfg).read_text(encoding="utf-8")) == FAKE_TOKEN_PAYLOAD
    )
    assert stat.S_IMODE(_token_path(cfg).stat().st_mode) == 0o600
    assert _lock_held(cfg) is False
    assert not _block_path(cfg).exists()


def test_other_fd_can_take_lock_while_prompting(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    login_stubs(mfa_results={"000000": AuthError("MFA failed"), GOOD_MFA_CODE: None})
    lockable: list[tuple[str, bool]] = []
    prompts = _prompts(
        "000000",
        GOOD_MFA_CODE,
        on_prompt=lambda name: lockable.append((name, _other_fd_can_lock(cfg))),
    )

    garmin.interactive_login(cfg, prompts)

    assert lockable == [("credentials", True), ("mfa_code", True), ("mfa_code", True)]


def test_login_without_mfa_checks_profile_then_writes_tokens(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    observed: list[tuple[str, bool]] = []
    created = login_stubs(
        needs_mfa=False, observe=lambda name: observed.append((name, _lock_held(cfg)))
    )
    prompts = _prompts()

    garmin.interactive_login(cfg, prompts)

    assert observed == [("login", True), ("profile", True), ("dump", True)]
    assert prompts.calls == ["credentials"]
    assert created[0].resume_calls == []
    assert (
        json.loads(_token_path(cfg).read_text(encoding="utf-8")) == FAKE_TOKEN_PAYLOAD
    )
    assert _lock_held(cfg) is False


def test_wrong_mfa_code_is_asked_again_on_same_instance(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    created = login_stubs()
    prompts = _prompts("000000", "111111", GOOD_MFA_CODE)

    garmin.interactive_login(cfg, prompts)

    (client,) = created
    assert prompts.calls == ["credentials", "mfa_code", "mfa_code", "mfa_code"]
    assert [code for _, code in client.resume_calls] == [
        "000000",
        "111111",
        GOOD_MFA_CODE,
    ]
    assert len(client.login_calls) == 1
    assert client.events == ["login", "resume", "resume", "resume", "profile", "dump"]
    assert _token_path(cfg).is_file()


def test_three_wrong_mfa_codes_fail_without_tokens(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    created = login_stubs()
    prompts = _prompts("000000", "111111", "222222")

    with pytest.raises(AuthFailed) as excinfo:
        garmin.interactive_login(cfg, prompts)

    assert excinfo.value.reason is AuthFailedReason.TOKEN_INVALID
    assert excinfo.value.__cause__ is None
    assert excinfo.value.__suppress_context__ is True
    assert prompts.calls.count("mfa_code") == 3
    assert len(created[0].resume_calls) == 3
    assert created[0].dump_calls == []
    assert not _token_path(cfg).exists()
    assert not _block_path(cfg).exists()
    assert _lock_held(cfg) is False


def test_auth_failure_after_mfa_passed_is_not_retried(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    created = login_stubs(profile_error=AuthError("Failed to retrieve social profile"))
    prompts = _prompts(GOOD_MFA_CODE, GOOD_MFA_CODE)

    with pytest.raises(AuthFailed):
        garmin.interactive_login(cfg, prompts)

    assert prompts.calls == ["credentials", "mfa_code"]
    assert created[0].events == ["login", "resume", "profile"]
    assert not _token_path(cfg).exists()


@pytest.mark.parametrize("reason", [RunStatus.RATE_LIMITED, RunStatus.BLOCKED_403])
def test_block_today_refuses_before_prompting(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    reason: RunStatus,
):
    raw = _write_block(cfg, _block(TODAY, reason))
    created = login_stubs()
    prompts = _prompts(GOOD_MFA_CODE)

    with pytest.raises(garmin.SessionBlocked) as excinfo:
        garmin.interactive_login(cfg, prompts)

    assert excinfo.value.reason is reason
    assert prompts.calls == []
    assert created == []
    assert _block_path(cfg).read_bytes() == raw


def test_past_block_does_not_stop_login(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    _write_block(cfg, _block(YESTERDAY))
    login_stubs()

    garmin.interactive_login(cfg, _prompts(GOOD_MFA_CODE))

    assert _token_path(cfg).is_file()


def test_invalid_block_file_refuses_before_prompting(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    _write_block(cfg, b"{not json")
    created = login_stubs()
    prompts = _prompts()

    with pytest.raises(garmin.BlockFileInvalid):
        garmin.interactive_login(cfg, prompts)

    assert prompts.calls == []
    assert created == []


def test_block_written_during_credentials_prompt_is_rechecked_under_lock(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    created = login_stubs()
    prompts = _prompts(on_prompt=lambda name: _write_block(cfg, _block(TODAY)))

    with pytest.raises(garmin.SessionBlocked):
        garmin.interactive_login(cfg, prompts)

    assert prompts.calls == ["credentials"]
    assert created == []
    assert _lock_held(cfg) is False


def test_block_written_during_mfa_prompt_skips_resume(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    created = login_stubs()

    def on_prompt(name: str) -> None:
        if name == "mfa_code":
            _write_block(cfg, _block(TODAY, "blocked_403"))

    with pytest.raises(garmin.SessionBlocked) as excinfo:
        garmin.interactive_login(cfg, _prompts(GOOD_MFA_CODE, on_prompt=on_prompt))

    assert excinfo.value.reason is RunStatus.BLOCKED_403
    assert created[0].events == ["login"]
    assert not _token_path(cfg).exists()


@pytest.mark.parametrize(
    ("make_error", "expected", "block_reason"),
    [
        pytest.param(
            lambda: TooMany("All login strategies rate limited (429)."),
            RateLimited,
            "rate_limited",
            id="429",
        ),
        pytest.param(
            lambda: _with_response(ConnError("Login failed"), 403),
            Blocked403,
            "blocked_403",
            id="403-response",
        ),
        pytest.param(
            lambda: ConnError("All login strategies exhausted: API Error 403"),
            Blocked403,
            "blocked_403",
            id="403-message",
        ),
        pytest.param(
            lambda: AuthError("Invalid credentials"),
            AuthFailed,
            None,
            id="wrong-credentials",
        ),
        pytest.param(
            lambda: _caused(ConnError("x"), library_requests.ConnectionError("down")),
            Transient,
            None,
            id="network",
        ),
    ],
)
def test_credential_login_error_classification(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    make_error: Callable[[], BaseException],
    expected: type[DomainError],
    block_reason: str | None,
):
    created = login_stubs(login_error=make_error())
    prompts = _prompts(GOOD_MFA_CODE)

    with pytest.raises(expected) as excinfo:
        garmin.interactive_login(cfg, prompts)

    assert type(excinfo.value) is expected
    assert excinfo.value.__cause__ is None
    assert prompts.calls == ["credentials"]
    assert created[0].events == ["login"]
    assert not _token_path(cfg).exists()
    assert _lock_held(cfg) is False
    if block_reason is None:
        assert not _block_path(cfg).exists()
    else:
        assert json.loads(_block_path(cfg).read_text(encoding="utf-8")) == _block(
            TODAY, block_reason
        )


@pytest.mark.parametrize(
    ("error", "expected", "blocked"),
    [
        pytest.param(TooMany("MFA verify returned 429"), RateLimited, True, id="429"),
        pytest.param(ConnError("API Error 503"), Transient, False, id="503"),
    ],
)
def test_mfa_error_other_than_wrong_code_stops_immediately(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    error: BaseException,
    expected: type[DomainError],
    blocked: bool,
):
    created = login_stubs(mfa_results={"999999": error})
    prompts = _prompts("999999", GOOD_MFA_CODE)

    with pytest.raises(expected):
        garmin.interactive_login(cfg, prompts)

    assert prompts.calls == ["credentials", "mfa_code"]
    assert len(created[0].resume_calls) == 1
    assert _block_path(cfg).exists() is blocked
    assert not _token_path(cfg).exists()
    assert _lock_held(cfg) is False


def test_profile_check_failure_without_mfa_writes_no_tokens(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    created = login_stubs(
        needs_mfa=False, profile_error=AuthError("Failed to retrieve user settings")
    )

    with pytest.raises(AuthFailed):
        garmin.interactive_login(cfg, _prompts())

    assert created[0].events == ["login", "profile"]
    assert not _token_path(cfg).exists()


def test_token_write_oserror_propagates_unclassified(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    original = PermissionError(13, "Permission denied")
    login_stubs(dump_error=original)

    with pytest.raises(PermissionError) as excinfo:
        garmin.interactive_login(cfg, _prompts(GOOD_MFA_CODE))

    assert excinfo.value is original
    assert not _block_path(cfg).exists()
    assert _lock_held(cfg) is False


def test_unclassified_interactive_login_error_propagates(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    original = TypeError("unexpected keyword")
    login_stubs(login_error=original)

    with pytest.raises(TypeError) as excinfo:
        garmin.interactive_login(cfg, _prompts())

    assert excinfo.value is original
    assert _lock_held(cfg) is False


def test_prompt_exception_propagates_and_releases_lock(
    cfg: config.Config, login_stubs: Callable[..., list[StubLoginClient]]
):
    created = login_stubs()

    with pytest.raises(EOFError):
        garmin.interactive_login(cfg, _prompts(EOFError()))

    assert created[0].events == ["login"]
    assert _lock_held(cfg) is False


@pytest.mark.parametrize("enabled", [True, False])
def test_interactive_login_cffi_api_session(
    make_cfg: Callable[..., config.Config],
    login_stubs: Callable[..., list[StubLoginClient]],
    enabled: bool,
):
    cfg = make_cfg(cffi_api_session=enabled)
    created = login_stubs(needs_mfa=False)

    garmin.interactive_login(cfg, _prompts())

    (at_login,) = created[0].api_session_at_login
    if enabled:
        assert isinstance(at_login, cffi_requests.Session)
        assert at_login.discard_cookies is True
    else:
        assert at_login is ORIGINAL_API_SESSION


def test_interactive_login_lock_timeout_creates_no_client(
    make_cfg: Callable[..., config.Config],
    login_stubs: Callable[..., list[StubLoginClient]],
    holder: Callable[[Path], subprocess.Popen[str]],
):
    cfg = make_cfg(lock_wait_seconds=0)
    holder(_lock_path(cfg))
    created = login_stubs()
    prompts = _prompts()

    with pytest.raises(garmin.SessionLockTimeout):
        garmin.interactive_login(cfg, prompts)

    assert prompts.calls == ["credentials"]
    assert created == []


@pytest.mark.parametrize("existing", [b"{not json", json.dumps({"di_token": "old"})])
def test_existing_token_file_is_not_read_and_is_replaced(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    existing: str | bytes,
):
    raw = existing if isinstance(existing, bytes) else existing.encode()
    _token_path(cfg).write_bytes(raw)
    created = login_stubs()

    garmin.interactive_login(cfg, _prompts(GOOD_MFA_CODE))

    assert len(created[0].login_calls) == 1
    assert (
        json.loads(_token_path(cfg).read_text(encoding="utf-8")) == FAKE_TOKEN_PAYLOAD
    )


def test_interactive_login_logs_hold_no_secrets(
    cfg: config.Config,
    login_stubs: Callable[..., list[StubLoginClient]],
    caplog: pytest.LogCaptureFixture,
):
    caplog.set_level(logging.DEBUG)
    wrong_code = "804213"
    good_code = "377155"
    secrets = (LOGIN_EMAIL, LOGIN_PASSWORD, wrong_code, good_code, *SECRETS)
    login_stubs(
        mfa_results={
            wrong_code: AuthError(f"MFA failed for {LOGIN_EMAIL} {SECRETS[2]}"),
            good_code: None,
        }
    )

    garmin.interactive_login(cfg, _prompts(wrong_code, good_code))

    login_stubs(
        login_error=_caused(
            AuthError(f"Failed {LOGIN_EMAIL}:{LOGIN_PASSWORD}"),
            ConnError(f"API Error 429 - {SECRETS[0]}"),
        )
    )
    with pytest.raises(RateLimited) as excinfo:
        garmin.interactive_login(cfg, _prompts())

    assert all(record.name == "garmin_pipeline.garmin" for record in caplog.records)
    assert "mfa=True" in caplog.text
    assert "attempt=1" in caplog.text
    assert "attempts=2" in caplog.text
    assert "RateLimited" in caplog.text
    for secret in secrets:
        assert secret not in caplog.text
        assert secret not in str(excinfo.value)
        assert secret not in repr(excinfo.value)
