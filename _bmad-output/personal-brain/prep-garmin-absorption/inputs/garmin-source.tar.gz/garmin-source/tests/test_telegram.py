"""로컬 Bot API와 가짜 세션만 사용한다. 실제 Telegram 호출은 없다."""

import json
import logging
import socket
import threading
from email.parser import BytesParser
from email.policy import default
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from types import SimpleNamespace

import pytest

from garmin_pipeline import ports

R = ports.errors.DeliveryReason
TOKEN = "fake-bot-secret-7f21"
CHAT = "fake-chat-secret-3c82"


@pytest.fixture
def credentials(tmp_path):
    # macOS /var는 symlink이므로 명시적으로 실제 경로를 사용한다.
    folder = tmp_path.resolve() / "tokens"
    folder.mkdir()
    path = folder / "telegram.json"
    path.write_text(json.dumps({"bot_token": TOKEN, "chat_id": CHAT}))
    path.chmod(0o600)
    return folder


@pytest.fixture
def bot_api():
    state = SimpleNamespace(
        status=200, body=b'{"ok":true}', calls=[], on_request=lambda: None
    )

    class Handler(BaseHTTPRequestHandler):
        def do_POST(self):
            raw = self.rfile.read(int(self.headers["Content-Length"]))
            content_type = self.headers["Content-Type"]
            if content_type.startswith("multipart/"):
                message = BytesParser(policy=default).parsebytes(
                    f"Content-Type: {content_type}\r\n\r\n".encode() + raw
                )
                payload = {}
                for part in message.iter_parts():
                    name = part.get_param("name", header="content-disposition")
                    payload[name] = (
                        part.get_payload(decode=True)
                        if part.get_filename()
                        else part.get_content()
                    )
            else:
                payload = json.loads(raw)
            state.calls.append((self.path, payload))
            state.on_request()
            self.send_response(state.status)
            self.end_headers()
            self.wfile.write(state.body)

        def log_message(self, *args):
            pass

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    state.base = f"http://127.0.0.1:{server.server_port}"
    yield state
    server.shutdown()
    server.server_close()
    thread.join()


def send(folder, *, session=None, api_base="http://127.0.0.1:1", text="message"):
    return ports.telegram.TelegramAdapter(
        folder, session=session, api_base=api_base
    ).send_message(text, timeout_seconds=2)


@pytest.mark.parametrize(
    ("status", "body", "expected"),
    [
        (200, b'{"ok":true}', None),
        (201, b'{"ok":true}', None),
        (400, b"private response", R.HTTP_4XX),
        (502, b"private response", R.HTTP_5XX),
        (429, b'{"retry_after":10}', R.RATE_LIMITED),
        (200, b'{"ok":false}', R.HTTP_5XX),
        (200, b"not json", R.HTTP_5XX),
        (200, b"[]", R.HTTP_5XX),
        (200, b'{"ok":1}', R.HTTP_5XX),
        (302, b"redirect", R.HTTP_5XX),
    ],
)
def test_http_classification(
    credentials, bot_api, status, body, expected, caplog, capsys
):
    caplog.set_level(logging.WARNING, logger="garmin_pipeline")
    bot_api.status, bot_api.body = status, body
    assert send(credentials, api_base=bot_api.base) == expected
    assert bot_api.calls == [
        (f"/bot{TOKEN}/sendMessage", {"chat_id": CHAT, "text": "message"})
    ]
    output = caplog.text + str(capsys.readouterr())
    assert (
        TOKEN not in output and CHAT not in output and "private response" not in output
    )


def test_timeout_and_redirect_options_and_secret_reload(credentials):
    calls = []

    def post(url, **kwargs):
        calls.append((url, kwargs))
        return SimpleNamespace(status_code=200, json=lambda: {"ok": True})

    session = SimpleNamespace(post=post)
    adapter = ports.telegram.TelegramAdapter(
        credentials, api_base="http://local", session=session
    )
    assert adapter.send_message("hello", timeout_seconds=3) is None
    assert calls[0][1] == {
        "json": {"chat_id": CHAT, "text": "hello"},
        "timeout": (1.5, 1.5),
        "allow_redirects": False,
    }
    (credentials / "telegram.json").write_text('{"bot_token":"changed", "chat_id":123}')
    assert adapter.send_message("hello", timeout_seconds=3) is None
    assert calls[1][0] == "http://local/botchanged/sendMessage"
    assert calls[1][1]["json"]["chat_id"] == 123


@pytest.mark.parametrize(
    "data",
    [
        [],
        {},
        {"bot_token": "a"},
        {"bot_token": "", "chat_id": 1},
        {"bot_token": 3, "chat_id": 1},
        {"bot_token": "a", "chat_id": True},
        {"bot_token": "a", "chat_id": " "},
        {"bot_token": "a", "chat_id": []},
        None,
    ],
)
def test_invalid_data_never_posts(credentials, data):
    (credentials / "telegram.json").write_text(json.dumps(data))
    assert (
        send(
            credentials,
            session=SimpleNamespace(post=lambda *a, **k: pytest.fail("network")),
        )
        == R.INVALID_CONFIG
    )


@pytest.mark.parametrize(
    "problem", ["mode", "file_link", "parent_link", "broken", "missing", "unreadable"]
)
def test_invalid_file_never_posts(credentials, problem, monkeypatch):
    path = credentials / "telegram.json"
    if problem == "mode":
        path.chmod(0o644)
    elif problem == "file_link":
        target = path.with_name("other.json")
        path.rename(target)
        path.symlink_to(target)
    elif problem == "parent_link":
        target = credentials.with_name("real")
        credentials.rename(target)
        credentials.symlink_to(target, target_is_directory=True)
    elif problem == "broken":
        path.write_text("{bad")
    elif problem == "missing":
        path.unlink()
    else:

        def denied(*args, **kwargs):
            raise PermissionError(TOKEN + CHAT)

        monkeypatch.setattr(ports.telegram.os, "open", denied)
    assert (
        send(
            credentials,
            session=SimpleNamespace(post=lambda *a, **k: pytest.fail("network")),
        )
        == R.INVALID_CONFIG
    )


@pytest.mark.parametrize(
    ("text", "expected"),
    [("a" * 4097, R.TOO_LARGE), ("😀" * 2048 + "a", R.TOO_LARGE), ("😀" * 2048, None)],
)
def test_utf16_limit(credentials, text, expected):
    calls = []

    def post(*args, **kwargs):
        calls.append(kwargs)
        return SimpleNamespace(status_code=200, json=lambda: {"ok": True})

    assert send(credentials, session=SimpleNamespace(post=post), text=text) == expected
    assert len(calls) == (expected is None)


def test_closed_port(credentials, caplog):
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    assert send(credentials, api_base=f"http://127.0.0.1:{port}") == R.NETWORK
    assert TOKEN not in caplog.text and CHAT not in caplog.text


def test_exception_message_never_logged(credentials, caplog, capsys):
    def fail(*args, **kwargs):
        raise OSError(TOKEN + CHAT)

    assert send(credentials, session=SimpleNamespace(post=fail)) == R.NETWORK
    assert "OSError" in caplog.text
    assert TOKEN not in caplog.text + str(capsys.readouterr())
    assert CHAT not in caplog.text


def test_source_boundary():
    import ast
    from pathlib import Path

    root = Path(__file__).resolve().parents[1] / "src" / "garmin_pipeline"
    for path in root.rglob("*.py"):
        text = path.read_text()
        if path.name != "telegram.py":
            assert "api.telegram.org" not in text
            for node in ast.walk(ast.parse(text)):
                if isinstance(node, ast.Import):
                    assert all(alias.name != "requests" for alias in node.names)
                if isinstance(node, ast.ImportFrom):
                    assert node.module != "requests"
    lock = (root.parents[1] / "uv.lock").read_text()
    for framework in ("python-telegram-bot", "pytelegrambotapi", "aiogram"):
        assert f'name = "{framework}"' not in lock


@pytest.mark.parametrize(
    ("status", "expected"),
    [(200, None), (429, "rate_limited"), (400, "http_4xx"), (502, "http_5xx")],
)
def test_collect_committed_before_post_and_idempotent(
    credentials, bot_api, write_config, monkeypatch, caplog, capsys, status, expected
):
    from dataclasses import replace
    from datetime import UTC, datetime

    from garmin_fakes import FakeGarmin

    from garmin_pipeline import cli, collect, config, dates, errors, store

    cfg = replace(
        config.load(write_config(lock_wait_seconds=6)), tokenstore=credentials
    )
    monkeypatch.setattr(dates, "_utc_now", lambda: datetime(2026, 10, 16, tzinfo=UTC))
    bot_api.status = status
    seen = []

    def check_committed():
        with store.read_connection(cfg) as other:
            seen.append(other.execute("SELECT event FROM notification").fetchall())

    bot_api.on_request = check_committed
    sender = ports.TelegramNoticeSender(credentials, api_base=bot_api.base)
    factory = lambda conn: ports.TelegramNotifier(conn, sender, budget_seconds=3)
    with cli._command_log(cfg, "collect"):
        for _ in range(2):
            fake = FakeGarmin(
                open_error=errors.AuthFailed(errors.AuthFailedReason.TOKEN_INVALID)
            )
            assert collect.collect(cfg, fake, force=True, notifier_factory=factory) == 0
    assert seen == [[("auth_failed",)]]
    assert len(bot_api.calls) == 1
    text = bot_api.calls[0][1]["text"]
    assert "2026-10-16" in text and "auth_failed" in text
    assert "사유: token_invalid" in text
    with store.read_connection(cfg) as conn:
        assert conn.execute("SELECT kind,event,ok,reason FROM delivery").fetchall() == [
            ("notify", "auth_failed", int(expected is None), expected)
        ]
        db_text = str(conn.execute("SELECT * FROM notification").fetchall())
        db_text += str(conn.execute("SELECT * FROM delivery").fetchall())
        db_text += str(conn.execute("SELECT detail FROM run").fetchall())
    all_text = (
        db_text
        + caplog.text
        + str(capsys.readouterr())
        + (cfg.data_dir / "logs/collect.log").read_text()
    )
    assert TOKEN not in all_text and CHAT not in all_text


@pytest.mark.parametrize("environment", ["dev", "runtime"])
@pytest.mark.parametrize("exists", [False, True])
@pytest.mark.parametrize("pytest_active", [False, True])
def test_cli_selection(write_config, monkeypatch, environment, exists, pytest_active):
    import sqlite3
    from dataclasses import replace

    from garmin_pipeline import cli, config

    cfg = replace(config.load(write_config()), environment=environment)
    if exists:
        cfg.tokenstore.mkdir(parents=True, exist_ok=True)
        (cfg.tokenstore / "telegram.json").symlink_to("missing.json")
    monkeypatch.setattr(config, "under_pytest", lambda: pytest_active)
    enabled = environment == "runtime" and exists and not pytest_active
    assert isinstance(cli._notice_sender(cfg), ports.TelegramNoticeSender) is enabled
    assert isinstance(cli._report_sink(cfg), ports.TelegramReportSink) is enabled
    factory = cli._notifier_factory(cfg)
    with sqlite3.connect(":memory:") as conn:
        notifier = factory(conn)
    assert isinstance(
        notifier, ports.TelegramNotifier if enabled else ports.TableNotifier
    )
    if not enabled:
        assert factory is ports.TableNotifier


def test_requests_import_failure_is_network(credentials, monkeypatch, caplog):
    import builtins

    original_import = builtins.__import__

    def import_without_requests(name, *args, **kwargs):
        if name == "requests":
            raise ImportError(TOKEN + CHAT)
        return original_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", import_without_requests)
    assert send(credentials) == R.NETWORK
    assert "ImportError" in caplog.text
    assert TOKEN not in caplog.text and CHAT not in caplog.text


@pytest.mark.parametrize("replacement", ["symlink", "insecure_file"])
def test_credentials_swap_before_open_is_rejected(
    credentials, monkeypatch, replacement
):
    path = credentials / "telegram.json"
    original_open = ports.telegram.os.open

    def swap_then_open(candidate, flags):
        target = path.with_name("original.json")
        path.rename(target)
        if replacement == "symlink":
            path.symlink_to(target)
        else:
            path.write_text(target.read_text())
            path.chmod(0o644)
        return original_open(candidate, flags)

    monkeypatch.setattr(ports.telegram.os, "open", swap_then_open)
    assert (
        send(
            credentials,
            session=SimpleNamespace(post=lambda *a, **k: pytest.fail("network")),
        )
        == R.INVALID_CONFIG
    )


def test_credentials_read_from_checked_descriptor(credentials, monkeypatch):
    path = credentials / "telegram.json"
    original_fstat = ports.telegram.os.fstat

    def swap_after_open(fd):
        mode = original_fstat(fd)
        path.rename(path.with_name("original.json"))
        path.write_text('{"bot_token":"swapped", "chat_id":123}')
        path.chmod(0o600)
        return mode

    monkeypatch.setattr(ports.telegram.os, "fstat", swap_after_open)
    calls = []

    def post(url, **kwargs):
        calls.append((url, kwargs["json"]))
        return SimpleNamespace(status_code=200, json=lambda: {"ok": True})

    assert send(credentials, session=SimpleNamespace(post=post)) is None
    assert calls == [
        (
            f"http://127.0.0.1:1/bot{TOKEN}/sendMessage",
            {"chat_id": CHAT, "text": "message"},
        )
    ]


@pytest.mark.parametrize("sizes", [(12, 13), (1, 11), ()])
def test_report_sink_multipart_order_and_records(
    credentials, bot_api, write_config, monkeypatch, sizes
):
    from datetime import date

    from garmin_pipeline import config, report, store

    cfg = config.load(write_config())
    day = date(2026, 10, 23)
    albums = []
    expected_photos = []
    for album_index, size in enumerate(sizes):
        album = []
        for photo_index in range(size):
            photo = credentials / f"graph-{album_index}-{photo_index}.png"
            content = f"synthetic-png-{album_index}-{photo_index}".encode()
            photo.write_bytes(content)
            album.append(photo)
            expected_photos.append(content)
        albums.append(tuple(album))
    document = credentials / "report.md"
    document.write_bytes(b"synthetic-report")
    sleeps = []
    monkeypatch.setattr(ports, "_sleep", sleeps.append)
    bot_api.on_request = lambda: assert_unlocked(cfg)

    def assert_unlocked(cfg):
        assert not store.write_lock_held(cfg)

    bundle = ports.ReportBundle(day, "[Garmin] summary", tuple(albums), document, True)
    ports.TelegramReportSink(
        credentials, record=report.delivery_recorder(cfg), api_base=bot_api.base
    ).deliver(bundle)
    expected = ["sendMessage"]
    for size in sizes:
        expected.extend(
            "sendPhoto" if min(10, size - offset) == 1 else "sendMediaGroup"
            for offset in range(0, size, 10)
        )
    expected.append("sendDocument")
    assert [url.rsplit("/", 1)[1] for url, _ in bot_api.calls] == expected
    assert sleeps == [1.0] * (len(expected) - 1)
    assert bot_api.calls[0][1]["text"] == "[재생성] [Garmin] summary"
    actual_photos = []
    for method, (_, payload) in zip(expected, bot_api.calls):
        assert "parse_mode" not in payload and "caption" not in payload
        if method == "sendMediaGroup":
            media = json.loads(payload["media"])
            assert 2 <= len(media) <= 10
            for entry in media:
                assert entry["media"].startswith("attach://")
                actual_photos.append(payload[entry["media"].removeprefix("attach://")])
        elif method == "sendPhoto":
            actual_photos.append(payload["photo"])
    assert actual_photos == expected_photos
    assert bot_api.calls[-1][1]["document"] == b"synthetic-report"
    with store.read_connection(cfg) as conn:
        rows = conn.execute(
            "SELECT kind, event, ok, reason FROM delivery ORDER BY id"
        ).fetchall()
    assert rows == [("report_text", None, 1, None)] + [
        ("report_album", None, 1, None)
    ] * (len(expected) - 2) + [("report_document", None, 1, None)]


@pytest.mark.parametrize(
    "method", ["send_message", "send_photo", "send_media_group", "send_document"]
)
@pytest.mark.parametrize(
    "status,expected",
    [
        (200, None),
        (403, R.HTTP_4XX),
        (503, R.HTTP_5XX),
        (429, R.RATE_LIMITED),
        (302, R.HTTP_5XX),
    ],
)
def test_all_methods_classify_and_hide_secrets(
    credentials, method, status, expected, caplog, capsys
):
    photo = credentials / "graph.png"
    photo.write_bytes(b"image")
    calls = []

    def post(url, **kwargs):
        calls.append(kwargs)
        return SimpleNamespace(status_code=status, json=lambda: {"ok": True})

    adapter = ports.telegram.TelegramAdapter(
        credentials, session=SimpleNamespace(post=post)
    )
    value = (
        "message"
        if method == "send_message"
        else (photo, photo)
        if method == "send_media_group"
        else photo
    )
    assert getattr(adapter, method)(value, timeout_seconds=30) == expected
    assert calls[0]["timeout"] == (15, 15)
    assert calls[0]["allow_redirects"] is False
    output = caplog.text + str(capsys.readouterr())
    assert TOKEN not in output and CHAT not in output
    (credentials / "telegram.json").chmod(0o644)
    assert getattr(adapter, method)(value, timeout_seconds=30) == R.INVALID_CONFIG
    assert len(calls) == 1


@pytest.mark.parametrize(
    "method", ["send_message", "send_photo", "send_media_group", "send_document"]
)
@pytest.mark.parametrize(
    "retry,second_status,expected,count",
    [
        (2, 200, None, 2),
        (0, 200, None, 2),
        (30, 200, None, 2),
        (60, 200, R.RATE_LIMITED, 1),
        (True, 200, R.RATE_LIMITED, 1),
        (-1, 200, R.RATE_LIMITED, 1),
        ("2", 200, R.RATE_LIMITED, 1),
        (2, 429, R.RATE_LIMITED, 2),
    ],
)
def test_rate_limit_retry_replays_uploads(
    credentials, monkeypatch, method, retry, second_status, expected, count
):
    path = credentials / "upload.png"
    path.write_bytes(b"complete-upload")
    calls, sleeps = [], []
    monkeypatch.setattr(ports.telegram, "_sleep", sleeps.append)

    def post(url, **kwargs):
        content = [stream.read() for _, stream in kwargs.get("files", {}).values()]
        calls.append(content)
        return SimpleNamespace(
            status_code=429 if len(calls) == 1 else second_status,
            json=lambda: {"ok": True, "parameters": {"retry_after": retry}},
        )

    adapter = ports.telegram.TelegramAdapter(
        credentials, session=SimpleNamespace(post=post)
    )
    value = (
        "message"
        if method == "send_message"
        else (path, path)
        if method == "send_media_group"
        else path
    )
    assert (
        getattr(adapter, method)(value, timeout_seconds=30, wait_rate_limit=True)
        == expected
    )
    assert len(calls) == count
    assert sleeps == ([retry] if count == 2 else [])
    assert all(content == calls[0] for content in calls)


@pytest.mark.parametrize(
    "method,limit",
    [("send_photo", 10), ("send_media_group", 10), ("send_document", 50)],
)
def test_upload_limits_and_local_failure(credentials, method, limit, caplog):
    path = credentials / "large.png"
    with path.open("wb") as stream:
        stream.truncate(limit * 1024 * 1024 + 1)
    adapter = ports.telegram.TelegramAdapter(
        credentials,
        session=SimpleNamespace(post=lambda *a, **kw: pytest.fail("network")),
    )
    value = (path, path) if method == "send_media_group" else path
    assert getattr(adapter, method)(value, timeout_seconds=30) == R.TOO_LARGE
    path.unlink()
    assert getattr(adapter, method)(value, timeout_seconds=30) == R.NETWORK
    assert "FileNotFoundError" in caplog.text


@pytest.mark.parametrize("size", [0, 1, 11])
def test_invalid_album_size_never_requests(credentials, size):
    adapter = ports.telegram.TelegramAdapter(
        credentials,
        session=SimpleNamespace(post=lambda *a, **kw: pytest.fail("network")),
    )
    assert (
        adapter.send_media_group((credentials / "missing",) * size, timeout_seconds=30)
        == R.TOO_LARGE
    )


@pytest.mark.parametrize("failure", ["exception", "http_5xx", "invalid_config"])
def test_report_sink_failure_continues(credentials, monkeypatch, failure, caplog):
    from datetime import date

    photo = credentials / "graph.png"
    photo.write_bytes(b"png")
    document = credentials / "report.md"
    document.write_text("report")
    calls, records = [], []
    monkeypatch.setattr(ports, "_sleep", lambda _: None)

    def post(*args, **kwargs):
        calls.append(kwargs)
        if failure == "exception":
            raise RuntimeError(TOKEN + CHAT)
        return SimpleNamespace(status_code=503, json=dict)

    if failure == "invalid_config":
        (credentials / "telegram.json").chmod(0o644)
    sink = ports.TelegramReportSink(
        credentials,
        record=lambda *args: records.append(args),
        session=SimpleNamespace(post=post),
    )
    sink.deliver(
        ports.ReportBundle(date(2026, 10, 23), "summary", ((photo,),), document, False)
    )
    expected = R.NETWORK if failure == "exception" else R(failure)
    assert [r[2] for r in records] == [expected] * 3
    assert len(calls) == (0 if failure == "invalid_config" else 3)
    assert TOKEN not in caplog.text and CHAT not in caplog.text


@pytest.mark.parametrize("failure", ["http_5xx", "network", "invalid_config"])
def test_cli_report_failed_delivery_preserves_report(
    credentials, bot_api, write_config, monkeypatch, caplog, capsys, failure
):
    from dataclasses import replace
    from datetime import date

    from garmin_pipeline import cli, config, report, store

    cfg = replace(
        config.load(write_config(report_wait_minutes=0)),
        environment="runtime",
        tokenstore=credentials,
    )
    day = date(2026, 10, 23)
    monkeypatch.setattr(report.dates, "today", lambda cfg: day)
    bot_api.status = 503
    if failure == "invalid_config":
        (credentials / "telegram.json").chmod(0o644)
    if failure == "network":

        def disconnected(*args, **kwargs):
            raise OSError(TOKEN + CHAT)

        session = SimpleNamespace(post=disconnected)
    else:
        session = None
    original = ports.TelegramReportSink
    monkeypatch.setattr(
        ports,
        "TelegramReportSink",
        lambda tokenstore, **kw: original(
            tokenstore, api_base=bot_api.base, session=session, **kw
        ),
    )
    monkeypatch.setattr(config, "under_pytest", lambda: False)
    monkeypatch.setattr(cli, "_load_config", lambda args: cfg)
    monkeypatch.setattr(report, "wait_for_collect", lambda *args: None)
    monkeypatch.setattr(
        report,
        "default_writer",
        lambda cfg: SimpleNamespace(
            write=lambda *a: report.DailyAnalysis("ok", "body", "summary"),
            period=lambda *a: report.DailyAnalysis("ok", "period", "period summary"),
        ),
    )
    monkeypatch.setattr(ports, "_sleep", lambda _: None)
    assert cli.main(["report"]) == 0
    assert report.report_path(cfg, day).exists()
    with store.read_connection(cfg) as conn:
        assert conn.execute(
            "SELECT kind,ok,reason,event FROM delivery ORDER BY id"
        ).fetchall() == [
            ("report_text", 0, failure, None),
            ("report_document", 0, failure, None),
        ]
        assert conn.execute("SELECT * FROM notification").fetchall() == []
    output = caplog.text + str(capsys.readouterr())
    assert TOKEN not in output and CHAT not in output


def test_notice_does_not_wait_on_short_rate_limit(credentials, monkeypatch):
    from datetime import date

    calls = []

    def post(*args, **kwargs):
        calls.append(kwargs)
        return SimpleNamespace(
            status_code=429, json=lambda: {"parameters": {"retry_after": 2}}
        )

    monkeypatch.setattr(
        ports.telegram, "_sleep", lambda _: pytest.fail("notice must not wait")
    )
    sender = ports.TelegramNoticeSender(credentials, session=SimpleNamespace(post=post))
    assert (
        sender.send(
            date(2026, 10, 23),
            ports.errors.NotifyEvent.REPORT_FAILED,
            "codex_failed",
            timeout_seconds=10,
        )
        == R.RATE_LIMITED
    )
    assert len(calls) == 1
