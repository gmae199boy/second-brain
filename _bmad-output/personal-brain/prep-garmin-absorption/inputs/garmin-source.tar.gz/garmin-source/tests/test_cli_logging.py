"""라이브러리 로그 차단(5.5, AD-20): `cli._command_log`가 라이브러리 로거 다섯을 명령 동안 막고 되돌리며,
로거 설정은 `cli`에만 있다.

실제 어댑터 시험은 실제 `garminconnect.Garmin()`에서 전송만 `GarminTransport`로 바꿔(백오프 0) 라이브러리의
재시도·`logger.warning`·`logger.exception`을 그대로 돌린다. 시계는 `dates._utc_now`만 바꾸고 `TZ`는 config
`timezone`(Asia/Seoul)으로 고정한다.
"""

import ast
import logging
import sqlite3
from collections.abc import Callable, Iterator
from datetime import UTC, date, datetime
from pathlib import Path

import pytest
import requests
from garmin_fakes import (
    FAKE_DISPLAY_NAME,
    GarminTransport,
    http_error,
    transport_client,
)

from garmin_pipeline import cli, config, dates, garmin, store

ROOT = Path(__file__).resolve().parents[1]
PACKAGE_DIR = ROOT / "src" / "garmin_pipeline"
LIBRARY_LOGGERS = ("garminconnect", "curl_cffi", "urllib3", "requests", "matplotlib")

# 서울 2026-10-16 10:00.
NOW = datetime(2026, 10, 16, 1, 0, tzinfo=UTC)
D = date(2026, 10, 16)
BODY_MARKER = "body-marker-3b9e"
SLEEP_PATH = f"/wellness-service/wellness/dailySleepData/{FAKE_DISPLAY_NAME}"
HRV_PATH = f"/hrv-service/hrv/{D.isoformat()}"


@pytest.fixture(autouse=True)
def library_loggers() -> Iterator[None]:
    """라이브러리 로거 다섯과 `garminconnect.client`의 전파·수준·처리기를 시험 뒤 되돌린다."""
    loggers = [
        logging.getLogger(name) for name in (*LIBRARY_LOGGERS, "garminconnect.client")
    ]
    saved = [(lg, lg.propagate, lg.level, list(lg.handlers)) for lg in loggers]
    yield
    for lg, propagate, level, handlers in saved:
        lg.propagate = propagate
        lg.setLevel(level)
        lg.handlers[:] = handlers


@pytest.fixture
def cfg(write_config: Callable[..., Path]) -> config.Config:
    return config.load(
        write_config(
            lock_wait_seconds=0,
            date_pause_seconds=0,
            call_pause_min_seconds=0,
            call_pause_max_seconds=0,
        )
    )


def test_library_logger_names_match_cli():
    assert cli._LIBRARY_LOGGERS == LIBRARY_LOGGERS


# --- 명령 동안·뒤 -----------------------------------------------------------------------------


def test_command_log_blocks_library_loggers(cfg: config.Config):
    with cli._command_log(cfg, "probe"):
        for name in LIBRARY_LOGGERS:
            lg = logging.getLogger(name)
            assert lg.propagate is False, name
            assert lg.getEffectiveLevel() > logging.CRITICAL, name
            assert not lg.isEnabledFor(logging.CRITICAL), name
        # 하위 로거는 따로 만지지 않아도 수준을 상속해 막힌다.
        child = logging.getLogger("garminconnect.client")
        assert child.level == logging.NOTSET
        assert child.getEffectiveLevel() > logging.CRITICAL
        assert not child.isEnabledFor(logging.CRITICAL)


@pytest.mark.parametrize("ending", ["normal", "exception"])
def test_command_log_restores_library_loggers(cfg: config.Config, ending: str):
    for name in LIBRARY_LOGGERS:
        lg = logging.getLogger(name)
        lg.propagate = True
        lg.setLevel(logging.DEBUG)
    logging.getLogger("garminconnect").propagate = False
    logging.getLogger("urllib3").setLevel(logging.ERROR)
    before = {
        name: (logging.getLogger(name).propagate, logging.getLogger(name).level)
        for name in LIBRARY_LOGGERS
    }
    handlers_before = {
        name: list(logging.getLogger(name).handlers) for name in LIBRARY_LOGGERS
    }

    if ending == "normal":
        with cli._command_log(cfg, "probe"):
            pass
    else:
        with (
            pytest.raises(RuntimeError, match="boom"),
            cli._command_log(cfg, "probe"),
        ):
            raise RuntimeError("boom")

    after = {
        name: (logging.getLogger(name).propagate, logging.getLogger(name).level)
        for name in LIBRARY_LOGGERS
    }
    assert after == before
    assert before["garminconnect"] == (False, logging.DEBUG)
    assert before["urllib3"] == (True, logging.ERROR)
    assert {
        name: list(logging.getLogger(name).handlers) for name in LIBRARY_LOGGERS
    } == handlers_before


# --- 실제 어댑터 collect의 로그 위생 ------------------------------------------------------------


def _run_failing_collect(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
) -> GarminTransport:
    """한 day 경로는 5xx, 다른 경로는 네트워크 오류를 계속 주는 실제 어댑터로 `collect`를 돈다."""
    monkeypatch.setattr(dates, "_utc_now", lambda: NOW)
    monkeypatch.setenv("TZ", "Asia/Seoul")
    cfg.tokenstore.mkdir()
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO meta (key, value) VALUES ('history_start', ?)",
            (D.isoformat(),),
        )
    transport = GarminTransport()
    transport.reply(SLEEP_PATH, http_error(500, detail=f"<html>{BODY_MARKER}</html>"))
    transport.reply(
        HRV_PATH,
        requests.ConnectionError(f"connection reset while reading {BODY_MARKER}"),
    )
    client = transport_client(transport)
    monkeypatch.setattr(garmin, "_new_client", lambda: client)

    assert cli.main(["collect", "--config", str(cfg.path)]) == 0

    # 라이브러리가 두 경로를 실제로 재시도했다(그때마다 경로·예외 문구를 WARNING으로 남기려 한다).
    attempts = client.retry_attempts + 1
    assert attempts > 1
    paths = [path for path, _ in transport.calls]
    assert paths.count(SLEEP_PATH) == attempts
    assert paths.count(HRV_PATH) == attempts
    return transport


def _leaks(text: str, transport: GarminTransport) -> list[str]:
    """`text`에 나타난 display name·호출된 URL 경로·본문 표식."""
    needles = {FAKE_DISPLAY_NAME, BODY_MARKER, *(path for path, _ in transport.calls)}
    return sorted(needle for needle in needles if needle in text)


def _records_text(caplog: pytest.LogCaptureFixture) -> str:
    return "\n".join([record.getMessage() for record in caplog.records] + [caplog.text])


def test_collect_5xx_and_network_failure_leave_no_library_log(
    cfg: config.Config,
    monkeypatch: pytest.MonkeyPatch,
    capfd: pytest.CaptureFixture[str],
    caplog: pytest.LogCaptureFixture,
):
    caplog.set_level(logging.DEBUG)

    transport = _run_failing_collect(cfg, monkeypatch)

    out, err = capfd.readouterr()
    log_text = (cfg.data_dir / "logs" / "collect.log").read_text("utf-8")
    assert _leaks(out + err, transport) == []
    assert _leaks(log_text, transport) == []
    assert _leaks(_records_text(caplog), transport) == []
    assert [r for r in caplog.records if r.name.split(".")[0] in LIBRARY_LOGGERS] == []

    # 어댑터·collect의 정제된 로그는 그대로 남는다.
    # 5xx는 상태 코드가 남고, 네트워크 오류는 상태 코드가 없다.
    for endpoint, status in (("sleep_data", "500"), ("hrv_data", "None")):
        assert (
            f"Garmin 데이터 호출 실패: stage=data endpoint={endpoint} status={status} "
            "error=Transient "
        ) in log_text, endpoint
        assert (
            f"항목 실패: scope=day key={D.isoformat()} endpoint={endpoint} "
            "error=Transient"
        ) in log_text
    assert "collect 끝: status=partial detail=transient=2" in log_text
    reader = sqlite3.connect(f"file:{cfg.db_path}?mode=ro", uri=True)
    try:
        assert reader.execute("SELECT status, detail FROM run").fetchall() == [
            ("partial", "transient=2")
        ]
    finally:
        reader.close()


def test_control_without_blocking_library_log_leaks(
    cfg: config.Config,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
):
    # 대조군: 막지 않으면 위 시험이 보는 곳에 라이브러리 기록이 실제로 나타난다.
    monkeypatch.setattr(cli, "_LIBRARY_LOGGERS", ())
    caplog.set_level(logging.DEBUG)

    transport = _run_failing_collect(cfg, monkeypatch)

    library_records = [r for r in caplog.records if r.name.startswith("garminconnect")]
    assert library_records
    text = "\n".join(r.getMessage() for r in library_records)
    assert SLEEP_PATH in text
    assert HRV_PATH in text
    assert BODY_MARKER in text
    assert _leaks(_records_text(caplog), transport)


# --- 로거 설정은 cli만 ------------------------------------------------------------------------

_LOGGER_METHODS = {"setLevel", "addHandler", "removeHandler"}
_LOGGING_FUNCTIONS = {"basicConfig", "disable"}
_LOGGER_ATTRIBUTES = {"propagate", "disabled", "level", "handlers", "lastResort"}


def _dotted(node: ast.expr) -> str | None:
    parts: list[str] = []
    while isinstance(node, ast.Attribute):
        parts.append(node.attr)
        node = node.value
    if not isinstance(node, ast.Name):
        return None
    parts.append(node.id)
    return ".".join(reversed(parts))


def _logger_config_sites(source: str, module: str) -> list[str]:
    """`source`에서 로거를 설정하는 문장의 `모듈:줄 설명` 목록."""
    sites: list[str] = []
    for node in ast.walk(ast.parse(source)):
        found: str | None = None
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
            name = _dotted(node.func) or node.func.attr
            if node.func.attr in _LOGGER_METHODS:
                found = f"{node.func.attr}() 호출"
            elif name in {
                f"logging.{f}" for f in _LOGGING_FUNCTIONS
            } or name.startswith("logging.config."):
                found = f"{name}() 호출"
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in _LOGGING_FUNCTIONS | {"dictConfig", "fileConfig"}:
                found = f"{node.func.id}() 호출"
        elif isinstance(node, ast.Assign | ast.AugAssign | ast.AnnAssign):
            targets = node.targets if isinstance(node, ast.Assign) else [node.target]
            for target in targets:
                for sub in ast.walk(target):
                    if (
                        isinstance(sub, ast.Attribute)
                        and sub.attr in _LOGGER_ATTRIBUTES
                    ):
                        found = f".{sub.attr} 대입"
        elif isinstance(node, ast.Import):
            if any(alias.name.startswith("logging.config") for alias in node.names):
                found = "logging.config import"
        elif isinstance(node, ast.ImportFrom):
            if (node.module or "").startswith("logging.config") or (
                node.module == "logging"
                and any(
                    alias.name in _LOGGING_FUNCTIONS | {"config"}
                    for alias in node.names
                )
            ):
                found = f"from {node.module} import"
        if found is not None:
            sites.append(f"{module}:{getattr(node, 'lineno', '?')} {found}")
    return sites


def test_only_cli_configures_loggers():
    modules = sorted(PACKAGE_DIR.rglob("*.py"))
    assert PACKAGE_DIR / "cli.py" in modules
    assert len(modules) > 10
    sites = [
        site
        for path in modules
        if path != PACKAGE_DIR / "cli.py"
        for site in _logger_config_sites(
            path.read_text(encoding="utf-8"), str(path.relative_to(ROOT))
        )
    ]
    assert sites == []


def test_cli_logger_config_is_seen_by_the_check():
    # 검사가 실제 설정 문장을 알아본다는 증거: cli 자신에는 설정이 있다.
    cli_sites = _logger_config_sites(
        (PACKAGE_DIR / "cli.py").read_text(encoding="utf-8"), "cli.py"
    )
    assert any("setLevel()" in site for site in cli_sites)
    assert any(".propagate 대입" in site for site in cli_sites)
    assert any("addHandler()" in site for site in cli_sites)


@pytest.mark.parametrize(
    ("statement", "kind"),
    [
        ("logger.setLevel(logging.DEBUG)", "setLevel() 호출"),
        ("logging.getLogger('x').addHandler(h)", "addHandler() 호출"),
        ("logger.removeHandler(h)", "removeHandler() 호출"),
        ("logging.basicConfig(level=10)", "logging.basicConfig() 호출"),
        ("logging.disable(50)", "logging.disable() 호출"),
        ("logging.config.dictConfig({})", "logging.config.dictConfig() 호출"),
        ("logger.propagate = False", ".propagate 대입"),
        ("logging.getLogger('x').disabled = True", ".disabled 대입"),
        ("logger.level = 10", ".level 대입"),
        ("logger.handlers = []", ".handlers 대입"),
        ("logging.lastResort = None", ".lastResort 대입"),
        ("from logging.config import dictConfig", "from logging.config import"),
        ("from logging import basicConfig", "from logging import"),
    ],
)
def test_logger_config_check_reports_module_and_line(statement: str, kind: str):
    source = f"import logging\n\n\ndef f(logger, h):\n    {statement}\n"

    assert _logger_config_sites(source, "garmin_pipeline/sample.py") == [
        f"garmin_pipeline/sample.py:5 {kind}"
    ]
