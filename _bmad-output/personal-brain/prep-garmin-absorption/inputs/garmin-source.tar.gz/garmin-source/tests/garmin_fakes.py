"""Garmin 테스트 대역.

- `FakeGarmin`·`FakeSession`: 호출자(collect·smoke 등) 테스트용 `GarminPort`·`GarminSession`
  구현. 네트워크·파일을 쓰지 않는다. `(endpoint, key)`별 payload·예외를 주입받는다.
- `StubGarminClient`: 어댑터 로그인 시험용 `garminconnect.Garmin` 대역. `garmin._new_client`
  seam만 이것으로 바꾼다. `login` 호출과 그 시점의 `client._api_session`을 기록하고 예외를
  주입받는다.
- `StubLoginClient`·`ScriptedPrompts`: 대화형 로그인(`interactive_login`·`auth.login`) 시험용
  `garminconnect.Garmin` 대역과 `LoginPrompts` 대역. 호출 순서를 `events`에 남기고, `observe`로
  각 호출·프롬프트 시점의 상태(세션 락 등)를 볼 수 있다.
- `GarminTransport`·`transport_client`: 어댑터 데이터 호출 시험용 전송 stub. 실제
  `garminconnect.Garmin()`의 `client.connectapi`(Client 쪽)만 바꿔 라이브러리의 실제 메서드·
  데코레이터·재시도가 돌게 한다.
"""

import contextlib
import json
import os
from collections.abc import Callable, Collection, Iterator, Mapping, Sequence
from datetime import date, datetime
from types import SimpleNamespace

import garminconnect

from garmin_pipeline import errors, garmin
from garmin_pipeline.garmin import (
    ACTIVITY_ENDPOINTS,
    DAY_ENDPOINTS,
    LIBRARY_VERSION,
    GarminSession,
    RawResponse,
    SessionBlocked,
)

_BLOCKING_ERRORS = {
    errors.RateLimited: errors.RunStatus.RATE_LIMITED,
    errors.Blocked403: errors.RunStatus.BLOCKED_403,
}


class FakeSession:
    """`FakeGarmin.open_session()`이 내주는 `GarminSession` 대역.

    `fake.responses[(endpoint, key)]`(day는 `date`, activity는 activityId)가 예외면 던지고, 값이면
    실제 세션과 같은 원문 검사(`None`·`[]`·`{}`면 `NoData`, `user_summary`의
    `privacyProtected: True`면 `AuthFailed(privacy_protected)`)를 거쳐 그대로
    `RawResponse.payload`에 담는다. 없으면 `NoData`다. 닿은 호출은 `fake.calls`에
    `(endpoint, key)`로 남는다. `RateLimited`·`Blocked403`을 던지면 `fake.blocked`를 그 사유로
    바꿔 어댑터의 `block.json`을 흉내 내고, 그 뒤 호출은 기록 없이 `SessionBlocked`다. 모르는
    endpoint는 `ValueError`, `day`가 순수 `date`가 아니면 `TypeError`이고 둘 다 기록하지 않는다.
    """

    def __init__(self, fake: "FakeGarmin") -> None:
        self._fake = fake

    def fetch_day(self, endpoint: str, day: date) -> RawResponse:
        if endpoint not in DAY_ENDPOINTS:
            raise ValueError(f"모르는 day endpoint다: {endpoint!r}")
        if not isinstance(day, date) or isinstance(day, datetime):
            raise TypeError(f"day는 date여야 한다: {type(day).__name__}")
        return self._fetch(endpoint, day)

    def fetch_activity(self, endpoint: str, activity_id: int) -> RawResponse:
        if endpoint not in ACTIVITY_ENDPOINTS:
            raise ValueError(f"모르는 activity endpoint다: {endpoint!r}")
        return self._fetch(endpoint, activity_id)

    def _fetch(self, endpoint: str, key: object) -> RawResponse:
        fake = self._fake
        if fake.blocked is not None:
            raise SessionBlocked(fake.blocked)
        fake.calls.append((endpoint, key))
        try:
            outcome = fake.responses[(endpoint, key)]
        except KeyError:
            raise errors.NoData(f"{endpoint}: 빈 응답") from None
        if isinstance(outcome, BaseException):
            for error_type, reason in _BLOCKING_ERRORS.items():
                if isinstance(outcome, error_type):
                    fake.blocked = reason
            raise outcome
        payload_error = garmin._check_payload(endpoint, outcome)
        if payload_error is not None:
            raise payload_error
        return RawResponse(endpoint, outcome, LIBRARY_VERSION)


class FakeGarmin:
    """`GarminPort` 대역.

    `calls`에 `"blocked_today"`·`"open_session"`·`"close_session"`과 세션 데이터 호출
    `(endpoint, key)`를 순서대로 남긴다. `block_error`(깨진 `block.json`의 `BlockFileInvalid` 등)가
    있으면 `blocked_today`가 기록한 뒤 그것을 던진다. `open_error`가 있으면 `open_session`이 그것을
    던지고, 없고 `block_error`가 있으면 그것을, 없고 `blocked`가 있으면 실제 어댑터처럼
    `SessionBlocked(blocked)`를 던진다. `responses`는 `FakeSession`이 쓰는 `(endpoint, key)` →
    payload 또는 예외다. `open_session(first_call_endpoints=...)`의 인자는 실제 어댑터와 같이
    검증하고(모르는 이름이면 기록 없이 `ValueError`), 열 때마다(다른 예외 전에)
    `first_call_endpoints`에 `frozenset`으로 남는다. 첫 호출 보호의 연속 403 예외는 흉내 내지
    않는다(`FakeSession`은 연속 403을 세지 않고 주입한 예외를 그대로 던진다).
    """

    def __init__(
        self,
        *,
        blocked: errors.RunStatus | None = None,
        block_error: BaseException | None = None,
        open_error: BaseException | None = None,
        responses: Mapping[tuple[str, object], object] | None = None,
    ) -> None:
        self.blocked = blocked
        self.block_error = block_error
        self.open_error = open_error
        self.responses: dict[tuple[str, object], object] = dict(responses or {})
        self.calls: list[str | tuple[str, object]] = []
        self.first_call_endpoints: list[frozenset[str]] = []
        self.session = FakeSession(self)

    def blocked_today(self) -> errors.RunStatus | None:
        self.calls.append("blocked_today")
        if self.block_error is not None:
            raise self.block_error
        return self.blocked

    @contextlib.contextmanager
    def open_session(
        self, *, first_call_endpoints: Collection[str] = ()
    ) -> Iterator[GarminSession]:
        first_call = garmin._first_call_endpoints(first_call_endpoints)
        self.calls.append("open_session")
        self.first_call_endpoints.append(first_call)
        if self.open_error is not None:
            raise self.open_error
        if self.block_error is not None:
            raise self.block_error
        if self.blocked is not None:
            raise SessionBlocked(self.blocked)
        try:
            yield self.session
        finally:
            self.calls.append("close_session")


ORIGINAL_API_SESSION = object()
"""`StubGarminClient`의 원래 `client._api_session` 자리 표시."""


class StubGarminClient:
    """`garminconnect.Garmin` 대역. 네트워크를 쓰지 않는다.

    `login_error`가 있으면 `login`이 그것을 던진다. `on_login`은 `login` 안에서(예외 전에)
    불린다. 세션 락을 쥐고 있는지 같은 그 시점의 상태를 볼 때 쓴다.
    """

    def __init__(
        self,
        *,
        login_error: BaseException | None = None,
        on_login: Callable[[], None] | None = None,
    ) -> None:
        self.client = SimpleNamespace(_api_session=ORIGINAL_API_SESSION)
        self.login_error = login_error
        self.on_login = on_login
        self.login_calls: list[object] = []
        self.api_session_at_login: list[object] = []

    def login(self, tokenstore: str | None = None) -> tuple[None, None]:
        self.login_calls.append(tokenstore)
        self.api_session_at_login.append(self.client._api_session)
        if self.on_login is not None:
            self.on_login()
        if self.login_error is not None:
            raise self.login_error
        return None, None


FAKE_TOKEN_PAYLOAD = {
    "di_token": "fake-di-token",
    "di_refresh_token": "fake-refresh-token",
    "di_client_id": "fake-client",
}
"""`StubLoginClient.client.dump`가 쓰는 가짜 토큰. 자격 증명은 담지 않는다."""

GOOD_MFA_CODE = "123456"
"""`StubLoginClient`가 기본으로 받아들이는 MFA 코드. 다른 코드는 틀린 코드다."""

Observer = Callable[[str], None]


class _StubLoginInner:
    """`StubLoginClient.client`(라이브러리 `Client`) 대역."""

    def __init__(self, outer: "StubLoginClient") -> None:
        self._outer = outer
        self._api_session: object = ORIGINAL_API_SESSION
        self._mfa_pending = False

    def login(
        self,
        email: str,
        password: str,
        prompt_mfa: object = None,
        return_on_mfa: bool = False,
    ) -> tuple[str | None, None]:
        outer = self._outer
        outer.login_calls.append(
            {
                "email": email,
                "password": password,
                "prompt_mfa": prompt_mfa,
                "return_on_mfa": return_on_mfa,
            }
        )
        outer.api_session_at_login.append(self._api_session)
        outer._event("login")
        if outer.login_error is not None:
            raise outer.login_error
        if outer.needs_mfa:
            self._mfa_pending = True
            return "needs_mfa", None
        return None, None

    def dump(self, path: str) -> None:
        """라이브러리처럼 `<path>/garmin_tokens.json`을 0600 임시 파일 + 교체로 쓴다."""
        outer = self._outer
        outer.dump_calls.append(path)
        outer._event("dump")
        if outer.dump_error is not None:
            raise outer.dump_error
        target = os.path.join(path, "garmin_tokens.json")
        temp = f"{target}.stub.tmp"
        fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            file.write(json.dumps(outer.token_payload))
        os.chmod(temp, 0o600)
        os.replace(temp, target)


class StubLoginClient:
    """대화형 로그인용 `garminconnect.Garmin` 대역. 네트워크를 쓰지 않는다.

    - `client.login(email, password, return_on_mfa=…)`: 인자를 `login_calls`에 남긴다.
      `login_error`가 있으면 던지고, `needs_mfa`면 `("needs_mfa", None)`, 아니면 `(None, None)`.
    - `resume_login(state, code)`: `mfa_results[code]`가 예외면 던지고 MFA 대기를 유지한다(틀린
      코드). 없는 코드는 `GarminConnectAuthenticationError`다. 맞으면 대기를 풀고 라이브러리처럼
      `_load_profile_and_settings()`를 부른다.
    - `_load_profile_and_settings()`: `profile_error`가 있으면 던진다.
    - `client.dump(path)`: `FAKE_TOKEN_PAYLOAD`(비밀번호 없음)를 0600으로 쓴다. `dump_error`면 던진다.
    - 토큰 파일을 읽는 `login(tokenstore)`는 부르면 실패한다.

    각 호출은 `events`에 이름(`login`·`resume`·`profile`·`dump`)으로 남고, 그 직전에
    `observe(이름)`이 불린다.
    """

    def __init__(
        self,
        *,
        needs_mfa: bool = True,
        login_error: BaseException | None = None,
        mfa_results: Mapping[str, BaseException | None] | None = None,
        profile_error: BaseException | None = None,
        dump_error: BaseException | None = None,
        token_payload: object = None,
        observe: Observer | None = None,
    ) -> None:
        self.needs_mfa = needs_mfa
        self.login_error = login_error
        self.mfa_results: dict[str, BaseException | None] = (
            {GOOD_MFA_CODE: None} if mfa_results is None else dict(mfa_results)
        )
        self.profile_error = profile_error
        self.dump_error = dump_error
        self.token_payload = (
            FAKE_TOKEN_PAYLOAD if token_payload is None else token_payload
        )
        self.observe = observe
        self.events: list[str] = []
        self.login_calls: list[dict[str, object]] = []
        self.api_session_at_login: list[object] = []
        self.resume_calls: list[tuple[object, str]] = []
        self.dump_calls: list[str] = []
        self.client = _StubLoginInner(self)

    def _event(self, name: str) -> None:
        if self.observe is not None:
            self.observe(name)
        self.events.append(name)

    def login(self, tokenstore: str | None = None) -> None:
        raise AssertionError("대화형 로그인이 토큰 파일 로그인(Garmin.login)을 불렀다")

    def resume_login(self, client_state: object, mfa_code: str) -> tuple[None, None]:
        self.resume_calls.append((client_state, mfa_code))
        self._event("resume")
        if not self.client._mfa_pending:
            raise garminconnect.GarminConnectAuthenticationError("no MFA pending")
        if mfa_code not in self.mfa_results:
            raise garminconnect.GarminConnectAuthenticationError("MFA failed")
        outcome = self.mfa_results[mfa_code]
        if outcome is not None:
            raise outcome
        self.client._mfa_pending = False
        self._load_profile_and_settings()
        return None, None

    def _load_profile_and_settings(self) -> None:
        self._event("profile")
        if self.profile_error is not None:
            raise self.profile_error


class ScriptedPrompts:
    """`LoginPrompts` 대역. 정해 둔 이메일·비밀번호·MFA 코드를 차례로 돌려준다.

    부를 때마다 `calls`에 `"credentials"`·`"mfa_code"`를 남기고, 그 직전에 `on_prompt(이름)`을
    부른다. 값 자리에 예외를 두면 그것을 던진다. MFA 코드가 바닥나면 테스트 실패다.
    """

    def __init__(
        self,
        email: str = "runner@example.com",
        password: str = "pw-correct-horse",
        codes: Sequence[str | BaseException] = (),
        *,
        credentials_error: BaseException | None = None,
        on_prompt: Observer | None = None,
    ) -> None:
        self.email = email
        self.password = password
        self.codes = list(codes)
        self.credentials_error = credentials_error
        self.on_prompt = on_prompt
        self.calls: list[str] = []

    def _prompt(self, name: str) -> None:
        if self.on_prompt is not None:
            self.on_prompt(name)
        self.calls.append(name)

    def credentials(self) -> tuple[str, str]:
        self._prompt("credentials")
        if self.credentials_error is not None:
            raise self.credentials_error
        return self.email, self.password

    def mfa_code(self) -> str:
        self._prompt("mfa_code")
        if not self.codes:
            raise AssertionError("준비한 MFA 코드보다 많이 물었다")
        code = self.codes.pop(0)
        if isinstance(code, BaseException):
            raise code
        return code


FAKE_DISPLAY_NAME = "runner-display"
"""`transport_client`가 라이브러리 클라이언트에 넣는 가짜 display name."""


def http_error(status: int, detail: str = "") -> BaseException:
    """`Client._run_request`가 HTTP `status`에 던지는 예외와 같은 모양(메시지 `API Error NNN`)."""
    message = f"API Error {status}" + (f" - {detail}" if detail else "")
    if status == 404:
        return garminconnect.GarminConnectNotFoundError(message)
    return garminconnect.GarminConnectConnectionError(message)


class GarminTransport:
    """`Client.connectapi(path, **kwargs)` 대역. 네트워크를 쓰지 않는다.

    `reply(path, *outcomes)`로 경로별 결과를 차례로 주입한다. 결과가 예외면 던지고, 값이면 디코드한
    JSON처럼 그대로 돌려준다. 마지막 결과는 다 쓴 뒤에도 반복한다. 주입하지 않은 경로는 실제
    서버처럼 404다. 호출은 `calls`에 `(path, params 사본)`으로 남는다.
    """

    def __init__(self) -> None:
        self.routes: dict[str, list[object]] = {}
        self.calls: list[tuple[str, dict[str, object] | None]] = []

    def reply(self, path: str, *outcomes: object) -> None:
        if not outcomes:
            raise ValueError("결과를 하나 이상 줘야 한다")
        self.routes[path] = list(outcomes)

    def connectapi(self, path: str, **kwargs: object) -> object:
        params = kwargs.get("params")
        self.calls.append((path, dict(params) if isinstance(params, dict) else None))
        outcomes = self.routes.get(path)
        if outcomes is None:
            raise http_error(404)
        outcome = outcomes.pop(0) if len(outcomes) > 1 else outcomes[0]
        if isinstance(outcome, BaseException):
            raise outcome
        return outcome


def transport_client(
    transport: GarminTransport, *, display_name: object = FAKE_DISPLAY_NAME
) -> garminconnect.Garmin:
    """실제 `garminconnect.Garmin()`에서 전송만 `transport`로 바꾼 클라이언트.

    `login`은 no-op이고 `display_name`은 가짜 값이다. 재시도 횟수는 라이브러리 기본값 그대로 두고
    백오프 대기만 0으로 둔다. 만들 때 네트워크를 쓰지 않는다.
    """
    client = garminconnect.Garmin(retry_min_wait=0, retry_max_wait=0)
    client.client.connectapi = transport.connectapi  # type: ignore[method-assign]
    client.login = lambda tokenstore=None: (None, None)  # type: ignore[method-assign]
    client.display_name = display_name  # type: ignore[assignment]
    return client
