"""Daily-analysis and body-intake skill boundaries and strict output contracts."""

import json
import re
from pathlib import Path

import jsonschema
import pytest

ROOT = Path(__file__).resolve().parents[1]
SCHEMAS = ROOT / "src/garmin_pipeline/schemas"


@pytest.mark.parametrize(
    "name,fields",
    [
        (
            "daily_analysis_output",
            {"status", "summary", "report_md", "judgments", "evidence", "next_checks"},
        ),
        (
            "period_review_output",
            {"status", "summary", "report_md", "judgments", "evidence", "next_checks"},
        ),
        ("body_intake_output", {"status", "detail"}),
    ],
)
def test_strict_schema(name, fields):
    schema = json.loads((SCHEMAS / f"{name}.schema.json").read_text())
    jsonschema.Draft202012Validator.check_schema(schema)
    assert set(schema["properties"]) == fields == set(schema["required"])
    assert schema["additionalProperties"] is False
    assert schema["properties"]["status"]["enum"] == ["ok", "failed"]
    example = dict.fromkeys(fields, "내용") | {"status": "ok"}
    example.update(
        {k: [] for k in ("judgments", "evidence", "next_checks") if k in fields}
    )
    jsonschema.validate(example, schema)
    for changed in (
        example | {"extra": 1},
        example | {"status": "insufficient"},
        {"status": "ok"},
    ):
        with pytest.raises(jsonschema.ValidationError):
            jsonschema.validate(changed, schema)


def test_skills_are_split_and_daily_scope_is_input_only():
    assert sorted(p.name for p in (ROOT / "skill").iterdir()) == [
        "garmin-body-intake",
        "garmin-daily-analysis",
        "garmin-period-review",
    ]
    text = (ROOT / "skill/garmin-daily-analysis/SKILL.md").read_text()
    assert "name: garmin-daily-analysis" in text
    for token in (
        "profile.md",
        "manifest.json",
        "digest.json",
        "labels/exercise_types_ko.json",
        "scratch/",
        "SQLite",
        "네트워크",
        "직전 7일",
        "진단",
        "유산소",
        "따로 걷기",
        "무게 제안",
        "daily_analysis_output.schema.json",
        "summary",
        "report_md",
    ):
        assert token in text
    assert "profile.json" not in text


def test_intake_retains_measurement_rules_and_cli_only_mutations():
    text = (ROOT / "skill/garmin-body-intake/SKILL.md").read_text()
    for token in (
        "body pending",
        "body write",
        "body reject",
        "--config config.toml",
        "첨부 순서",
        "단위",
        "반올림하지",
        "연도를 추론하지",
        "그대로 두",
        "body_intake_output.schema.json",
    ):
        assert token in text
    schema = json.loads((SCHEMAS / "body.schema.json").read_text())
    table_keys = set(re.findall(r"^\| `([a-z_]+)` \|", text, re.MULTILINE))
    assert table_keys == set(schema["$defs"]["measurement"]["properties"])


def test_repo_has_no_agents_folder():
    assert not (ROOT / ".agents/skills/garmin-daily-report").exists()


def test_period_skill_is_scoped_and_matches_evaluation_output():
    text = (ROOT / "skill/garmin-period-review/SKILL.md").read_text()
    for token in [
        "profile.md",
        "scope.json",
        "day_values.json",
        "evaluations.json",
        "previous.json",
        "날짜 계산",
        "actual_days",
        "partial_date",
        "가설",
        "직전 같은 길이 기간",
        "진단명",
        "유산소",
        "따로 걷기",
        "무게 제안",
        "scratch/",
        "SQLite",
        "네트워크",
        "요약",
        "항목별 판단",
        "근거 숫자 표",
        "다음에 확인할 것",
        "period_review_output.schema.json",
    ]:
        assert token in text


def test_daily_skill_uses_weight_and_preserves_missing_record_uncertainty():
    text = (ROOT / "skill/garmin-daily-analysis/SKILL.md").read_text()
    for phrase in (
        "`weight`",
        "그날 마지막 체중",
        "avg_7d_kg",
        "avg_7d_days",
        '"기록 없음"',
        "daily_weigh_ins",
        "lifestyle_logging_data",
    ):
        assert phrase in text
    progress = next(
        line for line in text.splitlines() if line.startswith("- **목표 진행:**")
    )
    assert "체중" in progress and "7일 평균" in progress
