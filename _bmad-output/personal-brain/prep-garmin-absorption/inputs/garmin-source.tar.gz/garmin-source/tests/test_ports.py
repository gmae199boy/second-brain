"""알림 교체 지점: 마이그레이션 `0005_notification`과 `ports.TableNotifier`(FR22, AD-10).

모두 패키지의 실제 마이그레이션 위에서 `write_session`으로 돈다. 시계는 `dates._utc_now`만 바꾼다.
"""

import sqlite3
from collections.abc import Callable
from datetime import UTC, date, datetime, timedelta
from pathlib import Path

import pytest

from garmin_pipeline import config, dates, errors, ports, store

NOW = datetime(2026, 10, 16, 1, 0, tzinfo=UTC)
NOW_MS = (NOW - datetime(1970, 1, 1, tzinfo=UTC)) // timedelta(milliseconds=1)
D = date(2026, 10, 16)


@pytest.fixture
def cfg(write_config: Callable[..., Path]) -> config.Config:
    return config.load(write_config(lock_wait_seconds=0))


@pytest.fixture
def clock(monkeypatch: pytest.MonkeyPatch) -> list[datetime]:
    current = [NOW]
    monkeypatch.setattr(dates, "_utc_now", lambda: current[0])
    return current


def _rows(conn: sqlite3.Connection) -> list[tuple]:
    return conn.execute(
        "SELECT local_date, event, detail, at FROM notification"
        " ORDER BY local_date, event"
    ).fetchall()


def test_notification_table_shape(cfg: config.Config):
    with store.write_session(cfg) as conn:
        columns = conn.execute("PRAGMA table_info(notification)").fetchall()
        indexes = conn.execute("PRAGMA index_list(notification)").fetchall()
        (unique,) = [name for _, name, is_unique, *_ in indexes if is_unique]
        unique_columns = [
            row[2] for row in conn.execute(f"PRAGMA index_info({unique})")
        ]

    assert [
        (name, kind, notnull, default) for _, name, kind, notnull, default, _ in columns
    ] == [
        ("local_date", "TEXT", 1, None),
        ("event", "TEXT", 1, None),
        ("detail", "TEXT", 1, "''"),
        ("at", "INTEGER", 1, None),
    ]
    assert unique_columns == ["local_date", "event"]


def test_event_check_allows_exactly_notify_events(cfg: config.Config):
    with store.write_session(cfg) as conn:
        for event in errors.NotifyEvent:
            conn.execute(
                "INSERT INTO notification (local_date, event, at) VALUES (?, ?, 0)",
                (D.isoformat(), event.value),
            )
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                "INSERT INTO notification (local_date, event, at) VALUES (?, ?, 0)",
                (D.isoformat(), "success"),
            )
        events = {row[1] for row in _rows(conn)}

    assert events == {event.value for event in errors.NotifyEvent}


def test_table_notifier_writes_one_row_with_now_ms(
    cfg: config.Config, clock: list[datetime]
):
    with store.write_session(cfg) as conn:
        ports.TableNotifier(conn).notify(
            D, errors.NotifyEvent.AUTH_FAILED, "token_invalid"
        )
        rows = _rows(conn)

    assert rows == [(D.isoformat(), "auth_failed", "token_invalid", NOW_MS)]


def test_table_notifier_keeps_first_row_per_day_and_event(
    cfg: config.Config, clock: list[datetime]
):
    with store.write_session(cfg) as conn:
        notifier = ports.TableNotifier(conn)
        notifier.notify(D, errors.NotifyEvent.RATE_LIMITED, "")
        clock[0] = NOW + timedelta(minutes=15)
        notifier.notify(D, errors.NotifyEvent.RATE_LIMITED, "transient=1")
        # 다른 사건·다른 날은 따로 남는다.
        notifier.notify(D, errors.NotifyEvent.ERROR, "abandoned")
        notifier.notify(D + timedelta(days=1), errors.NotifyEvent.RATE_LIMITED, "")
        rows = _rows(conn)

    later_ms = NOW_MS + 15 * 60_000
    assert rows == [
        (D.isoformat(), "error", "abandoned", later_ms),
        (D.isoformat(), "rate_limited", "", NOW_MS),
        ((D + timedelta(days=1)).isoformat(), "rate_limited", "", later_ms),
    ]


def test_insert_result_and_autocommit(cfg):
    with store.write_session(cfg) as conn:
        notifier = ports.TableNotifier(conn)
        assert notifier.notify(D, errors.NotifyEvent.ERROR, "abandoned") is True
        assert notifier.notify(D, errors.NotifyEvent.ERROR, "changed") is False
        with store.read_connection(cfg) as other:
            assert other.execute("SELECT detail FROM notification").fetchone() == (
                "abandoned",
            )


def test_telegram_budget_dedup_and_unexpected_exception(cfg, caplog):
    calls = []

    class Sender:
        def send(self, day, event, detail, *, timeout_seconds):
            calls.append(timeout_seconds)
            raise RuntimeError("private-token private-chat")

    with store.write_session(cfg) as conn:
        notifier = ports.TelegramNotifier(conn, Sender(), budget_seconds=3)
        assert notifier.notify(D, errors.NotifyEvent.ERROR, "abandoned") is True
        assert notifier.notify(D, errors.NotifyEvent.ERROR, "different") is False
        notifier.notify(D, errors.NotifyEvent.AUTH_FAILED, "token_invalid")
        rows = conn.execute(
            "SELECT kind, event, ok, reason FROM delivery ORDER BY id"
        ).fetchall()
    assert calls == [3]
    assert rows == [
        ("notify", "error", 0, "network"),
        ("notify", "auth_failed", 0, "network"),
    ]
    assert "budget_exhausted" in caplog.text and "RuntimeError" in caplog.text
    assert "private-token" not in caplog.text and "private-chat" not in caplog.text


@pytest.mark.parametrize("budget,expected", [(0.9, []), (1, [1]), (21, [10, 10, 1])])
def test_timeout_budget(cfg, budget, expected):
    calls = []

    class Sender:
        def send(self, *args, timeout_seconds):
            calls.append(timeout_seconds)

    with store.write_session(cfg) as conn:
        notifier = ports.TelegramNotifier(conn, Sender(), budget_seconds=budget)
        for event in errors.NotifyEvent:
            notifier.notify(D, event, "")
    assert calls == expected
    assert sum(calls) <= budget


def test_delivery_write_failure_is_swallowed_and_insert_failure_propagates(
    cfg, monkeypatch, caplog
):
    class Sender:
        def send(self, *args, **kwargs):
            return None

    with store.write_session(cfg) as conn:
        notifier = ports.TelegramNotifier(conn, Sender(), budget_seconds=10)
        conn.execute("DROP TABLE delivery")
        notifier.notify(D, errors.NotifyEvent.ERROR, "abandoned")
        assert "OperationalError" in caplog.text
        conn.execute("DROP TABLE notification")
        with pytest.raises(sqlite3.OperationalError):
            notifier.notify(D, errors.NotifyEvent.AUTH_FAILED, "token_invalid")


@pytest.mark.parametrize("event", list(errors.NotifyEvent))
@pytest.mark.parametrize("detail", ["", "token_invalid"])
def test_notice_text(event, detail):
    text = ports.notice_text(D, event, detail)
    assert text == ports.notice_text(D, event, detail)
    lines = text.splitlines()
    assert len(lines) == 3
    assert lines[0].startswith(f"[Garmin] {D} {event.value} ")
    assert lines[2] == f"사유: {detail or '-'}"
    if event == errors.NotifyEvent.AUTH_FAILED:
        assert "token_invalid" in lines[1] and "garmin-pipeline login" in lines[1]
        assert (
            "privacy_protected" in lines[1]
            and "Garmin Connect 프로필 공개 범위" in lines[1]
        )


@pytest.mark.parametrize(
    ("kind", "event", "ok", "reason", "valid"),
    [
        ("notify", "auth_failed", 1, None, True),
        ("report_document", None, 0, "too_large", True),
        ("wrong", None, 1, None, False),
        ("notify", "wrong", 1, None, False),
        ("notify", None, 2, "network", False),
        ("notify", None, 0, None, False),
        ("notify", None, 1, "network", False),
        ("notify", None, 0, "wrong", False),
    ],
)
def test_delivery_constraints(cfg, kind, event, ok, reason, valid):
    with store.write_session(cfg) as conn:

        def insert():
            conn.execute(
                "INSERT INTO delivery(local_date,kind,event,ok,reason,at) VALUES (?,?,?,?,?,0)",
                (D.isoformat(), kind, event, ok, reason),
            )

        if valid:
            insert()
        else:
            with pytest.raises(sqlite3.IntegrityError):
                insert()


def test_bundle_is_frozen(tmp_path):
    from dataclasses import FrozenInstanceError

    bundle = ports.ReportBundle(D, "summary", (), tmp_path / "report.md", False)
    with pytest.raises(FrozenInstanceError):
        bundle.summary_text = "changed"


def test_report_sink_handles_adapter_and_recorder_exceptions(
    tmp_path, monkeypatch, caplog
):
    records, sent = [], []
    sink = ports.TelegramReportSink(tmp_path, record=lambda *args: records.append(args))

    def text(*args, **kwargs):
        assert kwargs == {"timeout_seconds": 30, "wait_rate_limit": True}
        raise RuntimeError("private-token")

    def document(*args, **kwargs):
        sent.append("document")

    monkeypatch.setattr(sink._adapter, "send_message", text)
    monkeypatch.setattr(sink._adapter, "send_document", document)
    monkeypatch.setattr(ports, "_sleep", lambda _: None)
    bundle = ports.ReportBundle(D, "summary", (), tmp_path / "report.md", False)
    sink.deliver(bundle)
    assert records == [
        (D, errors.DeliveryKind.REPORT_TEXT, errors.DeliveryReason.NETWORK),
        (D, errors.DeliveryKind.REPORT_DOCUMENT, None),
    ]

    def record(*args):
        raise RuntimeError("private-token")

    sink._record = record
    sink.deliver(bundle)
    assert sent == ["document", "document"]
    assert "private-token" not in caplog.text
