"""import-linter 계약이 금지 import를 잡고 허용 경로는 통과시키는지 본다.

패키지를 `tmp_path`에 복사해 import를 넣고, `PYTHONPATH`로 복사본이 편집 설치보다 먼저
잡히게 한 뒤 저장소 `pyproject.toml` 설정 그대로 `lint-imports`를 실행한다.
"""

import os
import shutil
import subprocess
import sysconfig
import tomllib
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / "pyproject.toml"
PYPROJECT = tomllib.loads(CONFIG.read_text(encoding="utf-8"))
CONTRACTS = PYPROJECT["tool"]["importlinter"]["contracts"]
CONTRACT_NAMES = {contract["id"]: contract["name"] for contract in CONTRACTS}
GARMIN_LIBS = "garmin-libs-only-in-adapter"
NO_GARTH_OPENAI = "no-garth-openai"
COMMON_LAYER = "common-layer-imports-no-upper-modules"
STORE = "store-imports-no-upper-modules"
GARMIN_PROTECTED = "garmin-only-imported-by-auth-collect"
GARMIN_LAYER = "garmin-imports-no-upper-modules"
AUTH_LAYER = "auth-imports-no-cli"
RAWPARSE = "rawparse-is-pure"
COVERAGE = "coverage-imports-no-upper-modules"
COLLECT = "collect-imports-no-upper-modules"
PORTS = "ports-imports-no-upper-modules"
SCHEDULE = "schedule-imports-no-upper-modules"
CAPTURE = "capture-imports-no-upper-modules"
NORMALIZE = "normalize-imports-no-upper-modules"
BODY = "body-imports-no-upper-modules"
REPORT = "report-imports-no-upper-modules"


@pytest.fixture
def src(tmp_path: Path) -> Path:
    src = tmp_path / "src"
    shutil.copytree(
        ROOT / "src" / "garmin_pipeline",
        src / "garmin_pipeline",
        ignore=shutil.ignore_patterns("__pycache__"),
    )
    return src


def _add_modules(src: Path, modules: dict[str, str]) -> None:
    for relative, source in modules.items():
        path = src / "garmin_pipeline" / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(source, encoding="utf-8")


def _append_to_module(src: Path, relative: str, source: str) -> None:
    path = src / "garmin_pipeline" / relative
    path.write_text(path.read_text(encoding="utf-8") + source, encoding="utf-8")


def _lint_imports(src: Path) -> subprocess.CompletedProcess[str]:
    lint_imports = shutil.which("lint-imports", path=sysconfig.get_path("scripts"))
    assert lint_imports is not None
    pythonpath = os.pathsep.join(filter(None, [str(src), os.environ.get("PYTHONPATH")]))
    # 출력 문자열을 비교하므로 rich의 색 출력과 줄바꿈을 끈다.
    env = {key: value for key, value in os.environ.items() if key != "FORCE_COLOR"}
    env |= {
        "PYTHONPATH": pythonpath,
        "NO_COLOR": "1",
        "PYTHON_COLORS": "0",
        "COLUMNS": "200",
    }
    return subprocess.run(
        [lint_imports, "--config", str(CONFIG), "--no-cache", "--no-logo"],
        cwd=src.parent,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )


@pytest.mark.parametrize(
    ("modules", "contract", "illegal_import"),
    [
        pytest.param(
            {"auth.py": "import garminconnect\n"},
            GARMIN_LIBS,
            "garmin_pipeline.auth -> garminconnect",
            id="garminconnect-outside-adapter",
        ),
        pytest.param(
            {"store/__init__.py": "from curl_cffi import requests\n"},
            GARMIN_LIBS,
            "garmin_pipeline.store -> curl_cffi",
            id="curl_cffi-outside-adapter",
        ),
        pytest.param(
            {
                "collect.py": "def run():\n    import garminconnect\n\n    return garminconnect\n"
            },
            GARMIN_LIBS,
            "garmin_pipeline.collect -> garminconnect",
            id="lazy-import-outside-adapter",
        ),
        pytest.param(
            {"garmin_helpers.py": "import curl_cffi\n"},
            GARMIN_LIBS,
            "garmin_pipeline.garmin_helpers -> curl_cffi",
            id="sibling-with-adapter-prefix",
        ),
        pytest.param(
            {"garmin/__init__.py": "import garth\n"},
            NO_GARTH_OPENAI,
            "garmin_pipeline.garmin -> garth",
            id="garth-even-in-adapter",
        ),
        pytest.param(
            {"report.py": "from openai import OpenAI\n"},
            NO_GARTH_OPENAI,
            "garmin_pipeline.report -> openai",
            id="openai",
        ),
    ],
)
def test_forbidden_import_breaks_contract(
    src: Path, modules: dict[str, str], contract: str, illegal_import: str
):
    _add_modules(src, modules)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[contract]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_garmin_libs_allowed_inside_adapter(src: Path):
    _add_modules(
        src,
        {
            "garmin/__init__.py": "import garminconnect\nimport curl_cffi\n",
            "garmin/session.py": "from curl_cffi import requests\n",
            "garmin/calls/__init__.py": "",
            "garmin/calls/daily.py": "from garminconnect import Garmin\n",
            # auth → garmin → garminconnect 같은 간접 사슬은 허용한다.
            "auth.py": "from garmin_pipeline import garmin\n",
        },
    )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[GARMIN_LIBS]} KEPT (4 ignored imports)" in result.stdout
    assert f"{CONTRACT_NAMES[NO_GARTH_OPENAI]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[COMMON_LAYER]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[STORE]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[GARMIN_PROTECTED]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[GARMIN_LAYER]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[AUTH_LAYER]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[RAWPARSE]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[COVERAGE]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[COLLECT]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[PORTS]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[SCHEDULE]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[CAPTURE]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[NORMALIZE]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("module", "source", "illegal_import"),
    [
        pytest.param(
            "config.py",
            "\nimport garmin_pipeline.cli\n",
            "garmin_pipeline.config -> garmin_pipeline.cli",
            id="config",
        ),
        pytest.param(
            "dates.py",
            "\nfrom garmin_pipeline import cli\n",
            "garmin_pipeline.dates -> garmin_pipeline.cli",
            id="dates",
        ),
        pytest.param(
            "errors.py",
            "\n\ndef _late():\n    from garmin_pipeline import cli\n\n    return cli\n",
            "garmin_pipeline.errors -> garmin_pipeline.cli",
            id="lazy-in-errors",
        ),
        pytest.param(
            "config.py",
            "\nimport garmin_pipeline.store\n",
            "garmin_pipeline.config -> garmin_pipeline.store",
            id="config-to-store",
        ),
        pytest.param(
            "dates.py",
            "\n\ndef _late():\n    from garmin_pipeline import store\n\n    return store\n",
            "garmin_pipeline.dates -> garmin_pipeline.store",
            id="lazy-dates-to-store",
        ),
        pytest.param(
            "errors.py",
            "\nimport garmin_pipeline.garmin\n",
            "garmin_pipeline.errors -> garmin_pipeline.garmin",
            id="errors-to-garmin",
        ),
        pytest.param(
            "config.py",
            "\n\ndef _late():\n    from garmin_pipeline import auth\n\n    return auth\n",
            "garmin_pipeline.config -> garmin_pipeline.auth",
            id="lazy-config-to-auth",
        ),
        pytest.param(
            "dates.py",
            "\nfrom garmin_pipeline import rawparse\n",
            "garmin_pipeline.dates -> garmin_pipeline.rawparse",
            id="dates-to-rawparse",
        ),
        pytest.param(
            "errors.py",
            "\nfrom garmin_pipeline import coverage\n",
            "garmin_pipeline.errors -> garmin_pipeline.coverage",
            id="errors-to-coverage",
        ),
        pytest.param(
            "config.py",
            "\n\ndef _late():\n    from garmin_pipeline import collect\n\n    return collect\n",
            "garmin_pipeline.config -> garmin_pipeline.collect",
            id="lazy-config-to-collect",
        ),
        pytest.param(
            "errors.py",
            "\nfrom garmin_pipeline import ports\n",
            "garmin_pipeline.errors -> garmin_pipeline.ports",
            id="errors-to-ports",
        ),
        pytest.param(
            "dates.py",
            "\n\ndef _late():\n    from garmin_pipeline import schedule\n\n    return schedule\n",
            "garmin_pipeline.dates -> garmin_pipeline.schedule",
            id="lazy-dates-to-schedule",
        ),
        pytest.param(
            "config.py",
            "\nfrom garmin_pipeline import capture\n",
            "garmin_pipeline.config -> garmin_pipeline.capture",
            id="config-to-capture",
        ),
        pytest.param(
            "dates.py",
            "\n\ndef _late():\n    from garmin_pipeline import normalize\n\n    return normalize\n",
            "garmin_pipeline.dates -> garmin_pipeline.normalize",
            id="lazy-dates-to-normalize",
        ),
        pytest.param(
            "errors.py",
            "\nfrom garmin_pipeline.normalize import daily\n",
            "garmin_pipeline.errors -> garmin_pipeline.normalize.daily",
            id="errors-to-normalize-daily",
        ),
        pytest.param(
            "config.py",
            "\n\ndef _late():\n    from garmin_pipeline import body\n\n    return body\n",
            "garmin_pipeline.config -> garmin_pipeline.body",
            id="lazy-config-to-body",
        ),
    ],
)
def test_common_layer_importing_upper_module_breaks_contract(
    src: Path, module: str, source: str, illegal_import: str
):
    _append_to_module(src, module, source)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[COMMON_LAYER]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


@pytest.mark.parametrize(
    ("modules", "illegal_import"),
    [
        pytest.param(
            {"store/__init__.py": "from garmin_pipeline import cli\n"},
            "garmin_pipeline.store -> garmin_pipeline.cli",
            id="store-to-cli",
        ),
        pytest.param(
            {
                "store/_helpers.py": (
                    "def _late():\n    import garmin_pipeline.cli\n\n"
                    "    return garmin_pipeline.cli\n"
                )
            },
            "garmin_pipeline.store._helpers -> garmin_pipeline.cli",
            id="lazy-in-store-submodule",
        ),
        pytest.param(
            {
                "store/__init__.py": (
                    "def _late():\n    from garmin_pipeline import dates\n\n"
                    "    return dates\n"
                )
            },
            "garmin_pipeline.store -> garmin_pipeline.dates",
            id="lazy-store-to-dates",
        ),
        pytest.param(
            {"store/__init__.py": "from garmin_pipeline import garmin\n"},
            "garmin_pipeline.store -> garmin_pipeline.garmin",
            id="store-to-garmin",
        ),
        pytest.param(
            {"store/__init__.py": "from garmin_pipeline import auth\n"},
            "garmin_pipeline.store -> garmin_pipeline.auth",
            id="store-to-auth",
        ),
        pytest.param(
            {"store/__init__.py": "from garmin_pipeline import rawparse\n"},
            "garmin_pipeline.store -> garmin_pipeline.rawparse",
            id="store-to-rawparse",
        ),
        pytest.param(
            {"store/__init__.py": "from garmin_pipeline import coverage\n"},
            "garmin_pipeline.store -> garmin_pipeline.coverage",
            id="store-to-coverage",
        ),
        pytest.param(
            {"store/__init__.py": "from garmin_pipeline import collect\n"},
            "garmin_pipeline.store -> garmin_pipeline.collect",
            id="store-to-collect",
        ),
        pytest.param(
            {"store/__init__.py": "from garmin_pipeline import ports\n"},
            "garmin_pipeline.store -> garmin_pipeline.ports",
            id="store-to-ports",
        ),
        pytest.param(
            {"store/__init__.py": "from garmin_pipeline import schedule\n"},
            "garmin_pipeline.store -> garmin_pipeline.schedule",
            id="store-to-schedule",
        ),
        pytest.param(
            {"store/__init__.py": "from garmin_pipeline import capture\n"},
            "garmin_pipeline.store -> garmin_pipeline.capture",
            id="store-to-capture",
        ),
        pytest.param(
            {"store/__init__.py": "from garmin_pipeline import normalize\n"},
            "garmin_pipeline.store -> garmin_pipeline.normalize",
            id="store-to-normalize",
        ),
        pytest.param(
            {"store/__init__.py": "from garmin_pipeline import body\n"},
            "garmin_pipeline.store -> garmin_pipeline.body",
            id="store-to-body",
        ),
    ],
)
def test_store_importing_forbidden_module_breaks_contract(
    src: Path, modules: dict[str, str], illegal_import: str
):
    _add_modules(src, modules)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[STORE]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_store_may_import_config_and_errors(src: Path):
    _append_to_module(
        src, "store/__init__.py", "\nfrom garmin_pipeline import errors\n"
    )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[STORE]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[COMMON_LAYER]} KEPT" in result.stdout


def test_cli_may_import_common_layer(src: Path):
    _append_to_module(
        src, "cli.py", "\nfrom garmin_pipeline import config, dates, errors\n"
    )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[COMMON_LAYER]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("modules", "illegal_import"),
    [
        pytest.param(
            {"report.py": "from garmin_pipeline import garmin\n"},
            "garmin_pipeline.report -> garmin_pipeline.garmin",
            id="report",
        ),
        pytest.param(
            {"store/__init__.py": "import garmin_pipeline.garmin\n"},
            "garmin_pipeline.store -> garmin_pipeline.garmin",
            id="store",
        ),
        pytest.param(
            {
                "cli.py": (
                    "def _late():\n    from garmin_pipeline.garmin import GarminAdapter\n\n"
                    "    return GarminAdapter\n"
                )
            },
            "garmin_pipeline.cli -> garmin_pipeline.garmin",
            id="lazy-in-cli",
        ),
        pytest.param(
            {
                "garmin/_calls.py": "",
                "smoke.py": "from garmin_pipeline.garmin import _calls\n",
            },
            "garmin_pipeline.smoke -> garmin_pipeline.garmin._calls",
            id="adapter-submodule",
        ),
        pytest.param(
            {"collector.py": "from garmin_pipeline import garmin\n"},
            "garmin_pipeline.collector -> garmin_pipeline.garmin",
            id="sibling-with-allowed-prefix",
        ),
    ],
)
def test_importing_garmin_outside_auth_collect_breaks_contract(
    src: Path, modules: dict[str, str], illegal_import: str
):
    _add_modules(src, modules)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[GARMIN_PROTECTED]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_auth_and_collect_may_import_garmin(src: Path):
    # collect를 하위 모듈이 있는 패키지로 바꿔 `collect.**`도 허용되는지 본다.
    (src / "garmin_pipeline" / "collect.py").unlink()
    _add_modules(
        src,
        {
            "auth.py": "from garmin_pipeline import garmin\n",
            "collect/__init__.py": "from garmin_pipeline.garmin import GarminAdapter\n",
            "collect/plan.py": "import garmin_pipeline.garmin\n",
            # 어댑터 하위끼리의 import는 허용한다.
            "garmin/_calls.py": "from garmin_pipeline import garmin\n",
        },
    )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[GARMIN_PROTECTED]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[GARMIN_LAYER]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("modules", "illegal_import"),
    [
        pytest.param(
            {"garmin/_store.py": "from garmin_pipeline import store\n"},
            "garmin_pipeline.garmin._store -> garmin_pipeline.store",
            id="garmin-to-store",
        ),
        pytest.param(
            {
                "garmin/_cli.py": (
                    "def _late():\n    import garmin_pipeline.cli\n\n"
                    "    return garmin_pipeline.cli\n"
                )
            },
            "garmin_pipeline.garmin._cli -> garmin_pipeline.cli",
            id="lazy-garmin-to-cli",
        ),
        pytest.param(
            {"garmin/_auth.py": "from garmin_pipeline import auth\n"},
            "garmin_pipeline.garmin._auth -> garmin_pipeline.auth",
            id="garmin-to-auth",
        ),
        pytest.param(
            {
                "garmin/_parse.py": "from garmin_pipeline.rawparse import activity_refs\n"
            },
            "garmin_pipeline.garmin._parse -> garmin_pipeline.rawparse",
            id="garmin-to-rawparse",
        ),
        pytest.param(
            {"garmin/_coverage.py": "from garmin_pipeline import coverage\n"},
            "garmin_pipeline.garmin._coverage -> garmin_pipeline.coverage",
            id="garmin-to-coverage",
        ),
        pytest.param(
            {"garmin/_collect.py": "from garmin_pipeline import collect\n"},
            "garmin_pipeline.garmin._collect -> garmin_pipeline.collect",
            id="garmin-to-collect",
        ),
        pytest.param(
            {"garmin/_ports.py": "from garmin_pipeline import ports\n"},
            "garmin_pipeline.garmin._ports -> garmin_pipeline.ports",
            id="garmin-to-ports",
        ),
        pytest.param(
            {"garmin/_schedule.py": "from garmin_pipeline import schedule\n"},
            "garmin_pipeline.garmin._schedule -> garmin_pipeline.schedule",
            id="garmin-to-schedule",
        ),
        pytest.param(
            {"garmin/_capture.py": "from garmin_pipeline import capture\n"},
            "garmin_pipeline.garmin._capture -> garmin_pipeline.capture",
            id="garmin-to-capture",
        ),
        pytest.param(
            {"garmin/_normalize.py": "from garmin_pipeline import normalize\n"},
            "garmin_pipeline.garmin._normalize -> garmin_pipeline.normalize",
            id="garmin-to-normalize",
        ),
        pytest.param(
            {"garmin/_body.py": "from garmin_pipeline import body\n"},
            "garmin_pipeline.garmin._body -> garmin_pipeline.body",
            id="garmin-to-body",
        ),
    ],
)
def test_garmin_importing_forbidden_module_breaks_contract(
    src: Path, modules: dict[str, str], illegal_import: str
):
    _add_modules(src, modules)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[GARMIN_LAYER]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


@pytest.mark.parametrize(
    ("source", "illegal_import"),
    [
        pytest.param(
            "\nfrom garmin_pipeline import cli\n",
            "garmin_pipeline.auth -> garmin_pipeline.cli",
            id="auth-to-cli",
        ),
        pytest.param(
            "\n\ndef _late():\n    import garmin_pipeline.cli\n\n    return garmin_pipeline.cli\n",
            "garmin_pipeline.auth -> garmin_pipeline.cli",
            id="lazy-auth-to-cli",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import rawparse\n",
            "garmin_pipeline.auth -> garmin_pipeline.rawparse",
            id="auth-to-rawparse",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import coverage\n\n    return coverage\n",
            "garmin_pipeline.auth -> garmin_pipeline.coverage",
            id="lazy-auth-to-coverage",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import collect\n",
            "garmin_pipeline.auth -> garmin_pipeline.collect",
            id="auth-to-collect",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import ports\n",
            "garmin_pipeline.auth -> garmin_pipeline.ports",
            id="auth-to-ports",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import schedule\n",
            "garmin_pipeline.auth -> garmin_pipeline.schedule",
            id="auth-to-schedule",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import capture\n\n    return capture\n",
            "garmin_pipeline.auth -> garmin_pipeline.capture",
            id="lazy-auth-to-capture",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import normalize\n",
            "garmin_pipeline.auth -> garmin_pipeline.normalize",
            id="auth-to-normalize",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import body\n\n    return body\n",
            "garmin_pipeline.auth -> garmin_pipeline.body",
            id="lazy-auth-to-body",
        ),
    ],
)
def test_auth_importing_cli_breaks_contract(
    src: Path, source: str, illegal_import: str
):
    _append_to_module(src, "auth.py", source)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[AUTH_LAYER]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_cli_may_import_auth_lazily(src: Path):
    _append_to_module(
        src,
        "cli.py",
        "\n\ndef _late():\n    from garmin_pipeline import auth\n\n    return auth\n",
    )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[AUTH_LAYER]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("source", "illegal_import"),
    [
        pytest.param(
            "\nimport sqlite3\n",
            "garmin_pipeline.rawparse -> sqlite3",
            id="sqlite3",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import store\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.store",
            id="store",
        ),
        pytest.param(
            "\nfrom garmin_pipeline.config import Config\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.config",
            id="config",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import dates\n\n    return dates\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.dates",
            id="lazy-dates",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import errors\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.errors",
            id="errors",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import cli\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.cli",
            id="cli",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import garmin\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.garmin",
            id="garmin",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import auth\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.auth",
            id="auth",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import coverage\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.coverage",
            id="coverage",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import collect\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.collect",
            id="collect",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import ports\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.ports",
            id="ports",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import schedule\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.schedule",
            id="schedule",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import capture\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.capture",
            id="capture",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import normalize\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.normalize",
            id="normalize",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import body\n\n    return body\n",
            "garmin_pipeline.rawparse -> garmin_pipeline.body",
            id="lazy-body",
        ),
        pytest.param(
            "\nimport garminconnect\n",
            "garmin_pipeline.rawparse -> garminconnect",
            id="garminconnect",
        ),
        pytest.param(
            "\nfrom curl_cffi import requests\n",
            "garmin_pipeline.rawparse -> curl_cffi",
            id="curl_cffi",
        ),
        pytest.param(
            "\n\ndef _late():\n    import socket\n\n    return socket\n",
            "garmin_pipeline.rawparse -> socket",
            id="lazy-socket",
        ),
        pytest.param(
            "\nimport urllib.request\n",
            "garmin_pipeline.rawparse -> urllib",
            id="urllib",
        ),
        pytest.param(
            "\nimport http.client\n",
            "garmin_pipeline.rawparse -> http",
            id="http",
        ),
    ],
)
def test_rawparse_importing_anything_impure_breaks_contract(
    src: Path, source: str, illegal_import: str
):
    _append_to_module(src, "rawparse.py", source)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[RAWPARSE]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_rawparse_may_import_pure_stdlib_and_be_imported(src: Path):
    _append_to_module(src, "rawparse.py", "\nimport re\nfrom collections import abc\n")
    _add_modules(src, {"report_input.py": "from garmin_pipeline import rawparse\n"})

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[RAWPARSE]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("source", "illegal_import"),
    [
        pytest.param(
            "\nfrom garmin_pipeline import garmin\n",
            "garmin_pipeline.coverage -> garmin_pipeline.garmin",
            id="garmin",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import cli\n\n    return cli\n",
            "garmin_pipeline.coverage -> garmin_pipeline.cli",
            id="lazy-cli",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import auth\n",
            "garmin_pipeline.coverage -> garmin_pipeline.auth",
            id="auth",
        ),
        pytest.param(
            "\nimport garminconnect\n",
            "garmin_pipeline.coverage -> garminconnect",
            id="garminconnect",
        ),
        pytest.param(
            "\nfrom curl_cffi import requests\n",
            "garmin_pipeline.coverage -> curl_cffi",
            id="curl_cffi",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import collect\n\n    return collect\n",
            "garmin_pipeline.coverage -> garmin_pipeline.collect",
            id="lazy-collect",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import ports\n",
            "garmin_pipeline.coverage -> garmin_pipeline.ports",
            id="ports",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import schedule\n",
            "garmin_pipeline.coverage -> garmin_pipeline.schedule",
            id="schedule",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import capture\n",
            "garmin_pipeline.coverage -> garmin_pipeline.capture",
            id="capture",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import normalize\n",
            "garmin_pipeline.coverage -> garmin_pipeline.normalize",
            id="normalize",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import body\n",
            "garmin_pipeline.coverage -> garmin_pipeline.body",
            id="body",
        ),
    ],
)
def test_coverage_importing_forbidden_module_breaks_contract(
    src: Path, source: str, illegal_import: str
):
    _append_to_module(src, "coverage.py", source)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[COVERAGE]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_coverage_may_import_store_and_rawparse(src: Path):
    _append_to_module(
        src, "coverage.py", "\nfrom garmin_pipeline import rawparse, store\n"
    )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[COVERAGE]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[STORE]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[RAWPARSE]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("source", "illegal_import"),
    [
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import cli\n\n    return cli\n",
            "garmin_pipeline.collect -> garmin_pipeline.cli",
            id="lazy-cli",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import auth\n",
            "garmin_pipeline.collect -> garmin_pipeline.auth",
            id="auth",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import schedule\n",
            "garmin_pipeline.collect -> garmin_pipeline.schedule",
            id="schedule",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import capture\n\n    return capture\n",
            "garmin_pipeline.collect -> garmin_pipeline.capture",
            id="lazy-capture",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import body\n",
            "garmin_pipeline.collect -> garmin_pipeline.body",
            id="body",
        ),
    ],
)
def test_collect_importing_forbidden_module_breaks_contract(
    src: Path, source: str, illegal_import: str
):
    _append_to_module(src, "collect.py", source)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[COLLECT]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_cli_may_import_collect_lazily(src: Path):
    _append_to_module(
        src,
        "cli.py",
        "\n\ndef _late():\n    from garmin_pipeline import collect\n\n    return collect\n",
    )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[COLLECT]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("source", "illegal_import"),
    [
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import cli\n\n    return cli\n",
            "garmin_pipeline.ports -> garmin_pipeline.cli",
            id="lazy-cli",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import garmin\n",
            "garmin_pipeline.ports -> garmin_pipeline.garmin",
            id="garmin",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import auth\n",
            "garmin_pipeline.ports -> garmin_pipeline.auth",
            id="auth",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import collect\n\n    return collect\n",
            "garmin_pipeline.ports -> garmin_pipeline.collect",
            id="lazy-collect",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import coverage\n",
            "garmin_pipeline.ports -> garmin_pipeline.coverage",
            id="coverage",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import rawparse\n",
            "garmin_pipeline.ports -> garmin_pipeline.rawparse",
            id="rawparse",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import schedule\n",
            "garmin_pipeline.ports -> garmin_pipeline.schedule",
            id="schedule",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import capture\n",
            "garmin_pipeline.ports -> garmin_pipeline.capture",
            id="capture",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import normalize\n",
            "garmin_pipeline.ports -> garmin_pipeline.normalize",
            id="normalize",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import body\n",
            "garmin_pipeline.ports -> garmin_pipeline.body",
            id="body",
        ),
        pytest.param(
            "\nimport garminconnect\n",
            "garmin_pipeline.ports -> garminconnect",
            id="garminconnect",
        ),
        pytest.param(
            "\nfrom curl_cffi import requests\n",
            "garmin_pipeline.ports -> curl_cffi",
            id="curl_cffi",
        ),
    ],
)
def test_ports_importing_forbidden_module_breaks_contract(
    src: Path, source: str, illegal_import: str
):
    _append_to_module(src, "ports.py", source)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[PORTS]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_ports_cannot_import_store(src: Path):
    _append_to_module(src, "ports.py", "\nfrom garmin_pipeline import store\n")

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[PORTS]} BROKEN" in result.stdout
    assert "garmin_pipeline.ports -> garmin_pipeline.store" in result.stdout
    assert f"{CONTRACT_NAMES[COLLECT]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("source", "illegal_import"),
    [
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import cli\n\n    return cli\n",
            "garmin_pipeline.schedule -> garmin_pipeline.cli",
            id="lazy-cli",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import garmin\n",
            "garmin_pipeline.schedule -> garmin_pipeline.garmin",
            id="garmin",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import auth\n",
            "garmin_pipeline.schedule -> garmin_pipeline.auth",
            id="auth",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import collect\n\n    return collect\n",
            "garmin_pipeline.schedule -> garmin_pipeline.collect",
            id="lazy-collect",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import coverage\n",
            "garmin_pipeline.schedule -> garmin_pipeline.coverage",
            id="coverage",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import rawparse\n",
            "garmin_pipeline.schedule -> garmin_pipeline.rawparse",
            id="rawparse",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import ports\n",
            "garmin_pipeline.schedule -> garmin_pipeline.ports",
            id="ports",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import store\n",
            "garmin_pipeline.schedule -> garmin_pipeline.store",
            id="store",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import capture\n",
            "garmin_pipeline.schedule -> garmin_pipeline.capture",
            id="capture",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import normalize\n",
            "garmin_pipeline.schedule -> garmin_pipeline.normalize",
            id="normalize",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import body\n",
            "garmin_pipeline.schedule -> garmin_pipeline.body",
            id="body",
        ),
        pytest.param(
            "\nimport garminconnect\n",
            "garmin_pipeline.schedule -> garminconnect",
            id="garminconnect",
        ),
        pytest.param(
            "\nfrom curl_cffi import requests\n",
            "garmin_pipeline.schedule -> curl_cffi",
            id="curl_cffi",
        ),
    ],
)
def test_schedule_importing_forbidden_module_breaks_contract(
    src: Path, source: str, illegal_import: str
):
    _append_to_module(src, "schedule.py", source)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[SCHEDULE]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_schedule_may_import_errors_and_be_imported_by_cli_lazily(src: Path):
    _append_to_module(src, "schedule.py", "\nfrom garmin_pipeline import errors\n")
    _append_to_module(
        src,
        "cli.py",
        "\n\ndef _late():\n    from garmin_pipeline import schedule\n\n    return schedule\n",
    )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[SCHEDULE]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[COMMON_LAYER]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("source", "illegal_import"),
    [
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import cli\n\n    return cli\n",
            "garmin_pipeline.capture -> garmin_pipeline.cli",
            id="lazy-cli",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import garmin\n",
            "garmin_pipeline.capture -> garmin_pipeline.garmin",
            id="garmin",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import auth\n",
            "garmin_pipeline.capture -> garmin_pipeline.auth",
            id="auth",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import collect\n\n    return collect\n",
            "garmin_pipeline.capture -> garmin_pipeline.collect",
            id="lazy-collect",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import ports\n",
            "garmin_pipeline.capture -> garmin_pipeline.ports",
            id="ports",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import schedule\n",
            "garmin_pipeline.capture -> garmin_pipeline.schedule",
            id="schedule",
        ),
        pytest.param(
            "\nimport garminconnect\n",
            "garmin_pipeline.capture -> garminconnect",
            id="garminconnect",
        ),
        pytest.param(
            "\nfrom curl_cffi import requests\n",
            "garmin_pipeline.capture -> curl_cffi",
            id="curl_cffi",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import normalize\n\n    return normalize\n",
            "garmin_pipeline.capture -> garmin_pipeline.normalize",
            id="lazy-normalize",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import body\n",
            "garmin_pipeline.capture -> garmin_pipeline.body",
            id="body",
        ),
    ],
)
def test_capture_importing_forbidden_module_breaks_contract(
    src: Path, source: str, illegal_import: str
):
    _append_to_module(src, "capture.py", source)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[CAPTURE]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_capture_may_import_errors_and_be_imported_by_cli_lazily(src: Path):
    _append_to_module(src, "capture.py", "\nfrom garmin_pipeline import errors\n")
    _append_to_module(
        src,
        "cli.py",
        "\n\ndef _late():\n    from garmin_pipeline import capture\n\n    return capture\n",
    )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[CAPTURE]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[COMMON_LAYER]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("source", "illegal_import"),
    [
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import cli\n\n    return cli\n",
            "garmin_pipeline.normalize -> garmin_pipeline.cli",
            id="lazy-cli",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import garmin\n",
            "garmin_pipeline.normalize -> garmin_pipeline.garmin",
            id="garmin",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import auth\n",
            "garmin_pipeline.normalize -> garmin_pipeline.auth",
            id="auth",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import coverage\n",
            "garmin_pipeline.normalize -> garmin_pipeline.coverage",
            id="coverage",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import collect\n\n    return collect\n",
            "garmin_pipeline.normalize -> garmin_pipeline.collect",
            id="lazy-collect",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import ports\n",
            "garmin_pipeline.normalize -> garmin_pipeline.ports",
            id="ports",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import schedule\n",
            "garmin_pipeline.normalize -> garmin_pipeline.schedule",
            id="schedule",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import capture\n",
            "garmin_pipeline.normalize -> garmin_pipeline.capture",
            id="capture",
        ),
        pytest.param(
            "\nimport garminconnect\n",
            "garmin_pipeline.normalize -> garminconnect",
            id="garminconnect",
        ),
        pytest.param(
            "\nfrom curl_cffi import requests\n",
            "garmin_pipeline.normalize -> curl_cffi",
            id="curl_cffi",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import body\n\n    return body\n",
            "garmin_pipeline.normalize -> garmin_pipeline.body",
            id="lazy-body",
        ),
    ],
)
def test_normalize_importing_forbidden_module_breaks_contract(
    src: Path, source: str, illegal_import: str
):
    _append_to_module(src, "normalize/__init__.py", source)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[NORMALIZE]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_normalize_submodule_importing_forbidden_module_breaks_contract(src: Path):
    _append_to_module(
        src, "normalize/daily.py", "\nfrom garmin_pipeline import capture\n"
    )

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[NORMALIZE]} BROKEN" in result.stdout
    assert "garmin_pipeline.normalize.daily -> garmin_pipeline.capture" in result.stdout


def test_normalize_may_import_store_and_rawparse_and_be_imported_lazily(src: Path):
    _append_to_module(
        src,
        "normalize/__init__.py",
        "\nfrom garmin_pipeline import digest, errors, rawparse, store\n",
    )
    for module in ("collect.py", "cli.py"):
        _append_to_module(
            src,
            module,
            "\n\ndef _late():\n    from garmin_pipeline import normalize\n\n    return normalize\n",
        )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[NORMALIZE]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[COLLECT]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[COMMON_LAYER]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("source", "illegal_import"),
    [
        pytest.param(
            "\nfrom garmin_pipeline import cli\n",
            "garmin_pipeline.body -> garmin_pipeline.cli",
            id="cli",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import store\n",
            "garmin_pipeline.body -> garmin_pipeline.store",
            id="store",
        ),
        pytest.param(
            "\n\ndef _late():\n    from garmin_pipeline import store\n\n    return store\n",
            "garmin_pipeline.body -> garmin_pipeline.store",
            id="lazy-store",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import garmin\n",
            "garmin_pipeline.body -> garmin_pipeline.garmin",
            id="garmin",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import coverage\n",
            "garmin_pipeline.body -> garmin_pipeline.coverage",
            id="coverage",
        ),
        pytest.param(
            "\nfrom garmin_pipeline.normalize import daily\n",
            "garmin_pipeline.body -> garmin_pipeline.normalize.daily",
            id="normalize-daily",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import schedule\n",
            "garmin_pipeline.body -> garmin_pipeline.schedule",
            id="schedule",
        ),
        pytest.param(
            "\nimport garminconnect\n",
            "garmin_pipeline.body -> garminconnect",
            id="garminconnect",
        ),
        pytest.param(
            "\n\ndef _late():\n    from curl_cffi import requests\n\n    return requests\n",
            "garmin_pipeline.body -> curl_cffi",
            id="lazy-curl_cffi",
        ),
        pytest.param(
            "\nimport sqlite3\n",
            "garmin_pipeline.body -> sqlite3",
            id="sqlite3",
        ),
    ],
)
def test_body_importing_forbidden_module_breaks_contract(
    src: Path, source: str, illegal_import: str
):
    _append_to_module(src, "body.py", source)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[BODY]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_body_may_import_config_dates_and_be_imported_by_cli_lazily(src: Path):
    _append_to_module(src, "body.py", "\nfrom garmin_pipeline import config, dates\n")
    _append_to_module(
        src,
        "cli.py",
        "\n\ndef _late():\n    from garmin_pipeline import body\n\n    return body\n",
    )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[BODY]} KEPT" in result.stdout
    assert f"{CONTRACT_NAMES[COMMON_LAYER]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("source", "illegal_import"),
    [
        pytest.param(
            "\nfrom garmin_pipeline import garmin\n",
            "garmin_pipeline.report -> garmin_pipeline.garmin",
            id="garmin",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import cli\n",
            "garmin_pipeline.report -> garmin_pipeline.cli",
            id="cli",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import auth\n",
            "garmin_pipeline.report -> garmin_pipeline.auth",
            id="auth",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import collect\n",
            "garmin_pipeline.report -> garmin_pipeline.collect",
            id="collect",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import rawparse\n",
            "garmin_pipeline.report -> garmin_pipeline.rawparse",
            id="rawparse",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import schedule\n",
            "garmin_pipeline.report -> garmin_pipeline.schedule",
            id="schedule",
        ),
        pytest.param(
            "\nfrom garmin_pipeline import capture\n",
            "garmin_pipeline.report -> garmin_pipeline.capture",
            id="capture",
        ),
        pytest.param(
            "\nfrom garmin_pipeline.normalize import daily\n",
            "garmin_pipeline.report -> garmin_pipeline.normalize.daily",
            id="normalize-daily",
        ),
        pytest.param(
            "\nimport garminconnect\n",
            "garmin_pipeline.report -> garminconnect",
            id="garminconnect",
        ),
        pytest.param(
            "\n\ndef _late():\n    from curl_cffi import requests\n\n    return requests\n",
            "garmin_pipeline.report -> curl_cffi",
            id="lazy-curl_cffi",
        ),
    ],
)
def test_report_importing_forbidden_module_breaks_contract(
    src: Path, source: str, illegal_import: str
):
    _append_to_module(src, "report.py", source)

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[REPORT]} BROKEN" in result.stdout
    assert illegal_import in result.stdout


def test_report_may_import_allowed_modules_and_be_imported_by_cli_lazily(src: Path):
    _append_to_module(
        src,
        "report.py",
        "\nfrom garmin_pipeline import body, config, coverage, dates, errors, ports, store\n",
    )
    _append_to_module(
        src,
        "cli.py",
        "\n\ndef _late():\n    from garmin_pipeline import report\n\n    return report\n",
    )

    result = _lint_imports(src)

    assert result.returncode == 0, result.stdout + result.stderr
    assert result.stdout.count(" KEPT") == len(CONTRACT_NAMES)
    assert f"{CONTRACT_NAMES[REPORT]} KEPT" in result.stdout


@pytest.mark.parametrize(
    ("module", "contract"),
    [
        pytest.param("config.py", COMMON_LAYER, id="config"),
        pytest.param("dates.py", COMMON_LAYER, id="dates"),
        pytest.param("errors.py", COMMON_LAYER, id="errors"),
        pytest.param("store/__init__.py", STORE, id="store"),
        pytest.param("garmin/__init__.py", GARMIN_LAYER, id="garmin"),
        pytest.param("auth.py", AUTH_LAYER, id="auth"),
        pytest.param("rawparse.py", RAWPARSE, id="rawparse"),
        pytest.param("coverage.py", COVERAGE, id="coverage"),
        pytest.param("collect.py", COLLECT, id="collect"),
        pytest.param("ports.py", PORTS, id="ports"),
        pytest.param("schedule.py", SCHEDULE, id="schedule"),
        pytest.param("capture.py", CAPTURE, id="capture"),
        pytest.param("normalize/__init__.py", NORMALIZE, id="normalize"),
        pytest.param("body.py", BODY, id="body"),
    ],
)
def test_lower_module_importing_report_breaks_contract(
    src: Path, module: str, contract: str
):
    _append_to_module(
        src,
        module,
        "\n\ndef _late():\n    from garmin_pipeline import report\n\n    return report\n",
    )
    name = module.removesuffix(".py").removesuffix("/__init__").replace("/", ".")

    result = _lint_imports(src)

    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[contract]} BROKEN" in result.stdout
    assert f"garmin_pipeline.{name} -> garmin_pipeline.report" in result.stdout


def test_garmin_imports_pass_all_contracts():
    # 저장소 그대로의 패키지(실제 garmin 어댑터·auth·rawparse·coverage·ports·collect·schedule·
    # capture·normalize·body·report 포함)가 모든 계약을 지킨다.
    result = _lint_imports(ROOT / "src")

    assert result.returncode == 0, result.stdout + result.stderr
    assert result.stdout.count(" KEPT") == len(CONTRACT_NAMES) == 24


@pytest.mark.parametrize("module", ["report.py", "cli.py"])
def test_matplotlib_outside_charts_breaks_contract(src, module):
    _append_to_module(src, module, "\nimport matplotlib\n")
    result = _lint_imports(src)
    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES['matplotlib-only-in-charts']} BROKEN" in result.stdout


@pytest.mark.parametrize("module", ["cli.py", "store/__init__.py"])
def test_charts_imported_outside_report_breaks_contract(src, module):
    _append_to_module(src, module, "\nfrom garmin_pipeline import charts\n")
    result = _lint_imports(src)
    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES['charts-only-imported-by-report']} BROKEN" in result.stdout


@pytest.mark.parametrize(
    "module",
    [
        "socket",
        "urllib",
        "http",
        "requests",
        "garmin_pipeline.rawparse",
        "garmin_pipeline.coverage",
        "garmin_pipeline.digest",
        "garmin_pipeline.normalize",
        "garmin_pipeline.report_input",
        "garmin_pipeline.cli",
        "garmin_pipeline.telegram",
        "garmin_pipeline.report",
        "garminconnect",
        "curl_cffi",
    ],
)
def test_charts_forbidden_import_breaks_contract(src, module):
    _append_to_module(
        src, "charts.py", f"\ndef _late_contract_probe():\n    import {module}\n"
    )
    result = _lint_imports(src)
    assert result.returncode == 1, result.stdout + result.stderr
    assert (
        f"{CONTRACT_NAMES['charts-imports-no-upper-modules']} BROKEN" in result.stdout
    )


def test_charts_allowed_import_paths(src):
    _append_to_module(src, "report.py", "\nfrom garmin_pipeline import charts\n")
    _append_to_module(
        src,
        "charts.py",
        "\ndef _late_contract_probe():\n    import matplotlib.figure\n    import sqlite3\n    from garmin_pipeline import store, body\n",
    )
    result = _lint_imports(src)
    assert result.returncode == 0, result.stdout + result.stderr
    assert result.stdout.count(" KEPT") == 24


@pytest.mark.parametrize(
    ("module", "source", "contract"),
    [
        ("collect.py", "\nimport requests\n", "requests-only-in-telegram"),
        (
            "collect.py",
            "\nfrom garmin_pipeline import telegram\n",
            "telegram-only-imported-by-ports",
        ),
        (
            "telegram.py",
            "\nfrom garmin_pipeline import config\n",
            "telegram-imports-no-upper-modules",
        ),
        ("telegram.py", "\nimport telebot\n", NO_GARTH_OPENAI),
        ("ports.py", "\nimport aiogram\n", NO_GARTH_OPENAI),
        ("ports.py", "\nimport telegram\n", NO_GARTH_OPENAI),
    ],
)
def test_telegram_boundaries(src, module, source, contract):
    _append_to_module(src, module, source)
    result = _lint_imports(src)
    assert result.returncode == 1, result.stdout + result.stderr
    assert f"{CONTRACT_NAMES[contract]} BROKEN" in result.stdout


@pytest.mark.parametrize(
    "module,illegal,contract",
    [
        (
            "digest.py",
            "from garmin_pipeline import body\n",
            "digest-imports-no-upper-modules",
        ),
        ("digest.py", "import sqlite3\n", "digest-imports-no-upper-modules"),
        ("digest.py", "import socket\n", "digest-imports-no-upper-modules"),
        ("digest.py", "import urllib\n", "digest-imports-no-upper-modules"),
        ("digest.py", "import http\n", "digest-imports-no-upper-modules"),
        ("report_input.py", "from garmin_pipeline import charts\n", "report-input-imports-no-upper-modules"),
    ],
)
def test_analysis_import_contracts_reject_upper_layers(src, module, illegal, contract):
    _append_to_module(src, module, illegal)
    result = _lint_imports(src)
    assert result.returncode != 0
    assert f"{CONTRACT_NAMES[contract]} BROKEN" in result.stdout
