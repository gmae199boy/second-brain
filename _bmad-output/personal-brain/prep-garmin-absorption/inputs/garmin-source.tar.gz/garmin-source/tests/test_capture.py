"""실제 응답 fixture 내보내기: `capture` 모듈과 `garmin-pipeline capture-fixtures`(FR40, AD-1·3·4·12).

DB는 패키지 마이그레이션 위에서 `store.write_session` + `store.upsert_raw`로 만들고, 출력은
`tmp_path` 안의 임시 git 저장소(`monkeypatch.chdir`)에만 쓴다. 저장소의 실제
`tests/fixtures/garmin/`은 만들지 않는다.
"""

import json
import logging
import os
import shutil
import socket
import sqlite3
import stat
import subprocess
import sys
import sysconfig
from collections.abc import Callable, Iterator
from pathlib import Path

import pytest

from garmin_pipeline import capture, cli, config, coverage, store

ROOT = Path(__file__).resolve().parents[1]
REAL_OUTPUT = ROOT / "tests" / "fixtures" / "garmin"
NOW = 1_760_000_000_000
VERSION = "0.3.17"
MARKER = "원문표식-c7f3"
D1, D2, D3 = "2026-10-14", "2026-10-15", "2026-10-16"
ENDPOINTS = (*coverage.DAY_ENDPOINTS, *coverage.ACTIVITY_ENDPOINTS)
BASE_ACTIVITY = coverage.ACTIVITY_ENDPOINTS[:3]
"""합성 활동(세트 없음)이 담는 3종. 세트 상세 `activity_exercise_sets`는 근력 활동에만 있다."""
DAY_DATA = [e for e in coverage.DAY_ENDPOINTS if e != "activities_by_date"]
SETS = coverage.EXERCISE_SETS


# --- 준비 ----------------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _repo_output_untouched() -> Iterator[None]:
    existed = REAL_OUTPUT.exists()
    yield
    assert REAL_OUTPUT.exists() == existed, (
        "테스트가 저장소의 tests/fixtures/garmin/을 만들었다"
    )


@pytest.fixture
def cfg(write_config: Callable[..., Path]) -> config.Config:
    return config.load(write_config(lock_wait_seconds=0))


def _git_init(path: Path, ignore: str | None) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    subprocess.run(["git", "init", "-q", str(path)], check=True, capture_output=True)
    if ignore is not None:
        (path / ".gitignore").write_text(ignore, encoding="utf-8")
    return path


@pytest.fixture
def repo(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """`.gitignore`에 `tests/fixtures/garmin/`이 있는 임시 저장소로 cwd를 옮긴다."""
    path = _git_init(tmp_path / "repo", "tests/fixtures/garmin/\n")
    monkeypatch.chdir(path)
    return path


def _out(repo: Path) -> Path:
    return repo / "tests" / "fixtures" / "garmin"


def _payload(endpoint: str, key: str) -> dict[str, object]:
    # 한글과 정렬하지 않은 키: 파일은 저장된 원문 텍스트 그대로여야 한다.
    return {"zeta": key, "endpoint": endpoint, "메모": MARKER, "values": [1, 2.5, None]}


def _activity(activity_id: int, start: str) -> dict[str, object]:
    return {"activityId": activity_id, "startTimeLocal": start, "name": MARKER}


def _put(cfg: config.Config, rows: list[tuple[str, str, str, object]]) -> None:
    with store.write_session(cfg) as conn:
        for scope, key, endpoint, payload in rows:
            store.upsert_raw(
                conn,
                scope=scope,
                key=key,
                endpoint=endpoint,
                payload=payload,
                library_version=VERSION,
                now_ms=NOW,
            )


def _put_raw(cfg: config.Config, scope: str, key: str, endpoint: str, raw: str) -> None:
    """`upsert_raw`가 만들 수 없는 원문(JSON 아님)을 그대로 넣는다."""
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO raw_response"
            " (scope, key, endpoint, raw, fetched_at, checked_at, library_version)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)",
            (scope, key, endpoint, raw, NOW, NOW, VERSION),
        )


def _day_rows(key: str, **overrides: object) -> list[tuple[str, str, str, object]]:
    return [
        ("day", key, endpoint, overrides.get(endpoint, _payload(endpoint, key)))
        for endpoint in coverage.DAY_ENDPOINTS
    ]


def _activity_rows(
    activity_id: int, **overrides: object
) -> list[tuple[str, str, str, object]]:
    key = str(activity_id)
    return [
        ("activity", key, endpoint, overrides.get(endpoint, _payload(endpoint, key)))
        for endpoint in BASE_ACTIVITY
    ]


def _sets_payload(activity_id: int) -> dict[str, object]:
    """세트 상세 원문 모양(정렬하지 않은 키·한글·`null` 무게)."""
    return {
        "activityId": activity_id,
        "exerciseSets": [
            {"setType": "ACTIVE", "repetitionCount": 10, "weight": 60000.0},
            {"setType": "REST", "weight": None, "duration": 90.0},
        ],
        "메모": MARKER,
    }


def _db_raws(cfg: config.Config) -> dict[tuple[str, str], str]:
    conn = sqlite3.connect(cfg.db_path)
    try:
        rows = conn.execute("SELECT key, endpoint, raw FROM raw_response").fetchall()
    finally:
        conn.close()
    return {(endpoint, key): raw for key, endpoint, raw in rows}


def _files(out: Path) -> dict[str, bytes]:
    return {
        path.relative_to(out).as_posix(): path.read_bytes()
        for path in sorted(out.rglob("*"))
        if path.is_file()
    }


def _main(cfg: config.Config, *argv: str) -> int:
    return cli.main(["capture-fixtures", "--config", str(cfg.path), *argv])


def _count_lines(counts: dict[str, int]) -> list[str]:
    return [f"{endpoint}: {counts.get(endpoint, 0)}" for endpoint in ENDPOINTS]


def _default_db(cfg: config.Config) -> None:
    """매트릭스 "기본": 두 날 day 행(일부 null), 활동 목록 2일·활동 4개(1개는 상세 없음).

    103은 근력 활동이라 세트 상세(`activity_exercise_sets`) 원문도 있다.
    """
    _put(
        cfg,
        [
            *_day_rows(
                D1,
                activities_by_date=[
                    _activity(101, f"{D1} 06:00:00"),
                    _activity(102, f"{D1} 18:30:00"),
                ],
            ),
            *_day_rows(
                D2,
                sleep_data=None,
                hrv_data=None,
                activities_by_date=[
                    _activity(104, f"{D2} 07:00:00"),
                    {**_activity(103, f"{D2} 05:00:00"), "totalSets": 2},
                ],
            ),
            *_activity_rows(101),
            *_activity_rows(102),
            *_activity_rows(103),
            ("activity", "103", SETS, _sets_payload(103)),
            # 104는 상세가 없다(행 자체가 없거나 NoData뿐).
            ("activity", "104", "activity", None),
        ],
    )


DEFAULT_EXPECTED = {
    *(f"{e}/{D2}.json" for e in DAY_DATA if e not in ("sleep_data", "hrv_data")),
    f"sleep_data/{D1}.json",
    f"hrv_data/{D1}.json",
    f"activities_by_date/{D2}.json",
    *(f"{e}/{a}.json" for e in BASE_ACTIVITY for a in (101, 102, 103)),
    f"{SETS}/103.json",
}
DEFAULT_COUNTS = (
    dict.fromkeys(coverage.DAY_ENDPOINTS, 1)
    | dict.fromkeys(BASE_ACTIVITY, 3)
    | {SETS: 1}
)
"""`_default_db`의 기본 선택에서 endpoint별 쓴 파일 수."""


# --- 기본 선택 -------------------------------------------------------------------------------


def test_default_exports_latest_data_and_recent_activities(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    _default_db(cfg)

    assert _main(cfg) == 0

    out, err = capsys.readouterr()
    files = _files(_out(repo))
    assert set(files) == DEFAULT_EXPECTED
    raws = _db_raws(cfg)
    for relative, data in files.items():
        endpoint, name = relative.split("/")
        assert data == raws[(endpoint, name.removesuffix(".json"))].encode("utf-8")
    assert files[f"{SETS}/103.json"] == raws[(SETS, "103")].encode("utf-8")
    assert out.splitlines() == _count_lines(DEFAULT_COUNTS)
    assert MARKER not in out + err
    assert err == ""


def test_latest_null_falls_back_to_previous_day(cfg: config.Config, repo: Path):
    _put(cfg, [*_day_rows(D1), *_day_rows(D2, sleep_data=None)])

    assert _main(cfg) == 0

    assert sorted(path.name for path in (_out(repo) / "sleep_data").iterdir()) == [
        f"{D1}.json"
    ]
    assert sorted(path.name for path in (_out(repo) / "rhr_day").iterdir()) == [
        f"{D2}.json"
    ]


def test_default_picks_three_recent_activities_with_details(cfg: config.Config):
    _put(
        cfg,
        [
            *_day_rows(
                D1,
                activities_by_date=[
                    _activity(1, f"{D1} 06:00:00"),
                    _activity(2, f"{D1} 08:00:00"),
                ],
            ),
            *_day_rows(
                D2,
                activities_by_date=[
                    _activity(4, f"{D2} 09:00:00"),
                    _activity(3, f"{D2} 07:00:00"),
                    # 다른 날 목록에도 나온 활동은 처음 것 하나만 센다.
                    _activity(1, f"{D1} 06:00:00"),
                ],
            ),
            *_day_rows(D3, activities_by_date=None),
            ("activity", "4", "activity", None),
            ("activity", "4", "activity_details", None),
            ("activity", "4", "activity_hr_in_timezones", None),
            *_activity_rows(3, activity_details=None),
            *_activity_rows(1),
            *_activity_rows(2),
        ],
    )

    conn = store.read_connection(cfg)
    try:
        with store.transaction(conn):
            rows = capture.select(conn, days=[], activity_ids=[])
    finally:
        conn.close()

    activity_rows = [(row.key, row.endpoint) for row in rows if row.scope == "activity"]
    # 4는 상세 data가 없어 건너뛰고, 3(D2) 다음 D1 목록 순으로 1·2. 3의 null 상세는 쓰지 않는다.
    assert activity_rows == [
        ("3", "activity"),
        ("3", "activity_hr_in_timezones"),
        ("1", "activity"),
        ("1", "activity_details"),
        ("1", "activity_hr_in_timezones"),
        ("2", "activity"),
        ("2", "activity_details"),
        ("2", "activity_hr_in_timezones"),
    ]
    day_rows = {row.endpoint: row.key for row in rows if row.scope == "day"}
    # D3 activities_by_date는 null이라 D2 목록이 최신 data다.
    assert day_rows["activities_by_date"] == D2
    assert day_rows["sleep_data"] == D3


def test_recent_activities_follow_start_day_not_list_key(cfg: config.Config):
    # 목록 key와 활동 시작 날짜가 엇갈리면(여행 등) 목록 key가 아니라 시작 날짜(일 키) 내림차순이다.
    _put(
        cfg,
        [
            *_day_rows(D2, activities_by_date=[_activity(10, f"{D1} 23:00:00")]),
            *_day_rows(D1, activities_by_date=[_activity(20, f"{D2} 01:00:00")]),
            *_activity_rows(10),
            *_activity_rows(20),
        ],
    )

    conn = store.read_connection(cfg)
    try:
        with store.transaction(conn):
            rows = capture.select(conn, days=[], activity_ids=[])
    finally:
        conn.close()

    keys = [row.key for row in rows if row.scope == "activity"]
    assert keys == ["20"] * 3 + ["10"] * 3


def test_default_ignores_unknown_activity_endpoint(cfg: config.Config, repo: Path):
    # raw_response의 endpoint에는 CHECK가 없다. 모르는 activity endpoint 행은 내보내지 않고 세지도 않는다.
    _default_db(cfg)
    _put(cfg, [("activity", "101", "activity_splits", {"note": MARKER})])

    assert _main(cfg) == 0

    assert set(_files(_out(repo))) == DEFAULT_EXPECTED


def test_recent_activities_are_capped(cfg: config.Config, repo: Path):
    _put(
        cfg,
        [
            *_day_rows(
                D2,
                activities_by_date=[
                    _activity(n, f"{D2} 0{n}:00:00") for n in range(1, 6)
                ],
            ),
            *(row for n in range(1, 6) for row in _activity_rows(n)),
        ],
    )

    assert _main(cfg) == 0

    for endpoint in BASE_ACTIVITY:
        names = sorted(path.name for path in (_out(repo) / endpoint).iterdir())
        assert names == ["1.json", "2.json", "3.json"]
    assert capture.RECENT_ACTIVITIES == 3


# --- 지정 선택 -------------------------------------------------------------------------------


def test_date_on_day_without_activities_writes_all_nine_including_null(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    _default_db(cfg)
    _put(cfg, _day_rows(D3, activities_by_date=None, stress_data=None))

    assert _main(cfg, "--date", D3) == 0

    files = _files(_out(repo))
    assert set(files) == {f"{e}/{D3}.json" for e in coverage.DAY_ENDPOINTS}
    assert files[f"activities_by_date/{D3}.json"] == b"null"
    assert files[f"stress_data/{D3}.json"] == b"null"
    assert files[f"rhr_day/{D3}.json"] == _db_raws(cfg)[("rhr_day", D3)].encode()
    assert capsys.readouterr().out.splitlines() == _count_lines(
        dict.fromkeys(coverage.DAY_ENDPOINTS, 1)
    )


def test_activity_id_writes_only_that_activity(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    _default_db(cfg)

    assert _main(cfg, "--activity-id", "102") == 0

    files = _files(_out(repo))
    assert set(files) == {f"{e}/102.json" for e in BASE_ACTIVITY}
    assert capsys.readouterr().out.splitlines() == _count_lines(
        dict.fromkeys(BASE_ACTIVITY, 1)
    )


def test_activity_id_writes_sets_raw_of_strength_activity(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    _default_db(cfg)

    assert _main(cfg, "--activity-id", "103") == 0

    files = _files(_out(repo))
    assert set(files) == {f"{e}/103.json" for e in coverage.ACTIVITY_ENDPOINTS}
    assert files[f"{SETS}/103.json"] == _db_raws(cfg)[(SETS, "103")].encode("utf-8")
    assert json.loads(files[f"{SETS}/103.json"]) == _sets_payload(103)
    assert capsys.readouterr().out.splitlines() == _count_lines(
        dict.fromkeys(coverage.ACTIVITY_ENDPOINTS, 1)
    )


def test_date_and_activity_id_are_independent_and_deduplicated(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    _default_db(cfg)

    argv = ["--date", D1, "--date", D1, "--activity-id", "104", "--activity-id", "101"]
    assert _main(cfg, *argv) == 0

    files = _files(_out(repo))
    # 104는 NoData 행 하나뿐이다. 지정 선택은 null도 쓴다. 그날(D1)의 활동은 따로 쓰지 않는다.
    assert set(files) == {
        *(f"{e}/{D1}.json" for e in coverage.DAY_ENDPOINTS),
        "activity/104.json",
        *(f"{e}/101.json" for e in BASE_ACTIVITY),
    }
    assert files["activity/104.json"] == b"null"
    assert capsys.readouterr().out.splitlines() == _count_lines(
        dict.fromkeys(coverage.DAY_ENDPOINTS, 1)
        | {"activity": 2, "activity_details": 1, "activity_hr_in_timezones": 1}
    )


# --- 덮어쓰기·파일 모드 ------------------------------------------------------------------------


def test_second_run_overwrites_with_same_bytes_and_keeps_other_files(
    cfg: config.Config, repo: Path
):
    _default_db(cfg)
    out = _out(repo)
    (out / "sleep_data").mkdir(parents=True)
    # 이미 있는 폴더의 모드는 건드리지 않는다.
    os.chmod(out / "sleep_data", 0o755)
    (out / "sleep_data" / "old.json").write_bytes(b"keep")
    (out / "sleep_data" / f"{D1}.json").write_bytes(b"stale")

    assert _main(cfg) == 0
    first = _files(out)
    assert _main(cfg) == 0

    assert _files(out) == first
    assert first["sleep_data/old.json"] == b"keep"
    assert first[f"sleep_data/{D1}.json"] == _db_raws(cfg)[("sleep_data", D1)].encode()
    assert not [path for path in out.rglob("*.tmp")]
    assert stat.S_IMODE((out / "sleep_data").stat().st_mode) == 0o755


def test_new_dirs_are_0700_and_files_0600(cfg: config.Config, repo: Path):
    _default_db(cfg)

    assert _main(cfg) == 0

    out = _out(repo)
    assert stat.S_IMODE(out.stat().st_mode) == 0o700
    assert stat.S_IMODE((out / "sleep_data").stat().st_mode) == 0o700
    for path in out.rglob("*.json"):
        assert stat.S_IMODE(path.stat().st_mode) == 0o600


def test_write_fixture_removes_temporary_file_on_failure(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    def fail(*args: object) -> None:
        raise OSError("replace failed")

    monkeypatch.setattr(os, "replace", fail)

    with pytest.raises(OSError, match="replace failed"):
        capture.write_fixture(tmp_path / "x.json", "{}")

    assert list(tmp_path.iterdir()) == []


def test_write_error_exits_1(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    _default_db(cfg)
    # endpoint 폴더 자리가 파일이라 그 안에 쓸 수 없다.
    (_out(repo)).mkdir(parents=True)
    (_out(repo) / "sleep_data").write_bytes(b"")

    assert _main(cfg) == 1

    assert capsys.readouterr().err.startswith(
        "capture-fixtures 실패: fixture 파일을 쓰지 못했다"
    )


# --- 없음 ---------------------------------------------------------------------------------


def test_empty_db_prints_zero_counts_and_exits_1(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    _put(cfg, [])

    assert _main(cfg) == 1

    out, err = capsys.readouterr()
    assert out.splitlines() == _count_lines({})
    assert err == "capture-fixtures: 내보낼 원문이 없다\n"
    assert not _out(repo).exists()


def test_unknown_date_exits_1(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    _default_db(cfg)

    assert _main(cfg, "--date", "2020-01-01") == 1

    out, err = capsys.readouterr()
    assert out.splitlines() == _count_lines({})
    assert "내보낼 원문이 없다" in err
    assert not _out(repo).exists()


# --- git 확인 ------------------------------------------------------------------------------


def _forbid_db(monkeypatch: pytest.MonkeyPatch) -> None:
    def refuse(*args: object, **kwargs: object) -> None:
        pytest.fail("거부했는데 DB 연결을 열었다")

    monkeypatch.setattr(store, "read_connection", refuse)


@pytest.mark.parametrize("ignore", [None, "data/\n"], ids=["no-gitignore", "other"])
def test_refuses_when_output_not_ignored(
    cfg: config.Config,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    ignore: str | None,
):
    _default_db(cfg)
    repo = _git_init(tmp_path / "repo", ignore)
    monkeypatch.chdir(repo)
    _forbid_db(monkeypatch)

    assert _main(cfg) == 1

    out, err = capsys.readouterr()
    assert out == ""
    assert err.startswith("capture-fixtures 거부: 출력 폴더가 git에서 무시되지 않는다")
    assert not (repo / "tests").exists()
    assert not (cfg.data_dir / "logs").exists()


def test_refuses_from_repo_subdirectory(
    cfg: config.Config,
    repo: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    _default_db(cfg)
    (repo / "sub").mkdir()
    monkeypatch.chdir(repo / "sub")
    _forbid_db(monkeypatch)

    assert _main(cfg) == 1

    assert capsys.readouterr().err.startswith("capture-fixtures 거부: ")
    assert not (repo / "sub" / "tests").exists()
    assert not (cfg.data_dir / "logs").exists()


def test_refuses_outside_git_repository(
    cfg: config.Config,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    _default_db(cfg)
    plain = tmp_path / "plain"
    plain.mkdir()
    monkeypatch.chdir(plain)
    _forbid_db(monkeypatch)

    assert _main(cfg) == 1

    out, err = capsys.readouterr()
    assert out == ""
    assert err.startswith("capture-fixtures 거부: git 저장소 안이 아니다")
    # git이 알려 준 실제 사유(첫 줄)를 덧붙인다.
    assert "(git: fatal: not a git repository" in err
    assert list(plain.iterdir()) == []
    assert not (cfg.data_dir / "logs").exists()


def test_refuses_when_git_cannot_run(
    cfg: config.Config,
    repo: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    _default_db(cfg)

    def missing(*args: object, **kwargs: object) -> None:
        raise FileNotFoundError(2, "No such file or directory", "git")

    monkeypatch.setattr(subprocess, "run", missing)
    _forbid_db(monkeypatch)

    assert _main(cfg) == 1

    assert capsys.readouterr().err.startswith(
        "capture-fixtures 거부: git을 실행하지 못했다"
    )
    assert not (repo / "tests").exists()
    assert not (cfg.data_dir / "logs").exists()


def test_ignored_by_git_checks_directory_pattern(repo: Path):
    assert capture.ignored_by_git(repo / capture.OUTPUT_DIR) is None
    assert capture.ignored_by_git(repo / "tests" / "other") is not None


# --- DB 오류·설정 오류·인자 오류 -----------------------------------------------------------------


def test_missing_db_exits_1(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    assert _main(cfg) == 1

    assert capsys.readouterr().err.startswith("capture-fixtures 실패: DB 파일이 없다")
    assert not _out(repo).exists()
    assert not cfg.db_path.exists()


def test_corrupt_db_exits_1_without_traceback(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    _default_db(cfg)
    # 같은 경로에 SQLite가 아닌 바이트: sqlite3.DatabaseError("file is not a database").
    cfg.db_path.write_bytes(b"not a sqlite database at all " * 200)
    for suffix in ("-wal", "-shm"):
        cfg.db_path.with_name(cfg.db_path.name + suffix).unlink(missing_ok=True)

    assert _main(cfg) == 1

    err = capsys.readouterr().err
    assert err.startswith("capture-fixtures 실패: ")
    assert "Traceback" not in err
    assert not _out(repo).exists()


def test_export_selects_inside_one_read_transaction(
    cfg: config.Config, repo: Path, monkeypatch: pytest.MonkeyPatch
):
    _default_db(cfg)
    seen: list[bool] = []
    original = capture.select

    def recording(conn: sqlite3.Connection, **kwargs: object) -> list[capture.Row]:
        seen.append(conn.in_transaction)
        return original(conn, **kwargs)

    monkeypatch.setattr(capture, "select", recording)

    assert _main(cfg) == 0

    assert seen == [True]


def test_schema_mismatch_exits_1(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    _default_db(cfg)
    conn = sqlite3.connect(cfg.db_path)
    try:
        conn.execute("PRAGMA user_version = 99")
        conn.commit()
    finally:
        conn.close()

    assert _main(cfg) == 1

    assert capsys.readouterr().err.startswith(
        "capture-fixtures 실패: DB 스키마 버전 99"
    )
    assert not _out(repo).exists()


def test_log_open_failure_exits_1(
    write_config: Callable[..., Path],
    tmp_path: Path,
    repo: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    # data_dir 자리가 파일이라 logs 폴더를 만들 수 없다.
    (tmp_path / "data").write_text("", encoding="utf-8")
    cfg = config.load(write_config())
    _forbid_db(monkeypatch)

    assert _main(cfg) == 1

    assert capsys.readouterr().err.startswith(
        "capture-fixtures 실패: 로그 파일을 열지 못했다"
    )
    assert not _out(repo).exists()


def test_config_error_exits_2(
    tmp_path: Path, repo: Path, capsys: pytest.CaptureFixture[str]
):
    path = tmp_path / "nowhere.toml"

    assert cli.main(["capture-fixtures", "--config", str(path)]) == 2

    assert capsys.readouterr().err.startswith("설정 오류: ")
    assert not (tmp_path / "data").exists()
    assert not _out(repo).exists()


@pytest.mark.parametrize(
    "argv",
    [
        ["--date", "2026-13-01"],
        ["--date", "어제"],
        ["--activity-id", "0"],
        ["--activity-id", "-3"],
        ["--activity-id", "abc"],
        ["--activity-id", "1.5"],
        ["--activity-id", " 7"],
    ],
)
def test_bad_arguments_are_usage_errors(
    argv: list[str], capsys: pytest.CaptureFixture[str]
):
    with pytest.raises(SystemExit) as exit_info:
        cli.main(["capture-fixtures", *argv])

    assert exit_info.value.code == 2
    assert "usage:" in capsys.readouterr().err


def test_help_lists_options(capsys: pytest.CaptureFixture[str]):
    with pytest.raises(SystemExit) as exit_info:
        cli.main(["capture-fixtures", "--help"])

    assert exit_info.value.code == 0
    text = capsys.readouterr().out
    assert "--config PATH" in text
    assert "--date YYYY-MM-DD" in text
    assert "--activity-id N" in text


# --- 경로 검증·깨진 목록 ----------------------------------------------------------------------


def test_invalid_keys_are_skipped_with_warning(
    cfg: config.Config, repo: Path, caplog: pytest.LogCaptureFixture
):
    caplog.set_level(logging.WARNING, logger="garmin_pipeline.capture")
    _put(
        cfg,
        [
            ("day", "../x", "rhr_day", _payload("rhr_day", "../x")),
            ("day", D1, "sleep_data", _payload("sleep_data", D1)),
            # 문자열 순서로는 D1보다 뒤라 먼저 잡히지만 경로로 쓸 수 없다.
            ("day", f"{D1}/../../../escape", "sleep_data", {"a": 1}),
            ("day", "20261014", "stress_data", {"a": 1}),
            (
                "day",
                D1,
                "activities_by_date",
                [_activity(-7, f"{D1} 06:00:00"), _activity(5, f"{D1} 07:00:00")],
            ),
            *_activity_rows(-7),
            *_activity_rows(5),
        ],
    )

    assert _main(cfg) == 0

    assert set(_files(_out(repo))) == {
        f"sleep_data/{D1}.json",
        f"activities_by_date/{D1}.json",
        *(f"{e}/5.json" for e in BASE_ACTIVITY),
    }
    assert not (repo / "escape.json").exists()
    assert not (repo / "tests" / "escape.json").exists()
    assert not list(repo.parent.glob("x.json"))
    warnings = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert any("key='../x'" in message for message in warnings)
    assert any("escape" in message for message in warnings)
    assert any("key='20261014'" in message for message in warnings)
    assert any("key='-7'" in message for message in warnings)


def test_broken_activity_list_is_skipped(
    cfg: config.Config, repo: Path, caplog: pytest.LogCaptureFixture
):
    caplog.set_level(logging.WARNING, logger="garmin_pipeline.capture")
    _put(
        cfg,
        [
            ("day", D1, "activities_by_date", [_activity(11, f"{D1} 06:00:00")]),
            *_activity_rows(11),
            *_activity_rows(12),
        ],
    )
    _put_raw(cfg, "day", D2, "activities_by_date", f"not json {MARKER}")

    assert _main(cfg) == 0

    files = _files(_out(repo))
    assert {f"{e}/11.json" for e in BASE_ACTIVITY} <= set(files)
    assert not any(name.endswith("/12.json") for name in files)
    # 깨진 목록도 원문 그대로 day-scope 최신 data로 쓴다(바이트 그대로).
    assert files[f"activities_by_date/{D2}.json"] == f"not json {MARKER}".encode()
    warnings = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert warnings == [
        "활동 목록 원문 형식 오류(key=2026-10-15): 활동 목록 원문이 JSON이 아니다"
    ]


# --- 로그·출력 위생 ----------------------------------------------------------------------------


def test_command_log_has_counts_only(
    cfg: config.Config, repo: Path, capsys: pytest.CaptureFixture[str]
):
    _default_db(cfg)

    assert _main(cfg) == 0

    out, _ = capsys.readouterr()
    log = (cfg.data_dir / "logs" / "capture-fixtures.log").read_text(encoding="utf-8")
    counts = " ".join(f"{e}={DEFAULT_COUNTS.get(e, 0)}" for e in ENDPOINTS)
    assert f"capture-fixtures 끝: {counts}" in log
    assert MARKER not in log
    assert str(repo) not in log + out
    assert D2 not in out


# --- 네트워크 차단·어댑터 미로드 ----------------------------------------------------------------


def test_works_with_sockets_blocked(
    cfg: config.Config, repo: Path, monkeypatch: pytest.MonkeyPatch
):
    _default_db(cfg)

    class Blocked(socket.socket):
        # 함수가 아니라 하위 클래스로 바꿔 `ssl.SSLSocket(socket)` 같은 상속은 깨지지 않게 한다.
        def __init__(self, *args: object, **kwargs: object) -> None:
            raise OSError("소켓 차단")

    monkeypatch.setattr(socket, "socket", Blocked)

    assert _main(cfg) == 0

    files = _files(_out(repo))
    assert set(files) == DEFAULT_EXPECTED
    assert files[f"{SETS}/103.json"] == _db_raws(cfg)[(SETS, "103")].encode("utf-8")


def test_does_not_load_garmin_adapter(cfg: config.Config, repo: Path):
    _default_db(cfg)
    probe = (
        "import socket, sys\n"
        "class Blocked(socket.socket):\n"
        "    def __init__(self, *args, **kwargs):\n"
        "        raise OSError('socket blocked')\n"
        "socket.socket = Blocked\n"
        "from garmin_pipeline import cli\n"
        f"code = cli.main(['capture-fixtures', '--config', {str(cfg.path)!r}])\n"
        "loaded = sorted(name for name in sys.modules if name == 'garmin_pipeline.garmin'"
        " or name.startswith(('garmin_pipeline.garmin.', 'garminconnect', 'curl_cffi')))\n"
        "print('PROBE', code, loaded)\n"
    )

    result = subprocess.run(
        [sys.executable, "-c", probe],
        cwd=repo,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.stdout.splitlines()[-1:] == ["PROBE 0 []"], result.stderr
    assert set(_files(_out(repo))) == DEFAULT_EXPECTED


# --- 인수 기준: 콘솔 스크립트 ---------------------------------------------------------------------


def test_console_script_exports_fixtures(cfg: config.Config, repo: Path):
    _default_db(cfg)
    script = shutil.which("garmin-pipeline", path=sysconfig.get_path("scripts"))
    assert script is not None, "콘솔 스크립트가 없다. `uv sync`를 먼저 실행한다."
    env = {key: value for key, value in os.environ.items() if key != "FORCE_COLOR"}
    env |= {"NO_COLOR": "1", "PYTHON_COLORS": "0"}

    result = subprocess.run(
        [script, "capture-fixtures", "--config", str(cfg.path)],
        cwd=repo,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.splitlines() == _count_lines(DEFAULT_COUNTS)
    assert MARKER not in result.stdout
    raws = _db_raws(cfg)
    files = _files(_out(repo))
    assert set(files) == DEFAULT_EXPECTED
    for relative, data in files.items():
        endpoint, name = relative.split("/")
        assert data == raws[(endpoint, name.removesuffix(".json"))].encode("utf-8")
    assert json.loads(files[f"rhr_day/{D2}.json"])["메모"] == MARKER
