"""SQLite 저장소: 쓰기 세션의 락·마이그레이션, 읽기 연결의 버전 확인, 락 확인, pytest 가드."""

import dataclasses
import fcntl
import os
import signal
import sqlite3
import stat
import subprocess
import sys
import textwrap
import threading
import time
from collections.abc import Callable, Iterator
from pathlib import Path

import pytest

from garmin_pipeline import config, store
from garmin_pipeline.errors import DomainError

# 검사용 연결은 `connections` fixture가 가로채지 않도록 원래 함수로 연다.
_raw_connect = sqlite3.connect

LOG_0001 = "CREATE TABLE log (n INTEGER);\nINSERT INTO log VALUES (1);\n"
SECOND_0002 = "CREATE TABLE second (x TEXT);\nINSERT INTO log VALUES (2);\n"

# 다른 프로세스에서 쓰기 세션을 잡고 "held"를 출력한 뒤 stdin 한 줄을 받을 때까지 쥔다.
# 이 프로세스는 monkeypatch 밖이라 패키지의 실제 마이그레이션 목록을 쓴다.
HOLDER = textwrap.dedent(
    """
    import sys

    from garmin_pipeline import config, store

    cfg = config.load(sys.argv[1])
    with store.write_session(cfg):
        print("held", flush=True)
        sys.stdin.readline()
    """
)

# 쓰기 세션 안에서 오래 사는 손자 프로세스를 `close_fds=False`로 띄워 pid를 출력하고, 락을
# 풀지 않은 채 `os._exit(0)`로 끝난다. 손자가 락 fd를 물려받았다면 그 뒤에도 락이 남는다.
SPAWNER = textwrap.dedent(
    """
    import os
    import subprocess
    import sys

    from garmin_pipeline import config, store

    cfg = config.load(sys.argv[1])
    with store.write_session(cfg):
        grandchild = subprocess.Popen(
            [sys.executable, "-c", "import time; time.sleep(60)"],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            close_fds=False,
        )
        print(grandchild.pid, flush=True)
        os._exit(0)
    """
)


class Boom(Exception):
    pass


@pytest.fixture
def make_cfg(write_config: Callable[..., Path]) -> Callable[..., config.Config]:
    """`write_config`로 쓴 설정을 읽는다. `data_dir` 기본은 `tmp_path/"data"`다."""

    def make(**overrides: object) -> config.Config:
        return config.load(write_config(**overrides))

    return make


@pytest.fixture
def cfg(make_cfg: Callable[..., config.Config]) -> config.Config:
    return make_cfg(lock_wait_seconds=0)


@pytest.fixture
def migrations(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """`_migrations_dir` seam을 `tmp_path/"migrations"`(처음엔 빈 폴더)로 바꾼다."""
    directory = tmp_path / "migrations"
    directory.mkdir()
    monkeypatch.setattr(store, "_migrations_dir", lambda: directory)
    return directory


@pytest.fixture
def connections(monkeypatch: pytest.MonkeyPatch) -> list[sqlite3.Connection]:
    """이 테스트에서 `sqlite3.connect`로 열린 연결을 모두 모은다."""
    opened: list[sqlite3.Connection] = []

    def connect(*args: object, **kwargs: object) -> sqlite3.Connection:
        conn = _raw_connect(*args, **kwargs)  # type: ignore[arg-type]
        opened.append(conn)
        return conn

    monkeypatch.setattr(sqlite3, "connect", connect)
    return opened


@pytest.fixture
def holder() -> Iterator[Callable[[Path], subprocess.Popen[str]]]:
    """설정 파일 경로를 받아 그 쓰기 세션을 쥔 하위 프로세스를 띄운다."""
    processes: list[subprocess.Popen[str]] = []

    def start(config_path: Path) -> subprocess.Popen[str]:
        process = subprocess.Popen(
            [sys.executable, "-c", HOLDER, str(config_path)],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            text=True,
        )
        processes.append(process)
        assert process.stdout is not None
        assert process.stdout.readline() == "held\n"
        return process

    yield start
    for process in processes:
        process.kill()
        process.communicate()


def _write(directory: Path, name: str, sql: str = "SELECT 1;\n") -> None:
    (directory / name).write_text(sql, encoding="utf-8")


def _query(cfg: config.Config, sql: str) -> list[tuple[object, ...]]:
    conn = _raw_connect(cfg.db_path)
    try:
        return conn.execute(sql).fetchall()
    finally:
        conn.close()


def _version(cfg: config.Config) -> int:
    return _query(cfg, "PRAGMA user_version")[0][0]  # type: ignore[return-value]


def _tables(cfg: config.Config) -> set[object]:
    return {
        name
        for (name,) in _query(
            cfg, "SELECT name FROM sqlite_master WHERE type = 'table'"
        )
    }


def _log(cfg: config.Config) -> list[object]:
    return [n for (n,) in _query(cfg, "SELECT n FROM log ORDER BY rowid")]


def _is_closed(conn: sqlite3.Connection) -> bool:
    try:
        conn.execute("SELECT 1")
    except sqlite3.ProgrammingError:
        return True
    return False


def _tree(root: Path) -> dict[str, tuple[int, int, int]]:
    """`root` 아래 모든 경로의 (mode, size, mtime_ns). 심링크는 따라가지 않는다."""
    snapshot: dict[str, tuple[int, int, int]] = {}
    for dirpath, dirnames, filenames in os.walk(root):
        for name in [*dirnames, *filenames]:
            path = Path(dirpath, name)
            info = path.lstat()
            snapshot[str(path.relative_to(root))] = (
                info.st_mode,
                info.st_size,
                info.st_mtime_ns,
            )
    return snapshot


def _hold_lock_in_this_process(cfg: config.Config) -> int:
    """테스트 프로세스에서 락 파일에 직접 `flock(LOCK_EX)`을 잡고 fd를 돌려준다."""
    cfg.data_dir.mkdir(parents=True, exist_ok=True)
    fd = os.open(cfg.data_dir / store.LOCK_FILENAME, os.O_RDWR | os.O_CREAT)
    fcntl.flock(fd, fcntl.LOCK_EX)
    return fd


def test_store_errors_are_outside_domain_errors():
    for error in (
        store.LockTimeout,
        store.SchemaMismatch,
        store.DbMissing,
        store.MigrationError,
    ):
        assert issubclass(error, store.StoreError)
    assert issubclass(store.StoreError, Exception)
    assert not issubclass(store.StoreError, DomainError)

    mismatch = store.SchemaMismatch(3, 2)

    assert (mismatch.found, mismatch.expected) == (3, 2)
    assert "3" in str(mismatch) and "2" in str(mismatch)


def test_package_migrations_apply_and_write_then_read_works(cfg: config.Config):
    assert [m.name for m in store._load_migrations()] == [
        "0001_auth_event.sql",
        "0002_raw_response.sql",
        "0003_run_fetch_error.sql",
        "0004_meta.sql",
        "0005_notification.sql",
        "0006_normalize.sql",
        "0007_sleep_stress_body_battery.sql",
        "0008_hr_sample.sql",
        "0009_activity.sql",
        "0010_activity_recovery.sql",
        "0011_exercise_set.sql",
        "0012_drop_activity_recovery.sql",
        "0013_activity_body_battery.sql",
        "0014_zone_bounds_stress_bb.sql",
        "0015_delivery.sql",
        "0016_day_values_evaluation.sql",
    ]

    with store.write_session(cfg) as conn:
        assert conn.execute("PRAGMA user_version").fetchone() == (16,)
        columns = conn.execute("PRAGMA table_info(auth_event)").fetchall()
    assert [(name, kind, notnull, pk) for _, name, kind, notnull, _, pk in columns] == [
        ("id", "INTEGER", 0, 1),
        ("local_date", "TEXT", 1, 0),
        ("logged_in_at", "INTEGER", 1, 0),
    ]
    reader = store.read_connection(cfg)
    try:
        assert reader.execute("PRAGMA user_version").fetchone() == (16,)
    finally:
        reader.close()


def test_first_write_creates_dir_and_lock_and_applies_all(
    make_cfg: Callable[..., config.Config], migrations: Path, tmp_path: Path
):
    cfg = make_cfg(data_dir=str(tmp_path / "nested" / "data"))
    _write(migrations, "0002_second.sql", SECOND_0002)
    _write(migrations, "0001_log.sql", LOG_0001)
    assert not (tmp_path / "nested").exists()

    with store.write_session(cfg) as conn:
        assert conn.autocommit is True
        assert conn.execute("PRAGMA journal_mode").fetchone() == ("wal",)
        assert conn.execute("PRAGMA user_version").fetchone() == (2,)

    assert (cfg.data_dir / ".write.lock").is_file()
    assert cfg.db_path == cfg.data_dir / "garmin.db"
    assert _version(cfg) == 2
    assert {"log", "second"} <= _tables(cfg)
    assert _log(cfg) == [1, 2]


def test_migrations_run_with_foreign_keys_off_then_session_turns_them_on(
    make_cfg: Callable[..., config.Config], migrations: Path
):
    cfg = make_cfg()
    _write(
        migrations,
        "0001_parent_child.sql",
        "CREATE TABLE parent (id INTEGER PRIMARY KEY);\n"
        "CREATE TABLE child (parent_id INTEGER REFERENCES parent (id));\n",
    )
    # FK가 켜져 있으면 실패하는 삽입: 마이그레이션은 FK가 꺼진 채 돌아야 한다.
    _write(migrations, "0002_dangling.sql", "INSERT INTO child VALUES (999);\n")

    with store.write_session(cfg) as conn:
        assert conn.execute("PRAGMA user_version").fetchone() == (2,)
        assert conn.execute("SELECT parent_id FROM child").fetchall() == [(999,)]
        assert conn.execute("PRAGMA foreign_keys").fetchone() == (1,)


def test_new_data_dir_is_private_and_existing_dir_is_left_alone(
    make_cfg: Callable[..., config.Config], tmp_path: Path
):
    created = make_cfg(data_dir=str(tmp_path / "nested" / "data"))
    with store.write_session(created):
        pass
    assert stat.S_IMODE(created.data_dir.stat().st_mode) == 0o700

    existing = make_cfg(data_dir=str(tmp_path / "existing"))
    existing.data_dir.mkdir()
    existing.data_dir.chmod(0o750)
    with store.write_session(existing):
        pass
    assert stat.S_IMODE(existing.data_dir.stat().st_mode) == 0o750


def test_up_to_date_db_runs_nothing_again(cfg: config.Config, migrations: Path):
    _write(migrations, "0001_log.sql", LOG_0001)
    _write(migrations, "0002_second.sql", SECOND_0002)

    for _ in range(3):
        with store.write_session(cfg):
            pass

    assert _version(cfg) == 2
    assert _log(cfg) == [1, 2]


def test_only_pending_migrations_are_applied(cfg: config.Config, migrations: Path):
    _write(migrations, "0001_log.sql", LOG_0001)
    with store.write_session(cfg):
        pass
    assert (_version(cfg), _log(cfg)) == (1, [1])

    _write(migrations, "0002_second.sql", SECOND_0002)
    with store.write_session(cfg):
        pass

    assert (_version(cfg), _log(cfg)) == (2, [1, 2])


def test_failed_migration_rolls_back_that_file_and_releases_lock(
    cfg: config.Config, migrations: Path, connections: list[sqlite3.Connection]
):
    _write(migrations, "0001_log.sql", LOG_0001)
    _write(
        migrations,
        "0002_broken.sql",
        "CREATE TABLE second (x TEXT);\nINSERT INTO missing VALUES (1);\n",
    )

    with (
        pytest.raises(store.MigrationError, match="0002_broken.sql") as excinfo,
        store.write_session(cfg),
    ):
        pytest.fail("마이그레이션이 실패하면 세션에 들어가지 않는다")

    assert isinstance(excinfo.value.__cause__, sqlite3.OperationalError)
    assert _version(cfg) == 1
    assert "second" not in _tables(cfg)
    assert _log(cfg) == [1]
    assert all(_is_closed(conn) for conn in connections)
    assert store.write_lock_held(cfg) is False

    _write(migrations, "0002_broken.sql", SECOND_0002)
    with store.write_session(cfg):
        pass
    assert (_version(cfg), _log(cfg)) == (2, [1, 2])


def test_migration_that_ends_its_own_transaction_does_not_bump_version(
    cfg: config.Config, migrations: Path
):
    _write(migrations, "0001_commits.sql", "CREATE TABLE a (x);\nCOMMIT;\n")

    with (
        pytest.raises(store.MigrationError, match="0001_commits.sql"),
        store.write_session(cfg),
    ):
        pytest.fail("세션에 들어가지 않는다")

    assert _version(cfg) == 0
    assert store.write_lock_held(cfg) is False


def test_exception_in_block_propagates_closes_and_releases(
    cfg: config.Config, migrations: Path
):
    _write(migrations, "0001_log.sql", LOG_0001)

    with pytest.raises(Boom), store.write_session(cfg) as conn:
        conn.execute("BEGIN")
        conn.execute("INSERT INTO log VALUES (99)")
        raise Boom

    assert _is_closed(conn)
    assert store.write_lock_held(cfg) is False
    assert _log(cfg) == [1]


def test_single_insert_persists_and_open_transaction_rolls_back_on_exit(
    cfg: config.Config, migrations: Path
):
    _write(migrations, "0001_log.sql", LOG_0001)

    with store.write_session(cfg) as conn:
        conn.execute("INSERT INTO log VALUES (10)")
        assert _log(cfg) == [1, 10]
        conn.execute("BEGIN")
        conn.execute("INSERT INTO log VALUES (11)")

    assert _is_closed(conn)
    assert store.write_lock_held(cfg) is False
    assert _log(cfg) == [1, 10]


def test_transaction_commits_on_success_and_rolls_back_on_error(
    cfg: config.Config, migrations: Path
):
    _write(migrations, "0001_log.sql", LOG_0001)

    with store.write_session(cfg) as conn:
        with store.transaction(conn) as same:
            assert same is conn
            assert conn.in_transaction
            conn.execute("DELETE FROM log")
            conn.execute("INSERT INTO log VALUES (20)")
            assert _log(cfg) == [1]
        assert not conn.in_transaction
        assert _log(cfg) == [20]

        with pytest.raises(Boom), store.transaction(conn):
            conn.execute("INSERT INTO log VALUES (30)")
            raise Boom
        assert not conn.in_transaction
        assert _log(cfg) == [20]


def test_savepoint_keeps_success_and_undoes_only_its_own_writes_on_error(
    cfg: config.Config, migrations: Path
):
    _write(migrations, "0001_log.sql", LOG_0001)

    with store.write_session(cfg) as conn:
        with store.transaction(conn):
            conn.execute("INSERT INTO log VALUES (2)")
            with store.savepoint(conn) as same:
                assert same is conn
                conn.execute("INSERT INTO log VALUES (3)")
            assert conn.in_transaction

            with pytest.raises(Boom), store.savepoint(conn):
                conn.execute("INSERT INTO log VALUES (4)")
                raise Boom
            # 바깥 트랜잭션은 그대로 열려 있고 저장점 앞의 쓰기와 성공한 저장점은 남는다.
            assert conn.in_transaction
            conn.execute("INSERT INTO log VALUES (5)")
            # 다른 연결은 커밋 전이라 아직 못 본다.
            assert _log(cfg) == [1]
        assert not conn.in_transaction
        assert _log(cfg) == [1, 2, 3, 5]

        # 바깥 트랜잭션이 롤백되면 성공한 저장점의 쓰기도 함께 사라진다.
        with pytest.raises(Boom), store.transaction(conn):
            with store.savepoint(conn):
                conn.execute("INSERT INTO log VALUES (6)")
            raise Boom
        assert _log(cfg) == [1, 2, 3, 5]


def test_transaction_on_read_connection_reads_one_snapshot(
    cfg: config.Config, migrations: Path
):
    _write(migrations, "0001_log.sql", LOG_0001)

    with store.write_session(cfg) as writer:
        reader = store.read_connection(cfg)
        try:
            with store.transaction(reader):
                before = reader.execute("SELECT count(*) FROM log").fetchone()
                writer.execute("INSERT INTO log VALUES (40)")
                after = reader.execute("SELECT count(*) FROM log").fetchone()
            assert before == after == (1,)
            assert reader.execute("SELECT count(*) FROM log").fetchone() == (2,)
        finally:
            reader.close()


def test_lock_contention_with_other_process_times_out(
    make_cfg: Callable[..., config.Config],
    holder: Callable[[Path], subprocess.Popen[str]],
):
    cfg = make_cfg(lock_wait_seconds=0.3)
    process = holder(cfg.path)
    assert store.write_lock_held(cfg) is True

    started = time.monotonic()
    with pytest.raises(store.LockTimeout) as excinfo, store.write_session(cfg):
        pytest.fail("다른 프로세스가 쥔 락을 잡으면 안 된다")
    waited = time.monotonic() - started

    assert waited >= 0.3
    assert str(cfg.data_dir / ".write.lock") in str(excinfo.value)
    assert "0.3초" in str(excinfo.value)
    assert store.write_lock_held(cfg) is True

    process.communicate("\n", timeout=10)
    assert process.returncode == 0
    assert store.write_lock_held(cfg) is False


def test_session_starts_when_holder_releases_within_wait(
    make_cfg: Callable[..., config.Config],
):
    cfg = make_cfg(lock_wait_seconds=10)
    fd = _hold_lock_in_this_process(cfg)
    release = threading.Timer(0.3, os.close, args=(fd,))

    started = time.monotonic()
    release.start()
    try:
        with store.write_session(cfg) as conn:
            waited = time.monotonic() - started
            assert store.write_lock_held(cfg) is True
            conn.execute("SELECT 1")
    finally:
        release.join()

    assert 0.3 <= waited < 5


def test_zero_wait_tries_once(cfg: config.Config, monkeypatch: pytest.MonkeyPatch):
    sleeps: list[float] = []
    monkeypatch.setattr(time, "sleep", sleeps.append)
    fd = _hold_lock_in_this_process(cfg)
    try:
        with pytest.raises(store.LockTimeout, match="0초"), store.write_session(cfg):
            pytest.fail("락을 잡으면 안 된다")
    finally:
        os.close(fd)

    assert sleeps == []


def test_nested_session_fails_without_waiting(make_cfg: Callable[..., config.Config]):
    cfg = make_cfg(lock_wait_seconds=10)

    with store.write_session(cfg) as conn:
        # 실패한 중첩 시도가 바깥 세션의 표시를 지우지 않으므로 두 번째도 바로 실패한다.
        for _ in range(2):
            started = time.monotonic()
            with pytest.raises(RuntimeError, match="중첩"), store.write_session(cfg):
                pytest.fail("중첩 세션에 들어가면 안 된다")
            assert time.monotonic() - started < 1
        assert store.write_lock_held(cfg) is True
        conn.execute("SELECT 1")

    assert store.write_lock_held(cfg) is False
    with store.write_session(cfg):
        pass


def test_nested_session_through_symlinked_data_dir_fails(
    make_cfg: Callable[..., config.Config], tmp_path: Path
):
    cfg = make_cfg(lock_wait_seconds=10)
    (tmp_path / "alias").symlink_to(tmp_path / "data", target_is_directory=True)
    alias = dataclasses.replace(cfg, data_dir=tmp_path / "alias")

    with (
        store.write_session(cfg),
        pytest.raises(RuntimeError, match="중첩"),
        store.write_session(alias),
    ):
        pytest.fail("같은 락 파일이면 중첩이다")


def test_child_process_does_not_inherit_lock(cfg: config.Config):
    process = subprocess.Popen(
        [sys.executable, "-c", SPAWNER, str(cfg.path)],
        stdout=subprocess.PIPE,
        text=True,
    )
    assert process.stdout is not None
    with process.stdout:
        line = process.stdout.readline()
    assert process.wait(timeout=10) == 0
    grandchild = int(line)
    try:
        os.kill(grandchild, 0)  # 세션을 연 프로세스는 끝났지만 손자는 아직 살아 있다.
        assert store.write_lock_held(cfg) is False
    finally:
        # 손자는 launchd/init로 넘어갔으므로 여기서는 죽이기만 하고 거두기는 그쪽이 한다.
        try:
            os.kill(grandchild, signal.SIGKILL)
        except ProcessLookupError:
            pass


@pytest.mark.parametrize("state", ["no-data-dir", "no-lock-file", "data-dir-is-file"])
def test_lock_check_without_lock_file_is_false_and_creates_nothing(
    cfg: config.Config, tmp_path: Path, state: str
):
    if state == "no-lock-file":
        cfg.data_dir.mkdir()
    elif state == "data-dir-is-file":
        cfg.data_dir.write_text("", encoding="utf-8")
    before = _tree(tmp_path)

    assert store.write_lock_held(cfg) is False
    assert _tree(tmp_path) == before


def test_lock_check_with_released_lock_file_is_false(cfg: config.Config):
    with store.write_session(cfg):
        assert store.write_lock_held(cfg) is True

    assert (cfg.data_dir / ".write.lock").is_file()
    assert store.write_lock_held(cfg) is False


def test_read_connection_is_read_only_and_sees_committed_rows(
    cfg: config.Config, migrations: Path
):
    _write(migrations, "0001_log.sql", LOG_0001)

    with store.write_session(cfg) as writer:
        writer.execute("INSERT INTO log VALUES (50)")
        # 커밋은 됐지만 아직 체크포인트 전이라 WAL에만 있다.
        assert (cfg.data_dir / "garmin.db-wal").stat().st_size > 0
        reader = store.read_connection(cfg)
        try:
            assert reader.autocommit is True
            rows = reader.execute("SELECT n FROM log ORDER BY rowid").fetchall()
            assert rows == [(1,), (50,)]
            with pytest.raises(sqlite3.OperationalError, match="readonly"):
                reader.execute("INSERT INTO log VALUES (51)")
        finally:
            reader.close()

    assert _log(cfg) == [1, 50]


def test_read_rejects_older_db(
    cfg: config.Config, migrations: Path, connections: list[sqlite3.Connection]
):
    _write(migrations, "0001_log.sql", LOG_0001)
    with store.write_session(cfg):
        pass
    _write(migrations, "0002_second.sql", SECOND_0002)

    with pytest.raises(store.SchemaMismatch) as excinfo:
        store.read_connection(cfg)

    assert (excinfo.value.found, excinfo.value.expected) == (1, 2)
    assert _version(cfg) == 1
    assert all(_is_closed(conn) for conn in connections)


def test_read_rejects_newer_db(
    cfg: config.Config, migrations: Path, connections: list[sqlite3.Connection]
):
    _write(migrations, "0001_log.sql", LOG_0001)
    _write(migrations, "0002_second.sql", SECOND_0002)
    with store.write_session(cfg):
        pass
    (migrations / "0002_second.sql").unlink()

    with pytest.raises(store.SchemaMismatch) as excinfo:
        store.read_connection(cfg)

    assert (excinfo.value.found, excinfo.value.expected) == (2, 1)
    assert _version(cfg) == 2
    assert all(_is_closed(conn) for conn in connections)


def test_write_rejects_newer_db_without_changing_it(
    cfg: config.Config, migrations: Path, connections: list[sqlite3.Connection]
):
    _write(migrations, "0001_log.sql", LOG_0001)
    _write(migrations, "0002_second.sql", SECOND_0002)
    with store.write_session(cfg):
        pass
    (migrations / "0002_second.sql").unlink()
    tables = _tables(cfg)

    with pytest.raises(store.SchemaMismatch) as excinfo, store.write_session(cfg):
        pytest.fail("더 새 DB에는 쓰지 않는다")

    assert (excinfo.value.found, excinfo.value.expected) == (2, 1)
    assert _version(cfg) == 2
    assert _tables(cfg) == tables
    assert _log(cfg) == [1, 2]
    assert all(_is_closed(conn) for conn in connections)
    assert store.write_lock_held(cfg) is False


def test_write_rejects_newer_rollback_journal_db_before_switching_to_wal(
    cfg: config.Config, migrations: Path
):
    _write(migrations, "0001_log.sql", LOG_0001)
    cfg.data_dir.mkdir()
    raw = _raw_connect(cfg.db_path)
    try:
        raw.execute("PRAGMA user_version = 5")
    finally:
        raw.close()

    with pytest.raises(store.SchemaMismatch) as excinfo, store.write_session(cfg):
        pytest.fail("더 새 DB에는 쓰지 않는다")

    assert (excinfo.value.found, excinfo.value.expected) == (5, 1)
    assert not (cfg.data_dir / "garmin.db-wal").exists()
    assert _query(cfg, "PRAGMA journal_mode") == [("delete",)]
    assert _version(cfg) == 5


@pytest.mark.parametrize("data_dir_exists", [False, True])
def test_read_without_db_is_db_missing_and_creates_nothing(
    cfg: config.Config, tmp_path: Path, data_dir_exists: bool
):
    if data_dir_exists:
        cfg.data_dir.mkdir()
    before = _tree(tmp_path)

    with pytest.raises(store.DbMissing, match="garmin.db"):
        store.read_connection(cfg)

    assert _tree(tmp_path) == before


_RUN_ROW = {
    "local_date": "2026-10-16",
    "started_at": 1_000,
    "finished_at": 2_000,
    "status": "error",
    "detail": "lock_timeout",
}


def _runs(cfg: config.Config) -> list[tuple[object, ...]]:
    return _query(
        cfg,
        "SELECT local_date, started_at, finished_at, status, detail FROM run"
        " ORDER BY id",
    )


def test_unlocked_run_insert_works_while_another_process_holds_the_session(
    cfg: config.Config,
    holder: Callable[[Path], subprocess.Popen[str]],
    connections: list[sqlite3.Connection],
):
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO run (local_date, started_at, status) VALUES ('2026-10-15', 1, 'running')"
        )
    process = holder(cfg.path)
    opened = len(connections)

    store.insert_run_unlocked(cfg, **_RUN_ROW)

    assert store.write_lock_held(cfg) is True
    assert all(_is_closed(conn) for conn in connections[opened:])
    assert _runs(cfg) == [
        ("2026-10-15", 1, None, "running", ""),
        tuple(_RUN_ROW.values()),
    ]
    process.communicate("\n", timeout=10)
    assert process.returncode == 0


@pytest.mark.parametrize("data_dir_exists", [False, True])
def test_unlocked_run_insert_without_db_is_db_missing_and_creates_nothing(
    cfg: config.Config, tmp_path: Path, data_dir_exists: bool
):
    if data_dir_exists:
        cfg.data_dir.mkdir()
    before = _tree(tmp_path)

    with pytest.raises(store.DbMissing, match="garmin.db"):
        store.insert_run_unlocked(cfg, **_RUN_ROW)

    assert _tree(tmp_path) == before


@pytest.mark.parametrize("offset", [-1, 1], ids=["older", "newer"])
def test_unlocked_run_insert_rejects_other_schema_version_without_writing(
    cfg: config.Config, connections: list[sqlite3.Connection], offset: int
):
    with store.write_session(cfg):
        pass
    latest = store._latest(store._load_migrations())
    raw = _raw_connect(cfg.db_path)
    try:
        raw.execute(f"PRAGMA user_version = {latest + offset:d}")
    finally:
        raw.close()

    with pytest.raises(store.SchemaMismatch) as excinfo:
        store.insert_run_unlocked(cfg, **_RUN_ROW)

    assert (excinfo.value.found, excinfo.value.expected) == (latest + offset, latest)
    assert _runs(cfg) == []
    assert all(_is_closed(conn) for conn in connections)


def test_special_characters_in_data_dir(
    make_cfg: Callable[..., config.Config], migrations: Path, tmp_path: Path
):
    odd = "공백 있는 #해시 ?물음 한글"
    cfg = make_cfg(data_dir=str(tmp_path / odd / "data"))
    _write(migrations, "0001_log.sql", LOG_0001)

    with store.write_session(cfg) as conn:
        conn.execute("INSERT INTO log VALUES (60)")
    reader = store.read_connection(cfg)
    try:
        rows = reader.execute("SELECT n FROM log ORDER BY rowid").fetchall()
    finally:
        reader.close()

    assert rows == [(1,), (60,)]
    assert cfg.db_path.is_file()
    assert sorted(path.name for path in tmp_path.iterdir()) == sorted(
        ["config.toml", "migrations", odd]
    )
    assert [path.name for path in (tmp_path / odd).iterdir()] == ["data"]


@pytest.mark.parametrize(
    "names",
    [
        pytest.param(["0001_a.sql", "0001_b.sql"], id="duplicate"),
        pytest.param(["1_a.sql"], id="short-number"),
        pytest.param(["0001-a.sql"], id="dash"),
        pytest.param(["0001_A.sql"], id="uppercase"),
        pytest.param(["0001_a.txt"], id="not-sql"),
        pytest.param(["0001_.sql"], id="empty-name"),
        pytest.param(["0001_a.sql.bak"], id="suffix-after-sql"),
        pytest.param(["٠٠٠١_a.sql"], id="non-ascii-digits"),
        pytest.param(["0000_a.sql"], id="zero"),
        pytest.param(["0001_a.sql", "0003_c.sql"], id="gap"),
        pytest.param(["0002_b.sql"], id="not-from-0001"),
    ],
)
def test_invalid_migration_list_is_rejected_before_anything_is_created(
    cfg: config.Config, migrations: Path, tmp_path: Path, names: list[str]
):
    for name in names:
        _write(migrations, name)
    before = _tree(tmp_path)

    with pytest.raises(store.MigrationError):
        store._load_migrations()
    with pytest.raises(store.MigrationError), store.write_session(cfg):
        pytest.fail("목록이 잘못되면 세션에 들어가지 않는다")
    with pytest.raises(store.MigrationError):
        store.read_connection(cfg)

    assert _tree(tmp_path) == before


def test_directory_named_like_migration_is_rejected(migrations: Path):
    (migrations / "0001_a.sql").mkdir()

    with pytest.raises(store.MigrationError, match="0001_a.sql"):
        store._load_migrations()


def test_missing_migrations_dir_is_rejected(
    cfg: config.Config, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setattr(store, "_migrations_dir", lambda: tmp_path / "nowhere")
    before = _tree(tmp_path)

    with pytest.raises(store.MigrationError, match="폴더"):
        store._load_migrations()
    with pytest.raises(store.MigrationError), store.write_session(cfg):
        pytest.fail("목록이 없으면 세션에 들어가지 않는다")

    assert _tree(tmp_path) == before


def test_dotfiles_are_ignored_and_empty_list_is_version_0(migrations: Path):
    _write(migrations, ".gitkeep", "")
    _write(migrations, ".DS_Store", "\0")

    assert store._load_migrations() == []

    _write(migrations, "0002_b.sql")
    _write(migrations, "0001_a.sql")

    loaded = store._load_migrations()
    assert [(m.number, m.name) for m in loaded] == [
        (1, "0001_a.sql"),
        (2, "0002_b.sql"),
    ]


def test_non_wal_journal_mode_is_an_error(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
):
    opened: list[sqlite3.Connection] = []

    def memory_db(*args: object, **kwargs: object) -> sqlite3.Connection:
        # 메모리 DB는 WAL로 바뀌지 않고 `memory`를 돌려준다.
        conn = _raw_connect(":memory:", autocommit=True)
        opened.append(conn)
        return conn

    monkeypatch.setattr(sqlite3, "connect", memory_db)

    with pytest.raises(store.StoreError, match="WAL"), store.write_session(cfg):
        pytest.fail("WAL이 아니면 세션에 들어가지 않는다")

    assert len(opened) == 1 and _is_closed(opened[0])
    assert store.write_lock_held(cfg) is False


def _assert_all_refused(cfg: config.Config) -> None:
    """네 공개 함수가 모두 pytest 가드의 `StoreError`(하위 클래스 아님)로 거부한다."""

    def enter_write_session() -> None:
        with store.write_session(cfg):
            pytest.fail("runtime 아래에는 쓰지 않는다")

    def enter_report_session() -> None:
        with store.report_session(cfg, blocking=False):
            pytest.fail("runtime 아래에는 쓰지 않는다")

    for call in (
        enter_report_session,
        enter_write_session,
        lambda: store.read_connection(cfg),
        lambda: store.write_lock_held(cfg),
        lambda: store.insert_run_unlocked(cfg, **_RUN_ROW),
    ):
        with pytest.raises(store.StoreError, match="runtime") as excinfo:
            call()
        assert type(excinfo.value) is store.StoreError


@pytest.mark.parametrize("layout", ["direct", "symlink", "other-case"])
def test_pytest_guard_refuses_runtime_data_dir(
    make_cfg: Callable[..., config.Config], tmp_path: Path, layout: str
):
    if layout == "symlink":
        (tmp_path / "runtime").mkdir()
        (tmp_path / "live").symlink_to(tmp_path / "runtime", target_is_directory=True)
        data_dir = tmp_path / "live" / "data"
    elif layout == "other-case":
        # 대소문자를 가리지 않는 macOS에서는 `runtime/`과 같은 폴더다.
        data_dir = tmp_path / "Runtime" / "data"
    else:
        data_dir = tmp_path / "runtime" / "data"
    cfg = make_cfg(data_dir=str(data_dir))
    before = _tree(tmp_path)

    _assert_all_refused(cfg)

    assert _tree(tmp_path) == before


@pytest.mark.parametrize("name", ["garmin.db", ".write.lock", ".report.lock"])
def test_pytest_guard_refuses_file_symlinked_into_runtime(
    cfg: config.Config, tmp_path: Path, name: str
):
    target_dir = tmp_path / "runtime" / "data"
    target_dir.mkdir(parents=True)
    cfg.data_dir.mkdir()
    (cfg.data_dir / name).symlink_to(target_dir / name)
    before = _tree(tmp_path)

    _assert_all_refused(cfg)

    assert _tree(tmp_path) == before


def test_pytest_guard_only_applies_under_pytest(
    make_cfg: Callable[..., config.Config],
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    cfg = make_cfg(data_dir=str(tmp_path / "runtime" / "data"))
    monkeypatch.setattr(config, "under_pytest", lambda: False)

    latest = store._latest(store._load_migrations())

    assert store.write_lock_held(cfg) is False
    with store.write_session(cfg) as conn:
        assert conn.execute("PRAGMA user_version").fetchone() == (latest,)
    reader = store.read_connection(cfg)
    try:
        assert reader.execute("PRAGMA user_version").fetchone() == (latest,)
    finally:
        reader.close()
    assert cfg.db_path.is_file()


@pytest.mark.parametrize("blocking", [True, False])
@pytest.mark.parametrize("fail", [True, False])
def test_report_session_permissions_release_and_fd(cfg, monkeypatch, blocking, fail):
    opened = []
    original = os.open

    def track(*args, **kwargs):
        fd = original(*args, **kwargs)
        opened.append(fd)
        return fd

    monkeypatch.setattr(os, "open", track)
    try:
        with store.report_session(cfg, blocking=blocking):
            assert not os.get_inheritable(opened[-1])
            assert stat.S_IMODE(cfg.data_dir.stat().st_mode) == 0o700
            assert (
                stat.S_IMODE((cfg.data_dir / store.REPORT_LOCK_FILENAME).stat().st_mode)
                == 0o600
            )
            assert not cfg.db_path.exists()
            if fail:
                raise Boom
    except Boom:
        assert fail
    with store.report_session(cfg, blocking=False):
        pass


def test_report_session_wait_and_busy(cfg):
    cfg.data_dir.mkdir()
    path = cfg.data_dir / store.REPORT_LOCK_FILENAME
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    fcntl.flock(fd, fcntl.LOCK_EX)
    try:
        with (
            pytest.raises(store.ReportLockBusy, match=str(path)),
            store.report_session(cfg, False),
        ):
            pytest.fail("held")
        release = threading.Timer(0.15, os.close, args=(fd,))
        release.start()
        started = time.monotonic()
        with store.report_session(cfg, True):
            assert time.monotonic() - started >= 0.1
    finally:
        release.join()


def test_report_session_lock_order_and_nested_guard(cfg, tmp_path):
    other = dataclasses.replace(cfg, data_dir=tmp_path / "other")
    with store.write_session(cfg):
        with pytest.raises(RuntimeError), store.report_session(other, True):
            pytest.fail("inverted")
        assert not other.data_dir.exists()
    with store.report_session(cfg, True):
        for _ in range(2):
            with pytest.raises(RuntimeError), store.report_session(other, True):
                pytest.fail("nested")
        assert not other.data_dir.exists()
        with store.write_session(cfg):
            pass
