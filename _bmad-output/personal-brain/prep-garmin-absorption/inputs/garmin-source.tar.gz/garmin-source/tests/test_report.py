"""일일 리포트 조립과 실패 폴백: `report`와 `garmin-pipeline report`(FR22·33·36·37, AD-8·10·16).

하루 분석 작성기와 `ReportSink`는 fake다(실제 codex 실행기는 `tests/test_report_codex.py`). 수집 대기 시계는
`report._monotonic`·`report._sleep`, 오늘 날짜는 `dates._utc_now`만 바꾼다.
"""

import contextlib
import fcntl
import importlib.resources
import json
import os
import sqlite3
import stat
from collections.abc import Callable, Iterator
from datetime import UTC, date, datetime
from pathlib import Path

import pytest

from garmin_pipeline import cli, config, dates, errors, garmin, ports, report, store

CLOCK = datetime(2026, 10, 18, 2, 30, tzinfo=UTC)
"""Asia/Seoul로 2026-10-18 11:30이다."""
TODAY = date(2026, 10, 18)
SECRET = "섹션6-비밀-문장-91f3"
HEADING = "\n## 6. 몸상태 종합\n\n"
OK_BODY = f"회복 상태는 양호하다. {SECRET}"
PERIOD_BLOCK = "\n\n## 기간 평가\n\n### 7일\n\n기간 본문\n\n### 30일\n\n기간 본문\n\n### 전체\n\n기간 본문"
REASON = errors.ReportFailReason


# --- fake ---------------------------------------------------------------------------------


class FakeWriter:
    """정해진 결과를 돌려주거나 예외를 던지는 작성기. 받은 `inputs`를 남긴다."""

    def __init__(self, result: object = None, error: BaseException | None = None):
        self.result = result
        self.error = error
        self.calls: list[list[str]] = []

    def write(self, cfg: config.Config, inputs: list[str]) -> report.DailyAnalysis:
        self.calls.append(list(inputs))
        if self.error is not None:
            raise self.error
        return self.result  # type: ignore[return-value]

    def period(self, cfg, inputs, scope):
        if self.error is not None:
            raise self.error
        return report.DailyAnalysis("ok", "기간 본문", "기간 요약")


class FakeSink:
    def __init__(self, error: BaseException | None = None):
        self.error = error
        self.calls: list[ports.ReportBundle] = []

    def deliver(self, bundle: ports.ReportBundle) -> None:
        self.calls.append(bundle)
        if self.error is not None:
            raise self.error


def ok_writer(text: str = OK_BODY) -> FakeWriter:
    return FakeWriter(report.DailyAnalysis("ok", text))


# --- fixture ------------------------------------------------------------------------------


@pytest.fixture
def write_cfg(write_config: Callable[..., Path]) -> Callable[..., config.Config]:
    def make(**overrides: object) -> config.Config:
        values: dict[str, object] = {"report_wait_minutes": 0, "lock_wait_seconds": 0}
        return config.load(write_config(**(values | overrides)))

    return make


@pytest.fixture
def cfg(write_cfg: Callable[..., config.Config]) -> config.Config:
    return write_cfg()


@pytest.fixture
def no_sleep(monkeypatch: pytest.MonkeyPatch) -> None:
    """`run` 시험에서 대기가 실제로 잠들지 않게 한다(`report_wait_minutes = 0`이라 잠들면 오류다)."""

    def refuse(seconds: float) -> None:
        pytest.fail(f"대기하지 않아야 한다({seconds}초)")

    monkeypatch.setattr(report, "_sleep", refuse)


class FakeClock:
    def __init__(self) -> None:
        self.now = 1000.0
        self.sleeps: list[float] = []
        self.on_sleep: Callable[[], None] | None = None

    def monotonic(self) -> float:
        return self.now

    def sleep(self, seconds: float) -> None:
        self.sleeps.append(seconds)
        self.now += seconds
        if self.on_sleep is not None:
            self.on_sleep()


@pytest.fixture
def clock(monkeypatch: pytest.MonkeyPatch) -> FakeClock:
    fake = FakeClock()
    monkeypatch.setattr(report, "_monotonic", fake.monotonic)
    monkeypatch.setattr(report, "_sleep", fake.sleep)
    monkeypatch.setattr(dates, "_utc_now", lambda: CLOCK)
    return fake


# --- 도움 함수 -----------------------------------------------------------------------------


def _migrated_db(cfg: config.Config) -> None:
    with store.write_session(cfg):
        pass


def _insert_run(cfg: config.Config, day: date, status: str, detail: str = "") -> None:
    finished = None if status == errors.RunStatus.RUNNING else 2
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO run (local_date, started_at, finished_at, status, detail)"
            " VALUES (?, 1, ?, ?, ?)",
            (day.isoformat(), finished, status, detail),
        )


def _write_block(cfg: config.Config, day: date) -> None:
    cfg.tokenstore.mkdir(parents=True, exist_ok=True)
    payload = {
        "schema_version": 1,
        "local_date": day.isoformat(),
        "reason": "rate_limited",
    }
    (cfg.tokenstore / report.BLOCK_FILENAME).write_text(json.dumps(payload))


@contextlib.contextmanager
def _hold_lock(cfg: config.Config) -> Iterator[Callable[[], None]]:
    """다른 작성자처럼 쓰기 락을 쥔다. 내준 함수를 부르면 먼저 푼다."""
    cfg.data_dir.mkdir(parents=True, exist_ok=True)
    fd = os.open(cfg.data_dir / store.LOCK_FILENAME, os.O_RDWR | os.O_CREAT, 0o600)
    fcntl.flock(fd, fcntl.LOCK_EX)
    released = [False]

    def release() -> None:
        if not released[0]:
            fcntl.flock(fd, fcntl.LOCK_UN)
            released[0] = True

    try:
        yield release
    finally:
        release()
        os.close(fd)


def _notifications(cfg: config.Config) -> list[tuple[str, str, str]]:
    if not cfg.db_path.exists():
        return []
    conn = sqlite3.connect(cfg.db_path)
    try:
        return conn.execute(
            "SELECT local_date, event, detail FROM notification ORDER BY rowid"
        ).fetchall()
    finally:
        conn.close()


def _only_report(cfg: config.Config) -> Path:
    """`reports_dir`에 리포트 하나만(임시 파일 없이) 있으면 그 경로."""
    names = sorted(os.listdir(cfg.reports_dir))
    assert len(names) == 1, names
    (name,) = names
    assert name.endswith(".md") and not name.startswith(".")
    date.fromisoformat(name.removesuffix(".md"))
    return cfg.reports_dir / name


def _split(path: Path) -> tuple[bytes, str]:
    """(섹션 6 제목 앞 바이트, 섹션 6 본문)."""
    content = path.read_bytes()
    head, separator, tail = content.rpartition(HEADING.encode("utf-8"))
    assert separator, "섹션 6 제목이 없다"
    return head, tail.decode("utf-8").split("\n" + report.GRAPH_HEADING + "\n", 1)[0]


def _fallback(reason: str, text: str, skill: str | None = None) -> str:
    lines = [
        f"> 몸상태 종합을 쓰지 못했다: {text} (`{reason}`).",
        "> 섹션 1~5의 수치는 위와 같다. 같은 날 report를 다시 실행하면 이 섹션을 다시 쓴다.",
    ]
    if skill is not None:
        lines.append(f"> skill 메시지: {skill}")
    return "\n".join(lines) + "\n"


# --- 고정 사항 ------------------------------------------------------------------------------


def test_block_filename_matches_garmin_adapter():
    assert report.BLOCK_FILENAME == garmin.BLOCK_FILENAME


def test_daily_analysis_statuses_match_report_output_schema():
    schema = json.loads(
        importlib.resources.files("garmin_pipeline")
        .joinpath("schemas/daily_analysis_output.schema.json")
        .read_text(encoding="utf-8")
    )

    assert report.DAILY_STATUSES == tuple(schema["properties"]["status"]["enum"])


def test_fallback_text_covers_writer_reasons_only():
    assert set(report.FALLBACK_TEXT) == {
        REASON.CODEX_TIMEOUT,
        REASON.CODEX_FAILED,
        REASON.OUTPUT_INVALID,
        REASON.SKILL_FAILED,
    }


def test_writer_failed_keeps_reason_and_rejects_unknown():
    error = report.WriterFailed("codex_timeout", "exit=124")

    assert error.reason is REASON.CODEX_TIMEOUT
    assert error.detail == "exit=124"
    with pytest.raises(ValueError):
        report.WriterFailed("timeout")


def test_default_writer_is_codex_writer(cfg: config.Config):
    writer = report.default_writer(cfg)

    assert isinstance(writer, report.CodexWriter)
    assert not hasattr(report, "UnavailableWriter")
    # 기본 config는 report_model이 없어 codex를 띄우지 않고 실패한다.
    with pytest.raises(report.WriterFailed) as caught:
        writer.write(cfg, [])

    assert caught.value.reason is REASON.CODEX_FAILED
    assert caught.value.detail == "report_model 미설정"


# --- 정상 ------------------------------------------------------------------------------------


# --- 작성기 실패 폴백 -------------------------------------------------------------------------


# --- 쓰기 실패·알림 실패·전달 실패 -------------------------------------------------------------


def test_write_failure_cleans_temporary_and_exits_1(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch, no_sleep: None
):
    def refuse(source: object, target: object) -> None:
        raise OSError("쓰기 실패")

    monkeypatch.setattr(report.os, "replace", refuse)
    sink = FakeSink()
    failing = FakeWriter(error=report.WriterFailed(REASON.OUTPUT_INVALID))

    assert report.run(cfg, failing, sink) == 1

    assert os.listdir(cfg.reports_dir) == []
    assert sink.calls == []
    ((day, event, detail),) = _notifications(cfg)
    assert (event, detail) == (
        "report_failed",
        "codex_failed write_failed scopes=day,7d,30d,all",
    )
    date.fromisoformat(day)


def test_reports_dir_not_creatable(
    write_cfg: Callable[..., config.Config], tmp_path: Path, no_sleep: None
):
    (tmp_path / "blocker").write_text("파일")
    cfg = write_cfg(reports_dir="blocker/reports")

    assert report.run(cfg, ok_writer()) == 1

    assert [row[1:] for row in _notifications(cfg)] == [
        ("report_failed", "write_failed")
    ]


def test_notify_failure_is_logged_only(
    cfg: config.Config, caplog: pytest.LogCaptureFixture, no_sleep: None
):
    failing = FakeWriter(error=report.WriterFailed(REASON.CODEX_FAILED))

    with _hold_lock(cfg), caplog.at_level("INFO", logger="garmin_pipeline"):
        code = report.run(cfg, failing)

    assert code == 0
    _only_report(cfg)
    assert _notifications(cfg) == []
    assert "report_failed 알림을 기록하지 못했다" in caplog.text
    assert "LockTimeout" in caplog.text


def test_sink_failure_is_logged_only(
    cfg: config.Config, caplog: pytest.LogCaptureFixture, no_sleep: None
):
    sink = FakeSink(error=RuntimeError("전달 실패"))

    with caplog.at_level("INFO", logger="garmin_pipeline"):
        assert report.run(cfg, ok_writer(), sink) == 0

    assert len(sink.calls) == 1
    assert "리포트 전달 실패" in caplog.text
    assert _notifications(cfg) == []


# --- 수집 대기 --------------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("blocked", "lock_held", "status", "expected"),
    [
        (True, True, "not_run", False),
        (True, False, "not_run", False),
        (False, True, "success", True),
        (False, True, None, True),
        (False, False, "not_run", True),
        (False, False, "running", False),
        (False, False, "success", False),
        (False, False, "error", False),
        (False, False, None, False),
    ],
)
def test_should_wait_table(
    blocked: bool, lock_held: bool, status: str | None, expected: bool
):
    assert report._should_wait(blocked, lock_held, status) is expected


@pytest.mark.parametrize(
    "prepare",
    [
        pytest.param(lambda cfg: None, id="db-missing"),
        pytest.param(_migrated_db, id="no-run-today"),
        pytest.param(
            lambda cfg: _insert_run(cfg, date(2026, 10, 17), "success"),
            id="only-yesterday",
        ),
        pytest.param(lambda cfg: _write_block(cfg, date(2026, 10, 17)), id="old-block"),
        pytest.param(
            lambda cfg: (
                cfg.tokenstore.mkdir(parents=True),
                (cfg.tokenstore / "block.json").write_text("{깨짐"),
            ),
            id="broken-block",
        ),
    ],
)
def test_wait_not_run_until_limit(
    write_cfg: Callable[..., config.Config],
    clock: FakeClock,
    prepare: Callable[[config.Config], object],
):
    cfg = write_cfg(report_wait_minutes=2)
    prepare(cfg)

    report.wait_for_collect(cfg)

    assert clock.sleeps == [30, 30, 30, 30]


def test_wait_partial_last_sleep(
    write_cfg: Callable[..., config.Config], clock: FakeClock
):
    cfg = write_cfg(report_wait_minutes=1)

    def drift() -> None:
        clock.now += 5  # 확인에 걸린 시간

    clock.on_sleep = drift
    report.wait_for_collect(cfg)

    assert clock.sleeps == [30, 25]
    assert sum(clock.sleeps) <= 60


def test_wait_ends_when_lock_released_and_success(
    write_cfg: Callable[..., config.Config], clock: FakeClock
):
    cfg = write_cfg(report_wait_minutes=30)
    _insert_run(cfg, TODAY, "running")

    with _hold_lock(cfg) as release:

        def finish() -> None:
            release()
            _insert_run(cfg, TODAY, "success")

        clock.on_sleep = finish
        report.wait_for_collect(cfg)

    assert clock.sleeps == [30]


@pytest.mark.parametrize(
    "prepare",
    [
        pytest.param(lambda cfg: _write_block(cfg, TODAY), id="block-json"),
        pytest.param(
            lambda cfg: _insert_run(cfg, TODAY, "skipped_blocked"), id="skipped-row"
        ),
    ],
)
def test_wait_blocked_never_waits(
    write_cfg: Callable[..., config.Config],
    clock: FakeClock,
    prepare: Callable[[config.Config], object],
):
    cfg = write_cfg(report_wait_minutes=30)
    prepare(cfg)

    # 락을 쥐고 오늘 실행 기록도 없지만(not_run) 차단이면 기다리지 않는다.
    with _hold_lock(cfg):
        report.wait_for_collect(cfg)

    assert clock.sleeps == []


def test_wait_abandoned_running_never_waits(
    write_cfg: Callable[..., config.Config], clock: FakeClock
):
    cfg = write_cfg(report_wait_minutes=30)
    _insert_run(cfg, TODAY, "running")

    report.wait_for_collect(cfg)

    assert clock.sleeps == []


def test_wait_schema_mismatch_never_waits(
    write_cfg: Callable[..., config.Config], clock: FakeClock
):
    cfg = write_cfg(report_wait_minutes=30)
    _migrated_db(cfg)
    conn = sqlite3.connect(cfg.db_path)
    conn.execute("PRAGMA user_version = 999")
    conn.close()

    report.wait_for_collect(cfg)

    assert clock.sleeps == []


def test_wait_lock_until_limit_then_run_continues(
    write_cfg: Callable[..., config.Config], clock: FakeClock
):
    cfg = write_cfg(report_wait_minutes=1)
    _insert_run(cfg, TODAY, "success")

    with _hold_lock(cfg):
        assert report.run(cfg, ok_writer()) == 0

    assert clock.sleeps == [30, 30]
    _only_report(cfg)


def test_wait_keeps_start_day_across_midnight(
    write_cfg: Callable[..., config.Config],
    clock: FakeClock,
    monkeypatch: pytest.MonkeyPatch,
):
    cfg = write_cfg(report_wait_minutes=30)
    _insert_run(cfg, TODAY, "success")
    now = [datetime(2026, 10, 18, 14, 59, 50, tzinfo=UTC)]  # Asia/Seoul 23:59:50
    monkeypatch.setattr(dates, "_utc_now", lambda: now[0])

    with _hold_lock(cfg) as release:

        def cross_midnight() -> None:
            release()
            now[0] = datetime(2026, 10, 18, 15, 0, 20, tzinfo=UTC)  # 다음 날 00:00:20

        clock.on_sleep = cross_midnight
        report.wait_for_collect(cfg)

    # 다음 날(not_run)로 다시 판정했다면 30분 끝까지 기다렸을 것이다.
    assert clock.sleeps == [30]


def test_wait_does_not_write_db(
    write_cfg: Callable[..., config.Config], clock: FakeClock
):
    cfg = write_cfg(report_wait_minutes=1)

    report.wait_for_collect(cfg)

    assert not cfg.db_path.exists()


# --- CLI ------------------------------------------------------------------------------------


def _cli(cfg: config.Config) -> int:
    return cli.main(["report", "--config", str(cfg.path)])


def test_cli_config_error_exits_2(tmp_path: Path, capsys: pytest.CaptureFixture[str]):
    assert cli.main(["report", "--config", str(tmp_path / "없는.toml")]) == 2
    assert "설정 오류" in capsys.readouterr().err


def test_cli_log_open_failure_exits_1(
    write_cfg: Callable[..., config.Config],
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
):
    (tmp_path / "datafile").write_text("파일")
    cfg = write_cfg(data_dir="datafile")

    assert _cli(cfg) == 1
    assert "로그 파일을 열지 못했다" in capsys.readouterr().err


# --- 그래프 조립·폴더 교체 ------------------------------------------------------------------


@pytest.fixture
def graph_run(cfg, monkeypatch):
    monkeypatch.setattr(dates, "_utc_now", lambda: CLOCK)
    """실제 run 조립 순서를 가짜 작성기·그림으로 관찰한다."""
    events = []
    monkeypatch.setattr(report, "wait_for_collect", lambda *args: None)
    monkeypatch.setattr(report, "_pending_inputs", lambda cfg: [])

    class Writer:
        def period(self, cfg, inputs, scope):
            return report.DailyAnalysis("ok", "기간 본문", "기간 요약")

        def write(self, cfg, inputs):
            events.append("writer")
            return report.DailyAnalysis("ok", "본문")

    return events, TODAY, Writer()


@pytest.mark.parametrize("summary", [3, None, "\ud800"])
def test_invalid_summary_uses_existing_fallback(cfg, summary):
    result = report.DailyAnalysis("ok", OK_BODY, summary)
    text, failure, received = report._daily_analysis(cfg, FakeWriter(result), [])
    assert failure is REASON.OUTPUT_INVALID
    assert received is None
    assert text.startswith(report.FALLBACK_MARKER)


@pytest.mark.parametrize("summary", ["회복 양호.", " \n\t "])
def test_daily_analysis_preserves_valid_summary(cfg, summary):
    assert report._daily_analysis(
        cfg, FakeWriter(report.DailyAnalysis("ok", OK_BODY, summary)), []
    ) == (OK_BODY, None, summary)


def test_cli_report_passes_report_sink(cfg, monkeypatch):
    marker = object()
    seen = []
    monkeypatch.setattr(cli, "_report_sink", lambda cfg: marker)
    monkeypatch.setattr(
        report, "run", lambda cfg, writer, sink, **kw: seen.append(sink) or 0
    )
    assert cli.main(["report", "--config", str(cfg.path)]) == 0
    assert seen == [marker]


def test_delivery_recorder_failure_is_private(cfg, monkeypatch, caplog):
    def fail(cfg):
        raise RuntimeError("private-token-and-chat")

    monkeypatch.setattr(store, "write_session", fail)
    report.delivery_recorder(cfg)(TODAY, errors.DeliveryKind.REPORT_TEXT, None)
    assert "delivery 기록 실패 (RuntimeError)" in caplog.text
    assert "private-token-and-chat" not in caplog.text


def test_report_lock_is_held_through_delivery(cfg, monkeypatch):
    monkeypatch.setattr(report, "_render_charts", lambda *args: [])

    class Sink:
        def deliver(self, bundle):
            assert not store.write_lock_held(cfg)
            fd = os.open(cfg.data_dir / store.REPORT_LOCK_FILENAME, os.O_RDWR)
            try:
                with pytest.raises(BlockingIOError):
                    fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            finally:
                os.close(fd)

    assert report.run(cfg, ok_writer(), Sink()) == 0


def test_scheduled_reports_serialize_and_second_skips(cfg, monkeypatch):
    import concurrent.futures
    import threading

    monkeypatch.setattr(dates, "_utc_now", lambda: CLOCK)
    monkeypatch.setattr(report, "_render_charts", lambda *args: [])
    entered, release, second_started = (
        threading.Event(),
        threading.Event(),
        threading.Event(),
    )
    calls = []
    sink = FakeSink()

    class Writer:
        def period(self, cfg, inputs, scope):
            return report.DailyAnalysis("ok", "기간 본문", "기간 요약")

        def write(self, cfg, inputs):
            calls.append(1)
            entered.set()
            assert release.wait(5)
            return report.DailyAnalysis("ok", "judgment")

    def second():
        second_started.set()
        return report.run(cfg, Writer(), sink)

    with concurrent.futures.ThreadPoolExecutor(2) as executor:
        first = executor.submit(report.run, cfg, Writer(), sink)
        try:
            assert entered.wait(5)
            pending = executor.submit(second)
            assert second_started.wait(5)
            with pytest.raises(concurrent.futures.TimeoutError):
                pending.result(timeout=0.1)
            assert calls == [1]
        finally:
            release.set()
        assert first.result(timeout=5) == pending.result(timeout=5) == 0
    assert calls == [1]
    assert len(sink.calls) == 1


@pytest.mark.parametrize("existing", [False, True])
def test_cli_regenerate_busy_has_no_report_or_db_effects(
    cfg, monkeypatch, capsys, existing
):
    if existing:
        with store.write_session(cfg):
            pass
        cfg.reports_dir.mkdir()
        report.report_path(cfg, TODAY).write_text("old" + HEADING + "judgment")
        before_db = cfg.db_path.read_bytes()
        before_report = report.report_path(cfg, TODAY).read_bytes()
    else:
        cfg.data_dir.mkdir()
    fd = os.open(
        cfg.data_dir / store.REPORT_LOCK_FILENAME, os.O_RDWR | os.O_CREAT, 0o600
    )
    fcntl.flock(fd, fcntl.LOCK_EX)
    writer = ok_writer()
    monkeypatch.setattr(report, "default_writer", lambda cfg: writer)

    try:
        assert cli.main(["report", "--regenerate", "--config", str(cfg.path)]) == 1
    finally:
        os.close(fd)
    out = capsys.readouterr()
    assert out.out == ""
    assert (
        "report 거부: 다른 report가 실행 중이다(--regenerate는 기다리지 않는다)"
        in out.err
    )
    assert "WARNING" in (cfg.data_dir / "logs/report.log").read_text()
    assert writer.calls == []
    if existing:
        assert cfg.db_path.read_bytes() == before_db
        assert report.report_path(cfg, TODAY).read_bytes() == before_report
    else:
        assert not cfg.db_path.exists() and not cfg.reports_dir.exists()


@pytest.mark.parametrize("extra", [["2026-10-01"], ["--date", "2026-10-01"]])
def test_cli_regenerate_rejects_historical_date(extra):
    with pytest.raises(SystemExit) as error:
        cli.main(["report", "--regenerate", *extra])
    assert error.value.code == 2


def test_report_session_only_called_by_report_run():
    import ast

    calls = []
    root = Path(report.__file__).parent
    for path in root.rglob("*.py"):
        tree = ast.parse(path.read_text())
        for node in ast.walk(tree):
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                for child in ast.walk(node):
                    if (
                        isinstance(child, ast.Call)
                        and isinstance(child.func, ast.Attribute)
                        and child.func.attr == "report_session"
                    ):
                        calls.append((path.relative_to(root).as_posix(), node.name))
    assert calls == [("report.py", "run")]


def test_regenerate_marks_dangling_symlink_as_previous_file(cfg, monkeypatch):
    monkeypatch.setattr(dates, "_utc_now", lambda: CLOCK)
    monkeypatch.setattr(report, "_render_charts", lambda *args: [])
    path = report.report_path(cfg, TODAY)
    path.parent.mkdir(parents=True)
    path.symlink_to(path.parent / "missing.md")
    sink = FakeSink()
    assert report.run(cfg, ok_writer(), sink, regenerate=True) == 0
    assert not path.is_symlink()
    assert sink.calls[0].regenerated is True


@pytest.fixture
def daily_setup(cfg, monkeypatch):
    monkeypatch.setattr(dates, "_utc_now", lambda: CLOCK)
    return cfg


def test_daily_report_and_summary_are_model_output(daily_setup):
    cfg = daily_setup
    sink = FakeSink()
    writer = FakeWriter(
        report.DailyAnalysis("ok", "# 하루 분석\n\n내용", "전송용 요약")
    )
    assert report.run(cfg, writer, sink) == 0
    assert (
        report.report_path(cfg, TODAY).read_text()
        == "# 하루 분석\n\n내용" + PERIOD_BLOCK + "\n\n## 그래프\n"
    )
    assert (
        sink.calls[0].summary_text
        == "전송용 요약\n7일: 기간 요약\n30일: 기간 요약\n전체: 기간 요약"
    )
    assert writer.calls == [["data/report-input/2026-10-18"]]
    assert (cfg.data_dir / "report-input/2026-10-18/digest.json").is_file()


@pytest.mark.parametrize(
    "failure",
    [
        REASON.CODEX_FAILED,
        REASON.CODEX_TIMEOUT,
        REASON.OUTPUT_INVALID,
        REASON.SKILL_FAILED,
    ],
)
def test_daily_failures_write_report_and_notify_once(daily_setup, failure):
    cfg = daily_setup
    sink = FakeSink()
    writer = (
        FakeWriter(report.DailyAnalysis("failed", "失敗"))
        if failure == REASON.SKILL_FAILED
        else FakeWriter(error=report.WriterFailed(failure))
    )
    for _ in range(2):
        assert report.run(cfg, writer, sink) == 0
    content = report.report_path(cfg, TODAY).read_text()
    assert content.startswith(f"# {TODAY} 하루 리포트")
    assert "수집 상태:" in content
    assert report.FALLBACK_MARKER in content
    assert failure.value in content
    assert _notifications(cfg) == [
        (
            str(TODAY),
            "report_failed",
            failure.value
            + (
                " scopes=day"
                if failure == REASON.SKILL_FAILED
                else " scopes=day,7d,30d,all"
            ),
        )
    ]
    assert failure.value in sink.calls[-1].summary_text
    assert str(TODAY) in sink.calls[-1].summary_text


def test_scheduled_success_skips_all_work_and_regeneration_failure_preserves(
    daily_setup, monkeypatch
):
    cfg = daily_setup
    path = report.report_path(cfg, TODAY)
    path.parent.mkdir()
    path.write_text("# Successful full report")
    report._save_evaluation(
        cfg, TODAY, "day", report.DailyAnalysis("ok", "# Successful full report")
    )
    monkeypatch.setattr(report, "wait_for_collect", lambda *a: pytest.fail("wait"))
    monkeypatch.setattr(report, "_render_charts", lambda *a: pytest.fail("charts"))
    writer = FakeWriter(error=RuntimeError("analysis failure"))
    sink = FakeSink()
    assert report.run(cfg, writer, sink) == 0
    assert writer.calls == sink.calls == []
    monkeypatch.setattr(report, "wait_for_collect", lambda *a: None)
    assert report.run(cfg, writer, sink, regenerate=True) == 0
    assert path.read_text() == "# Successful full report"
    assert sink.calls == []
    assert _notifications(cfg) == [
        (str(TODAY), "report_failed", "codex_failed scopes=day")
    ]


def test_graphs_are_appended_only_when_files_exist_and_albums_stay_grouped(
    daily_setup, monkeypatch
):
    cfg = daily_setup

    def render(*args):
        folder = cfg.reports_dir / str(TODAY)
        folder.mkdir(parents=True)
        (folder / "01_sleep.png").write_bytes(b"png")
        (folder / "50_hr.png").write_bytes(b"png")
        return [
            report.charts.Graph("01_sleep.png", "수면"),
            report.charts.Graph("50_hr.png", "심박"),
            report.charts.Graph("51_missing.png", "없음"),
        ]

    monkeypatch.setattr(report, "_render_charts", render)
    sink = FakeSink()
    assert report.run(cfg, ok_writer(), sink) == 0
    content = report.report_path(cfg, TODAY).read_text()
    assert "01_sleep.png" in content and "50_hr.png" in content
    assert "51_missing" not in content
    assert len(sink.calls[0].albums) == 2


@pytest.mark.parametrize("fail", [False, True])
def test_body_intake_precedes_export_and_failure_keeps_pending(
    daily_setup, monkeypatch, fail
):
    cfg = daily_setup
    from garmin_pipeline import body

    inbox = cfg.inbox_dir / "inbody"
    inbox.mkdir(parents=True)
    source = inbox / "measurement.txt"
    source.write_text("2026-10-18 체중 70kg")

    class IntakeWriter(FakeWriter):
        def intake(self, cfg, inputs):
            assert inputs == ["inbox/inbody/measurement.txt"]
            assert not (cfg.data_dir / "report-input/2026-10-18").exists()
            if fail:
                raise report.WriterFailed(REASON.CODEX_TIMEOUT)
            body.write(cfg, TODAY, [inputs[0]], '{"weight_kg": 70}')
            return {"status": "ok", "detail": "done"}

    writer = IntakeWriter(report.DailyAnalysis("ok", "# 분석", "요약"))
    assert report.run(cfg, writer) == 0
    doc = json.loads((cfg.data_dir / "report-input/2026-10-18/digest.json").read_text())
    if fail:
        assert source.exists()
        assert doc["body"]["latest"] is None
    else:
        assert not source.exists()
        assert doc["body"]["new_today"] is True
        assert doc["body"]["latest"]["values"]["weight_kg"] == 70


def test_unreadable_existing_report_is_kept(cfg: config.Config, no_sleep: None):
    assert report.run(cfg, ok_writer()) == 0
    path = _only_report(cfg)
    path.write_bytes(b"\xff\xfe not utf-8")

    failing = FakeWriter(error=report.WriterFailed(REASON.CODEX_FAILED))
    assert report.run(cfg, failing, regenerate=True) == 0

    assert path.read_bytes() == b"\xff\xfe not utf-8"


@pytest.mark.parametrize(
    "names",
    [
        [
            report.charts.Graph("01-yesterday.png", "어제 하루"),
            report.charts.Graph("04-strength-1.png", "근력 진행 · 스쿼트"),
        ],
        [],
    ],
)
@pytest.mark.parametrize("regenerate", [False, True])
def test_graph_block_replaces_whole_folder_and_delivers(
    cfg, monkeypatch, graph_run, names, regenerate
):
    events, _fp, writer = graph_run
    if regenerate:
        cfg.reports_dir.mkdir(parents=True)
        report.report_path(cfg, TODAY).write_text("old" + HEADING + "old judgment")
    folder = cfg.reports_dir / str(TODAY)
    folder.mkdir(parents=True)
    (folder / "03-session-2.png").write_bytes(b"old")

    def render(actual_cfg, report_date, out_dir):
        events.append("charts")
        assert actual_cfg == cfg and report_date == TODAY
        assert out_dir.parent == cfg.reports_dir
        assert out_dir.name.startswith(f".{TODAY}.charts-")
        assert stat.S_IMODE(out_dir.stat().st_mode) == 0o700
        assert list(out_dir.iterdir()) == []
        for name, title in names:
            (out_dir / name).write_bytes(b"new")
        return names

    monkeypatch.setattr(report.charts, "render", render)

    class Sink:
        def deliver(self, bundle):
            events.append("deliver")
            assert bundle.report_date == TODAY
            assert bundle.document_path.exists()
            assert bundle.regenerated is regenerate
            assert all(path.exists() for album in bundle.albums for path in album)
            for name, title in names:
                assert (folder / name).read_bytes() == b"new"

    assert report.run(cfg, writer, Sink(), regenerate=regenerate) == 0
    assert events == ["writer", "charts", "deliver"]
    text = report.report_path(cfg, TODAY).read_text()
    base = "본문" + PERIOD_BLOCK + "\n"
    if names:
        assert (
            text
            == base
            + "\n## 그래프\n\n![어제 하루](2026-10-18/01-yesterday.png)\n\n![근력 진행 · 스쿼트](2026-10-18/04-strength-1.png)\n"
        )
        assert sorted(p.name for p in folder.iterdir()) == [g.name for g in names]
    else:
        assert text == base + "\n## 그래프\n"
        assert not folder.exists()
    assert sorted(p.name for p in cfg.reports_dir.iterdir()) == sorted(
        [f"{TODAY}.md"] + ([str(TODAY)] if names else [])
    )


@pytest.mark.parametrize("stage", ["render", "old_rename", "new_rename", "mkdir"])
def test_graph_failure_restores_old_folder_and_report_succeeds(
    cfg, monkeypatch, graph_run, stage, caplog
):
    _, _, writer = graph_run
    folder = cfg.reports_dir / str(TODAY)
    folder.mkdir(parents=True)
    (folder / "old.png").write_bytes(b"old")

    def render(cfg, report_date, output):
        (output / "01-yesterday.png").write_bytes(b"new")
        if stage == "render":
            raise RuntimeError("private health detail")
        return [report.charts.Graph("01-yesterday.png", "어제 하루")]

    monkeypatch.setattr(report.charts, "render", render)
    real_rename = Path.rename

    def rename(path, target):
        if (stage == "old_rename" and path == folder) or (
            stage == "new_rename"
            and ".charts-" in path.name
            and ".charts-old-" not in path.name
        ):
            raise OSError("private")
        return real_rename(path, target)

    monkeypatch.setattr(Path, "rename", rename)
    real_rmtree = report.shutil.rmtree

    def rmtree(path, *args, **kwargs):
        if stage == "remove_old" and ".charts-old-" in Path(path).name:
            raise OSError("private")
        return real_rmtree(path, *args, **kwargs)

    monkeypatch.setattr(report.shutil, "rmtree", rmtree)
    real_mkdtemp = report.tempfile.mkdtemp

    def mkdtemp(*args, **kwargs):
        if stage == "mkdir" and ".charts-" in kwargs.get("prefix", ""):
            raise OSError("private")
        return real_mkdtemp(*args, **kwargs)

    monkeypatch.setattr(report.tempfile, "mkdtemp", mkdtemp)
    sink = FakeSink()
    assert report.run(cfg, writer, sink) == 0
    assert len(sink.calls) == 1
    assert report.report_path(cfg, TODAY).read_text().endswith("## 그래프\n")
    assert (folder / "old.png").read_bytes() == b"old"
    assert sorted(p.name for p in cfg.reports_dir.iterdir()) == [
        str(TODAY),
        f"{TODAY}.md",
    ]
    assert "report 그래프 실패: error=" in caplog.text
    assert "private" not in caplog.text


def test_writer_failure_preserves_existing_report_and_graphs(
    cfg, monkeypatch, graph_run
):
    _, _, _ = graph_run
    folder = cfg.reports_dir / str(TODAY)
    folder.mkdir(parents=True)
    (folder / "old.png").write_bytes(b"old")
    path = report.report_path(cfg, TODAY)
    path.write_text("data" + HEADING + "기존 본문\n\n## 그래프\n\n![기존](old.png)\n")
    original = path.read_bytes()
    report._save_evaluation(cfg, TODAY, "day", report.DailyAnalysis("ok", "existing"))

    def refuse(*args):
        pytest.fail("preserved report must not render charts")

    monkeypatch.setattr(report.charts, "render", refuse)
    notifications = []
    monkeypatch.setattr(
        report, "_notify_failed", lambda *args, **kwargs: notifications.append(args)
    )
    writer = FakeWriter(error=report.WriterFailed(REASON.CODEX_FAILED))
    assert report.run(cfg, writer, regenerate=True) == 0
    assert path.read_bytes() == original
    assert (folder / "old.png").read_bytes() == b"old"
    assert notifications[0][2] == [REASON.CODEX_FAILED]


@pytest.mark.parametrize("has_graphs", [True, False])
def test_backup_partial_cleanup_failure_keeps_rendered_album(
    cfg, monkeypatch, graph_run, caplog, has_graphs
):
    _, _, writer = graph_run
    folder = cfg.reports_dir / str(TODAY)
    folder.mkdir(parents=True)
    (folder / "old-1.png").write_bytes(b"old")
    (folder / "old-2.png").write_bytes(b"old")

    def render(cfg, report_date, output):
        if not has_graphs:
            return []
        (output / "01-yesterday.png").write_bytes(b"new")
        return [report.charts.Graph("01-yesterday.png", "어제 하루")]

    monkeypatch.setattr(report.charts, "render", render)
    real_rmtree = report.shutil.rmtree

    def partial_cleanup(path, *args, **kwargs):
        if ".charts-old-" in Path(path).name:
            (Path(path) / "old-1.png").unlink()
            raise OSError("private")
        return real_rmtree(path, *args, **kwargs)

    monkeypatch.setattr(report.shutil, "rmtree", partial_cleanup)
    sink = FakeSink()
    assert report.run(cfg, writer, sink) == 0
    assert len(sink.calls) == 1
    text = report.report_path(cfg, TODAY).read_text()
    if has_graphs:
        assert [p.name for p in folder.iterdir()] == ["01-yesterday.png"]
        assert (folder / "01-yesterday.png").read_bytes() == b"new"
        assert f"![어제 하루]({TODAY}/01-yesterday.png)" in text
    else:
        assert not folder.exists()
        assert text.endswith("## 그래프\n")
    backups = list(cfg.reports_dir.glob(f".{TODAY}.charts-old-*"))
    assert len(backups) == 1
    assert [p.name for p in backups[0].iterdir()] == ["old-2.png"]
    assert list(cfg.reports_dir.glob(f".{TODAY}.charts-*")) == backups
    assert "report 그래프 정리 실패: error=OSError" in caplog.text
    assert "private" not in caplog.text


def test_staging_cleanup_failure_warns_and_report_succeeds(
    cfg, monkeypatch, graph_run, caplog
):
    _, _, writer = graph_run
    monkeypatch.setattr(report.charts, "render", lambda *args: [])
    real_rmtree = report.shutil.rmtree

    def fail_cleanup(path, *args, **kwargs):
        if ".charts-" in Path(path).name:
            if not kwargs.get("ignore_errors", False):
                raise OSError("private")
            return None
        return real_rmtree(path, *args, **kwargs)

    monkeypatch.setattr(report.shutil, "rmtree", fail_cleanup)
    sink = FakeSink()
    assert report.run(cfg, writer, sink) == 0
    assert len(sink.calls) == 1
    assert report.report_path(cfg, TODAY).read_text().endswith("## 그래프\n")
    assert len(list(cfg.reports_dir.glob(f".{TODAY}.charts-*"))) == 1
    assert "report 그래프 정리 실패: error=OSError" in caplog.text
    assert "private" not in caplog.text


@pytest.mark.parametrize("result", [None, errors.DeliveryReason.RATE_LIMITED, "raise"])
def test_report_failure_notice_outside_lock_and_once(cfg, result, caplog):
    calls = []

    class Sender:
        def send(self, day, event, detail, *, timeout_seconds):
            assert not store.write_lock_held(cfg)
            with store.read_connection(cfg) as conn:
                assert conn.execute("SELECT event FROM notification").fetchall() == [
                    ("report_failed",)
                ]
            calls.append((event, timeout_seconds))
            if result == "raise":
                raise RuntimeError("private-token private-chat")
            return result

    writer = FakeWriter(error=report.WriterFailed(REASON.CODEX_FAILED))
    assert report.run(cfg, writer, notice_sender=Sender()) == 0
    assert report.run(cfg, writer, notice_sender=Sender()) == 0
    assert calls == [(errors.NotifyEvent.REPORT_FAILED, 10)]
    reason = "network" if result == "raise" else result
    with store.read_connection(cfg) as conn:
        assert conn.execute("SELECT kind,event,ok,reason FROM delivery").fetchall() == [
            ("notify", "report_failed", int(reason is None), reason)
        ]
    assert "private-token" not in caplog.text and "private-chat" not in caplog.text


def test_cli_report_passes_notice_sender(cfg, monkeypatch):
    marker = object()
    seen = []
    monkeypatch.setattr(cli, "_notice_sender", lambda cfg: marker)
    monkeypatch.setattr(
        report,
        "run",
        lambda cfg, writer, sink, **kw: seen.append({**kw, "sink": sink}) or 0,
    )
    assert cli.main(["report", "--config", str(cfg.path)]) == 0
    assert seen == [{"notice_sender": marker, "sink": None, "regenerate": False}]


def test_post_send_delivery_write_failure_keeps_notification(
    cfg, monkeypatch, caplog, no_sleep
):
    monkeypatch.setattr(dates, "_utc_now", lambda: CLOCK)
    calls = []

    class Sender:
        def send(self, *args, **kwargs):
            assert not store.write_lock_held(cfg)
            calls.append(args)

    def refuse(*args, **kwargs):
        raise sqlite3.OperationalError("private-token private-chat " + SECRET)

    monkeypatch.setattr(report.ports, "record_delivery", refuse)
    for _ in range(2):
        assert (
            report.run(
                cfg,
                FakeWriter(error=report.WriterFailed(REASON.CODEX_FAILED)),
                notice_sender=Sender(),
            )
            == 0
        )
        assert _notifications(cfg) == [
            (TODAY.isoformat(), "report_failed", "codex_failed scopes=day,7d,30d,all")
        ]
    assert len(calls) == 1
    with store.read_connection(cfg) as conn:
        assert conn.execute("SELECT * FROM delivery").fetchall() == []
    assert "delivery 기록 실패 (OperationalError)" in caplog.text
    assert "private-token" not in caplog.text and "private-chat" not in caplog.text
    assert SECRET not in caplog.text


@pytest.mark.parametrize("failed_scope", [None, "day", "7d", "30d", "all"])
def test_four_sessions_in_order_persist_immediately_and_continue_after_failures(
    daily_setup, failed_scope, caplog
):
    cfg = daily_setup
    seen = []

    class Writer:
        def write(self, actual_cfg, inputs):
            return self.session("day")

        def period(self, actual_cfg, inputs, scope):
            folder = report.body.runtime_root(cfg) / inputs[0]
            evaluations = json.loads((folder / "evaluations.json").read_text())
            expected = "day" if scope == "7d" else "7d" if scope == "30d" else "30d"
            if expected != failed_scope:
                assert any(
                    e["scope"] == expected and e["report_date"] == str(TODAY)
                    for e in evaluations
                )
            return self.session(scope)

        def session(self, scope):
            assert not store.write_lock_held(cfg)
            seen.append(scope)
            if scope == failed_scope:
                raise report.WriterFailed(REASON.CODEX_TIMEOUT)
            return report.DailyAnalysis(
                "ok",
                f"{scope} body",
                f"{scope} summary",
                ["judgment"],
                ["evidence"],
                ["check"],
                {"input_tokens": 10, "cached_input_tokens": 2, "output_tokens": 3},
            )

    import logging

    sink = FakeSink()
    with caplog.at_level(logging.INFO):
        assert report.run(cfg, Writer(), sink) == 0
    assert seen == ["day", "7d", "30d", "all"]
    with store.read_connection(cfg) as conn:
        assert conn.execute("SELECT COUNT(*) FROM evaluation").fetchone()[0] == (
            4 if failed_scope is None else 3
        )
    if failed_scope:
        assert f"scopes={failed_scope}" in _notifications(cfg)[0][2]
    else:
        assert _notifications(cfg) == []
    content = report.report_path(cfg, TODAY).read_text()
    assert all(f"### {label}" in content for label in ["7일", "30일", "전체"])
    if failed_scope == "30d":
        section = content.split("### 30일\n\n", 1)[1].split("\n\n### 전체", 1)[0]
        assert section == "> 기간 평가를 쓰지 못했다: 분석 시간이 제한을 넘었다"
        assert "30일: 평가를 쓰지 못했다" in sink.calls[0].summary_text.splitlines()
    assert "report session scope=day" in caplog.text
    assert "input_tokens=10" in caplog.text
    assert "judgment" not in caplog.text


def test_scheduled_report_runs_sessions_when_evaluation_read_fails(
    daily_setup, monkeypatch
):
    cfg = daily_setup
    report._save_evaluation(cfg, TODAY, "day", report.DailyAnalysis("ok", "old day"))
    read_connection = store.read_connection
    failed_reads = []

    def fail_first_read(actual_cfg):
        if not failed_reads:
            failed_reads.append(True)
            raise store.StoreError("evaluation read unavailable")
        return read_connection(actual_cfg)

    monkeypatch.setattr(store, "read_connection", fail_first_read)
    seen = []

    class Writer(FakeWriter):
        def write(self, cfg, inputs):
            seen.append("day")
            return report.DailyAnalysis("ok", "new day", "day summary")

        def period(self, cfg, inputs, scope):
            seen.append(scope)
            return super().period(cfg, inputs, scope)

    assert report.run(cfg, Writer(), FakeSink()) == 0
    assert failed_reads == [True]
    assert seen == ["day", "7d", "30d", "all"]
    assert report.report_path(cfg, TODAY).read_text().startswith("new day")


def test_regenerate_failed_period_reuses_same_day_evaluation_in_report_summary_and_downstream(
    daily_setup,
):
    cfg = daily_setup
    report._save_evaluation(
        cfg,
        TODAY,
        "7d",
        report.DailyAnalysis("ok", "old week body", "old week summary"),
    )
    sink = FakeSink()

    class Writer(FakeWriter):
        def period(self, cfg, inputs, scope):
            if scope == "7d":
                raise report.WriterFailed(REASON.CODEX_TIMEOUT)
            if scope == "30d":
                values = json.loads(
                    (
                        report.body.runtime_root(cfg) / inputs[0] / "evaluations.json"
                    ).read_text()
                )
                assert values[0]["summary"] == "old week summary"
            return report.DailyAnalysis("ok", scope, scope)

    assert (
        report.run(
            cfg, Writer(report.DailyAnalysis("ok", "day", "day")), sink, regenerate=True
        )
        == 0
    )
    assert "old week body" in report.report_path(cfg, TODAY).read_text()
    assert "7일: old week summary" in sink.calls[0].summary_text
    with store.read_connection(cfg) as conn:
        assert (
            conn.execute("SELECT summary FROM evaluation WHERE scope='7d'").fetchone()[
                0
            ]
            == "old week summary"
        )
    assert _notifications(cfg)[0][2] == "codex_timeout scopes=7d"


def test_summary_utf16_limit_drops_periods_in_reverse_order_and_preserves_emoji():
    assert (
        report._combined_summary("a" * 3990, ["7일: a", "30일: a", "전체: a"])
        == "a" * 3990 + "\n7일: a"
    )
    assert (
        report._combined_summary("😀" * 2001, ["7일: x", "30일: y", "전체: z"])
        == "😀" * 2000
    )
    assert report._combined_summary("a" * 3999 + "😀", []) == "a" * 3999


def test_regenerate_write_failure_preserves_existing_success_and_returns_zero(
    daily_setup, monkeypatch
):
    cfg = daily_setup
    assert report.run(cfg, ok_writer()) == 0
    path = report.report_path(cfg, TODAY)
    previous = path.read_bytes()

    def refuse(*args):
        raise OSError("disk full")

    monkeypatch.setattr(report, "_write_report", refuse)
    assert report.run(cfg, ok_writer(), regenerate=True) == 0
    assert path.read_bytes() == previous
