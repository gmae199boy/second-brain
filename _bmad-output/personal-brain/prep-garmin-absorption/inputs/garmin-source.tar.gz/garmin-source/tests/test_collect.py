"""웰니스 일일 수집(`collect`·`garmin-pipeline collect`)과 빠진 날 자동 메우기, 하루 단위 멱등
(FR5~8·15~17·19~21).

모두 패키지의 실제 마이그레이션 위에서 `FakeGarmin`으로 돈다. 시계는 `dates._utc_now`만 바꾸고,
시간대 시험 밖에서는 `TZ`를 config `timezone`(Asia/Seoul)으로 고정해 `timezone_mismatch`가 끼지 않게 한다.
"""

import fcntl
import json
import logging
import os
import re
import sqlite3
from collections.abc import Callable
from datetime import UTC, date, datetime, timedelta
from pathlib import Path

import pytest
import schema_version
from garmin_fakes import (
    FAKE_DISPLAY_NAME,
    FakeGarmin,
    GarminTransport,
    StubGarminClient,
    http_error,
    transport_client,
)

from garmin_pipeline import (
    cli,
    collect,
    config,
    coverage,
    dates,
    errors,
    garmin,
    normalize,
    ports,
    store,
)

# 서울 2026-10-16 10:00.
NOW = datetime(2026, 10, 16, 1, 0, tzinfo=UTC)
D = date(2026, 10, 16)
EPOCH = datetime(1970, 1, 1, tzinfo=UTC)
NOW_MS = (NOW - EPOCH) // timedelta(milliseconds=1)
MARKER = "payload-marker-7c21"
DATA_ENDPOINTS = tuple(e for e in garmin.DAY_ENDPOINTS if e != "activities_by_date")
LOG_PREFIX = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z ")


class Clock:
    def __init__(self) -> None:
        self.moment = NOW

    def advance(self, days: int) -> None:
        self.moment += timedelta(days=days)


@pytest.fixture(autouse=True)
def clock(monkeypatch: pytest.MonkeyPatch) -> Clock:
    current = Clock()
    monkeypatch.setattr(dates, "_utc_now", lambda: current.moment)
    return current


@pytest.fixture(autouse=True)
def system_zone(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("TZ", "Asia/Seoul")


@pytest.fixture
def make_cfg(write_config: Callable[..., Path]) -> Callable[..., config.Config]:
    def make(**overrides: object) -> config.Config:
        return config.load(write_config(**{"lock_wait_seconds": 0, **overrides}))

    return make


@pytest.fixture
def cfg(make_cfg: Callable[..., config.Config]) -> config.Config:
    return make_cfg()


@pytest.fixture
def sleeps() -> list[float]:
    return []


def _days_back(first: date, count: int) -> list[date]:
    return [first - timedelta(days=offset) for offset in range(count)]


def _payload(endpoint: str, day: date) -> dict[str, object]:
    return {"calendarDate": day.isoformat(), "endpoint": endpoint, "note": MARKER}


def _full(days: list[date]) -> dict[tuple[str, object], object]:
    """그날들의 day 응답. `activities_by_date`는 응답 없음(`NoData`)이다."""
    return {
        (endpoint, day): _payload(endpoint, day)
        for day in days
        for endpoint in DATA_ENDPOINTS
    }


def _run(
    cfg: config.Config, fake: FakeGarmin, sleeps: list[float], *, force: bool = False
) -> int:
    return collect.collect(cfg, fake, sleep=sleeps.append, force=force)


def _day_calls(fake: FakeGarmin) -> list[tuple[str, object]]:
    return [call for call in fake.calls if isinstance(call, tuple)]


def _days(calls: list[tuple[str, object]]) -> list[object]:
    """요청한 일 키를 처음 나온 순서대로."""
    return list(dict.fromkeys(day for _, day in calls))


def _query(cfg: config.Config, sql: str, params: tuple = ()) -> list[tuple]:
    reader = store.read_connection(cfg)
    try:
        return reader.execute(sql, params).fetchall()
    finally:
        reader.close()


def _runs(cfg: config.Config) -> list[tuple]:
    return _query(
        cfg,
        "SELECT id, local_date, started_at, finished_at, status, detail FROM run"
        " ORDER BY id",
    )


def _fetch_errors(cfg: config.Config) -> list[tuple]:
    return _query(
        cfg,
        "SELECT run_id, scope, key, endpoint, kind, local_date, occurred_at, error_code"
        " FROM fetch_error ORDER BY id",
    )


def _raw_count(cfg: config.Config) -> int:
    return _query(cfg, "SELECT COUNT(*) FROM raw_response")[0][0]


def _collect_meta(cfg: config.Config) -> list[tuple]:
    """collect가 쓰는 `meta` 행(정규화가 쓰는 `normalize_version`은 뺀다)."""
    return _query(
        cfg,
        "SELECT key, value FROM meta WHERE key != ? ORDER BY key",
        (normalize.NORMALIZE_VERSION_KEY,),
    )


def _set_history_start(cfg: config.Config, day: date) -> None:
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO meta (key, value) VALUES ('history_start', ?)",
            (day.isoformat(),),
        )


def _items(cfg: config.Config, start: date, end: date) -> list[coverage.CoverageItem]:
    reader = store.read_connection(cfg)
    try:
        return [
            item
            for item in coverage.items(reader, cfg, start, end)
            if item.scope == "day"
        ]
    finally:
        reader.close()


def _complete(item: coverage.CoverageItem) -> bool:
    return item.final and item.state in {
        coverage.CoverageState.DATA,
        coverage.CoverageState.EMPTY,
    }


# --- 첫 실행·history_start --------------------------------------------------------------------


def test_first_run_creates_meta_and_fetches_latest_ten_days(
    cfg: config.Config, sleeps: list[float]
):
    fake = FakeGarmin(responses=_full(_days_back(D, 31)))

    assert _run(cfg, fake, sleeps) == 0

    assert _query(cfg, "PRAGMA user_version") == [(schema_version.LATEST,)]
    assert _collect_meta(cfg) == [("history_start", "2026-09-16")]
    calls = _day_calls(fake)
    assert _days(calls) == _days_back(D, 10)
    assert calls == [
        (endpoint, day)
        for day in _days_back(D, 10)
        for endpoint in garmin.DAY_ENDPOINTS
        if endpoint not in ("daily_weigh_ins", "lifestyle_logging_data")
        or day >= D - timedelta(days=2)
    ]
    assert fake.calls[:2] == ["blocked_today", "open_session"]
    assert fake.calls[-1] == "close_session"
    assert fake.calls.count("open_session") == 1
    assert sleeps == [cfg.date_pause_seconds] * 9
    assert _runs(cfg) == [(1, D.isoformat(), NOW_MS, NOW_MS, "success", "")]
    assert _fetch_errors(cfg) == []
    assert _raw_count(cfg) == 10 * len(garmin.DAY_ENDPOINTS) - 14


def test_meta_table_shape(cfg: config.Config):
    with store.write_session(cfg) as conn:
        columns = conn.execute("PRAGMA table_info(meta)").fetchall()

    assert [(name, kind, notnull, pk) for _, name, kind, notnull, _, pk in columns] == [
        ("key", "TEXT", 0, 1),
        ("value", "TEXT", 1, 0),
    ]


def test_history_start_is_written_once(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    fake = FakeGarmin(responses=_full(_days_back(D + timedelta(days=5), 36)))
    _run(cfg, fake, sleeps)
    clock.advance(days=5)

    _run(cfg, fake, sleeps)

    assert _collect_meta(cfg) == [("history_start", "2026-09-16")]
    assert [row[1] for row in _runs(cfg)] == ["2026-10-16", "2026-10-21"]


# --- 백필·빠진 날 ---------------------------------------------------------------------------


def _backfill(cfg: config.Config, fake: FakeGarmin, sleeps: list[float]) -> list[list]:
    """같은 D에 `--force`로 5번 실행하고 실행마다 요청한 일 키 목록을 돌려준다."""
    per_run: list[list] = []
    for _ in range(5):
        before = len(_day_calls(fake))
        assert _run(cfg, fake, sleeps, force=True) == 0
        per_run.append(_days(_day_calls(fake)[before:]))
    return per_run


def test_backfill_completes_thirty_days_in_five_runs(
    cfg: config.Config, sleeps: list[float]
):
    fake = FakeGarmin(responses=_full(_days_back(D, 31)))

    per_run = _backfill(cfg, fake, sleeps)

    assert all(len(days) <= cfg.max_dates_per_run for days in per_run)
    assert all(days[0] == D for days in per_run)
    assert per_run[1] == [D, *_days_back(D - timedelta(days=3), 9)]
    past = _items(cfg, D - timedelta(days=30), D - timedelta(days=1))
    assert len(past) == 30 * len(garmin.DAY_ENDPOINTS)
    assert all(_complete(item) for item in past)
    assert {item.state for item in past} == {
        coverage.CoverageState.DATA,
        coverage.CoverageState.EMPTY,
    }

    # 백필이 끝나면 확정되지 않은 오늘만 다시 받는다.
    before = len(_day_calls(fake))
    _run(cfg, fake, sleeps, force=True)
    assert _days(_day_calls(fake)[before:]) == [D]


def test_backfill_without_force_takes_five_days(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    # 하루 한 번 성공 실행: 매일 새 오늘과 확정되지 않은 어제가 두 자리를 차지한다.
    last = D + timedelta(days=4)
    fake = FakeGarmin(responses=_full(_days_back(last, 35)))
    per_day: list[list] = []
    for offset in range(5):
        before = len(_day_calls(fake))
        assert _run(cfg, fake, sleeps) == 0
        # 같은 날 두 번째 실행은 아무것도 하지 않는다.
        assert _run(cfg, fake, sleeps) == 0
        per_day.append(_days(_day_calls(fake)[before:]))
        if offset < 4:
            clock.advance(days=1)

    assert per_day[0] == _days_back(D, 10)
    assert per_day[1] == [
        D + timedelta(days=1),
        D,
        *_days_back(D - timedelta(days=3), 8),
    ]
    assert per_day[2] == [
        D + timedelta(days=2),
        D + timedelta(days=1),
        *_days_back(D - timedelta(days=11), 8),
    ]
    assert per_day[3] == [
        D + timedelta(days=3),
        D + timedelta(days=2),
        *_days_back(D - timedelta(days=19), 8),
    ]
    assert per_day[4] == [
        last,
        last - timedelta(days=1),
        *_days_back(D - timedelta(days=27), 4),
    ]
    assert all(
        _complete(item)
        for item in _items(cfg, D - timedelta(days=30), last - timedelta(days=1))
    )
    assert [row[4] for row in _runs(cfg)] == ["success"] * 5


def test_missing_days_after_gap_are_filled(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    later = D + timedelta(days=3)
    fake = FakeGarmin(responses=_full(_days_back(later, 34)))
    _backfill(cfg, fake, sleeps)
    clock.advance(days=3)
    before = len(_day_calls(fake))

    assert _run(cfg, fake, sleeps) == 0

    assert _days(_day_calls(fake)[before:]) == _days_back(later, 4)
    assert all(_complete(item) for item in _items(cfg, D, later - timedelta(days=1)))
    assert not any(item.final for item in _items(cfg, later, later))


def test_rerun_same_day_upserts_without_new_rows(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D - timedelta(days=1))
    fake = FakeGarmin(responses=_full(_days_back(D, 2)))
    _run(cfg, fake, sleeps)
    rows = _raw_count(cfg)
    before = len(_day_calls(fake))

    _run(cfg, fake, sleeps, force=True)

    assert rows == 2 * len(garmin.DAY_ENDPOINTS)
    assert _raw_count(cfg) == rows
    assert _days(_day_calls(fake)[before:]) == [D]
    assert [row[4] for row in _runs(cfg)] == ["success", "success"]


# --- 결과 처리 ----------------------------------------------------------------------------


def test_partial_failure_records_errors_and_continues(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    responses = _full([D])
    responses[("sleep_data", D)] = errors.Transient(f"sleep_data: HTTP 503 {MARKER}")
    responses[("hrv_data", D)] = errors.Rejected("hrv_data: HTTP 400")
    fake = FakeGarmin(responses=responses)

    assert _run(cfg, fake, sleeps) == 0

    assert _day_calls(fake) == [(endpoint, D) for endpoint in garmin.DAY_ENDPOINTS]
    saved = _query(cfg, "SELECT endpoint FROM raw_response ORDER BY endpoint")
    assert {endpoint for (endpoint,) in saved} == set(garmin.DAY_ENDPOINTS) - {
        "sleep_data",
        "hrv_data",
    }
    assert _fetch_errors(cfg) == [
        (
            1,
            "day",
            D.isoformat(),
            "sleep_data",
            "transient",
            D.isoformat(),
            NOW_MS,
            "transient",
        ),
        (
            1,
            "day",
            D.isoformat(),
            "hrv_data",
            "rejected",
            D.isoformat(),
            NOW_MS,
            "rejected",
        ),
    ]
    assert _runs(cfg) == [
        (1, D.isoformat(), NOW_MS, NOW_MS, "partial", "transient=1 rejected=1")
    ]


def test_detail_counts_each_kind(cfg: config.Config, sleeps: list[float]):
    _set_history_start(cfg, D - timedelta(days=1))
    responses = _full(_days_back(D, 2))
    for day in _days_back(D, 2):
        responses[("rhr_day", day)] = errors.Rejected("rhr_day: HTTP 403")
    responses[("stress_data", D)] = errors.Rejected("stress_data: HTTP 404")
    fake = FakeGarmin(responses=responses)

    _run(cfg, fake, sleeps)

    assert _runs(cfg)[0][4:] == ("partial", "rejected=3")


@pytest.mark.parametrize("empty", [None, []], ids=["missing", "empty-list"])
def test_no_data_is_stored_as_null_and_not_a_failure(
    cfg: config.Config, sleeps: list[float], empty: object
):
    _set_history_start(cfg, D)
    responses: dict[tuple[str, object], object] = {}
    if empty is not None:
        responses = {(endpoint, D): empty for endpoint in garmin.DAY_ENDPOINTS}
    fake = FakeGarmin(responses=responses)

    assert _run(cfg, fake, sleeps) == 0

    rows = _query(cfg, "SELECT raw, library_version FROM raw_response")
    assert rows == [("null", garmin.LIBRARY_VERSION)] * len(garmin.DAY_ENDPOINTS)
    assert {item.state for item in _items(cfg, D, D)} == {coverage.CoverageState.EMPTY}
    assert _fetch_errors(cfg) == []
    assert _runs(cfg)[0][4:] == ("success", "")


def test_unencodable_payload_is_saved_ascii_escaped(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    payload = {"note": "\ud83d", "메모": "수면"}
    responses = _full([D])
    responses[("sleep_data", D)] = payload
    fake = FakeGarmin(responses=responses)

    assert _run(cfg, fake, sleeps) == 0

    ((raw,),) = _query(
        cfg, "SELECT raw FROM raw_response WHERE endpoint = 'sleep_data'"
    )
    assert raw == json.dumps(payload, ensure_ascii=True)
    assert json.loads(raw) == payload
    assert _raw_count(cfg) == len(garmin.DAY_ENDPOINTS)
    assert _runs(cfg)[0][4:] == ("success", "")


def test_other_errors_propagate_and_leave_running_row(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    responses = _full([D])
    # 중단 규칙 밖의 예외(다음 실행이 `abandoned`로 정리한다).
    responses[("hrv_data", D)] = RuntimeError("hrv_data: 예상하지 못한 오류")
    fake = FakeGarmin(responses=responses)

    with pytest.raises(RuntimeError):
        _run(cfg, fake, sleeps)

    assert _runs(cfg) == [(1, D.isoformat(), NOW_MS, None, "running", "")]
    assert _query(cfg, "SELECT endpoint FROM raw_response") == [("sleep_data",)]
    assert fake.calls[-1] == "close_session"

    # 다음 실행이 그 행을 `abandoned`로 정리하고, 그날 상태가 `error`라 전체 계획으로 돈다.
    retry = FakeGarmin(responses=_full([D]))
    assert _run(cfg, retry, sleeps) == 0
    assert [row[3:] for row in _runs(cfg)] == [
        (NOW_MS, "error", "abandoned"),
        (NOW_MS, "success", ""),
    ]
    assert _day_calls(retry) == [(e, D) for e in garmin.DAY_ENDPOINTS]


# --- 실행 중단 ------------------------------------------------------------------------------

SECRET_EMAIL = "runner@example.com"


@pytest.fixture(autouse=True)
def _refuse_password_login(monkeypatch: pytest.MonkeyPatch) -> None:
    """무인 수집은 자격 증명 로그인을 부르지 않는다. 부르면 시험 실패다."""

    def refuse(*args: object, **kwargs: object) -> None:
        pytest.fail("collect가 자격 증명 로그인(garmin.interactive_login)을 불렀다")

    monkeypatch.setattr(garmin, "interactive_login", refuse)


class _Forbidden(GarminTransport):
    """모든 데이터 경로에 403을 던지는 전송 stub."""

    def connectapi(self, path: str, **kwargs: object) -> object:
        self.calls.append((path, None))
        raise http_error(403)


def _adapter(cfg: config.Config, sleeps: list[float]) -> garmin.GarminAdapter:
    return garmin.GarminAdapter(cfg, sleep=sleeps.append)


def _use_client(monkeypatch: pytest.MonkeyPatch, client: object) -> None:
    """`garmin._new_client` seam을 이 클라이언트를 돌려주게 바꾼다."""
    monkeypatch.setattr(garmin, "_new_client", lambda: client)


def _block_file(cfg: config.Config) -> object:
    path = cfg.tokenstore / garmin.BLOCK_FILENAME
    return json.loads(path.read_text("utf-8")) if path.exists() else None


def _block(reason: str, day: date = D) -> dict[str, object]:
    return {"schema_version": 1, "local_date": day.isoformat(), "reason": reason}


def _finished_run(cfg: config.Config) -> tuple:
    """중단 실행의 공통 조건: `run` 행은 정확히 1개이고 끝났으며 `running`이 아니다."""
    (row,) = _runs(cfg)
    assert row[3] is not None
    assert row[4] != "running"
    return row


def _hold_write_lock(cfg: config.Config) -> int:
    """테스트 프로세스에서 다른 fd로 `.write.lock`에 `flock(LOCK_EX)`을 잡고 fd를 돌려준다."""
    cfg.data_dir.mkdir(parents=True, exist_ok=True)
    fd = os.open(cfg.data_dir / store.LOCK_FILENAME, os.O_RDWR | os.O_CREAT, 0o600)
    fcntl.flock(fd, fcntl.LOCK_EX)
    return fd


@pytest.mark.parametrize(
    ("open_error", "status", "detail"),
    [
        (errors.RateLimited("login 단계: HTTP 429"), "rate_limited", ""),
        (errors.Blocked403("login 단계: HTTP 403"), "blocked_403", ""),
        (errors.AuthFailed("token_invalid"), "auth_failed", "token_invalid"),
        (errors.Transient("login 단계: HTTP 503"), "error", "login_transient"),
        (garmin.SessionLockTimeout("세션 락"), "error", "session_lock_timeout"),
        (garmin.BlockFileInvalid("차단 파일"), "error", "block_file_invalid"),
        (garmin.SessionBlocked("rate_limited"), "skipped_blocked", ""),
    ],
    ids=lambda value: type(value).__name__ if isinstance(value, Exception) else None,
)
def test_session_open_stops_map_to_run_status(
    cfg: config.Config,
    sleeps: list[float],
    open_error: Exception,
    status: str,
    detail: str,
    caplog: pytest.LogCaptureFixture,
):
    caplog.set_level(logging.INFO, logger="garmin_pipeline")
    _set_history_start(cfg, D)
    fake = FakeGarmin(open_error=open_error, responses=_full([D]))

    assert _run(cfg, fake, sleeps) == 0

    assert fake.calls == ["blocked_today", "open_session"]
    assert _finished_run(cfg) == (1, D.isoformat(), NOW_MS, NOW_MS, status, detail)
    assert _raw_count(cfg) == 0
    assert _fetch_errors(cfg) == []
    assert sleeps == []
    # 당일 차단으로 건너뛰는 것만 예정된 결과라 INFO이고, 나머지 중단은 WARNING이다.
    (record,) = [
        r for r in caplog.records if "collect 중단: stage=login" in r.getMessage()
    ]
    expected = (
        logging.INFO
        if isinstance(open_error, garmin.SessionBlocked)
        else logging.WARNING
    )
    assert record.levelno == expected
    assert record.getMessage().endswith(f"error={type(open_error).__name__}")


@pytest.mark.parametrize(
    ("data_error", "status", "detail"),
    [
        (errors.RateLimited("rhr_day: HTTP 429"), "rate_limited", "transient=1"),
        (errors.Blocked403("rhr_day: HTTP 403"), "blocked_403", "transient=1"),
        (
            errors.AuthFailed("token_invalid"),
            "auth_failed",
            "token_invalid transient=1",
        ),
    ],
    ids=["RateLimited", "Blocked403", "AuthFailed"],
)
def test_data_stops_keep_saved_raw_and_make_no_more_calls(
    cfg: config.Config,
    sleeps: list[float],
    data_error: Exception,
    status: str,
    detail: str,
):
    _set_history_start(cfg, D - timedelta(days=2))
    responses = _full(_days_back(D, 3))
    responses[("sleep_data", D)] = errors.Transient("sleep_data: HTTP 503")
    responses[("rhr_day", D)] = data_error
    fake = FakeGarmin(responses=responses)

    assert _run(cfg, fake, sleeps) == 0

    assert _day_calls(fake) == [("sleep_data", D), ("hrv_data", D), ("rhr_day", D)]
    assert fake.calls[-1] == "close_session"
    assert sleeps == []
    assert _query(cfg, "SELECT endpoint FROM raw_response") == [("hrv_data",)]
    # 중단 오류는 fetch_error에 남기지 않는다.
    assert [row[3:5] for row in _fetch_errors(cfg)] == [("sleep_data", "transient")]
    assert _finished_run(cfg) == (1, D.isoformat(), NOW_MS, NOW_MS, status, detail)
    expected_block = {
        errors.RateLimited: errors.RunStatus.RATE_LIMITED,
        errors.Blocked403: errors.RunStatus.BLOCKED_403,
    }.get(type(data_error))
    assert fake.blocked == expected_block


def test_next_day_collects_dates_missed_by_a_stopped_run(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    _set_history_start(cfg, D - timedelta(days=2))
    responses = _full(_days_back(D, 3))
    responses[("rhr_day", D)] = errors.RateLimited("rhr_day: HTTP 429")
    assert _run(cfg, FakeGarmin(responses=responses), sleeps) == 0
    clock.advance(days=1)
    tomorrow = D + timedelta(days=1)
    fake = FakeGarmin(responses=_full(_days_back(tomorrow, 4)))

    assert _run(cfg, fake, sleeps) == 0

    assert _days(_day_calls(fake)) == _days_back(tomorrow, 4)
    # Newly protected endpoints stop after three dates; the next forced run fills the oldest.
    assert _run(cfg, fake, sleeps, force=True) == 0
    assert all(_complete(item) for item in _items(cfg, D - timedelta(days=2), D))
    assert [row[4:] for row in _runs(cfg)] == [
        ("rate_limited", ""),
        ("success", ""),
        ("success", ""),
    ]


def test_privacy_protected_detail_order(
    cfg: config.Config, sleeps: list[float], monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setenv("TZ", "UTC")
    _set_history_start(cfg, D)
    responses = _full([D])
    responses[("sleep_data", D)] = errors.Transient("sleep_data: HTTP 503")
    responses[("user_summary", D)] = {"privacyProtected": True}
    fake = FakeGarmin(responses=responses)

    assert _run(cfg, fake, sleeps) == 0

    stop = garmin.DAY_ENDPOINTS.index("user_summary")
    assert _day_calls(fake) == [(e, D) for e in garmin.DAY_ENDPOINTS[: stop + 1]]
    assert _raw_count(cfg) == stop - 1
    assert _finished_run(cfg)[4:] == (
        "auth_failed",
        "privacy_protected transient=1 timezone_mismatch",
    )


def test_session_lock_timeout_token_matches_adapter():
    assert garmin.SessionLockTimeout.reason == errors.RunDetail.SESSION_LOCK_TIMEOUT


# 실제 어댑터(`garmin._new_client` seam만 대역).


def test_login_403_with_real_adapter_records_block(
    cfg: config.Config, sleeps: list[float], monkeypatch: pytest.MonkeyPatch
):
    cfg.tokenstore.mkdir()
    _set_history_start(cfg, D)
    # 대역의 `client.client`에는 자격 증명 `login`이 없어 불리면 AttributeError로 실패한다.
    client = StubGarminClient(login_error=http_error(403))
    _use_client(monkeypatch, client)

    assert collect.collect(cfg, _adapter(cfg, sleeps), sleep=sleeps.append) == 0

    assert client.login_calls == [str(cfg.tokenstore)]
    assert _block_file(cfg) == _block("blocked_403")
    assert _finished_run(cfg)[4:] == ("blocked_403", "")
    assert _raw_count(cfg) == 0
    assert _fetch_errors(cfg) == []
    assert sleeps == []


def test_consecutive_data_403_with_real_adapter_is_blocked_403(
    cfg: config.Config, sleeps: list[float], monkeypatch: pytest.MonkeyPatch
):
    cfg.tokenstore.mkdir()
    _set_history_start(cfg, D)
    transport = _Forbidden()
    _use_client(monkeypatch, transport_client(transport))

    assert collect.collect(cfg, _adapter(cfg, sleeps), sleep=sleeps.append) == 0

    assert cfg.max_consecutive_403 == 3
    # sleep_data·hrv_data·rhr_day 순으로 한 번씩, 승격 뒤 호출 없음(재시도도 없다).
    assert [path for path, _ in transport.calls] == [
        f"/wellness-service/wellness/dailySleepData/{FAKE_DISPLAY_NAME}",
        f"/hrv-service/hrv/{D.isoformat()}",
        f"/userstats-service/wellness/daily/{FAKE_DISPLAY_NAME}",
    ]
    assert _block_file(cfg) == _block("blocked_403")
    assert [row[3:5] for row in _fetch_errors(cfg)] == [
        ("sleep_data", "rejected"),
        ("hrv_data", "rejected"),
    ]
    assert _finished_run(cfg)[4:] == ("blocked_403", "rejected=2")
    assert _raw_count(cfg) == 0


@pytest.mark.parametrize("cause", ["missing-tokenstore", "login-401"])
def test_invalid_token_with_real_adapter_is_auth_failed(
    cfg: config.Config,
    sleeps: list[float],
    monkeypatch: pytest.MonkeyPatch,
    cause: str,
):
    _set_history_start(cfg, D)
    if cause == "login-401":
        cfg.tokenstore.mkdir()
        client = StubGarminClient(login_error=http_error(401))
        _use_client(monkeypatch, client)
    # missing-tokenstore: conftest의 seam 가드가 그대로라 클라이언트를 만들면 실패한다.

    assert collect.collect(cfg, _adapter(cfg, sleeps), sleep=sleeps.append) == 0

    assert _finished_run(cfg)[4:] == ("auth_failed", "token_invalid")
    assert _block_file(cfg) is None
    assert _raw_count(cfg) == 0
    assert _fetch_errors(cfg) == []
    assert sleeps == []
    if cause == "missing-tokenstore":
        assert not cfg.tokenstore.exists()
    else:
        # tokenstore 로그인 한 번뿐이다(자격 증명 로그인은 대역에 없어 불리면 실패한다).
        assert client.login_calls == [str(cfg.tokenstore)]


@pytest.mark.parametrize(
    "login_error",
    [http_error(503), ConnectionResetError("connection reset")],
    ids=["http-503", "network"],
)
def test_login_transient_with_real_adapter_is_error(
    cfg: config.Config,
    sleeps: list[float],
    monkeypatch: pytest.MonkeyPatch,
    login_error: BaseException,
):
    cfg.tokenstore.mkdir()
    _set_history_start(cfg, D)
    client = StubGarminClient(login_error=login_error)
    _use_client(monkeypatch, client)

    assert collect.collect(cfg, _adapter(cfg, sleeps), sleep=sleeps.append) == 0

    assert client.login_calls == [str(cfg.tokenstore)]
    assert _finished_run(cfg)[4:] == ("error", "login_transient")
    assert _block_file(cfg) is None
    assert _raw_count(cfg) == 0
    assert _fetch_errors(cfg) == []
    assert sleeps == []


def test_invalid_block_file_with_real_adapter_is_error(
    cfg: config.Config, sleeps: list[float]
):
    cfg.tokenstore.mkdir()
    (cfg.tokenstore / garmin.BLOCK_FILENAME).write_bytes(b"{not json")
    _set_history_start(cfg, D)

    # conftest의 seam 가드가 그대로라 클라이언트를 만들면(네트워크로 가면) 실패한다.
    assert collect.collect(cfg, _adapter(cfg, sleeps), sleep=sleeps.append) == 0

    assert _finished_run(cfg)[4:] == ("error", "block_file_invalid")
    assert (cfg.tokenstore / garmin.BLOCK_FILENAME).read_bytes() == b"{not json"
    assert _raw_count(cfg) == 0


def test_block_today_with_real_adapter_is_skipped_blocked(
    cfg: config.Config, sleeps: list[float], caplog: pytest.LogCaptureFixture
):
    caplog.set_level(logging.INFO, logger="garmin_pipeline")
    cfg.tokenstore.mkdir()
    raw = json.dumps(_block("rate_limited")).encode("utf-8")
    (cfg.tokenstore / garmin.BLOCK_FILENAME).write_bytes(raw)
    _set_history_start(cfg, D)

    assert collect.collect(cfg, _adapter(cfg, sleeps), sleep=sleeps.append) == 0

    assert _finished_run(cfg)[4:] == ("skipped_blocked", "")
    assert (cfg.tokenstore / garmin.BLOCK_FILENAME).read_bytes() == raw
    assert _raw_count(cfg) == 0
    # 진입 표 1행이 세션을 열기 전에 막는다. 예정된 건너뛰기라 WARNING이 아니라 INFO다.
    (record,) = [r for r in caplog.records if "collect 중단" in r.getMessage()]
    assert record.levelno == logging.INFO
    assert record.getMessage() == "collect 중단: stage=entry blocked=rate_limited"


# 쓰기 락 시간 초과.


@pytest.mark.parametrize(
    ("zone", "detail"),
    [("Asia/Seoul", "lock_timeout"), ("UTC", "lock_timeout timezone_mismatch")],
    ids=["same-zone", "timezone-mismatch"],
)
def test_write_lock_timeout_records_error_row_without_network(
    cfg: config.Config,
    sleeps: list[float],
    monkeypatch: pytest.MonkeyPatch,
    zone: str,
    detail: str,
):
    monkeypatch.setenv("TZ", zone)
    _set_history_start(cfg, D)
    fake = FakeGarmin(responses=_full([D]))
    fd = _hold_write_lock(cfg)
    try:
        assert _run(cfg, fake, sleeps) == 0
    finally:
        os.close(fd)

    assert fake.calls == []
    assert sleeps == []
    assert _runs(cfg) == [(1, D.isoformat(), NOW_MS, NOW_MS, "error", detail)]
    assert _raw_count(cfg) == 0


@pytest.mark.parametrize("zone", ["Asia/Seoul", "UTC"], ids=["same-zone", "mismatch"])
def test_lock_timeout_row_does_not_hide_the_day_result(
    cfg: config.Config,
    sleeps: list[float],
    monkeypatch: pytest.MonkeyPatch,
    clock: Clock,
    zone: str,
):
    monkeypatch.setenv("TZ", zone)
    _set_history_start(cfg, D)
    assert _run(cfg, FakeGarmin(responses=_full([D])), sleeps) == 0
    clock.moment = NOW + timedelta(minutes=15)
    fd = _hold_write_lock(cfg)
    try:
        assert _run(cfg, FakeGarmin(), sleeps) == 0
    finally:
        os.close(fd)

    assert [row[4] for row in _runs(cfg)] == ["success", "error"]
    reader = store.read_connection(cfg)
    try:
        assert coverage.day_status(reader, D).status == errors.RunStatus.SUCCESS
    finally:
        reader.close()


def test_write_lock_timeout_row_times_come_from_command_start_and_end(
    cfg: config.Config,
    sleeps: list[float],
    monkeypatch: pytest.MonkeyPatch,
    clock: Clock,
):
    # 서울 2026-10-16 23:59에 시작해 락을 기다리는 동안 다음 날 00:01이 된다.
    _set_history_start(cfg, D)
    start = datetime(2026, 10, 16, 14, 59, tzinfo=UTC)
    end = datetime(2026, 10, 16, 15, 1, tzinfo=UTC)
    clock.moment = start
    real_write_session = store.write_session

    def slow_write_session(session_cfg: config.Config) -> object:
        clock.moment = end
        return real_write_session(session_cfg)

    monkeypatch.setattr(store, "write_session", slow_write_session)
    fake = FakeGarmin(responses=_full([D]))
    fd = _hold_write_lock(cfg)
    try:
        assert _run(cfg, fake, sleeps) == 0
    finally:
        os.close(fd)

    def ms(moment: datetime) -> int:
        return (moment - EPOCH) // timedelta(milliseconds=1)

    assert fake.calls == []
    assert _runs(cfg) == [
        (1, D.isoformat(), ms(start), ms(end), "error", "lock_timeout")
    ]


def test_locked_run_crossing_midnight_keeps_the_start_day(
    cfg: config.Config, clock: Clock
):
    # 서울 2026-10-16 23:59에 시작하고, 날짜 사이 쉬는 동안 다음 날 00:01이 된다. 그 뒤의 항목 실패·
    # 중단·알림도 모두 명령 시작 날(D)로 남고, 시각만 실제 시각이다.
    yesterday = D - timedelta(days=1)
    _set_history_start(cfg, yesterday)
    start = datetime(2026, 10, 16, 14, 59, tzinfo=UTC)
    end = datetime(2026, 10, 16, 15, 1, tzinfo=UTC)
    clock.moment = start
    responses = _full([D, yesterday])
    responses[("rhr_day", yesterday)] = errors.Transient("rhr_day: HTTP 503")
    responses[("stress_data", yesterday)] = errors.RateLimited("stress_data: HTTP 429")
    fake = FakeGarmin(responses=responses)

    def pause_past_midnight(seconds: float) -> None:
        clock.moment = end

    assert collect.collect(cfg, fake, sleep=pause_past_midnight) == 0

    def ms(moment: datetime) -> int:
        return (moment - EPOCH) // timedelta(milliseconds=1)

    assert _days(_day_calls(fake)) == [D, yesterday]
    assert _runs(cfg) == [
        (1, D.isoformat(), ms(start), ms(end), "rate_limited", "transient=1")
    ]
    assert [(row[3], row[5], row[6]) for row in _fetch_errors(cfg)] == [
        ("rhr_day", D.isoformat(), ms(end))
    ]
    assert _run_notifications(cfg) == [
        (D.isoformat(), "rate_limited", "transient=1", ms(end))
    ]


def test_stop_from_activity_fetch_on_a_later_date_makes_no_more_calls(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D - timedelta(days=2))
    yesterday = D - timedelta(days=1)
    responses = _full(_days_back(D, 3))
    responses[("activities_by_date", yesterday)] = [
        _activity(11, yesterday),
        _activity(22, yesterday),
    ]
    responses.update(_activity_full([11, 22]))
    responses[("activity_details", 11)] = errors.RateLimited("activity_details: 429")
    fake = FakeGarmin(responses=responses)

    assert _run(cfg, fake, sleeps) == 0

    assert _day_calls(fake) == [
        *[(endpoint, D) for endpoint in garmin.DAY_ENDPOINTS],
        *[(endpoint, yesterday) for endpoint in garmin.DAY_ENDPOINTS],
        ("activity", 11),
        ("activity_details", 11),
    ]
    assert fake.calls[-1] == "close_session"
    # 두 번째 날짜 앞에서만 쉬었고, 중단 뒤 세 번째 날짜로 넘어가지 않았다.
    assert sleeps == [cfg.date_pause_seconds]
    saved = _query(cfg, "SELECT scope, key FROM raw_response")
    assert sum(1 for scope, key in saved if key == D.isoformat()) == len(
        garmin.DAY_ENDPOINTS
    )
    assert sum(1 for scope, key in saved if key == yesterday.isoformat()) == len(
        garmin.DAY_ENDPOINTS
    )
    assert [key for scope, key in saved if scope == "activity"] == ["11"]
    assert _fetch_errors(cfg) == []
    assert _finished_run(cfg)[4:] == ("rate_limited", "")
    assert fake.blocked is errors.RunStatus.RATE_LIMITED


@pytest.mark.parametrize("problem", ["db-missing", "schema-mismatch", "not-sqlite"])
def test_write_lock_timeout_without_usable_db_writes_nothing_and_exits_1(
    cfg: config.Config,
    sleeps: list[float],
    caplog: pytest.LogCaptureFixture,
    problem: str,
):
    caplog.set_level(logging.INFO, logger="garmin_pipeline")
    fd = _hold_write_lock(cfg)
    if problem == "schema-mismatch":
        old = sqlite3.connect(cfg.db_path)
        try:
            old.execute("PRAGMA user_version = 3")
        finally:
            old.close()
    elif problem == "not-sqlite":
        cfg.db_path.write_bytes(b"not a sqlite database" * 100)
    fake = FakeGarmin(responses=_full([D]))
    try:
        # SQLite 오류도 traceback 없이 1로 끝난다.
        assert _run(cfg, fake, sleeps) == 1
    finally:
        os.close(fd)

    assert fake.calls == []
    if problem == "db-missing":
        assert not cfg.db_path.exists()
        name = "DbMissing"
    elif problem == "not-sqlite":
        assert cfg.db_path.read_bytes() == b"not a sqlite database" * 100
        name = "DatabaseError"
    else:
        check = sqlite3.connect(cfg.db_path)
        try:
            assert check.execute("PRAGMA user_version").fetchone() == (3,)
            assert check.execute("SELECT name FROM sqlite_master").fetchall() == []
        finally:
            check.close()
        name = "SchemaMismatch"
    warnings = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert f"lock_timeout 실행 행을 남기지 못했다: error={name}" in warnings


# --- 진입 표(하루 단위 멱등) ----------------------------------------------------------------

MINUTE_MS = 60_000
DAY_MS = 24 * 60 * MINUTE_MS
LATER = NOW + timedelta(minutes=15)
"""11:15 재시도(서울 10:15, 같은 날)."""
LATER_MS = NOW_MS + 15 * MINUTE_MS


def _insert_run(
    cfg: config.Config,
    day: date,
    status: str,
    detail: str = "",
    *,
    started_at: int = NOW_MS,
    finished_at: int | None = NOW_MS,
) -> None:
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO run (local_date, started_at, finished_at, status, detail)"
            " VALUES (?, ?, ?, ?, ?)",
            (day.isoformat(), started_at, finished_at, status, detail),
        )


def _no_running(cfg: config.Config) -> None:
    assert _query(cfg, "SELECT COUNT(*) FROM run WHERE status = 'running'") == [(0,)]


def _snapshot(cfg: config.Config) -> tuple:
    return (
        _runs(cfg),
        _collect_meta(cfg),
        _query(cfg, "SELECT * FROM raw_response ORDER BY scope, key, endpoint"),
        _fetch_errors(cfg),
    )


def test_abandoned_running_rows_are_closed_and_today_reruns_full_plan(
    cfg: config.Config,
    sleeps: list[float],
    clock: Clock,
    caplog: pytest.LogCaptureFixture,
):
    caplog.set_level(logging.INFO, logger="garmin_pipeline")
    yesterday = D - timedelta(days=1)
    _set_history_start(cfg, yesterday)
    # 어제 실행과 오늘 11:00 실행이 끝나지 못하고(프로세스 종료 등) `running`으로 남았다.
    _insert_run(cfg, yesterday, "running", started_at=NOW_MS - DAY_MS, finished_at=None)
    _insert_run(cfg, D, "running", started_at=NOW_MS, finished_at=None)
    clock.moment = LATER
    fake = FakeGarmin(responses=_full(_days_back(D, 2)))

    assert _run(cfg, fake, sleeps) == 0

    assert _runs(cfg) == [
        (1, yesterday.isoformat(), NOW_MS - DAY_MS, LATER_MS, "error", "abandoned"),
        (2, D.isoformat(), NOW_MS, LATER_MS, "error", "abandoned"),
        (3, D.isoformat(), LATER_MS, LATER_MS, "success", ""),
    ]
    # 그날 상태가 `error`가 되어 전체 계획으로 돌았다.
    assert _days(_day_calls(fake)) == [D, yesterday]
    messages = [r.getMessage() for r in caplog.records]
    assert (
        "끝나지 않은 실행을 정리했다: rows=2 status=error detail=abandoned" in messages
    )
    assert "collect 진입: plan=full day_status=error" in messages


def test_block_from_another_environment_skips_without_a_client(
    make_cfg: Callable[..., config.Config],
    tmp_path: Path,
    sleeps: list[float],
    monkeypatch: pytest.MonkeyPatch,
):
    # 같은 tokenstore, 다른 DB(data_dir)의 두 환경.
    tokens = tmp_path / "shared-tokens"
    tokens.mkdir()
    cfg_a = make_cfg(tokenstore=str(tokens), data_dir=str(tmp_path / "data-a"))
    cfg_b = make_cfg(tokenstore=str(tokens), data_dir=str(tmp_path / "data-b"))
    _use_client(monkeypatch, StubGarminClient(login_error=http_error(429)))
    assert collect.collect(cfg_a, _adapter(cfg_a, sleeps), sleep=sleeps.append) == 0
    assert _finished_run(cfg_a)[4:] == ("rate_limited", "")
    assert _block_file(cfg_b) == _block("rate_limited")
    created: list[object] = []
    monkeypatch.setattr(garmin, "_new_client", lambda: created.append(1))

    assert collect.collect(cfg_b, _adapter(cfg_b, sleeps), sleep=sleeps.append) == 0

    assert created == []
    assert _runs(cfg_b) == [(1, D.isoformat(), NOW_MS, NOW_MS, "skipped_blocked", "")]
    assert _collect_meta(cfg_b) == []
    assert _raw_count(cfg_b) == 0
    assert sleeps == []


def test_retry_requests_only_the_transient_item(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    _set_history_start(cfg, D)
    responses = _full([D])
    responses[("sleep_data", D)] = errors.Transient("sleep_data: HTTP 503")
    assert _run(cfg, FakeGarmin(responses=responses), sleeps) == 0
    assert _runs(cfg)[0][4:] == ("partial", "transient=1")
    clock.moment = LATER
    retry = FakeGarmin(responses=_full([D]))

    assert _run(cfg, retry, sleeps) == 0

    assert retry.calls == [
        "blocked_today",
        "open_session",
        ("sleep_data", D),
        "close_session",
    ]
    assert _runs(cfg)[1] == (2, D.isoformat(), LATER_MS, LATER_MS, "success", "")
    states = {item.endpoint: item.state for item in _items(cfg, D, D)}
    assert states["sleep_data"] == coverage.CoverageState.DATA
    _no_running(cfg)


def test_retry_with_rejected_items_requests_only_transient_ones(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    yesterday = D - timedelta(days=1)
    _set_history_start(cfg, yesterday)
    responses = _full(_days_back(D, 2))
    responses[("activities_by_date", D)] = [_activity(11, D)]
    responses.update(_activity_full([11]))
    responses[("sleep_data", D)] = errors.Transient("sleep_data: HTTP 503")
    responses[("hrv_data", D)] = errors.Rejected("hrv_data: HTTP 400")
    responses[("activity_details", 11)] = errors.Transient("activity_details: 502")
    responses[("activity_hr_in_timezones", 11)] = errors.Rejected("hr: HTTP 403")
    responses[("rhr_day", yesterday)] = errors.Transient("rhr_day: HTTP 503")
    assert _run(cfg, FakeGarmin(responses=responses), sleeps) == 0
    assert _runs(cfg)[0][4:] == ("partial", "transient=3 rejected=2")
    clock.moment = LATER
    good = _full(_days_back(D, 2))
    good[("activities_by_date", D)] = [_activity(11, D)]
    good.update(_activity_full([11]))
    retry = FakeGarmin(responses=good)
    sleeps.clear()

    assert _run(cfg, retry, sleeps) == 0

    # 오늘 확인한 원문과 오늘 `rejected`로 남은 항목(day·activity)은 다시 받지 않는다.
    assert _day_calls(retry) == [
        ("sleep_data", D),
        ("activity_details", 11),
        ("rhr_day", yesterday),
    ]
    assert sleeps == [cfg.date_pause_seconds]
    assert _runs(cfg)[1][4:] == ("success", "")
    _no_running(cfg)


def test_retry_requests_transient_item_with_raw_checked_on_an_earlier_day(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    yesterday = D - timedelta(days=1)
    _set_history_start(cfg, yesterday)
    # 어제 받은 어제 원문: 확정되지 않았고 `checked_at`은 어제다.
    with store.write_session(cfg) as conn:
        for endpoint in garmin.DAY_ENDPOINTS:
            store.upsert_raw(
                conn,
                scope="day",
                key=yesterday.isoformat(),
                endpoint=endpoint,
                payload=None if endpoint == "activities_by_date" else {"seeded": True},
                library_version=garmin.LIBRARY_VERSION,
                now_ms=NOW_MS - DAY_MS,
            )
    responses = _full(_days_back(D, 2))
    responses[("sleep_data", yesterday)] = errors.Transient("sleep_data: HTTP 503")
    assert _run(cfg, FakeGarmin(responses=responses), sleeps) == 0
    assert _runs(cfg)[0][4:] == ("partial", "transient=1")
    clock.moment = LATER
    retry = FakeGarmin(responses=_full(_days_back(D, 2)))

    assert _run(cfg, retry, sleeps) == 0

    # 어제 확인한 원문만 남은 항목은 다시 받고, 오늘 확인한 항목은 받지 않는다.
    assert _day_calls(retry) == [("sleep_data", yesterday)]
    assert _runs(cfg)[1][4:] == ("success", "")
    _no_running(cfg)


def test_empty_retry_plan_records_success_without_a_session(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    _set_history_start(cfg, D)
    responses = _full([D])
    responses[("sleep_data", D)] = errors.Transient("sleep_data: HTTP 503")
    assert _run(cfg, FakeGarmin(responses=responses), sleeps) == 0
    assert _runs(cfg)[0][4:] == ("partial", "transient=1")
    # 실패한 항목이 그 뒤 채워졌다(오늘 확인).
    with store.write_session(cfg) as conn:
        store.upsert_raw(
            conn,
            scope="day",
            key=D.isoformat(),
            endpoint="sleep_data",
            payload={"seeded": True},
            library_version=garmin.LIBRARY_VERSION,
            now_ms=NOW_MS,
        )
    clock.moment = LATER
    fake = FakeGarmin(responses=_full([D]))

    assert _run(cfg, fake, sleeps) == 0

    assert fake.calls == ["blocked_today"]
    assert _runs(cfg)[1] == (2, D.isoformat(), LATER_MS, LATER_MS, "success", "")
    _no_running(cfg)


@pytest.mark.parametrize(
    ("case", "status", "detail"),
    [("success", "success", ""), ("rejected-only", "partial", "rejected=1")],
)
def test_nothing_to_do_writes_nothing_and_calls_no_garmin(
    cfg: config.Config,
    sleeps: list[float],
    clock: Clock,
    caplog: pytest.LogCaptureFixture,
    case: str,
    status: str,
    detail: str,
):
    _set_history_start(cfg, D)
    responses = _full([D])
    if case == "rejected-only":
        responses[("hrv_data", D)] = errors.Rejected("hrv_data: HTTP 400")
    assert _run(cfg, FakeGarmin(responses=responses), sleeps) == 0
    assert _runs(cfg)[0][4:] == (status, detail)
    before = _snapshot(cfg)
    clock.moment = LATER
    caplog.set_level(logging.INFO, logger="garmin_pipeline")
    caplog.clear()
    fake = FakeGarmin(responses=_full([D]))

    assert _run(cfg, fake, sleeps) == 0

    assert fake.calls == ["blocked_today"]
    assert _snapshot(cfg) == before
    assert sleeps == []
    assert [r.getMessage() for r in caplog.records] == [
        f"collect 건너뜀: day_status={status} detail={detail}",
        "normalize 끝: processed=0 failed=0",
    ]
    _no_running(cfg)


@pytest.mark.parametrize(
    ("token_at", "reruns"),
    [
        (NOW_MS - 4 * MINUTE_MS, True),
        # 실패 실행 도중의 토큰 갱신(무인 login의 선제 갱신)은 재로그인이 아니다.
        (NOW_MS - 7 * MINUTE_MS, False),
        (NOW_MS - 5 * MINUTE_MS, False),
        (NOW_MS - 20 * MINUTE_MS, False),
        (None, False),
    ],
    ids=["after-finish", "during-run", "at-finish", "before-start", "no-file"],
)
def test_auth_failed_reruns_only_after_relogin(
    cfg: config.Config, sleeps: list[float], token_at: int | None, reruns: bool
):
    _set_history_start(cfg, D)
    _insert_run(
        cfg,
        D,
        "auth_failed",
        "token_invalid",
        started_at=NOW_MS - 10 * MINUTE_MS,
        finished_at=NOW_MS - 5 * MINUTE_MS,
    )
    cfg.tokenstore.mkdir()
    if token_at is not None:
        token = cfg.tokenstore / garmin.TOKEN_FILENAME
        token.write_bytes(b"{}")
        os.utime(token, ns=(token_at * 1_000_000, token_at * 1_000_000))
    before = _snapshot(cfg)
    fake = FakeGarmin(responses=_full([D]))

    assert _run(cfg, fake, sleeps) == 0

    if reruns:
        assert _day_calls(fake) == [(e, D) for e in garmin.DAY_ENDPOINTS]
        assert _runs(cfg)[1][4:] == ("success", "")
    else:
        assert fake.calls == ["blocked_today"]
        assert _snapshot(cfg) == before


@pytest.mark.parametrize(
    ("status", "detail"),
    [
        ("error", "login_transient"),
        ("error", "lock_timeout"),
        ("error", "abandoned"),
        ("rate_limited", ""),
        ("blocked_403", "transient=1"),
    ],
)
def test_failed_day_without_block_reruns_full_plan(
    cfg: config.Config, sleeps: list[float], status: str, detail: str
):
    _set_history_start(cfg, D)
    # 오늘 이미 받은 원문이 있어도 전체 계획이라 다시 받는다.
    _seed_days(cfg, [D], {})
    _insert_run(cfg, D, status, detail)
    fake = FakeGarmin(responses=_full([D]))

    assert _run(cfg, fake, sleeps) == 0

    assert _day_calls(fake) == [(e, D) for e in garmin.DAY_ENDPOINTS]
    assert _runs(cfg)[1][4:] == ("success", "")


def test_force_reruns_a_successful_day(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    _set_history_start(cfg, D)
    responses = _full([D])
    responses[("hrv_data", D)] = errors.Rejected("hrv_data: HTTP 400")
    assert _run(cfg, FakeGarmin(responses=responses), sleeps) == 0
    clock.moment = LATER
    fake = FakeGarmin(responses=_full([D]))

    assert _run(cfg, fake, sleeps, force=True) == 0

    # 오늘 확인한 항목·오늘 rejected 항목도 다시 받는다.
    assert _day_calls(fake) == [(e, D) for e in garmin.DAY_ENDPOINTS]
    assert [row[4:] for row in _runs(cfg)] == [
        ("partial", "rejected=1"),
        ("success", ""),
    ]


@pytest.mark.parametrize("force", [False, True], ids=["plain", "force"])
@pytest.mark.parametrize(
    ("fake_kwargs", "status", "detail"),
    [
        ({"blocked": errors.RunStatus.BLOCKED_403}, "skipped_blocked", ""),
        (
            {"block_error": garmin.BlockFileInvalid("차단 파일")},
            "error",
            "block_file_invalid",
        ),
    ],
    ids=["blocked", "block-file-invalid"],
)
def test_block_check_ends_with_one_row_and_no_network(
    cfg: config.Config,
    sleeps: list[float],
    fake_kwargs: dict[str, object],
    status: str,
    detail: str,
    force: bool,
):
    fake = FakeGarmin(responses=_full([D]), **fake_kwargs)  # type: ignore[arg-type]

    assert _run(cfg, fake, sleeps, force=force) == 0

    assert fake.calls == ["blocked_today"]
    assert _runs(cfg) == [(1, D.isoformat(), NOW_MS, NOW_MS, status, detail)]
    assert _collect_meta(cfg) == []
    assert _raw_count(cfg) == 0
    assert sleeps == []


def test_blocked_entry_row_notes_timezone_mismatch(
    cfg: config.Config, sleeps: list[float], monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setenv("TZ", "UTC")

    assert _run(cfg, FakeGarmin(blocked=errors.RunStatus.RATE_LIMITED), sleeps) == 0

    assert _runs(cfg)[0][4:] == ("skipped_blocked", "timezone_mismatch")


@pytest.mark.parametrize(
    "entry", ["blocked", "block-file-invalid", "nothing", "full", "retry"]
)
def test_no_running_rows_after_any_entry(
    cfg: config.Config, sleeps: list[float], entry: str
):
    yesterday = D - timedelta(days=1)
    _set_history_start(cfg, D)
    _insert_run(cfg, yesterday, "running", finished_at=None)
    if entry == "nothing":
        _insert_run(cfg, D, "success")
    elif entry == "retry":
        _insert_run(cfg, D, "partial", "transient=1")
    fake = FakeGarmin(
        blocked=errors.RunStatus.RATE_LIMITED if entry == "blocked" else None,
        block_error=garmin.BlockFileInvalid("차단 파일")
        if entry == "block-file-invalid"
        else None,
        responses=_full([D]),
    )

    assert _run(cfg, fake, sleeps) == 0

    _no_running(cfg)
    assert _runs(cfg)[0][4:] == ("error", "abandoned")
    assert ("open_session" in fake.calls) is (entry in {"full", "retry"})


# --- 계획 ----------------------------------------------------------------------------------


def test_plan_is_newest_first_and_only_pending_items(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D - timedelta(days=6))
    with store.write_session(cfg) as conn:
        for day in _days_back(D - timedelta(days=2), 5):
            for endpoint in garmin.DAY_ENDPOINTS:
                if day == D - timedelta(days=5) and endpoint == "hrv_data":
                    continue
                store.upsert_raw(
                    conn,
                    scope="day",
                    key=day.isoformat(),
                    endpoint=endpoint,
                    # 활동 목록은 리스트여야 하므로(아니면 확정되지 않는다) 빈 응답으로 둔다.
                    payload=None
                    if endpoint == "activities_by_date"
                    else {"seeded": True},
                    library_version=garmin.LIBRARY_VERSION,
                    now_ms=NOW_MS,
                )
    fake = FakeGarmin(responses=_full(_days_back(D, 7)))

    _run(cfg, fake, sleeps)

    assert _day_calls(fake) == [
        *[(endpoint, D) for endpoint in garmin.DAY_ENDPOINTS],
        *[(endpoint, D - timedelta(days=1)) for endpoint in garmin.DAY_ENDPOINTS],
        ("hrv_data", D - timedelta(days=5)),
    ]
    assert sleeps == [cfg.date_pause_seconds] * 2


def _activity(activity_id: int, day: date) -> dict[str, object]:
    return {"activityId": activity_id, "startTimeLocal": f"{day} 07:00:00"}


BASE_ACTIVITY = garmin.ACTIVITY_ENDPOINTS[:3]
"""세트가 없는 활동이 받는 3종(세트 상세 `activity_exercise_sets` 제외)."""
SETS = "activity_exercise_sets"


def _activity_full(activity_ids: list[int]) -> dict[tuple[str, object], object]:
    """그 활동들의 activity 3종 응답(세트 상세는 `_sets_response`)."""
    return {
        (endpoint, activity_id): {"activityId": activity_id, "note": MARKER}
        for activity_id in activity_ids
        for endpoint in BASE_ACTIVITY
    }


def _activity_calls(activity_id: int) -> list[tuple[str, object]]:
    return [(endpoint, activity_id) for endpoint in BASE_ACTIVITY]


def _seed_days(
    cfg: config.Config, days: list[date], lists: dict[date, list[object]]
) -> None:
    """그날들의 day 9종을 `NOW`에 확정된 원문으로 넣는다. 활동 목록은 `lists`, 없으면 `null`."""
    with store.write_session(cfg) as conn:
        for day in days:
            for endpoint in garmin.DAY_ENDPOINTS:
                payload: object = {"seeded": True}
                if endpoint == "activities_by_date":
                    payload = lists.get(day)
                store.upsert_raw(
                    conn,
                    scope="day",
                    key=day.isoformat(),
                    endpoint=endpoint,
                    payload=payload,
                    library_version=garmin.LIBRARY_VERSION,
                    now_ms=NOW_MS,
                )


def _activity_rows(cfg: config.Config) -> list[tuple]:
    return _query(
        cfg,
        "SELECT key, endpoint, raw FROM raw_response WHERE scope = 'activity'"
        " ORDER BY key, endpoint",
    )


def test_new_activities_are_fetched_in_the_same_run(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    responses = _full([D])
    responses[("activities_by_date", D)] = [_activity(11, D), _activity(22, D)]
    responses.update(_activity_full([11, 22]))
    del responses[("activity_hr_in_timezones", 22)]
    fake = FakeGarmin(responses=responses)

    assert _run(cfg, fake, sleeps) == 0

    assert _day_calls(fake) == [
        *[(endpoint, D) for endpoint in garmin.DAY_ENDPOINTS],
        *_activity_calls(11),
        *_activity_calls(22),
    ]
    assert sleeps == []
    rows = _activity_rows(cfg)
    assert [(key, endpoint) for key, endpoint, _ in rows] == [
        (key, endpoint) for key in ("11", "22") for endpoint in sorted(BASE_ACTIVITY)
    ]
    raws = {(key, endpoint): raw for key, endpoint, raw in rows}
    assert raws[("22", "activity_hr_in_timezones")] == "null"
    assert MARKER in raws[("11", "activity_details")]
    assert _runs(cfg)[0][4:] == ("success", "")


def test_complete_activity_items_are_not_requested_again(
    cfg: config.Config, sleeps: list[float]
):
    # 같은 날 다시 실행하면 확정되지 않은 오늘 day 항목은 다시 받지만 activity 항목은 받지 않는다.
    _set_history_start(cfg, D)
    responses = _full([D])
    responses[("activities_by_date", D)] = [_activity(11, D)]
    responses.update(_activity_full([11]))
    first = FakeGarmin(responses=responses)
    assert _run(cfg, first, sleeps) == 0
    second = FakeGarmin(responses=responses)

    assert _run(cfg, second, sleeps, force=True) == 0

    assert _day_calls(second) == [(endpoint, D) for endpoint in garmin.DAY_ENDPOINTS]
    assert len(_activity_rows(cfg)) == 3


def test_failed_activity_item_is_the_only_one_requested_later(
    cfg: config.Config, clock: Clock, sleeps: list[float]
):
    _set_history_start(cfg, D)
    responses = _full([D])
    responses[("activities_by_date", D)] = [_activity(11, D)]
    responses.update(_activity_full([11]))
    responses[("activity_details", 11)] = errors.Transient("activity_details")
    first = FakeGarmin(responses=responses)

    assert _run(cfg, first, sleeps) == 0

    assert _fetch_errors(cfg) == [
        (1, "activity", "11", "activity_details", "transient", D.isoformat(), NOW_MS)
        + ("transient",)
    ]
    assert _runs(cfg)[0][4:] == ("partial", "transient=1")

    # 다음 날: 어제 day 항목은 확정되지 않았으니 다시 받고, activity 항목은 실패한 것만 받는다.
    clock.advance(days=1)
    tomorrow = D + timedelta(days=1)
    responses = _full([tomorrow, D])
    responses[("activities_by_date", D)] = [_activity(11, D)]
    responses.update(_activity_full([11]))
    second = FakeGarmin(responses=responses)

    assert _run(cfg, second, sleeps) == 0

    assert _day_calls(second) == [
        *[(endpoint, tomorrow) for endpoint in garmin.DAY_ENDPOINTS],
        *[(endpoint, D) for endpoint in garmin.DAY_ENDPOINTS],
        ("activity_details", 11),
    ]
    assert len(_activity_rows(cfg)) == 3
    assert _runs(cfg)[1][4:] == ("success", "")


def test_activity_items_count_by_activity_day_key(
    make_cfg: Callable[..., config.Config], sleeps: list[float]
):
    # 지난 4일의 day 항목은 확정. 미완료 activity 항목은 D−2(D−1 목록의 활동 33 포함), D−3, D−4에 있다.
    cfg = make_cfg(max_dates_per_run=3)
    past = _days_back(D - timedelta(days=1), 4)
    d1, d2, d3, d4 = past
    _set_history_start(cfg, d4)
    _seed_days(
        cfg,
        past,
        {
            d1: [_activity(33, d2)],
            d2: [_activity(22, d2)],
            d3: [_activity(44, d3)],
            d4: [_activity(55, d4)],
        },
    )
    responses = _full([D])
    responses.update(_activity_full([22, 33, 44, 55]))
    fake = FakeGarmin(responses=responses)

    assert _run(cfg, fake, sleeps) == 0

    assert _day_calls(fake) == [
        *[(endpoint, D) for endpoint in garmin.DAY_ENDPOINTS],
        *_activity_calls(22),
        *_activity_calls(33),
        *_activity_calls(44),
    ]
    assert sleeps == [cfg.date_pause_seconds] * 2
    assert {key for key, _, _ in _activity_rows(cfg)} == {"22", "33", "44"}


# ---- 세트 상세(activity_exercise_sets) ----


def _strength(activity_id: int, day: date, total_sets: int = 5) -> dict[str, object]:
    return {**_activity(activity_id, day), "totalSets": total_sets}


def _sets_response(activity_id: int, version: int = 1) -> dict[str, object]:
    return {"activityId": activity_id, "exerciseSets": [{"v": version}], "m": MARKER}


def _sets_calls(fake: FakeGarmin) -> list[tuple[str, object]]:
    return [call for call in _day_calls(fake) if call[0] == SETS]


def _sets_row(cfg: config.Config, activity_id: int) -> tuple | None:
    rows = _query(
        cfg,
        "SELECT scope, key, raw, fetched_at, checked_at FROM raw_response"
        " WHERE endpoint = ? AND key = ?",
        (SETS, str(activity_id)),
    )
    return rows[0] if rows else None


def _sets_item(
    cfg: config.Config, day: date, activity_id: int
) -> coverage.CoverageItem:
    reader = store.read_connection(cfg)
    try:
        (item,) = [
            item
            for item in coverage.items(reader, cfg, day, day)
            if item.endpoint == SETS and item.key == str(activity_id)
        ]
    finally:
        reader.close()
    return item


def _strength_day(
    day: date, lists: dict[date, list[object]], *activity_ids: int
) -> dict[tuple[str, object], object]:
    """그날 day 응답, 목록 `lists`, 활동 3종과 세트 상세 응답."""
    responses = _full([day])
    for list_day, entries in lists.items():
        responses[("activities_by_date", list_day)] = entries
    responses.update(_activity_full(list(activity_ids)))
    responses.update({(SETS, i): _sets_response(i) for i in activity_ids})
    return responses


def test_sets_are_requested_only_for_strength_activities(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    responses = _strength_day(D, {D: [_strength(11, D), _activity(22, D)]}, 11, 22)
    fake = FakeGarmin(responses=responses)

    assert _run(cfg, fake, sleeps) == 0

    # 근력 활동은 기존 3종 다음 세트, 다른 활동의 호출은 기존 3종 그대로다.
    assert _day_calls(fake) == [
        *[(endpoint, D) for endpoint in garmin.DAY_ENDPOINTS],
        *_activity_calls(11),
        (SETS, 11),
        *_activity_calls(22),
    ]
    assert _sets_row(cfg, 11) == (
        "activity",
        "11",
        json.dumps(_sets_response(11), ensure_ascii=False),
        NOW_MS,
        NOW_MS,
    )
    assert _sets_row(cfg, 22) is None
    assert _runs(cfg)[0][4:] == ("success", "")


def test_same_list_again_does_not_request_sets(
    cfg: config.Config, clock: Clock, sleeps: list[float]
):
    _set_history_start(cfg, D)
    lists = {D: [_strength(11, D)]}
    assert _run(cfg, FakeGarmin(responses=_strength_day(D, lists, 11)), sleeps) == 0

    # 다음 날: 확정되지 않은 어제(D) 목록을 같은 내용으로 다시 받는다.
    clock.advance(days=1)
    tomorrow = D + timedelta(days=1)
    responses = _strength_day(D, lists, 11) | _full([tomorrow])
    second = FakeGarmin(responses=responses)

    assert _run(cfg, second, sleeps) == 0

    assert ("activities_by_date", D) in _day_calls(second)
    assert _sets_calls(second) == []
    assert [call for call in _day_calls(second) if call[1] == 11] == []
    assert _sets_item(cfg, D, 11).fresh is True


def test_changed_list_requests_sets_again_only_for_that_days_strength_activities(
    cfg: config.Config, clock: Clock, sleeps: list[float]
):
    yesterday = D - timedelta(days=1)
    _set_history_start(cfg, yesterday)
    lists = {
        yesterday: [_strength(33, yesterday)],
        D: [_strength(11, D), _activity(22, D), _strength(44, D, total_sets=3)],
    }
    first = _strength_day(D, lists, 11, 22, 33, 44) | _full([yesterday])
    assert _run(cfg, FakeGarmin(responses=first), sleeps) == 0
    before_33 = _sets_row(cfg, 33)

    # 다음 날: 앱에서 11의 세트를 고쳐 D 목록 원문이 바뀌었다(어제 목록은 확정이라 받지 않는다).
    clock.advance(days=1)
    tomorrow = D + timedelta(days=1)
    changed = {
        D: [_strength(11, D, total_sets=6), _activity(22, D), _strength(44, D, 3)]
    }
    responses = _strength_day(D, changed, 11, 22, 33, 44) | _full([tomorrow])
    responses[(SETS, 11)] = _sets_response(11, version=2)
    second = FakeGarmin(responses=responses)

    assert _run(cfg, second, sleeps) == 0

    # 바뀐 목록의 근력 활동(11·44)만 세트를 다시 받는다. 기존 3종·비근력·다른 날 활동은 받지 않는다.
    assert [call for call in _day_calls(second) if isinstance(call[1], int)] == [
        (SETS, 11),
        (SETS, 44),
    ]
    later_ms = NOW_MS + DAY_MS
    row = _sets_row(cfg, 11)
    assert row is not None
    assert row[2] == json.dumps(_sets_response(11, 2), ensure_ascii=False)
    assert row[3:] == (later_ms, later_ms)
    assert _sets_row(cfg, 33) == before_33
    for activity_id in (11, 44):
        item = _sets_item(cfg, D, activity_id)
        assert (item.state, item.fresh) == (coverage.CoverageState.DATA, True)


def test_retry_plan_uses_the_same_sets_judgement(
    cfg: config.Config, clock: Clock, sleeps: list[float]
):
    # 어제(D−1) 받은 근력 활동 11의 세트가 있다. 오늘 어제 목록이 바뀌어 세트를 다시 받다 일시 실패했다.
    yesterday = D - timedelta(days=1)
    _set_history_start(cfg, yesterday)
    with store.write_session(cfg) as conn:
        for endpoint in garmin.DAY_ENDPOINTS:
            store.upsert_raw(
                conn,
                scope="day",
                key=yesterday.isoformat(),
                endpoint=endpoint,
                payload=(
                    [_strength(11, yesterday)]
                    if endpoint == "activities_by_date"
                    else {"seeded": True}
                ),
                library_version=garmin.LIBRARY_VERSION,
                now_ms=NOW_MS - DAY_MS,
            )
        for endpoint, payload in (
            *((e, {"activityId": 11}) for e in BASE_ACTIVITY),
            (SETS, _sets_response(11)),
        ):
            store.upsert_raw(
                conn,
                scope="activity",
                key="11",
                endpoint=endpoint,
                payload=payload,
                library_version=garmin.LIBRARY_VERSION,
                now_ms=NOW_MS - DAY_MS,
            )
    responses = _full(_days_back(D, 2))
    responses[("activities_by_date", yesterday)] = [_strength(11, yesterday, 6)]
    responses[(SETS, 11)] = errors.Transient("exercise_sets: HTTP 503")
    first = FakeGarmin(responses=responses)
    assert _run(cfg, first, sleeps) == 0
    assert _sets_calls(first) == [(SETS, 11)]
    assert _runs(cfg)[0][4:] == ("partial", "transient=1")
    stale = _sets_item(cfg, yesterday, 11)
    assert (stale.state, stale.fresh) == (coverage.CoverageState.DATA, False)

    # 11:15 재시도: 오늘 확인한 항목은 빼고, 같은 판정으로 낡은 세트만 다시 받는다.
    clock.moment = LATER
    responses[(SETS, 11)] = _sets_response(11, version=2)
    retry = FakeGarmin(responses=responses)

    assert _run(cfg, retry, sleeps) == 0

    assert _day_calls(retry) == [(SETS, 11)]
    assert _runs(cfg)[1][4:] == ("success", "")
    assert _sets_item(cfg, yesterday, 11).fresh is True


@pytest.mark.parametrize(
    "empty", [None, {}, []], ids=["missing", "empty-dict", "empty-list"]
)
def test_empty_sets_response_keeps_existing_raw(
    cfg: config.Config, clock: Clock, sleeps: list[float], empty: object
):
    _set_history_start(cfg, D)
    assert (
        _run(
            cfg,
            FakeGarmin(responses=_strength_day(D, {D: [_strength(11, D)]}, 11)),
            sleeps,
        )
        == 0
    )
    before = _sets_row(cfg, 11)
    assert before is not None

    clock.advance(days=1)
    tomorrow = D + timedelta(days=1)
    responses = _strength_day(D, {D: [_strength(11, D, 6)]}, 11) | _full([tomorrow])
    if empty is None:
        del responses[(SETS, 11)]
    else:
        responses[(SETS, 11)] = empty
    second = FakeGarmin(responses=responses)

    assert _run(cfg, second, sleeps) == 0

    assert _sets_calls(second) == [(SETS, 11)]
    later_ms = NOW_MS + DAY_MS
    assert _sets_row(cfg, 11) == (*before[:4], later_ms)
    # 확인 시각이 목록보다 뒤라 다시 받지 않는다.
    assert _sets_item(cfg, D, 11).fresh is True


def test_unplannable_activity_items_are_not_planned(
    make_cfg: Callable[..., config.Config], sleeps: list[float]
):
    # 지난날 day 항목은 확정, 활동 44의 activity 항목은 모두 거부 한도를 넘었다.
    cfg = make_cfg(max_rejected_attempts=1)
    old = D - timedelta(days=1)
    _set_history_start(cfg, old)
    _seed_days(cfg, [old], {old: [_activity(44, old)]})
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO run (local_date, started_at, finished_at, status, detail)"
            " VALUES (?, ?, ?, 'partial', 'rejected=3')",
            (old.isoformat(), NOW_MS, NOW_MS),
        )
        for endpoint in BASE_ACTIVITY:
            conn.execute(
                "INSERT INTO fetch_error (run_id, scope, key, endpoint, kind,"
                " local_date, occurred_at, error_code)"
                " VALUES (1, 'activity', '44', ?, 'rejected', ?, ?, 'rejected')",
                (endpoint, old.isoformat(), NOW_MS),
            )
    fake = FakeGarmin(responses=_full([D]))

    assert _run(cfg, fake, sleeps) == 0

    assert _day_calls(fake) == [(endpoint, D) for endpoint in garmin.DAY_ENDPOINTS]
    assert sleeps == []


# ---- 첫 호출 보호(activity_exercise_sets) ----

STRENGTH_IDS = list(range(101, 113))
"""같은 날(D) 근력 활동 12개."""


def _strength_responses(ids: list[int]) -> dict[tuple[str, object], object]:
    return _strength_day(D, {D: [_strength(i, D) for i in ids]}, *ids)


def _first_run_calls(ids: list[int], with_sets: list[int]) -> list[tuple]:
    """D의 day 9종, 이어서 활동마다 기존 3종(과 `with_sets`면 세트 상세)."""
    calls: list[tuple] = [(endpoint, D) for endpoint in garmin.DAY_ENDPOINTS]
    for activity_id in ids:
        calls.extend(_activity_calls(activity_id))
        if activity_id in with_sets:
            calls.append((SETS, activity_id))
    return calls


def test_first_call_constants():
    assert collect.FIRST_CALL_ENDPOINTS == (
        coverage.EXERCISE_SETS,
        "daily_weigh_ins",
        "lifestyle_logging_data",
    )
    assert collect.FIRST_CALL_LIMIT == 3


def test_first_call_limits_sets_requests_to_three_per_run(
    cfg: config.Config, sleeps: list[float], caplog: pytest.LogCaptureFixture
):
    caplog.set_level(logging.INFO, logger="garmin_pipeline")
    _set_history_start(cfg, D)
    fake = FakeGarmin(responses=_strength_responses(STRENGTH_IDS))

    assert _run(cfg, fake, sleeps) == 0

    # 세트 상세는 앞 3개 활동만, 다른 3종은 활동마다 그대로 받는다.
    assert fake.first_call_endpoints == [frozenset(collect.FIRST_CALL_ENDPOINTS)]
    assert _day_calls(fake) == _first_run_calls(STRENGTH_IDS, STRENGTH_IDS[:3])
    assert [key for key, endpoint, _ in _activity_rows(cfg) if endpoint == SETS] == [
        str(i) for i in STRENGTH_IDS[:3]
    ]
    # 건너뛴 9건은 실패가 아니다.
    assert _fetch_errors(cfg) == []
    assert _runs(cfg)[0][4:] == ("success", "")
    skipped = [r for r in caplog.records if "첫 호출 보호로 건너뜀" in r.getMessage()]
    assert [(r.levelno, r.getMessage()) for r in skipped] == [
        (
            logging.INFO,
            "collect 첫 호출 보호로 건너뜀: endpoint=activity_exercise_sets skipped=9",
        )
    ]


def test_first_call_limit_spans_dates_in_one_run(
    cfg: config.Config, sleeps: list[float], caplog: pytest.LogCaptureFixture
):
    caplog.set_level(logging.INFO, logger="garmin_pipeline")
    days = _days_back(D, 3)
    _set_history_start(cfg, days[-1])
    by_day = {
        day: [200 + 10 * index + n for n in (1, 2)] for index, day in enumerate(days)
    }
    responses = _full(days)
    for day, ids in by_day.items():
        responses[("activities_by_date", day)] = [_strength(i, day) for i in ids]
        responses.update(_activity_full(ids))
        responses.update({(SETS, i): _sets_response(i) for i in ids})
    fake = FakeGarmin(responses=responses)

    assert _run(cfg, fake, sleeps) == 0

    # 상한은 날짜마다가 아니라 실행 전체 3건이다: 최신 날짜(D)의 2건, 다음 날짜의 첫 1건.
    planned = [i for day in days for i in by_day[day]]
    assert _sets_calls(fake) == [(SETS, i) for i in planned[:3]]
    assert _fetch_errors(cfg) == []
    assert _runs(cfg)[0][4:] == ("success", "")
    assert (
        "collect 첫 호출 보호로 건너뜀: endpoint=activity_exercise_sets skipped=3"
        in caplog.text
    )


def test_first_call_protection_ends_once_sets_data_is_saved(
    cfg: config.Config, sleeps: list[float], caplog: pytest.LogCaptureFixture
):
    _set_history_start(cfg, D)
    responses = _strength_responses(STRENGTH_IDS)
    assert _run(cfg, FakeGarmin(responses=responses), sleeps) == 0
    caplog.clear()
    caplog.set_level(logging.INFO, logger="garmin_pipeline")
    second = FakeGarmin(responses=responses)

    assert _run(cfg, second, sleeps, force=True) == 0

    # `data`가 저장됐으니 보호 대상이 없다: 빈 집합으로 열고 남은 9건을 모두 받는다.
    assert second.first_call_endpoints == [frozenset()]
    assert _sets_calls(second) == [(SETS, i) for i in STRENGTH_IDS[3:]]
    assert len([row for row in _activity_rows(cfg) if row[1] == SETS]) == 12
    assert "첫 호출 보호로 건너뜀" not in caplog.text
    assert _runs(cfg)[1][4:] == ("success", "")


def test_first_call_protection_stays_while_sets_raws_are_only_null(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    responses = _strength_responses(STRENGTH_IDS)
    for activity_id in STRENGTH_IDS:
        del responses[(SETS, activity_id)]  # 세트 상세가 모두 NoData(`null`)다.
    first = FakeGarmin(responses=responses)
    assert _run(cfg, first, sleeps) == 0
    assert _sets_calls(first) == [(SETS, i) for i in STRENGTH_IDS[:3]]
    assert _query(
        cfg, "SELECT DISTINCT raw FROM raw_response WHERE endpoint = ?", (SETS,)
    ) == [("null",)]
    second = FakeGarmin(responses=responses)

    assert _run(cfg, second, sleeps, force=True) == 0

    # `null`만 있으면 아직 보호 대상이다(상한·403 예외 유지).
    assert second.first_call_endpoints == [frozenset({SETS})]
    assert _sets_calls(second) == [(SETS, i) for i in STRENGTH_IDS[3:6]]


def test_first_call_counts_failed_attempts_and_skips_without_errors(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    ids = STRENGTH_IDS[:5]
    responses = _strength_responses(ids)
    responses[(SETS, ids[0])] = errors.Rejected(f"{SETS}: HTTP 403")
    responses[(SETS, ids[1])] = errors.Transient(f"{SETS}: HTTP 503")
    fake = FakeGarmin(responses=responses)

    assert _run(cfg, fake, sleeps) == 0

    # 실패한 시도도 1건이다. 상한을 넘은 4·5번째는 부르지도 기록하지도 않는다.
    assert _sets_calls(fake) == [(SETS, i) for i in ids[:3]]
    assert [row[2:5] for row in _fetch_errors(cfg)] == [
        (str(ids[0]), SETS, "rejected"),
        (str(ids[1]), SETS, "transient"),
    ]
    assert _runs(cfg)[0][4:] == ("partial", "transient=1 rejected=1")


def test_no_first_call_target_opens_session_with_empty_set(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    with store.write_session(cfg) as conn:
        store.upsert_raw(
            conn,
            scope="activity",
            key="99",
            endpoint=SETS,
            payload=_sets_response(99),
            library_version=garmin.LIBRARY_VERSION,
            now_ms=NOW_MS,
        )
    with store.write_session(cfg) as conn:
        for endpoint in ("daily_weigh_ins", "lifestyle_logging_data"):
            store.upsert_raw(
                conn,
                scope="day",
                key=D.isoformat(),
                endpoint=endpoint,
                payload={},
                library_version=garmin.LIBRARY_VERSION,
                now_ms=NOW_MS,
            )
    fake = FakeGarmin(responses=_strength_responses(STRENGTH_IDS[:5]))

    assert _run(cfg, fake, sleeps) == 0

    assert fake.first_call_endpoints == [frozenset()]
    assert _sets_calls(fake) == [(SETS, i) for i in STRENGTH_IDS[:5]]


# 실제 어댑터: 근력 활동 3개의 기존 3종은 이미 받았고 세트 상세만 남았다(세트 호출이 연달아 나간다).

FIRST_CALL_IDS = [11, 22, 33]


def _sets_path(activity_id: int) -> str:
    return f"/activity-service/activity/{activity_id}/exerciseSets"


def _seed_strength_without_sets(cfg: config.Config) -> None:
    yesterday = D - timedelta(days=1)
    _set_history_start(cfg, yesterday)
    _seed_days(
        cfg, [yesterday], {yesterday: [_strength(i, yesterday) for i in FIRST_CALL_IDS]}
    )
    with store.write_session(cfg) as conn:
        for activity_id in FIRST_CALL_IDS:
            for endpoint in BASE_ACTIVITY:
                store.upsert_raw(
                    conn,
                    scope="activity",
                    key=str(activity_id),
                    endpoint=endpoint,
                    payload={"activityId": activity_id},
                    library_version=garmin.LIBRARY_VERSION,
                    now_ms=NOW_MS,
                )


def test_first_call_403s_with_real_adapter_are_not_promoted(
    cfg: config.Config, sleeps: list[float], monkeypatch: pytest.MonkeyPatch
):
    cfg.tokenstore.mkdir()
    _seed_strength_without_sets(cfg)
    transport = GarminTransport()
    for activity_id in FIRST_CALL_IDS:
        transport.reply(_sets_path(activity_id), http_error(403))
    _use_client(monkeypatch, transport_client(transport))

    assert collect.collect(cfg, _adapter(cfg, sleeps), sleep=sleeps.append) == 0

    assert cfg.max_consecutive_403 == 3
    # 오늘 day 9종(전송 stub에 없어 404 → null) 다음 세트 403이 세 번 연달아 나가도 승격하지 않는다.
    sets_calls = [path for path, _ in transport.calls if path.endswith("/exerciseSets")]
    assert sets_calls == [_sets_path(i) for i in FIRST_CALL_IDS]
    assert transport.calls[-3:] == [(path, None) for path in sets_calls]
    assert _block_file(cfg) is None
    assert [row[2:5] for row in _fetch_errors(cfg)] == [
        (str(i), SETS, "rejected") for i in FIRST_CALL_IDS
    ]
    assert _finished_run(cfg)[4:] == ("partial", "rejected=3")


def test_first_call_429_with_real_adapter_stops_the_run(
    cfg: config.Config, sleeps: list[float], monkeypatch: pytest.MonkeyPatch
):
    cfg.tokenstore.mkdir()
    _seed_strength_without_sets(cfg)
    transport = GarminTransport()
    for activity_id in FIRST_CALL_IDS:
        transport.reply(_sets_path(activity_id), http_error(429))
    _use_client(monkeypatch, transport_client(transport))

    assert collect.collect(cfg, _adapter(cfg, sleeps), sleep=sleeps.append) == 0

    sets_paths = {path for path, _ in transport.calls if path.endswith("/exerciseSets")}
    assert sets_paths == {_sets_path(FIRST_CALL_IDS[0])}
    assert transport.calls[-1][0] == _sets_path(FIRST_CALL_IDS[0])
    assert _block_file(cfg) == _block("rate_limited")
    assert _fetch_errors(cfg) == []
    assert _finished_run(cfg)[4:] == ("rate_limited", "")


def test_max_dates_per_run_limits_plan(
    make_cfg: Callable[..., config.Config], sleeps: list[float]
):
    cfg = make_cfg(max_dates_per_run=3)
    fake = FakeGarmin(responses=_full(_days_back(D, 31)))

    _run(cfg, fake, sleeps)

    assert _days(_day_calls(fake)) == _days_back(D, 3)
    assert sleeps == [cfg.date_pause_seconds] * 2


def test_unplannable_items_mean_no_session(
    make_cfg: Callable[..., config.Config], sleeps: list[float]
):
    cfg = make_cfg(max_rejected_attempts=1)
    _set_history_start(cfg, D)
    with store.write_session(cfg) as conn:
        # 오늘 실행 기록이 있으면 진입 표가 먼저 끝내므로 어제 실행으로 둔다.
        conn.execute(
            "INSERT INTO run (local_date, started_at, finished_at, status, detail)"
            " VALUES (?, ?, ?, 'partial', 'rejected=9')",
            ((D - timedelta(days=1)).isoformat(), NOW_MS, NOW_MS),
        )
        for endpoint in garmin.DAY_ENDPOINTS:
            conn.execute(
                "INSERT INTO fetch_error (run_id, scope, key, endpoint, kind,"
                " local_date, occurred_at, error_code)"
                " VALUES (1, 'day', ?, ?, 'rejected', ?, ?, 'rejected')",
                (D.isoformat(), endpoint, D.isoformat(), NOW_MS),
            )
    fake = FakeGarmin()

    assert _run(cfg, fake, sleeps) == 0

    assert fake.calls == ["blocked_today"]
    assert sleeps == []
    assert _runs(cfg)[1] == (2, D.isoformat(), NOW_MS, NOW_MS, "success", "")


def test_history_start_after_today_means_no_plan(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D + timedelta(days=1))
    fake = FakeGarmin(responses=_full([D]))

    assert _run(cfg, fake, sleeps) == 0

    assert fake.calls == ["blocked_today"]
    assert _runs(cfg) == [(1, D.isoformat(), NOW_MS, NOW_MS, "success", "")]


# --- 시간대 --------------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("fail", "detail", "status"),
    [
        (False, "timezone_mismatch", "success"),
        (True, "transient=1 timezone_mismatch", "partial"),
    ],
    ids=["alone", "after-counts"],
)
def test_system_timezone_mismatch_is_noted(
    cfg: config.Config,
    sleeps: list[float],
    monkeypatch: pytest.MonkeyPatch,
    fail: bool,
    detail: str,
    status: str,
):
    monkeypatch.setenv("TZ", "UTC")
    _set_history_start(cfg, D)
    responses = _full([D])
    if fail:
        responses[("stress_data", D)] = errors.Transient("stress_data: HTTP 502")
    fake = FakeGarmin(responses=responses)

    _run(cfg, fake, sleeps)

    assert cfg.timezone == "Asia/Seoul"
    assert _runs(cfg)[0][4:] == (status, detail)


def test_unknown_system_timezone_is_not_a_mismatch(
    cfg: config.Config, sleeps: list[float], monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setattr(dates, "system_timezone", lambda: None)
    _set_history_start(cfg, D)

    _run(cfg, FakeGarmin(responses=_full([D])), sleeps)

    assert _runs(cfg)[0][4:] == ("success", "")


# --- 알림(Notifier) ------------------------------------------------------------------------

YESTERDAY = D - timedelta(days=1)


class RecordingNotifier:
    """`ports.Notifier` 대역. 받은 사건을 순서대로 남긴다."""

    def __init__(self) -> None:
        self.calls: list[tuple[date, errors.NotifyEvent, str]] = []

    def notify(self, local_date: date, event: errors.NotifyEvent, detail: str) -> None:
        self.calls.append((local_date, event, detail))


def _notifications(cfg: config.Config) -> list[tuple]:
    return _query(
        cfg,
        "SELECT local_date, event, detail, at FROM notification ORDER BY rowid",
    )


def _run_notifications(cfg: config.Config) -> list[tuple]:
    """실행 끝·`abandoned` 알림만. 합성 원문이 정규화에서 내는 `normalize_failed`는 뺀다."""
    return [row for row in _notifications(cfg) if row[1] != "normalize_failed"]


@pytest.mark.parametrize(
    ("open_error", "expected"),
    [
        (errors.AuthFailed("token_invalid"), [("auth_failed", "token_invalid")]),
        (errors.RateLimited("login 단계: HTTP 429"), [("rate_limited", "")]),
        (errors.Blocked403("login 단계: HTTP 403"), [("blocked_403", "")]),
        (errors.Transient("login 단계: HTTP 503"), [("error", "login_transient")]),
        (garmin.SessionLockTimeout("세션 락"), [("error", "session_lock_timeout")]),
        (garmin.BlockFileInvalid("차단 파일"), [("error", "block_file_invalid")]),
        (garmin.SessionBlocked("rate_limited"), []),
    ],
    ids=lambda value: type(value).__name__ if isinstance(value, Exception) else None,
)
def test_stopped_run_notifies_event_named_after_status(
    cfg: config.Config,
    sleeps: list[float],
    open_error: Exception,
    expected: list[tuple[str, str]],
):
    _set_history_start(cfg, D)

    assert _run(cfg, FakeGarmin(open_error=open_error), sleeps) == 0

    assert _run_notifications(cfg) == [
        (D.isoformat(), event, detail, NOW_MS) for event, detail in expected
    ]


@pytest.mark.parametrize(
    ("data_error", "event", "detail"),
    [
        (
            errors.AuthFailed("token_invalid"),
            "auth_failed",
            "token_invalid transient=1",
        ),
        (errors.RateLimited("hrv_data: HTTP 429"), "rate_limited", "transient=1"),
    ],
    ids=["auth-failed", "rate-limited"],
)
def test_data_stop_notifies_with_run_detail(
    cfg: config.Config,
    sleeps: list[float],
    data_error: Exception,
    event: str,
    detail: str,
):
    _set_history_start(cfg, D)
    responses = _full([D])
    responses[("sleep_data", D)] = errors.Transient("sleep_data: HTTP 503")
    responses[("hrv_data", D)] = data_error

    assert _run(cfg, FakeGarmin(responses=responses), sleeps) == 0

    assert _finished_run(cfg)[4:] == (event, detail)
    assert _run_notifications(cfg) == [(D.isoformat(), event, detail, NOW_MS)]


@pytest.mark.parametrize("force", [False, True], ids=["plain", "force"])
def test_invalid_block_file_at_entry_notifies_error(
    cfg: config.Config, sleeps: list[float], force: bool
):
    fake = FakeGarmin(block_error=garmin.BlockFileInvalid("차단 파일"))

    assert _run(cfg, fake, sleeps, force=force) == 0

    assert _run_notifications(cfg) == [
        (D.isoformat(), "error", "block_file_invalid", NOW_MS)
    ]


def _transient(*endpoints: str) -> dict[tuple[str, object], object]:
    responses = _full([D])
    for endpoint in endpoints:
        responses[(endpoint, D)] = errors.Transient(f"{endpoint}: HTTP 503")
    return responses


def test_transient_partial_two_days_in_a_row_notifies_repeated_partial(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    _set_history_start(cfg, D)
    _insert_run(cfg, YESTERDAY, "partial", "transient=1", started_at=NOW_MS - DAY_MS)
    fake = FakeGarmin(responses=_transient("sleep_data", "hrv_data"))

    assert _run(cfg, fake, sleeps) == 0

    assert _runs(cfg)[1][4:] == ("partial", "transient=2")
    assert _run_notifications(cfg) == [
        (D.isoformat(), "repeated_partial", "transient=2", NOW_MS)
    ]
    # 11:15 재시도로 회복해도 11:00에 남긴 알림은 그대로다.
    clock.moment = LATER

    assert _run(cfg, FakeGarmin(responses=_full([D])), sleeps) == 0

    assert _runs(cfg)[2][4:] == ("success", "")
    assert _run_notifications(cfg) == [
        (D.isoformat(), "repeated_partial", "transient=2", NOW_MS)
    ]


@pytest.mark.parametrize(
    ("yesterday", "today_responses", "today_end"),
    [
        (("partial", "transient=1"), _full([D]), ("success", "")),
        (("success", ""), _transient("sleep_data"), ("partial", "transient=1")),
        (
            ("partial", "rejected=1"),
            _transient("sleep_data"),
            ("partial", "transient=1"),
        ),
        (None, _transient("sleep_data"), ("partial", "transient=1")),
    ],
    ids=["only-yesterday", "only-today", "yesterday-rejected-only", "no-yesterday"],
)
def test_transient_partial_on_one_day_only_notifies_nothing(
    cfg: config.Config,
    sleeps: list[float],
    yesterday: tuple[str, str] | None,
    today_responses: dict[tuple[str, object], object],
    today_end: tuple[str, str],
):
    _set_history_start(cfg, D)
    if yesterday is not None:
        _insert_run(cfg, YESTERDAY, *yesterday, started_at=NOW_MS - DAY_MS)

    assert _run(cfg, FakeGarmin(responses=today_responses), sleeps) == 0

    assert _runs(cfg)[-1][4:] == today_end
    assert _run_notifications(cfg) == []


def test_rejected_only_partial_today_after_transient_yesterday_notifies_nothing(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    _insert_run(cfg, YESTERDAY, "partial", "transient=1", started_at=NOW_MS - DAY_MS)
    responses = _full([D])
    responses[("hrv_data", D)] = errors.Rejected("hrv_data: HTTP 400")

    assert _run(cfg, FakeGarmin(responses=responses), sleeps) == 0

    assert _runs(cfg)[1][4:] == ("partial", "rejected=1")
    assert _run_notifications(cfg) == []


def test_same_event_twice_a_day_keeps_first_row(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    _set_history_start(cfg, D)
    assert _run(cfg, FakeGarmin(open_error=errors.RateLimited("429")), sleeps) == 0
    clock.moment = LATER

    assert (
        _run(cfg, FakeGarmin(open_error=errors.RateLimited("429")), sleeps, force=True)
        == 0
    )

    assert [row[4] for row in _runs(cfg)] == ["rate_limited", "rate_limited"]
    assert _run_notifications(cfg) == [(D.isoformat(), "rate_limited", "", NOW_MS)]


@pytest.mark.parametrize("entry", ["skipped-blocked", "rejected-only", "nothing"])
def test_runs_without_an_event_leave_notifications_unchanged(
    cfg: config.Config, sleeps: list[float], clock: Clock, entry: str
):
    _set_history_start(cfg, D)
    # 이미 있는 알림 행은 그대로 남아야 한다.
    with store.write_session(cfg) as conn:
        ports.TableNotifier(conn).notify(YESTERDAY, errors.NotifyEvent.RATE_LIMITED, "")
    if entry == "skipped-blocked":
        fake = FakeGarmin(blocked=errors.RunStatus.RATE_LIMITED)
    elif entry == "rejected-only":
        responses = _full([D])
        responses[("hrv_data", D)] = errors.Rejected("hrv_data: HTTP 400")
        fake = FakeGarmin(responses=responses)
    else:
        assert _run(cfg, FakeGarmin(responses=_full([D])), sleeps) == 0
        clock.moment = LATER
        fake = FakeGarmin(responses=_full([D]))
    before = _run_notifications(cfg)
    assert before == [(YESTERDAY.isoformat(), "rate_limited", "", NOW_MS)]

    assert _run(cfg, fake, sleeps) == 0

    assert _run_notifications(cfg) == before


def test_injected_notifier_is_the_only_one_called(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    _insert_run(cfg, YESTERDAY, "running", started_at=NOW_MS - DAY_MS, finished_at=None)
    notifier = RecordingNotifier()

    assert (
        collect.collect(
            cfg,
            FakeGarmin(open_error=errors.RateLimited("429")),
            sleep=sleeps.append,
            notifier_factory=lambda conn: notifier,
        )
        == 0
    )

    # 정리한 어제 행이 먼저, 그다음 오늘 판정이다.
    assert notifier.calls == [
        (YESTERDAY, errors.NotifyEvent.ERROR, "abandoned"),
        (D, errors.NotifyEvent.RATE_LIMITED, ""),
    ]
    assert _run_notifications(cfg) == []


@pytest.mark.parametrize("entry", ["full", "blocked", "nothing"])
def test_abandoned_rows_notify_error_on_their_own_date(
    cfg: config.Config, sleeps: list[float], entry: str
):
    _set_history_start(cfg, D)
    two_days_ago = D - timedelta(days=2)
    _insert_run(
        cfg, two_days_ago, "running", started_at=NOW_MS - 2 * DAY_MS, finished_at=None
    )
    _insert_run(cfg, YESTERDAY, "running", started_at=NOW_MS - DAY_MS, finished_at=None)
    if entry == "nothing":
        _insert_run(cfg, D, "success")
    fake = FakeGarmin(
        blocked=errors.RunStatus.RATE_LIMITED if entry == "blocked" else None,
        responses=_full(_days_back(D, 3)),
    )

    assert _run(cfg, fake, sleeps) == 0

    assert _run_notifications(cfg) == [
        (two_days_ago.isoformat(), "error", "abandoned", NOW_MS),
        (YESTERDAY.isoformat(), "error", "abandoned", NOW_MS),
    ]


def test_write_lock_timeout_notifies_nothing(cfg: config.Config, sleeps: list[float]):
    _set_history_start(cfg, D)
    notifier = RecordingNotifier()
    fd = _hold_write_lock(cfg)
    try:
        assert (
            collect.collect(
                cfg,
                FakeGarmin(),
                sleep=sleeps.append,
                notifier_factory=lambda conn: notifier,
            )
            == 0
        )
        assert _run(cfg, FakeGarmin(), sleeps) == 0
    finally:
        os.close(fd)

    assert [row[4:] for row in _runs(cfg)] == [("error", "lock_timeout")] * 2
    assert notifier.calls == []
    assert _run_notifications(cfg) == []


# --- 마이그레이션 ---------------------------------------------------------------------------


def test_version_3_db_migrates_to_latest_and_keeps_rows(
    cfg: config.Config, sleeps: list[float]
):
    # 2.2까지의 DB: 0001~0003만 적용되고 각 테이블에 행이 있다.
    migrations = Path(store.__file__).parent / "migrations"
    cfg.data_dir.mkdir(parents=True)
    raw = sqlite3.connect(cfg.db_path)
    try:
        for name in (
            "0001_auth_event.sql",
            "0002_raw_response.sql",
            "0003_run_fetch_error.sql",
        ):
            raw.executescript((migrations / name).read_text(encoding="utf-8"))
        raw.execute("INSERT INTO auth_event VALUES (1, '2026-10-01', ?)", (NOW_MS,))
        raw.execute(
            "INSERT INTO raw_response VALUES"
            " ('day', '2026-01-01', 'sleep_data', '{}', ?, ?, '0.3.17')",
            (NOW_MS, NOW_MS),
        )
        raw.execute(
            "INSERT INTO run VALUES (1, '2026-10-01', ?, ?, 'success', '')",
            (NOW_MS, NOW_MS),
        )
        raw.execute(
            "INSERT INTO fetch_error VALUES"
            " (1, 1, 'day', '2026-01-01', 'hrv_data', 'transient', '2026-10-01', ?,"
            " 'transient')",
            (NOW_MS,),
        )
        raw.execute("PRAGMA user_version = 3")
        raw.commit()
    finally:
        raw.close()

    assert _run(cfg, FakeGarmin(responses=_full(_days_back(D, 31))), sleeps) == 0

    assert _query(cfg, "PRAGMA user_version") == [(schema_version.LATEST,)]
    assert _query(cfg, "SELECT * FROM auth_event") == [(1, "2026-10-01", NOW_MS)]
    assert _query(cfg, "SELECT * FROM raw_response WHERE key = '2026-01-01'") == [
        ("day", "2026-01-01", "sleep_data", "{}", NOW_MS, NOW_MS, "0.3.17")
    ]
    assert _runs(cfg)[0] == (1, "2026-10-01", NOW_MS, NOW_MS, "success", "")
    assert _query(cfg, "SELECT * FROM fetch_error") == [
        (
            1,
            1,
            "day",
            "2026-01-01",
            "hrv_data",
            "transient",
            "2026-10-01",
            NOW_MS,
            "transient",
        )
    ]
    assert _runs(cfg)[1][4] == "success"


def test_version_4_db_migrates_to_latest_and_keeps_rows(
    cfg: config.Config, sleeps: list[float]
):
    # 2.6까지의 DB: 0001~0004만 적용되고 각 테이블에 행이 있다.
    migrations = Path(store.__file__).parent / "migrations"
    cfg.data_dir.mkdir(parents=True)
    raw = sqlite3.connect(cfg.db_path)
    try:
        for name in (
            "0001_auth_event.sql",
            "0002_raw_response.sql",
            "0003_run_fetch_error.sql",
            "0004_meta.sql",
        ):
            raw.executescript((migrations / name).read_text(encoding="utf-8"))
        raw.execute("INSERT INTO auth_event VALUES (1, '2026-10-01', ?)", (NOW_MS,))
        raw.execute(
            "INSERT INTO run VALUES (1, '2026-10-01', ?, ?, 'rate_limited', '')",
            (NOW_MS, NOW_MS),
        )
        raw.execute("INSERT INTO meta VALUES ('history_start', ?)", (D.isoformat(),))
        raw.execute("PRAGMA user_version = 4")
        raw.commit()
    finally:
        raw.close()

    assert _run(cfg, FakeGarmin(responses=_full([D])), sleeps) == 0

    assert _query(cfg, "PRAGMA user_version") == [(schema_version.LATEST,)]
    assert _query(cfg, "SELECT * FROM auth_event") == [(1, "2026-10-01", NOW_MS)]
    assert _runs(cfg) == [
        (1, "2026-10-01", NOW_MS, NOW_MS, "rate_limited", ""),
        (2, D.isoformat(), NOW_MS, NOW_MS, "success", ""),
    ]
    assert _collect_meta(cfg) == [("history_start", D.isoformat())]
    # 이전 실행은 소급해 알리지 않는다.
    assert _run_notifications(cfg) == []


# --- cli -----------------------------------------------------------------------------------


def test_cli_collect_logs_plan_failures_and_result_without_payload(
    make_cfg: Callable[..., config.Config],
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    cfg = make_cfg(date_pause_seconds=0)
    responses = _full(_days_back(D, 31))
    responses[("sleep_data", D)] = errors.Transient(f"sleep_data: {MARKER}")
    fake = FakeGarmin(responses=responses)
    monkeypatch.setattr(garmin, "GarminAdapter", lambda _cfg: fake)

    assert cli.main(["collect", "--config", str(cfg.path)]) == 0

    out, err = capsys.readouterr()
    assert MARKER not in out + err
    assert len(_days(_day_calls(fake))) == 10
    log_path = cfg.data_dir / "logs" / "collect.log"
    assert log_path.is_file()
    bodies = [
        LOG_PREFIX.sub("", line, count=1)
        for line in log_path.read_text("utf-8").splitlines()
    ]
    text = "\n".join(bodies)
    assert "collect 계획: dates=10" in text
    assert (
        "항목 실패: scope=day key=2026-10-16 endpoint=sleep_data error=Transient"
        in text
    )
    assert "collect 끝: status=partial detail=transient=1" in text
    assert MARKER not in text
    assert _runs(cfg)[0][4:] == ("partial", "transient=1")


def test_cli_collect_log_failure_exits_1_without_collecting(
    make_cfg: Callable[..., config.Config],
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    # data_dir 자리가 파일이라 logs 폴더를 만들 수 없다.
    (tmp_path / "data").write_text("", encoding="utf-8")
    cfg = make_cfg()
    called: list[object] = []
    monkeypatch.setattr(collect, "collect", lambda *args, **kwargs: called.append(1))

    assert cli.main(["collect", "--config", str(cfg.path)]) == 1

    assert capsys.readouterr().err.startswith("collect 실패: 로그 파일을 열지 못했다")
    assert called == []


@pytest.mark.parametrize("problem", ["missing", "runtime"])
def test_cli_collect_config_error_exits_2(
    write_config: Callable[..., Path],
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
    problem: str,
):
    if problem == "missing":
        path = tmp_path / "nowhere.toml"
    else:
        path = write_config(environment="runtime")

    assert cli.main(["collect", "--config", str(path)]) == 2

    assert capsys.readouterr().err.startswith("설정 오류: ")
    assert not (tmp_path / "data").exists()


def test_cli_collect_help_offers_config_and_force(capsys: pytest.CaptureFixture[str]):
    with pytest.raises(SystemExit) as excinfo:
        cli.main(["collect", "--help"])

    assert excinfo.value.code == 0
    out = capsys.readouterr().out
    assert set(re.findall(r"--[a-z][a-z-]*", out)) == {"--help", "--config", "--force"}


@pytest.mark.parametrize(("argv", "force"), [([], False), (["--force"], True)])
def test_cli_collect_passes_force(
    make_cfg: Callable[..., config.Config],
    monkeypatch: pytest.MonkeyPatch,
    argv: list[str],
    force: bool,
):
    cfg = make_cfg()
    seen: list[dict[str, object]] = []

    def fake_collect(*args: object, **kwargs: object) -> int:
        seen.append(kwargs)
        return 0

    monkeypatch.setattr(collect, "collect", fake_collect)

    assert cli.main(["collect", "--config", str(cfg.path), *argv]) == 0

    assert seen == [
        {"force": force, "manual": force, "notifier_factory": ports.TableNotifier}
    ]


@pytest.mark.parametrize("stage", ["login", "data"])
def test_cli_collect_stop_logs_status_detail_and_error_name_only(
    make_cfg: Callable[..., config.Config],
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    stage: str,
):
    cfg = make_cfg(date_pause_seconds=0)
    secret = f"{MARKER} {SECRET_EMAIL} token=secret-token-4f9a"
    responses = _full(_days_back(D, 31))
    open_error = None
    if stage == "login":
        open_error = errors.Blocked403(secret)
    else:
        responses[("sleep_data", D)] = errors.Transient(secret)
        responses[("hrv_data", D)] = errors.Blocked403(secret)
    fake = FakeGarmin(open_error=open_error, responses=responses)
    monkeypatch.setattr(garmin, "GarminAdapter", lambda _cfg: fake)

    assert cli.main(["collect", "--config", str(cfg.path)]) == 0

    out, err = capsys.readouterr()
    text = (cfg.data_dir / "logs" / "collect.log").read_text("utf-8")
    for leaked in (MARKER, SECRET_EMAIL, "secret-token-4f9a"):
        assert leaked not in out + err + text
    detail = "" if stage == "login" else "transient=1"
    assert f"collect 중단: stage={stage} error=Blocked403" in text
    assert f"collect 끝: status=blocked_403 detail={detail}" in text
    assert _finished_run(cfg)[4:] == ("blocked_403", detail)


def test_cli_collect_write_lock_timeout_exit_codes(
    make_cfg: Callable[..., config.Config],
):
    cfg = make_cfg()
    fd = _hold_write_lock(cfg)
    try:
        # DB가 없으면 행을 남기지 못하고 1, 있으면 lock_timeout 행을 남기고 0이다.
        assert cli.main(["collect", "--config", str(cfg.path)]) == 1
        assert not cfg.db_path.exists()
        os.close(fd)
        _set_history_start(cfg, D)
        fd = _hold_write_lock(cfg)
        assert cli.main(["collect", "--config", str(cfg.path)]) == 0
    finally:
        os.close(fd)

    assert _finished_run(cfg)[4:] == ("error", "lock_timeout")
    text = (cfg.data_dir / "logs" / "collect.log").read_text("utf-8")
    assert "collect 중단: stage=write_lock error=LockTimeout" in text
    assert "collect 끝: status=error detail=lock_timeout" in text


# --- 수집 뒤 정규화·normalize_failed(3.6) ------------------------------------------------------

USER_SUMMARY = {
    "totalSteps": 1234,
    "totalDistanceMeters": 800,
    "activeKilocalories": 50,
    "moderateIntensityMinutes": 1,
    "vigorousIntensityMinutes": 0,
    "minHeartRate": 50,
    "maxHeartRate": 120,
}
BROKEN = {"note": MARKER}
"""정규화에서 `parse_error`가 나는 원문(등록된 endpoint 모두)."""


def _steps(cfg: config.Config) -> list[tuple]:
    return _query(cfg, "SELECT day_key, steps FROM daily_metric ORDER BY day_key")


def _upsert(
    cfg: config.Config, day: date, endpoint: str, payload: object, now_ms: int
) -> None:
    """죽은 실행이 남긴 것처럼 원문만 넣는다(정규화하지 않는다)."""
    with store.write_session(cfg) as conn:
        store.upsert_raw(
            conn,
            scope="day",
            key=day.isoformat(),
            endpoint=endpoint,
            payload=payload,
            library_version=garmin.LIBRARY_VERSION,
            now_ms=now_ms,
        )


def _earlier_failure(cfg: config.Config, clock: Clock) -> None:
    """하루 전 실행이 남긴 실패(`stress_data`, `normalized_at` < 이번 `started_at`)와 정규화 버전."""
    old = D - timedelta(days=20)
    clock.moment = NOW - timedelta(days=1)
    _upsert(cfg, old, "stress_data", BROKEN, NOW_MS - DAY_MS)
    with store.write_session(cfg) as conn:
        normalize.run(conn)
    clock.moment = NOW
    assert _query(cfg, "SELECT endpoint, ok, normalized_at FROM normalize_result") == [
        ("stress_data", 0, NOW_MS - DAY_MS)
    ]


def _spy_normalize(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
) -> list[tuple[sqlite3.Connection, dict[str, object], bool]]:
    calls: list[tuple[sqlite3.Connection, dict[str, object], bool]] = []
    original = normalize.run

    def spy(conn: sqlite3.Connection, **kwargs: object) -> normalize.Summary:
        calls.append((conn, kwargs, store.write_lock_held(cfg)))
        return original(conn, **kwargs)  # type: ignore[arg-type]

    monkeypatch.setattr(normalize, "run", spy)
    return calls


def test_collect_normalizes_with_the_same_connection_under_the_lock(
    cfg: config.Config, sleeps: list[float], monkeypatch: pytest.MonkeyPatch
):
    _set_history_start(cfg, D)
    received: list[sqlite3.Connection] = []
    original_run = collect.run

    def run_spy(conn: sqlite3.Connection, *args: object, **kwargs: object) -> None:
        received.append(conn)
        original_run(conn, *args, **kwargs)  # type: ignore[arg-type]

    monkeypatch.setattr(collect, "run", run_spy)
    calls = _spy_normalize(cfg, monkeypatch)
    fake = FakeGarmin(responses={("user_summary", D): USER_SUMMARY})

    assert _run(cfg, fake, sleeps) == 0

    assert len(received) == 1
    assert calls == [(received[0], {"timezone": cfg.timezone}, True)]
    assert _steps(cfg) == [(D.isoformat(), 1234)]
    assert _query(cfg, "SELECT value FROM meta WHERE key = 'normalize_version'") == [
        (str(normalize.NORMALIZE_VERSION),)
    ]
    assert _notifications(cfg) == []


def test_nothing_to_do_still_normalizes_leftover_raws(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    _insert_run(cfg, D, "success")
    _upsert(cfg, D, "user_summary", USER_SUMMARY, NOW_MS)
    fake = FakeGarmin(responses=_full([D]))

    assert _run(cfg, fake, sleeps) == 0

    assert fake.calls == ["blocked_today"]
    assert len(_runs(cfg)) == 1
    assert _steps(cfg) == [(D.isoformat(), 1234)]


def test_blocked_today_still_normalizes(cfg: config.Config, sleeps: list[float]):
    _set_history_start(cfg, D)
    _upsert(cfg, D, "user_summary", USER_SUMMARY, NOW_MS)
    fake = FakeGarmin(blocked=errors.RunStatus.RATE_LIMITED)

    assert _run(cfg, fake, sleeps) == 0

    assert fake.calls == ["blocked_today"]
    assert _runs(cfg) == [(1, D.isoformat(), NOW_MS, NOW_MS, "skipped_blocked", "")]
    assert _steps(cfg) == [(D.isoformat(), 1234)]


def test_write_lock_timeout_does_not_normalize(
    cfg: config.Config, sleeps: list[float], monkeypatch: pytest.MonkeyPatch
):
    _set_history_start(cfg, D)
    _upsert(cfg, D, "user_summary", BROKEN, NOW_MS)
    calls = _spy_normalize(cfg, monkeypatch)
    fd = _hold_write_lock(cfg)
    try:
        assert _run(cfg, FakeGarmin(), sleeps) == 0
    finally:
        os.close(fd)

    assert [row[4:] for row in _runs(cfg)] == [("error", "lock_timeout")]
    assert calls == []
    assert _query(cfg, "SELECT COUNT(*) FROM normalize_result") == [(0,)]
    assert _notifications(cfg) == []


def test_this_runs_normalize_failures_notify_once_with_endpoint_counts(
    cfg: config.Config,
    sleeps: list[float],
    clock: Clock,
    caplog: pytest.LogCaptureFixture,
):
    _set_history_start(cfg, D)
    _earlier_failure(cfg, clock)
    caplog.set_level(logging.WARNING, logger="garmin_pipeline.collect")
    fake = FakeGarmin(
        responses={
            ("user_summary", D): USER_SUMMARY,
            ("sleep_data", D): BROKEN,
            ("hrv_data", D): BROKEN,
        }
    )

    assert _run(cfg, fake, sleeps) == 0

    assert _runs(cfg)[-1][4:] == ("success", "")
    # 이전 실행의 stress_data 실패는 detail에 들지 않는다.
    assert _notifications(cfg) == [
        (D.isoformat(), "normalize_failed", "hrv_data=1 sleep_data=1", NOW_MS)
    ]
    assert _steps(cfg) == [(D.isoformat(), 1234)]
    assert "collect 정규화 실패: hrv_data=1 sleep_data=1" in [
        r.getMessage() for r in caplog.records if r.levelno == logging.WARNING
    ]


def test_normalize_failed_goes_through_the_injected_notifier(
    cfg: config.Config, sleeps: list[float]
):
    _set_history_start(cfg, D)
    notifier = RecordingNotifier()

    assert (
        collect.collect(
            cfg,
            FakeGarmin(responses={("hrv_data", D): BROKEN}),
            sleep=sleeps.append,
            notifier_factory=lambda conn: notifier,
        )
        == 0
    )

    assert notifier.calls[-1] == (D, errors.NotifyEvent.NORMALIZE_FAILED, "hrv_data=1")
    assert _query(
        cfg, "SELECT COUNT(*) FROM notification WHERE event = 'normalize_failed'"
    ) == [(0,)]


def test_earlier_normalize_failures_only_notify_nothing(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    _set_history_start(cfg, D)
    _earlier_failure(cfg, clock)
    fake = FakeGarmin(responses={("user_summary", D): USER_SUMMARY})

    assert _run(cfg, fake, sleeps) == 0

    assert _runs(cfg)[-1][4:] == ("success", "")
    assert _query(cfg, "SELECT endpoint, ok FROM normalize_result WHERE ok = 0") == [
        ("stress_data", 0)
    ]
    assert _notifications(cfg) == []


def test_version_rebuild_reports_failures_again(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    _set_history_start(cfg, D)
    _earlier_failure(cfg, clock)
    with store.write_session(cfg) as conn:
        conn.execute(
            "UPDATE meta SET value = '0' WHERE key = ?",
            (normalize.NORMALIZE_VERSION_KEY,),
        )
    _insert_run(cfg, D, "success")

    assert _run(cfg, FakeGarmin(), sleeps) == 0

    assert _notifications(cfg) == [
        (D.isoformat(), "normalize_failed", "stress_data=1", NOW_MS)
    ]
    assert _query(cfg, "SELECT value FROM meta WHERE key = 'normalize_version'") == [
        (str(normalize.NORMALIZE_VERSION),)
    ]


def test_normalize_failed_twice_a_day_keeps_first_row(
    cfg: config.Config, sleeps: list[float], clock: Clock
):
    _set_history_start(cfg, D)
    first = FakeGarmin(responses={("hrv_data", D): BROKEN})
    assert _run(cfg, first, sleeps) == 0
    clock.moment = LATER
    second = FakeGarmin(
        responses={("hrv_data", D): {"changed": MARKER}, ("sleep_data", D): BROKEN}
    )

    assert _run(cfg, second, sleeps, force=True) == 0

    assert _query(
        cfg, "SELECT endpoint FROM normalize_result WHERE ok = 0 ORDER BY endpoint"
    ) == [("hrv_data",), ("sleep_data",)]
    assert _notifications(cfg) == [
        (D.isoformat(), "normalize_failed", "hrv_data=1", NOW_MS)
    ]


def test_normalize_error_propagates_from_collect(
    cfg: config.Config, sleeps: list[float], monkeypatch: pytest.MonkeyPatch
):
    _set_history_start(cfg, D)

    def broken(conn: sqlite3.Connection, **kwargs: object) -> normalize.Summary:
        raise sqlite3.OperationalError("disk I/O error")

    monkeypatch.setattr(normalize, "run", broken)

    with pytest.raises(sqlite3.OperationalError):
        _run(cfg, FakeGarmin(), sleeps)

    # 수집은 끝났고 run 행도 끝난 상태다.
    assert _runs(cfg)[-1][4:] == ("success", "")
    assert _notifications(cfg) == []


def test_unexpected_collect_error_skips_normalize(
    cfg: config.Config, sleeps: list[float], monkeypatch: pytest.MonkeyPatch
):
    _set_history_start(cfg, D)
    calls = _spy_normalize(cfg, monkeypatch)

    with pytest.raises(RuntimeError):
        _run(cfg, FakeGarmin(open_error=RuntimeError("예상 밖")), sleeps)

    assert calls == []
    assert _runs(cfg)[-1][4] == "running"


def test_notification_budget_shared_by_abandoned_rows_and_end_event(make_cfg):
    cfg = make_cfg(lock_wait_seconds=6)
    calls = []

    class Sender:
        def send(self, day, event, detail, *, timeout_seconds):
            calls.append(timeout_seconds)
            assert store.write_lock_held(cfg)

    with store.write_session(cfg) as conn:
        for offset in (1, 2):
            conn.execute(
                "INSERT INTO run(local_date,started_at,status) VALUES (?,?,'running')",
                ((D - timedelta(days=offset)).isoformat(), NOW_MS - offset),
            )
    fake = FakeGarmin(
        open_error=errors.AuthFailed(errors.AuthFailedReason.TOKEN_INVALID)
    )
    assert (
        collect.collect(
            cfg,
            fake,
            notifier_factory=lambda conn: ports.TelegramNotifier(
                conn, Sender(), budget_seconds=cfg.lock_wait_seconds / 2
            ),
        )
        == 0
    )
    assert calls == [3]
    with store.read_connection(cfg) as conn:
        assert conn.execute(
            "SELECT event,ok,reason FROM delivery ORDER BY id"
        ).fetchall() == [
            ("error", 1, None),
            ("error", 0, "network"),
            ("auth_failed", 0, "network"),
        ]


@pytest.mark.parametrize("endpoint", ["daily_weigh_ins", "lifestyle_logging_data"])
@pytest.mark.parametrize("outcome", ["data", "null", "403"])
def test_weight_lifestyle_first_run_limit_and_raw_preservation(
    cfg, sleeps, endpoint, outcome
):
    days = _days_back(D, 5)
    _set_history_start(cfg, days[-1])
    responses = _full(days)
    for day in days:
        if outcome == "null":
            responses[(endpoint, day)] = None
        elif outcome == "403":
            responses[(endpoint, day)] = errors.Rejected(f"{endpoint}: HTTP 403")
    fake = FakeGarmin(responses=responses)
    assert _run(cfg, fake, sleeps) == 0
    assert [(name, day) for name, day in _day_calls(fake) if name == endpoint] == [
        (endpoint, day) for day in days[:3]
    ]
    rows = _query(
        cfg,
        "SELECT key, raw FROM raw_response WHERE endpoint=? ORDER BY key DESC",
        (endpoint,),
    )
    if outcome == "403":
        assert rows == []
        assert len(_fetch_errors(cfg)) == 3
    else:
        assert rows == [
            (
                str(day),
                "null"
                if outcome == "null"
                else json.dumps(responses[(endpoint, day)], ensure_ascii=True),
            )
            for day in days[:3]
        ]


@pytest.mark.parametrize(
    "endpoint,path",
    [
        ("daily_weigh_ins", "/weight-service/weight/dayview/"),
        ("lifestyle_logging_data", "/lifestylelogging-service/dailyLog/"),
    ],
)
@pytest.mark.parametrize("status", [403, 429])
def test_weight_lifestyle_first_call_http_protection(
    cfg, sleeps, monkeypatch, endpoint, path, status
):
    days = _days_back(D, 5)
    _set_history_start(cfg, days[-1])
    cfg.tokenstore.mkdir()
    transport = GarminTransport()
    for day in days:
        transport.reply(path + str(day), http_error(status))
    _use_client(monkeypatch, transport_client(transport))
    assert collect.collect(cfg, _adapter(cfg, sleeps), sleep=sleeps.append) == 0
    calls = [url for url, _ in transport.calls if url.startswith(path)]
    if status == 403:
        assert calls == [path + str(day) for day in days[:3]]
        assert _block_file(cfg) is None
        assert len(_fetch_errors(cfg)) == 3
    else:
        assert calls == [path + str(D)]
        assert _block_file(cfg) == _block("rate_limited")
