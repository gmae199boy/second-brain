// 인수 테스트용 합성 인바디 결과 이미지(inbody-synthetic.png)를 만든다(4.7, A2 이미지 판독 확인).
// 실제 측정이 아니다. 값은 같은 폴더 inbody-synthetic.md와 tests/test_acceptance_report.py의 기대값과 같다.
//
// 실행(저장소 루트에서): swift tests/fixtures/inbody/make_inbody_png.swift tests/fixtures/inbody/inbody-synthetic.png
import AppKit

let lines: [(String, CGFloat)] = [
    ("InBody 체성분 결과", 56),
    ("측정 일시: 2026-10-16 08:12", 44),
    ("", 24),
    ("체중  72.4 kg", 48),
    ("골격근량  33.1 kg", 48),
    ("체지방량  13.2 kg", 48),
    ("체지방률  18.2 %", 48),
    ("BMI  23.4 kg/m²", 48),
    ("기초대사량  1642 kcal", 48),
    ("내장지방 레벨  6", 48),
    ("인바디 점수  81 점", 48),
]

guard CommandLine.arguments.count == 2 else {
    FileHandle.standardError.write("usage: swift make_inbody_png.swift <출력.png>\n".data(using: .utf8)!)
    exit(2)
}
let output = URL(fileURLWithPath: CommandLine.arguments[1])

let width = 900
let height = 1100
guard let rep = NSBitmapImageRep(
    bitmapDataPlanes: nil, pixelsWide: width, pixelsHigh: height,
    bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false,
    colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0
) else {
    FileHandle.standardError.write("비트맵을 만들지 못했다\n".data(using: .utf8)!)
    exit(1)
}

NSGraphicsContext.saveGraphicsState()
NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: rep)
NSColor.white.setFill()
NSRect(x: 0, y: 0, width: width, height: height).fill()

let font = NSFont(name: "Apple SD Gothic Neo", size: 48) ?? NSFont.systemFont(ofSize: 48)
var y = CGFloat(height) - 80
for (text, size) in lines {
    let attributes: [NSAttributedString.Key: Any] = [
        .font: NSFont(descriptor: font.fontDescriptor, size: size) ?? font,
        .foregroundColor: NSColor.black,
    ]
    NSAttributedString(string: text, attributes: attributes).draw(at: NSPoint(x: 60, y: y))
    y -= size * 1.7
}
NSGraphicsContext.restoreGraphicsState()

guard let png = rep.representation(using: .png, properties: [:]) else {
    FileHandle.standardError.write("PNG로 인코딩하지 못했다\n".data(using: .utf8)!)
    exit(1)
}
try png.write(to: output)
