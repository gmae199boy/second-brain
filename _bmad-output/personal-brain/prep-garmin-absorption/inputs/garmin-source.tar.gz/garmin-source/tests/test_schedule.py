"""`schedule`: collect·report LaunchAgent plist, 거부 사유, 원자적 쓰기, launchctl 순서(2.8·4.6).

pytest 안에서는 `launchctl`과 codex를 실행하지 않는다. `subprocess.run`은 언제나 가짜로 바꾸고, `HOME`은
`tmp_path`로 바꿔 실제 `~/Library/LaunchAgents`에 닿지 않게 한다. codex 검색을 결정적으로 하려고
`PATH` 앞에 tmp `bin/codex`(실행되지 않는 셸 스크립트)를 둔다.
"""

import dataclasses
import os
import plistlib
import stat
import subprocess
from collections.abc import Callable
from pathlib import Path

import pytest

from garmin_pipeline import cli, config, schedule

LABEL = "local.garmin-pipeline.collect"
REPORT_LABEL = "local.garmin-pipeline.report"
BASE_PATH = "/usr/bin:/bin:/usr/sbin:/sbin"


@pytest.fixture(autouse=True)
def _home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """`HOME`을 tmp로 바꾸고 `subprocess.run`을 "호출되면 실패"로 바꾼다."""
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))

    def refuse(*args: object, **kwargs: object) -> None:
        pytest.fail(f"테스트에서 subprocess.run을 불렀다: {args!r}")

    monkeypatch.setattr(subprocess, "run", refuse)
    return home


@pytest.fixture(autouse=True)
def codex(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """`PATH` 맨 앞의 tmp `bin/codex`(0755). `find_codex()`는 언제나 이것을 찾는다."""
    binary = tmp_path / "bin" / "codex"
    binary.parent.mkdir()
    binary.write_text("#!/bin/sh\nexit 99\n", encoding="utf-8")
    binary.chmod(0o755)
    monkeypatch.setenv("PATH", f"{binary.parent}{os.pathsep}{os.environ['PATH']}")
    return binary


def _without_codex(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """`PATH`를 빈 tmp 폴더 하나로 바꿔 codex를 찾지 못하게 한다."""
    empty = tmp_path / "empty-path"
    empty.mkdir()
    monkeypatch.setenv("PATH", str(empty))


@pytest.fixture
def make_runtime_cfg(
    write_config: Callable[..., Path],
) -> Callable[..., config.Config]:
    """dev config를 읽은 뒤 `environment`만 `"runtime"`으로 바꾼 `Config`(pytest 가드를 피한다)."""

    def make(**overrides: object) -> config.Config:
        environment = overrides.pop("environment", "runtime")
        cfg = config.load(write_config(**overrides))
        return dataclasses.replace(cfg, environment=environment)

    return make


def _snapshot_executable(cfg: config.Config) -> Path:
    binary = cfg.path.parent / ".venv" / "bin" / "garmin-pipeline"
    binary.parent.mkdir(parents=True, exist_ok=True)
    binary.write_text("#!/bin/sh\n", encoding="utf-8")
    binary.chmod(0o755)
    return binary


def _refusals(cfg: config.Config, **overrides: object) -> list[str]:
    kwargs: dict[str, object] = {
        "system_zone": cfg.timezone,
        "in_pytest": False,
        "codex": Path("/x/bin/codex"),
    }
    kwargs |= overrides
    return schedule.refusals(cfg, **kwargs)  # type: ignore[arg-type]


# --- plist ---------------------------------------------------------------------------------


def test_collect_plist_has_absolute_paths_and_config_times(
    make_runtime_cfg: Callable[..., config.Config], tmp_path: Path
):
    cfg = make_runtime_cfg()

    agent = plistlib.loads(schedule.collect_plist(cfg))

    assert agent == {
        "Label": LABEL,
        "ProgramArguments": [
            str(tmp_path / ".venv" / "bin" / "garmin-pipeline"),
            "collect",
            "--config",
            str(tmp_path / "config.toml"),
        ],
        "WorkingDirectory": str(tmp_path),
        "StartCalendarInterval": [
            {"Hour": 11, "Minute": 0},
            {"Hour": 11, "Minute": 15},
        ],
        "StandardOutPath": str(tmp_path / "data" / "logs" / "launchd-collect.out.log"),
        "StandardErrorPath": str(
            tmp_path / "data" / "logs" / "launchd-collect.err.log"
        ),
    }
    paths = [
        *agent["ProgramArguments"][:1],
        agent["ProgramArguments"][3],
        agent["WorkingDirectory"],
        agent["StandardOutPath"],
        agent["StandardErrorPath"],
    ]
    assert all(Path(path).is_absolute() for path in paths)


def test_collect_plist_uses_config_times_not_system_clock(
    make_runtime_cfg: Callable[..., config.Config],
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    cfg = make_runtime_cfg(
        collect_time="06:05",
        retry_time="06:20",
        report_time="07:00",
        data_dir=str(tmp_path / "elsewhere"),
    )
    monkeypatch.setenv("TZ", "America/Los_Angeles")
    first = schedule.collect_plist(cfg)
    monkeypatch.setenv("TZ", "UTC")

    agent = plistlib.loads(first)
    assert agent["StartCalendarInterval"] == [
        {"Hour": 6, "Minute": 5},
        {"Hour": 6, "Minute": 20},
    ]
    assert agent["StandardOutPath"] == str(
        tmp_path / "elsewhere" / "logs" / "launchd-collect.out.log"
    )
    assert schedule.collect_plist(cfg) == first


def test_write_plist_is_idempotent_and_0644(
    make_runtime_cfg: Callable[..., config.Config], tmp_path: Path
):
    cfg = make_runtime_cfg()
    agents = tmp_path / "agents"
    target = schedule.plist_path(agents, LABEL)

    schedule.write_plist(target, schedule.collect_plist(cfg))
    first = target.read_bytes()
    schedule.write_plist(target, schedule.collect_plist(cfg))

    assert target.name == f"{LABEL}.plist"
    assert sorted(path.name for path in agents.iterdir()) == [target.name]
    assert target.read_bytes() == first
    assert stat.S_IMODE(target.stat().st_mode) == 0o644


def test_write_plist_replaces_other_content(tmp_path: Path):
    target = tmp_path / "agents" / f"{LABEL}.plist"
    target.parent.mkdir()
    target.write_bytes(b"old")

    schedule.write_plist(target, b"new")

    assert target.read_bytes() == b"new"
    assert [path.name for path in target.parent.iterdir()] == [target.name]


@pytest.mark.parametrize("label", [LABEL, REPORT_LABEL])
def test_launchctl_argv_uses_current_api(label: str):
    agents = Path("/Users/me/Library/LaunchAgents")
    plist = schedule.plist_path(agents, label)

    assert plist == agents / f"{label}.plist"
    assert schedule.launchctl_print(501, label) == [
        "launchctl",
        "print",
        f"gui/501/{label}",
    ]
    assert schedule.launchctl_bootout(501, label) == [
        "launchctl",
        "bootout",
        f"gui/501/{label}",
    ]
    assert schedule.launchctl_bootstrap(501, plist) == [
        "launchctl",
        "bootstrap",
        "gui/501",
        str(plist),
    ]


# --- report plist와 codex ------------------------------------------------------------------


def test_report_plist_has_absolute_paths_report_time_and_codex_path(
    make_runtime_cfg: Callable[..., config.Config], tmp_path: Path
):
    cfg = make_runtime_cfg()

    data = schedule.report_plist(cfg, Path("/x/bin/codex"))
    agent = plistlib.loads(data)

    assert agent == {
        "Label": REPORT_LABEL,
        "ProgramArguments": [
            str(tmp_path / ".venv" / "bin" / "garmin-pipeline"),
            "report",
            "--config",
            str(tmp_path / "config.toml"),
        ],
        "WorkingDirectory": str(tmp_path),
        "StartCalendarInterval": [{"Hour": 11, "Minute": 30}],
        "StandardOutPath": str(tmp_path / "data" / "logs" / "launchd-report.out.log"),
        "StandardErrorPath": str(tmp_path / "data" / "logs" / "launchd-report.err.log"),
        "EnvironmentVariables": {"PATH": f"/x/bin:{BASE_PATH}"},
    }
    paths = [
        agent["ProgramArguments"][0],
        agent["ProgramArguments"][3],
        agent["WorkingDirectory"],
        agent["StandardOutPath"],
        agent["StandardErrorPath"],
        *agent["EnvironmentVariables"]["PATH"].split(":"),
    ]
    assert all(Path(path).is_absolute() for path in paths)
    assert schedule.report_plist(cfg, Path("/x/bin/codex")) == data


def test_report_plist_uses_config_report_time_not_system_clock(
    make_runtime_cfg: Callable[..., config.Config], monkeypatch: pytest.MonkeyPatch
):
    cfg = make_runtime_cfg(
        collect_time="06:05", retry_time="06:20", report_time="07:45"
    )
    monkeypatch.setenv("TZ", "America/Los_Angeles")
    first = schedule.report_plist(cfg, Path("/x/bin/codex"))
    monkeypatch.setenv("TZ", "UTC")

    agent = plistlib.loads(first)
    assert agent["StartCalendarInterval"] == [{"Hour": 7, "Minute": 45}]
    assert schedule.report_plist(cfg, Path("/x/bin/codex")) == first


@pytest.mark.parametrize("folder", ["/usr/bin", "/bin", "/usr/sbin", "/sbin"])
def test_launchd_path_does_not_repeat_base_folder(folder: str):
    assert schedule.launchd_path(Path(folder) / "codex") == BASE_PATH


def test_report_plist_with_codex_in_base_folder_has_no_duplicate(
    make_runtime_cfg: Callable[..., config.Config],
):
    cfg = make_runtime_cfg()

    agent = plistlib.loads(schedule.report_plist(cfg, Path("/usr/bin/codex")))

    assert agent["EnvironmentVariables"] == {"PATH": BASE_PATH}


def test_collect_plist_has_no_environment_variables(
    make_runtime_cfg: Callable[..., config.Config],
):
    assert "EnvironmentVariables" not in plistlib.loads(
        schedule.collect_plist(make_runtime_cfg())
    )


def test_find_codex_returns_absolute_path_on_path(codex: Path):
    assert schedule.find_codex() == codex
    assert schedule.find_codex().is_absolute()  # type: ignore[union-attr]


def test_find_codex_keeps_symlink(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, codex: Path
):
    # Homebrew처럼 PATH 폴더의 codex가 버전 폴더의 실제 파일을 가리키는 심링크다.
    link_dir = tmp_path / "brew" / "bin"
    link_dir.mkdir(parents=True)
    (link_dir / "codex").symlink_to(codex)
    monkeypatch.setenv("PATH", str(link_dir))

    assert schedule.find_codex() == link_dir / "codex"


def test_find_codex_makes_relative_path_entry_absolute(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    # autouse `codex`는 tmp_path/bin/codex다. PATH에 상대 폴더만 둔다.
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("PATH", "bin")

    found = schedule.find_codex()

    assert found == tmp_path / "bin" / "codex"
    assert found is not None and found.is_absolute()


def test_find_codex_returns_none_when_missing(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    _without_codex(tmp_path, monkeypatch)

    assert schedule.find_codex() is None


# --- 거부 사유 -----------------------------------------------------------------------------


def test_no_refusal_when_everything_is_ready(
    make_runtime_cfg: Callable[..., config.Config],
):
    cfg = make_runtime_cfg()
    _snapshot_executable(cfg)

    assert _refusals(cfg) == []


def test_refuses_inside_pytest(make_runtime_cfg: Callable[..., config.Config]):
    cfg = make_runtime_cfg()
    _snapshot_executable(cfg)

    (reason,) = _refusals(cfg, in_pytest=True)
    assert "pytest" in reason


def test_refuses_dev_environment(make_runtime_cfg: Callable[..., config.Config]):
    cfg = make_runtime_cfg(environment="dev")
    _snapshot_executable(cfg)

    (reason,) = _refusals(cfg)
    assert "`environment`" in reason
    assert "'dev'" in reason


@pytest.mark.parametrize(
    ("collect_time", "retry_time", "report_time"),
    [
        ("11:15", "11:15", "11:30"),
        ("11:20", "11:15", "11:30"),
        ("11:00", "11:30", "11:30"),
        ("11:00", "11:40", "11:30"),
    ],
    ids=[
        "retry-equals-collect",
        "retry-before-collect",
        "report-equals-retry",
        "report-before-retry",
    ],
)
def test_refuses_time_order(
    make_runtime_cfg: Callable[..., config.Config],
    collect_time: str,
    retry_time: str,
    report_time: str,
):
    cfg = make_runtime_cfg(
        collect_time=collect_time, retry_time=retry_time, report_time=report_time
    )
    _snapshot_executable(cfg)

    (reason,) = _refusals(cfg)
    assert "`collect_time` < `retry_time` < `report_time`" in reason
    assert f"{collect_time}·{retry_time}·{report_time}" in reason


@pytest.mark.parametrize(
    ("system_zone", "expected"),
    [("UTC", "시스템 시간대(UTC)"), (None, "시스템 시간대를 알 수 없다")],
    ids=["mismatch", "unknown"],
)
def test_refuses_system_timezone(
    make_runtime_cfg: Callable[..., config.Config],
    system_zone: str | None,
    expected: str,
):
    cfg = make_runtime_cfg(timezone="Asia/Seoul")
    _snapshot_executable(cfg)

    (reason,) = _refusals(cfg, system_zone=system_zone)
    assert expected in reason
    assert "Asia/Seoul" in reason


@pytest.mark.parametrize("state", ["missing", "not-executable"])
def test_refuses_missing_snapshot_executable(
    make_runtime_cfg: Callable[..., config.Config], tmp_path: Path, state: str
):
    cfg = make_runtime_cfg()
    if state == "not-executable":
        _snapshot_executable(cfg).chmod(0o644)

    (reason,) = _refusals(cfg)
    assert str(tmp_path / ".venv" / "bin" / "garmin-pipeline") in reason


def test_refuses_missing_codex(make_runtime_cfg: Callable[..., config.Config]):
    cfg = make_runtime_cfg()
    _snapshot_executable(cfg)

    (reason,) = _refusals(cfg, codex=None)
    assert "`codex`를 PATH에서 찾지 못했다" in reason
    assert "report 예약" in reason


def test_reports_every_refusal(make_runtime_cfg: Callable[..., config.Config]):
    cfg = make_runtime_cfg(environment="dev", retry_time="10:00")

    reasons = _refusals(cfg, in_pytest=True, system_zone="UTC", codex=None)

    assert len(reasons) == 6
    assert "pytest" in reasons[0]
    assert "`environment`" in reasons[1]
    assert "`collect_time` < `retry_time` < `report_time`" in reasons[2]
    assert "시스템 시간대(UTC)" in reasons[3]
    assert ".venv/bin/garmin-pipeline" in reasons[4]
    assert "`codex`를 PATH에서 찾지 못했다" in reasons[5]


# --- install -------------------------------------------------------------------------------


def test_install_refuses_inside_pytest_without_side_effects(
    make_runtime_cfg: Callable[..., config.Config],
    _home: Path,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    cfg = make_runtime_cfg()
    _snapshot_executable(cfg)
    monkeypatch.setenv("TZ", cfg.timezone)

    assert schedule.install(cfg) == 1

    err = capsys.readouterr().err.splitlines()
    assert len(err) == 1
    assert err[0].startswith("install-schedule 거부: pytest")
    assert not (_home / "Library").exists()
    assert not (tmp_path / "data").exists()


def test_cli_install_schedule_refuses_dev_config_inside_pytest(
    write_config: Callable[..., Path],
    _home: Path,
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
):
    path = write_config(retry_time="10:00")

    assert cli.main(["install-schedule", "--config", str(path)]) == 1

    err = capsys.readouterr().err.splitlines()
    assert all(line.startswith("install-schedule 거부: ") for line in err)
    assert "pytest" in err[0]
    assert any("`environment`" in line for line in err)
    assert any("`retry_time`" in line for line in err)
    assert any(".venv/bin/garmin-pipeline" in line for line in err)
    assert not (_home / "Library").exists()
    assert not (tmp_path / "data").exists()


def test_cli_install_schedule_config_error_exits_2(
    tmp_path: Path, capsys: pytest.CaptureFixture[str]
):
    assert cli.main(["install-schedule", "--config", str(tmp_path / "no.toml")]) == 2

    assert capsys.readouterr().err.startswith("설정 오류: ")


def test_cli_install_schedule_help(capsys: pytest.CaptureFixture[str]):
    with pytest.raises(SystemExit) as exit_info:
        cli.main(["install-schedule", "--help"])

    assert exit_info.value.code == 0
    assert "--config PATH" in capsys.readouterr().out


class _FakeLaunchctl:
    """`subprocess.run` 자리. 실제 `launchctl`은 실행하지 않고 argv만 기록한다.

    `fail`은 실패할 동사(`bootout`·`bootstrap`), `fail_label`은 그 동사가 실패할 label이다.
    """

    def __init__(
        self, *, loaded: bool, fail: str | None = None, fail_label: str = LABEL
    ) -> None:
        self.loaded = loaded
        self.fail = fail
        self.fail_label = fail_label
        self.calls: list[list[str]] = []

    def __call__(
        self, argv: list[str], **kwargs: object
    ) -> subprocess.CompletedProcess[str]:
        assert kwargs == {"capture_output": True, "text": True, "check": False}
        assert argv[0] == "launchctl", argv
        self.calls.append(list(argv))
        verb = argv[1]
        label = Path(argv[3]).stem if verb == "bootstrap" else argv[2].split("/")[-1]
        if verb == "print":
            code = 0 if self.loaded else 113
        else:
            code = 5 if (verb, label) == (self.fail, self.fail_label) else 0
        stderr = f"{verb} failed: boom" if code == 5 else ""
        return subprocess.CompletedProcess(argv, code, stdout="", stderr=stderr)


@pytest.fixture
def ready(
    make_runtime_cfg: Callable[..., config.Config], monkeypatch: pytest.MonkeyPatch
) -> config.Config:
    """거부 사유가 없는 상태: runtime config, 스냅샷 실행 파일, 같은 시스템 시간대, pytest 가드 끔.

    pytest 가드를 끄는 것은 순서 검증용이다. `subprocess.run`은 가짜라 `launchctl`은 실행되지 않는다.
    """
    cfg = make_runtime_cfg()
    _snapshot_executable(cfg)
    monkeypatch.setenv("TZ", cfg.timezone)
    monkeypatch.setattr(config, "under_pytest", lambda: False)
    return cfg


@pytest.mark.parametrize("loaded", [False, True], ids=["first", "replace"])
def test_install_writes_both_plists_and_bootstraps_in_order(
    ready: config.Config,
    _home: Path,
    tmp_path: Path,
    codex: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    loaded: bool,
):
    fake = _FakeLaunchctl(loaded=loaded)
    monkeypatch.setattr(subprocess, "run", fake)
    uid = os.getuid()
    agents = _home / "Library" / "LaunchAgents"
    collect_target = agents / f"{LABEL}.plist"
    report_target = agents / f"{REPORT_LABEL}.plist"

    assert schedule.install(ready) == 0

    expected: list[list[str]] = []
    for label, target in ((LABEL, collect_target), (REPORT_LABEL, report_target)):
        expected.append(["launchctl", "print", f"gui/{uid}/{label}"])
        if loaded:
            expected.append(["launchctl", "bootout", f"gui/{uid}/{label}"])
        expected.append(["launchctl", "bootstrap", f"gui/{uid}", str(target)])
    assert fake.calls == expected
    assert collect_target.read_bytes() == schedule.collect_plist(ready)
    assert report_target.read_bytes() == schedule.report_plist(ready, codex)
    for target in (collect_target, report_target):
        assert stat.S_IMODE(target.stat().st_mode) == 0o644
    report_env = plistlib.loads(report_target.read_bytes())["EnvironmentVariables"]
    assert report_env == {"PATH": f"{codex.parent}:{BASE_PATH}"}
    logs = tmp_path / "data" / "logs"
    assert stat.S_IMODE(logs.stat().st_mode) == 0o700
    captured = capsys.readouterr()
    assert captured.err == ""
    assert captured.out.splitlines() == [
        f"예약을 설치했다: {LABEL} ({collect_target})",
        f"예약을 설치했다: {REPORT_LABEL} ({report_target})",
    ]


def test_install_twice_replaces_with_same_bytes(
    ready: config.Config, _home: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setattr(subprocess, "run", _FakeLaunchctl(loaded=False))
    assert schedule.install(ready) == 0
    agents = _home / "Library" / "LaunchAgents"
    names = [f"{LABEL}.plist", f"{REPORT_LABEL}.plist"]
    first = {name: (agents / name).read_bytes() for name in names}
    fake = _FakeLaunchctl(loaded=True)
    monkeypatch.setattr(subprocess, "run", fake)

    assert schedule.install(ready) == 0

    assert [call[1] for call in fake.calls] == ["print", "bootout", "bootstrap"] * 2
    assert sorted(path.name for path in agents.iterdir()) == names
    assert {name: (agents / name).read_bytes() for name in names} == first


@pytest.mark.parametrize("fail", ["bootout", "bootstrap"])
@pytest.mark.parametrize(
    ("fail_label", "name"), [(LABEL, "collect"), (REPORT_LABEL, "report")]
)
def test_install_launchctl_failure_exits_1_with_reason(
    ready: config.Config,
    _home: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    fail: str,
    fail_label: str,
    name: str,
):
    fake = _FakeLaunchctl(loaded=True, fail=fail, fail_label=fail_label)
    monkeypatch.setattr(subprocess, "run", fake)

    assert schedule.install(ready) == 1

    captured = capsys.readouterr()
    err = captured.err
    assert err.startswith("install-schedule 실패: `launchctl " + fail)
    assert f"{fail} failed: boom" in err
    assert f"{name} 예약이 내려가 있을 수 있다" in err
    skipped = "report 예약은 다시 로드하지 않았다"
    assert (skipped in err) == (name == "collect")
    assert "scripts/deploy.sh를 다시 실행한다" in err
    assert captured.out == ""
    assert fake.calls[-1][1] == fail
    # 실패한 label 뒤의 단계는 하지 않는다(collect가 실패하면 report는 건드리지 않는다).
    touched = {
        Path(call[3]).stem if call[1] == "bootstrap" else call[2].split("/")[-1]
        for call in fake.calls
    }
    assert touched == ({LABEL} if name == "collect" else {LABEL, REPORT_LABEL})
    # 두 plist는 launchctl 단계 전에 모두 쓴다.
    agents = _home / "Library" / "LaunchAgents"
    assert (agents / f"{LABEL}.plist").is_file()
    assert (agents / f"{REPORT_LABEL}.plist").is_file()


def test_install_report_bootstrap_failure_on_first_install(
    ready: config.Config,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    fake = _FakeLaunchctl(loaded=False, fail="bootstrap", fail_label=REPORT_LABEL)
    monkeypatch.setattr(subprocess, "run", fake)

    assert schedule.install(ready) == 1

    assert [call[1] for call in fake.calls] == ["print", "bootstrap"] * 2
    assert "report 예약이 내려가 있을 수 있다" in capsys.readouterr().err


def test_install_refuses_missing_codex_without_side_effects(
    ready: config.Config,
    _home: Path,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    fake = _FakeLaunchctl(loaded=False)
    monkeypatch.setattr(subprocess, "run", fake)
    _without_codex(tmp_path, monkeypatch)

    assert schedule.install(ready) == 1

    err = capsys.readouterr().err.splitlines()
    assert len(err) == 1
    assert err[0].startswith("install-schedule 거부: `codex`를 PATH에서 찾지 못했다")
    assert not (_home / "Library").exists()
    assert not (tmp_path / "data").exists()
    assert fake.calls == []


def test_install_searches_codex_once(
    ready: config.Config, codex: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setattr(subprocess, "run", _FakeLaunchctl(loaded=False))
    found: list[Path | None] = []
    original = schedule.find_codex

    def counting() -> Path | None:
        found.append(original())
        return found[-1]

    monkeypatch.setattr(schedule, "find_codex", counting)

    assert schedule.install(ready) == 0

    assert found == [codex]


def test_install_without_launchctl_exits_1(
    ready: config.Config,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    def missing(*args: object, **kwargs: object) -> None:
        raise FileNotFoundError(2, "No such file or directory", "launchctl")

    monkeypatch.setattr(subprocess, "run", missing)

    assert schedule.install(ready) == 1

    err = capsys.readouterr().err
    assert "launchctl을 실행하지 못했다" in err
    assert "collect 예약이 내려가 있을 수 있다" in err
    assert "report 예약은 다시 로드하지 않았다" in err


def test_install_without_launchctl_at_report_stage_names_report(
    ready: config.Config,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    # collect는 로드했고 report 단계에서 launchctl을 실행하지 못하면 report 예약만 말한다.
    fake = _FakeLaunchctl(loaded=False)

    def missing_for_report(
        argv: list[str], **kwargs: object
    ) -> subprocess.CompletedProcess[str]:
        if REPORT_LABEL in " ".join(argv):
            raise FileNotFoundError(2, "No such file or directory", "launchctl")
        return fake(argv, **kwargs)

    monkeypatch.setattr(subprocess, "run", missing_for_report)

    assert schedule.install(ready) == 1

    err = capsys.readouterr().err
    assert "launchctl을 실행하지 못했다" in err
    assert "report 예약이 내려가 있을 수 있다" in err
    assert "collect 예약이 내려가 있을 수 있다" not in err
    assert "다시 로드하지 않았다" not in err
    assert [call[1] for call in fake.calls] == ["print", "bootstrap"]


def test_cli_install_schedule_logs_after_checks_pass(
    ready: config.Config,
    _home: Path,
    tmp_path: Path,
    codex: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    # 파일은 dev config라 pytest 가드를 지나도록 읽은 결과만 runtime `Config`로 바꾼다.
    monkeypatch.setattr(config, "load", lambda path: ready)
    monkeypatch.setattr(subprocess, "run", _FakeLaunchctl(loaded=False))

    assert cli.main(["install-schedule", "--config", str(ready.path)]) == 0

    log = (tmp_path / "data" / "logs" / "install-schedule.log").read_text("utf-8")
    assert (
        "install-schedule 끝: collect_replaced=False report_replaced=False "
        f"collect=11:00 retry=11:15 report=11:30 codex={codex}"
    ) in log
    agents = _home / "Library" / "LaunchAgents"
    assert (agents / f"{LABEL}.plist").is_file()
    assert (agents / f"{REPORT_LABEL}.plist").read_bytes() == schedule.report_plist(
        ready, codex
    )


def test_install_refuses_system_timezone_mismatch_without_side_effects(
    ready: config.Config,
    _home: Path,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    fake = _FakeLaunchctl(loaded=False)
    monkeypatch.setattr(subprocess, "run", fake)
    monkeypatch.setenv("TZ", "UTC")

    assert schedule.install(ready) == 1

    assert "시스템 시간대(UTC)" in capsys.readouterr().err
    assert not (_home / "Library").exists()
    assert not (tmp_path / "data" / "logs").exists()
    assert fake.calls == []


def test_cli_install_schedule_log_failure_exits_1(
    ready: config.Config,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    # `data/logs` 자리가 일반 파일이라 로그 폴더를 만들 수 없다.
    (tmp_path / "data").mkdir()
    (tmp_path / "data" / "logs").write_text("", encoding="utf-8")
    monkeypatch.setattr(config, "load", lambda path: ready)
    fake = _FakeLaunchctl(loaded=False)
    monkeypatch.setattr(subprocess, "run", fake)

    assert cli.main(["install-schedule", "--config", str(ready.path)]) == 1

    assert "로그 파일을 열지 못했다" in capsys.readouterr().err
    assert fake.calls == []


def test_install_plist_write_failure_exits_1_without_launchctl(
    ready: config.Config,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    blocker = tmp_path / "not-a-dir"
    blocker.write_text("", encoding="utf-8")
    fake = _FakeLaunchctl(loaded=False)
    monkeypatch.setattr(subprocess, "run", fake)

    assert schedule.install(ready, agents_dir=blocker / "LaunchAgents") == 1

    err = capsys.readouterr().err.splitlines()
    assert any(line.startswith("install-schedule 실패:") for line in err)
    assert fake.calls == []


def test_cli_install_schedule_refuses_missing_codex(
    ready: config.Config,
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    monkeypatch.setattr(config, "load", lambda path: ready)
    fake = _FakeLaunchctl(loaded=False)
    monkeypatch.setattr(subprocess, "run", fake)
    _without_codex(tmp_path, monkeypatch)

    assert cli.main(["install-schedule", "--config", str(ready.path)]) == 1

    err = capsys.readouterr().err.splitlines()
    assert len(err) == 1
    assert err[0].startswith("install-schedule 거부: `codex`")
    assert not (tmp_path / "data" / "logs").exists()
    assert fake.calls == []
