"""`dates`: config 시간대 기준 "오늘"과 일 키. 시스템 시간대에 영향받지 않는다."""

import time
from collections.abc import Callable, Iterator
from datetime import UTC, date, datetime, timedelta
from pathlib import Path

import pytest

from garmin_pipeline import config, dates
from garmin_pipeline.config import Config

EPOCH = datetime(1970, 1, 1, tzinfo=UTC)
NOW = datetime(2026, 10, 14, 15, 30, tzinfo=UTC)
NOW_MS = 1_791_991_800_000

# 시스템 시간대별 NOW의 UTC 오프셋(초). 시스템 시간대가 실제로 바뀌었는지 확인한다.
SYSTEM_OFFSETS = {"UTC": 0, "America/Los_Angeles": -7 * 3600}


def _ms(moment: datetime) -> int:
    return (moment - EPOCH) // timedelta(milliseconds=1)


@pytest.fixture(params=sorted(SYSTEM_OFFSETS))
def system_tz(request: pytest.FixtureRequest) -> Iterator[str]:
    """프로세스의 시스템 시간대를 바꾼다. 정리할 때 원래 TZ로 되돌리고 다시 `tzset`한다."""
    patch = pytest.MonkeyPatch()
    try:
        patch.setenv("TZ", request.param)
        time.tzset()
        # 로컬 시각 API는 금지(TID251)지만, 여기서는 시스템 시간대가 바뀌었는지 보려고 쓴다.
        offset = time.localtime(NOW.timestamp()).tm_gmtoff  # noqa: TID251
        assert offset == SYSTEM_OFFSETS[request.param]
        yield request.param
    finally:
        patch.undo()
        time.tzset()


@pytest.fixture
def cfg(write_config: Callable[..., Path]) -> Config:
    return config.load(write_config())


def _freeze(monkeypatch: pytest.MonkeyPatch, moment: datetime) -> None:
    monkeypatch.setattr(dates, "_utc_now", lambda: moment)


def test_today_and_day_key_follow_config_timezone(
    system_tz: str, cfg: Config, monkeypatch: pytest.MonkeyPatch
):
    _freeze(monkeypatch, NOW)

    assert cfg.timezone == "Asia/Seoul"
    assert dates.today(cfg) == date(2026, 10, 15)
    assert dates.day_key(NOW_MS, cfg) == "2026-10-15"


@pytest.mark.parametrize(
    ("moment", "expected"),
    [
        (datetime(2026, 10, 14, 14, 59, 59, 999_000, tzinfo=UTC), "2026-10-14"),
        (datetime(2026, 10, 14, 15, 0, 0, 0, tzinfo=UTC), "2026-10-15"),
    ],
    ids=["before-midnight-kst", "midnight-kst"],
)
def test_day_boundary(
    moment: datetime,
    expected: str,
    system_tz: str,
    cfg: Config,
    monkeypatch: pytest.MonkeyPatch,
):
    _freeze(monkeypatch, moment)

    assert dates.day_key(_ms(moment), cfg) == expected
    assert dates.today(cfg).isoformat() == expected


@pytest.mark.parametrize(
    ("timezone", "expected"),
    [
        ("UTC", "2026-10-14"),
        ("America/Los_Angeles", "2026-10-14"),
        ("Asia/Seoul", "2026-10-15"),
    ],
)
def test_config_timezone_is_the_only_zone(
    timezone: str,
    expected: str,
    system_tz: str,
    write_config: Callable[..., Path],
    monkeypatch: pytest.MonkeyPatch,
):
    cfg = config.load(write_config(timezone=timezone))
    _freeze(monkeypatch, NOW)

    assert dates.day_key(NOW_MS, cfg) == expected
    assert dates.today(cfg).isoformat() == expected


@pytest.mark.parametrize(
    ("moment", "timezone", "expected"),
    [
        (
            datetime(2026, 10, 14, 14, 59, 59, 999_000, tzinfo=UTC),
            "Asia/Seoul",
            "2026-10-14 23:59",
        ),
        (
            datetime(2026, 10, 14, 15, 0, 0, 0, tzinfo=UTC),
            "Asia/Seoul",
            "2026-10-15 00:00",
        ),
        (NOW, "Asia/Seoul", "2026-10-15 00:30"),
        (NOW, "UTC", "2026-10-14 15:30"),
        (NOW, "America/Los_Angeles", "2026-10-14 08:30"),
    ],
    ids=["before-midnight-kst", "midnight-kst", "seoul", "utc", "los-angeles"],
)
def test_local_minute_follows_config_timezone(
    moment: datetime,
    timezone: str,
    expected: str,
    system_tz: str,
    write_config: Callable[..., Path],
):
    cfg = config.load(write_config(timezone=timezone))

    assert dates.local_minute(_ms(moment), cfg) == expected


def test_now_ms_reads_the_clock_seam(monkeypatch: pytest.MonkeyPatch):
    _freeze(monkeypatch, NOW)

    assert _ms(NOW) == NOW_MS
    assert dates.now_ms() == NOW_MS
    assert type(dates.now_ms()) is int


def test_real_clock_is_aware_utc():
    now = dates._utc_now()

    assert now.utcoffset() == timedelta(0)
    assert abs(dates.now_ms() - time.time_ns() // 1_000_000) < 60_000


# --- system_timezone -----------------------------------------------------------------------


@pytest.fixture
def localtime(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """`/etc/localtime` 자리에 `tmp_path`의 링크를 둔다. 링크 대상은 테스트가 만든다."""
    link = tmp_path / "etc" / "localtime"
    link.parent.mkdir()
    monkeypatch.setattr(dates, "_LOCALTIME", link)
    return link


@pytest.mark.parametrize(
    ("value", "expected"),
    [("UTC", "UTC"), ("America/Los_Angeles", "America/Los_Angeles")],
)
def test_system_timezone_reads_tz(
    value: str, expected: str, localtime: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setenv("TZ", value)

    assert dates.system_timezone() == expected


def test_system_timezone_strips_colon_prefix(
    localtime: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setenv("TZ", ":Asia/Seoul")

    assert dates.system_timezone() == "Asia/Seoul"


@pytest.mark.parametrize("tz", [None, "", ":"], ids=["unset", "empty", "colon-only"])
def test_system_timezone_falls_back_to_localtime_link(
    tz: str | None, localtime: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    if tz is None:
        monkeypatch.delenv("TZ", raising=False)
    else:
        monkeypatch.setenv("TZ", tz)
    # macOS처럼 링크가 다시 링크를 거쳐도 실제 경로의 마지막 `zoneinfo/` 뒤를 쓴다.
    target = (
        tmp_path / "db" / "zoneinfo" / "tz" / "2026a" / "zoneinfo" / "Asia" / "Seoul"
    )
    target.parent.mkdir(parents=True)
    target.write_bytes(b"TZif")
    middle = tmp_path / "var" / "localtime"
    middle.parent.mkdir()
    middle.symlink_to(target)
    localtime.symlink_to(middle)

    assert dates.system_timezone() == "Asia/Seoul"


@pytest.mark.parametrize("state", ["missing", "no-zoneinfo", "loop", "dangling"])
def test_system_timezone_unknown_is_none(
    state: str, localtime: Path, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.delenv("TZ", raising=False)
    if state == "no-zoneinfo":
        target = tmp_path / "zones" / "Seoul"
        target.parent.mkdir()
        target.write_bytes(b"TZif")
        localtime.symlink_to(target)
    elif state == "loop":
        localtime.symlink_to(localtime)
    elif state == "dangling":
        # 이름은 zoneinfo 아래지만 대상 파일이 없다.
        localtime.symlink_to(tmp_path / "zoneinfo" / "Asia" / "Seoul")

    assert dates.system_timezone() is None


# --- 시간대 표기 없는 UTC 시각 문자열 ----------------------------------------------------------


@pytest.mark.parametrize(
    ("text", "moment"),
    [
        pytest.param(
            "2026-10-14T22:30:00", datetime(2026, 10, 14, 22, 30, tzinfo=UTC), id="t"
        ),
        pytest.param(
            "2026-10-14 22:30:00",
            datetime(2026, 10, 14, 22, 30, tzinfo=UTC),
            id="space",
        ),
        pytest.param(
            "2026-10-14T22:30:00.0",
            datetime(2026, 10, 14, 22, 30, tzinfo=UTC),
            id="fraction-zero",
        ),
        pytest.param(
            "2026-10-14T22:30:00.1239",
            datetime(2026, 10, 14, 22, 30, 0, 123_000, tzinfo=UTC),
            id="fraction-truncated-to-ms",
        ),
        pytest.param("1970-01-01 00:00:00", EPOCH, id="epoch"),
    ],
)
def test_utc_text_ms_reads_text_as_utc(system_tz: str, text: str, moment: datetime):
    assert dates.utc_text_ms(text) == _ms(moment)


@pytest.mark.parametrize(
    "text",
    [
        pytest.param("2026-10-14", id="date-only"),
        pytest.param("2026-10-14T22:30:00Z", id="z"),
        pytest.param("2026-10-14T22:30:00+09:00", id="offset"),
        pytest.param("2026-10-14T22:30:00.0Z", id="fraction-z"),
        pytest.param("2026-10-14T22:30", id="no-seconds"),
        pytest.param("2026-10-14T22:30:00.", id="empty-fraction"),
        pytest.param("2026-13-14T22:30:00", id="bad-month"),
        pytest.param("2026-10-14T24:30:00", id="bad-hour"),
        pytest.param("20261014T223000", id="basic-format"),
        pytest.param("２０２６-10-14T22:30:00", id="non-ascii-digits"),
        pytest.param(" 2026-10-14T22:30:00", id="leading-space"),
        pytest.param("garbage", id="garbage"),
        pytest.param("", id="empty"),
    ],
)
def test_utc_text_ms_rejects_other_forms(text: str):
    with pytest.raises(ValueError) as excinfo:
        dates.utc_text_ms(text)

    assert text.strip() == "" or text not in str(excinfo.value)
    assert excinfo.value.__context__ is None


@pytest.mark.parametrize(
    ("timezone", "day", "expected", "hours"),
    [
        ("Asia/Seoul", date(2026, 3, 8), datetime(2026, 3, 7, 15, tzinfo=UTC), 24),
        ("America/New_York", date(2026, 3, 8), datetime(2026, 3, 8, 5, tzinfo=UTC), 23),
        (
            "America/New_York",
            date(2026, 11, 1),
            datetime(2026, 11, 1, 4, tzinfo=UTC),
            25,
        ),
    ],
)
def test_day_start_ms_with_dst(write_config, timezone, day, expected, hours):
    cfg = config.load(write_config(timezone=timezone))
    start = dates.day_start_ms(day, cfg)
    assert start == _ms(expected)
    assert dates.day_key(start, cfg) == day.isoformat()
    assert dates.day_start_ms(day + timedelta(days=1), cfg) - start == hours * 3_600_000
