"""Manual sync uses real migrated storage and fake Garmin, writers, and sinks."""

import fcntl
import json
import os
from dataclasses import replace
from datetime import UTC, date, datetime, timedelta

import pytest
from garmin_fakes import FakeGarmin
from test_report import FakeSink, FakeWriter, ok_writer

from garmin_pipeline import (
    cli,
    collect,
    config,
    coverage,
    dates,
    errors,
    garmin,
    report,
    store,
)

TODAY = date(2026, 10, 18)
NOW = datetime(2026, 10, 18, 2, 30, tzinfo=UTC)
NOW_MS = int(NOW.timestamp() * 1000)
DAYS = [TODAY - timedelta(days=i) for i in range(7)]


@pytest.fixture
def setup(write_config, monkeypatch):
    monkeypatch.setattr(dates, "_utc_now", lambda: NOW + timedelta(seconds=1))
    monkeypatch.setenv("TZ", "Asia/Seoul")
    cfg = config.load(
        write_config(lock_wait_seconds=0, date_pause_seconds=0, report_wait_minutes=0)
    )
    fake = FakeGarmin()
    monkeypatch.setattr(garmin, "GarminAdapter", lambda cfg: fake)
    monkeypatch.setattr(
        report, "default_writer", lambda cfg: ok_writer("updated analysis")
    )
    monkeypatch.setattr(report, "_render_charts", lambda *args: [])
    sink = FakeSink()
    monkeypatch.setattr(cli, "_report_sink", lambda cfg: sink)
    seed(cfg)
    return cfg, fake, sink


def seed(cfg):
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO meta (key, value) VALUES ('history_start', ?)",
            (min(DAYS).isoformat(),),
        )
        for day in DAYS:
            for endpoint in coverage.DAY_ENDPOINTS:
                store.upsert_raw(
                    conn,
                    scope="day",
                    key=day.isoformat(),
                    endpoint=endpoint,
                    payload=[] if endpoint == "activities_by_date" else None,
                    library_version="fake",
                    now_ms=NOW_MS,
                )


def rows(cfg):
    with store.read_connection(cfg) as conn:
        return conn.execute("SELECT status, detail FROM run ORDER BY id").fetchall()


def sync(cfg):
    return cli.main(["sync", "--config", str(cfg.path)])


def list_calls(fake):
    return [
        call[1]
        for call in fake.calls
        if isinstance(call, tuple) and call[0] == "activities_by_date"
    ]


def test_sync_rewrites_and_delivers_after_collect_releases_lock(setup, monkeypatch):
    cfg, fake, sink = setup
    assert report.run(cfg, ok_writer("old analysis")) == 0
    original_run = report.run

    def checked_run(*args, **kwargs):
        assert rows(cfg)[-1] == ("success", "manual")
        fd = os.open(cfg.data_dir / store.LOCK_FILENAME, os.O_RDWR)
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        finally:
            os.close(fd)
        with store.write_session(cfg):
            pass
        return original_run(*args, **kwargs)

    monkeypatch.setattr(report, "run", checked_run)
    assert sync(cfg) == 0
    assert "updated analysis" in report.report_path(cfg, TODAY).read_text()
    assert sink.calls[0].regenerated is True
    assert list_calls(fake) == DAYS
    assert (cfg.data_dir / "logs" / "sync.log").exists()
    assert not (cfg.data_dir / "logs" / "collect.log").exists()
    assert not (cfg.data_dir / "logs" / "report.log").exists()
    assert not [
        c
        for c in fake.calls
        if isinstance(c, tuple)
        and isinstance(c[1], date)
        and c[1] != TODAY
        and c[0] != "activities_by_date"
    ]


@pytest.mark.parametrize("limit", [3, 10])
def test_recent_lists_share_newest_first_date_limit(setup, limit):
    cfg, fake, _ = setup

    cfg = replace(cfg, max_dates_per_run=limit)
    assert (
        collect.collect(
            cfg, fake, force=True, manual=True, recent_lists=True, sleep=lambda _: None
        )
        == 0
    )
    assert list_calls(fake) == DAYS[:limit]


def test_recent_lists_respect_history_start(setup):
    cfg, fake, _ = setup
    with store.write_session(cfg) as conn:
        conn.execute(
            "UPDATE meta SET value=? WHERE key='history_start'", (DAYS[2].isoformat(),)
        )
    assert sync(cfg) == 0
    assert list_calls(fake) == DAYS[:3]


def test_sync_excludes_today_rejected_in_day_and_activity_plan(setup):
    cfg, fake, _ = setup
    day = DAYS[3]
    activity = {"activityId": 42, "startTimeLocal": f"{day} 07:00:00"}
    with store.write_session(cfg) as conn:
        store.upsert_raw(
            conn,
            scope="day",
            key=day.isoformat(),
            endpoint="activities_by_date",
            payload=[activity],
            library_version="fake",
            now_ms=NOW_MS,
        )
        run_id = conn.execute(
            "INSERT INTO run(local_date, started_at, finished_at, status) VALUES (?, 1, 2, 'partial')",
            (str(TODAY),),
        ).lastrowid
        for scope, key, endpoint in [
            ("day", str(DAYS[4]), "activities_by_date"),
            ("day", str(TODAY), "sleep_data"),
            ("activity", "42", "activity_details"),
        ]:
            conn.execute(
                "INSERT INTO fetch_error(run_id, scope, key, endpoint, kind, local_date, occurred_at, error_code) VALUES (?, ?, ?, ?, 'rejected', ?, ?, 'rejected')",
                (run_id, scope, key, endpoint, str(TODAY), NOW_MS),
            )
    fake.responses[("activities_by_date", day)] = [activity]
    assert sync(cfg) == 0
    assert DAYS[4] not in list_calls(fake)
    assert ("sleep_data", TODAY) not in fake.calls
    assert ("activity_details", 42) not in fake.calls
    assert ("activity", 42) in fake.calls


def test_changed_list_refetches_sets_for_only_changed_day(setup):
    cfg, fake, _ = setup
    lists = {
        day: [
            {"activityId": i + 1, "startTimeLocal": f"{day} 07:00:00", "totalSets": 5}
        ]
        for i, day in enumerate(DAYS)
    }
    with store.write_session(cfg) as conn:
        for day, entries in lists.items():
            store.upsert_raw(
                conn,
                scope="day",
                key=str(day),
                endpoint="activities_by_date",
                payload=entries,
                library_version="fake",
                now_ms=NOW_MS,
            )
            for endpoint in coverage.ACTIVITY_ENDPOINTS:
                store.upsert_raw(
                    conn,
                    scope="activity",
                    key=str(entries[0]["activityId"]),
                    endpoint=endpoint,
                    payload={"seeded": True},
                    library_version="fake",
                    now_ms=NOW_MS,
                )
            fake.responses[("activities_by_date", day)] = entries
    changed_day = DAYS[4]
    fake.responses[("activities_by_date", changed_day)] = [
        {**lists[changed_day][0], "totalSets": 6}
    ]
    fake.responses[(coverage.EXERCISE_SETS, 5)] = {"exerciseSets": []}
    assert sync(cfg) == 0
    assert [
        c for c in fake.calls if isinstance(c, tuple) and isinstance(c[1], int)
    ] == [(coverage.EXERCISE_SETS, 5)]
    fake.calls.clear()
    assert sync(cfg) == 0
    assert not [c for c in fake.calls if isinstance(c, tuple) and isinstance(c[1], int)]


@pytest.mark.parametrize("force", [False, True])
def test_collect_cli_manual_only_when_force_and_no_recent_lists(setup, force):
    cfg, fake, _ = setup
    assert (
        cli.main(
            ["collect", "--config", str(cfg.path), *(["--force"] if force else [])]
        )
        == 0
    )
    assert rows(cfg)[-1][1] == ("manual" if force else "")
    assert list_calls(fake) == [TODAY]


def test_blocked_sync_uses_saved_data_without_garmin_calls(setup):
    cfg, fake, sink = setup
    fake.blocked = errors.RunStatus.RATE_LIMITED
    cfg.tokenstore.mkdir(parents=True)
    (cfg.tokenstore / garmin.BLOCK_FILENAME).write_text(
        json.dumps(
            {"schema_version": 1, "local_date": str(TODAY), "reason": "rate_limited"}
        )
    )
    assert sync(cfg) == 0
    assert rows(cfg) == [("skipped_blocked", "manual")]
    assert fake.calls == ["blocked_today"]
    assert len(sink.calls) == 1


def test_sync_report_lock_busy_after_collect(setup, capsys):
    cfg, _, _ = setup
    fd = os.open(
        cfg.data_dir / store.REPORT_LOCK_FILENAME, os.O_RDWR | os.O_CREAT, 0o600
    )
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert sync(cfg) == 1
    finally:
        os.close(fd)
    assert rows(cfg) == [("success", "manual")]
    assert "sync 리포트 거부: 다른 report가 실행 중이다" in capsys.readouterr().err
    assert "WARNING" in (cfg.data_dir / "logs" / "sync.log").read_text()


@pytest.mark.parametrize("failure", ["day", "write"])
def test_sync_returns_failure_when_previous_report_is_preserved(
    setup, monkeypatch, failure
):
    cfg, _, _ = setup
    assert report.run(cfg, ok_writer("old")) == 0
    previous = report.report_path(cfg, TODAY).read_bytes()
    if failure == "day":
        monkeypatch.setattr(
            report,
            "default_writer",
            lambda cfg: FakeWriter(
                error=report.WriterFailed(errors.ReportFailReason.CODEX_FAILED)
            ),
        )
    else:

        def refuse(*args):
            raise OSError("write failure")

        monkeypatch.setattr(report, "_write_report", refuse)
    assert sync(cfg) == 1
    assert report.report_path(cfg, TODAY).read_bytes() == previous
    assert cli.main(["report", "--regenerate", "--config", str(cfg.path)]) == 0


@pytest.mark.parametrize("failure", ["code", "exception"])
def test_collect_failure_still_attempts_report(setup, monkeypatch, failure):
    cfg, _, sink = setup

    def fail(*args, **kwargs):
        if failure == "exception":
            raise RuntimeError("secret exception content")
        return 1

    monkeypatch.setattr(collect, "collect", fail)
    assert sync(cfg) == 1
    assert len(sink.calls) == 1
    log = (cfg.data_dir / "logs" / "sync.log").read_text()
    assert "secret exception content" not in log


@pytest.mark.parametrize("command", ["sync", "collect"])
def test_manual_lock_timeout_keeps_first_token(setup, command):
    cfg, fake, _ = setup
    fd = os.open(cfg.data_dir / store.LOCK_FILENAME, os.O_RDWR)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        assert (
            collect.collect(
                cfg, fake, force=True, manual=True, recent_lists=command == "sync"
            )
            == 0
        )
    finally:
        os.close(fd)
    assert rows(cfg) == [("error", "lock_timeout manual")]
    with store.read_connection(cfg) as conn:
        assert coverage.day_status(conn, TODAY).detail == "lock_timeout manual"
    assert fake.calls == []


@pytest.mark.parametrize(
    "failure,detail",
    [
        (garmin.BlockFileInvalid("bad"), "block_file_invalid manual"),
        (errors.Transient("login"), "login_transient manual"),
        (garmin.SessionLockTimeout("busy"), "session_lock_timeout manual"),
        (
            errors.AuthFailed(errors.AuthFailedReason.TOKEN_INVALID),
            "token_invalid manual",
        ),
    ],
)
def test_manual_entry_and_session_stops(setup, failure, detail):
    cfg, fake, _ = setup
    if isinstance(failure, garmin.BlockFileInvalid):
        fake.block_error = failure
    else:
        fake.open_error = failure
    assert collect.collect(cfg, fake, force=True, manual=True) == 0
    assert rows(cfg)[-1][1] == detail


def test_manual_does_not_mark_abandoned_and_is_after_timezone(setup, monkeypatch):
    cfg, fake, _ = setup
    monkeypatch.setenv("TZ", "UTC")
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO run(local_date, started_at, status) VALUES (?, 1, 'running')",
            (str(TODAY),),
        )
    assert collect.collect(cfg, fake, force=True, manual=True) == 0
    assert rows(cfg) == [
        ("error", "abandoned"),
        ("success", "timezone_mismatch manual"),
    ]


def test_sync_config_and_log_failures(setup, monkeypatch, capsys):
    cfg, fake, _ = setup
    assert cli.main(["sync", "--config", str(cfg.path.parent / "missing.toml")]) == 2

    def fail(*args):
        raise OSError("log failure")

    monkeypatch.setattr(cli, "_command_log", fail)
    assert sync(cfg) == 1
    assert fake.calls == []
    assert "sync 실패" in capsys.readouterr().err
