"""Opt-in end-to-end report acceptance using only a fake Codex executable.

Run with `uv run pytest -m acceptance tests/test_acceptance_report.py`.
No Garmin client, real Codex, or operational database is used.
"""

import json
import sys

import chart_db as base
import pytest

from garmin_pipeline import cli, config, dates, report

pytestmark = pytest.mark.acceptance


def test_fake_codex_daily_report_exports_inputs_and_accepts_body(
    write_config, monkeypatch, tmp_path
):
    cfg = config.load(write_config(report_model="fake", report_wait_minutes=0))
    monkeypatch.setattr(dates, "_utc_now", lambda: base.CLOCK)
    base.synthetic(cfg)
    script = tmp_path / "fake-codex"
    script.write_text(
        f"#!{sys.executable}\n"
        + """import json, pathlib, subprocess, sys
args = sys.argv[1:]
output = pathlib.Path(args[args.index('-o') + 1])
root = pathlib.Path(args[args.index('-C') + 1])
schema = args[args.index('--output-schema') + 1]
if 'body_intake' in schema:
    subprocess.run([str(pathlib.Path(sys.executable).parent / 'garmin-pipeline'), 'body', 'write', '2026-10-18', '--config', str(root / 'config.toml'), '--source', 'inbox/inbody/measurement.txt'], input='{"weight_kg":70}', text=True, check=True)
    result = {'status':'ok','detail':'done'}
elif 'period_review' in schema:
    result = {'status':'ok','summary':'기간 요약','report_md':'기간 분석','judgments':[],'evidence':[],'next_checks':[]}
else:
    prompt = args[args.index('-o') + 2]
    folder = root / prompt.splitlines()[-1]
    manifest = json.loads((folder / 'manifest.json').read_text())
    digest = json.loads((folder / 'digest.json').read_text())
    assert manifest['report_date'] == '2026-10-18'
    assert digest['body']['latest']['values']['weight_kg'] == 70
    assert (folder / 'labels/exercise_types_ko.json').is_file()
    result = {'status':'ok','summary':'요약','report_md':'# 하루 분석\\n\\n실행 결과','judgments':[],'evidence':[],'next_checks':[]}
output.write_text(json.dumps(result, ensure_ascii=False))
"""
    )
    script.chmod(0o755)
    monkeypatch.setattr(report, "CODEX_EXECUTABLE", str(script))
    source = cfg.inbox_dir / "inbody/measurement.txt"
    source.parent.mkdir(parents=True)
    source.write_text("2026-10-18 체중 70kg")
    assert cli.main(["report", "--config", str(cfg.path)]) == 0
    path = cfg.reports_dir / "2026-10-18.md"
    assert path.read_text().startswith("# 하루 분석\n\n실행 결과")
    assert "\n## 그래프\n" in path.read_text()
    assert "## 기간 평가" in path.read_text()
    assert all(f"### {label}" in path.read_text() for label in ["7일", "30일", "전체"])
    from garmin_pipeline import store

    with store.read_connection(cfg) as conn:
        assert conn.execute("SELECT COUNT(*) FROM evaluation").fetchone()[0] == 4
    assert (source.parent / "processed/measurement.txt").exists()
    folder = cfg.data_dir / "report-input/2026-10-18"
    assert json.loads((folder / "digest.json").read_text())["body"]["new_today"] is True
    assert not list(cfg.data_dir.glob(".codex-*"))

    images = sorted((cfg.reports_dir / base.REPORT_DATE).glob("*.png"))
    assert [p.name for p in images] == [
        "01-yesterday.png",
        "02-session-1.png",
        "03-session-2.png",
        "04-strength-1.png",
        "05-strength-2.png",
        "50-sleep-30d.png",
        "51-hrv-30d.png",
        "52-heart-30d.png",
        "53-workouts-30d.png",
        "54-sleep-all.png",
        "55-hrv-all.png",
        "56-heart-all.png",
        "57-workouts-all.png",
        "58-strength-all.png",
        "59-body.png",
    ]
    assert all(f"({base.REPORT_DATE}/{p.name})" in path.read_text() for p in images)
