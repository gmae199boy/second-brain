"""`scripts/build_exercise_labels.py`(종목 라벨 데이터 파일 생성 스크립트) 시험. 합성 properties만 쓴다."""

import importlib.util
import json
import subprocess
import sys
from pathlib import Path
from types import ModuleType

SCRIPT = Path(__file__).resolve().parents[1] / "scripts" / "build_exercise_labels.py"

SYNTHETIC = """\
# 주석 줄
! 느낌표 주석

activities_with_no_exercise_types=선택한 활동에 특정 운동 유형이 없습니다.
category_type_CURL=컬(Curl)
category_type_SQUAT=스쿼트
CURL_X=컬 X(Curl X)
CURL_HAMMER_CURL=해머 컬
SQUAT_GOBLET_SQUAT=고블릿 스쿼트
SQUAT_A=b=c
exercise_type_X=운동 X
curl_lower=소문자 키
MOVE_ARCH=Arch
CURLY_THING=분류 접두어가 아니다
CURL_bad=소문자 섞임
category_type_=빈 분류
"""


def _module() -> ModuleType:
    spec = importlib.util.spec_from_file_location("build_exercise_labels", SCRIPT)
    assert spec is not None and spec.loader is not None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_build_labels_keeps_only_category_and_exercise_keys():
    module = _module()

    labels = module.build_labels(module.parse_properties(SYNTHETIC))

    # 주석·빈 줄은 건너뛰고 값 안 `=`는 첫 `=`로만 나눈다. `exercise_type_`·소문자·UI 문구·MOVE(분류 키 없음)·
    # 분류 접두어가 `<CATEGORY>_`가 아닌 키(CURLY_THING)는 넣지 않는다.
    assert labels == {
        "categories": {"CURL": "컬(Curl)", "SQUAT": "스쿼트"},
        "exercises": {
            "CURL_HAMMER_CURL": "해머 컬",
            "CURL_X": "컬 X(Curl X)",
            "SQUAT_A": "b=c",
            "SQUAT_GOBLET_SQUAT": "고블릿 스쿼트",
        },
        "fetched_on": "2026-10-21",
        "source": (
            "https://connect.garmin.com/web-translations/exercise_types/"
            "exercise_types_ko.properties"
        ),
    }


def test_script_writes_sorted_utf8_json(tmp_path: Path):
    source = tmp_path / "exercise_types_ko.properties"
    source.write_text(SYNTHETIC, encoding="utf-8")
    output = tmp_path / "out.json"

    result = subprocess.run(
        [sys.executable, "-I", str(SCRIPT), str(source), str(output)],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    text = output.read_text(encoding="utf-8")
    assert "고블릿 스쿼트" in text  # ensure_ascii=False
    data = json.loads(text)
    assert list(data) == sorted(data)
    assert list(data["exercises"]) == sorted(data["exercises"])
    assert text == json.dumps(data, ensure_ascii=False, sort_keys=True, indent=2) + "\n"


def test_script_refuses_empty_labels(tmp_path: Path):
    # 받은 파일이 오류 페이지면 분류·이름 키가 없다: 기존 출력 파일을 덮지 않고 종료 코드 1이다.
    source = tmp_path / "error.properties"
    source.write_text("<html>404 Not Found</html>\n", encoding="utf-8")
    output = tmp_path / "out.json"
    output.write_text("기존 내용\n", encoding="utf-8")

    result = subprocess.run(
        [sys.executable, "-I", str(SCRIPT), str(source), str(output)],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 1
    assert "오류:" in result.stderr
    assert output.read_text(encoding="utf-8") == "기존 내용\n"


def test_script_usage_error(tmp_path: Path):
    result = subprocess.run(
        [sys.executable, "-I", str(SCRIPT)],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 2
    assert "사용:" in result.stderr


def test_package_data_file_matches_builder_shape():
    # 커밋된 데이터 파일은 스크립트 출력 모양(키 정렬, 한글 그대로, 끝 줄바꿈)이고 규칙대로의 키만 담는다.
    module = _module()
    path = (
        Path(__file__).resolve().parents[1]
        / "src"
        / "garmin_pipeline"
        / "labels"
        / "exercise_types_ko.json"
    )
    text = path.read_text(encoding="utf-8")
    data = json.loads(text)

    assert text == module.render(data)
    assert set(data) == {"categories", "exercises", "fetched_on", "source"}
    assert (data["source"], data["fetched_on"]) == (module.SOURCE, module.FETCHED_ON)
    rebuilt = module.build_labels(
        {f"category_type_{k}": v for k, v in data["categories"].items()}
        | data["exercises"]
    )
    assert rebuilt == data
