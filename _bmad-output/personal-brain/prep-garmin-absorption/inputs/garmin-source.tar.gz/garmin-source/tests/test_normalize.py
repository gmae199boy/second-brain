"""정규화 작업 집합, 일일 요약 지표, 활동과 근력 세트: `normalize`와 `garmin-pipeline normalize`(FR9·11·13, NFR3·5, AD-13).

DB는 패키지 마이그레이션 위에서 `store.write_session` + `store.upsert_raw`로 만든다. 시계는
`dates._utc_now`만 바꾼다. 원문은 합성 값이고, 실제 Venu 3 fixture(`tests/fixtures/garmin/`)가 있으면
그것으로도 돈다(없으면 skip).
"""

import dataclasses
import fcntl
import importlib.util
import json
import logging
import os
import shutil
import socket
import sqlite3
import subprocess
import sys
import sysconfig
import textwrap
from collections.abc import Callable, Mapping, Sequence
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest
import schema_version

from garmin_pipeline import cli, config, dates, normalize, rawparse, store
from garmin_pipeline.normalize import activity, daily

ROOT = Path(__file__).resolve().parents[1]
REAL_FIXTURES = ROOT / "tests" / "fixtures" / "garmin"
FETCHED = 1_760_000_000_000
VERSION = "0.3.17"
MARKER = "원문표식-9b2e"
D0, D1, D2 = "2026-10-14", "2026-10-15", "2026-10-16"
CLOCK = datetime(2026, 10, 17, 21, 0, tzinfo=UTC)
CLOCK_MS = int(CLOCK.timestamp() * 1000)
ENDPOINTS = (
    "body_battery",
    "heart_rates",
    "hrv_data",
    "rhr_day",
    "sleep_data",
    "stress_data",
    "training_readiness",
    "user_summary",
)
# scope `activity`의 3종(3.4). 합성 활동(`_activity_rows`)이 담는 것이고 세트 상세는 뺀다.
ACTIVITY_ENDPOINTS = ("activity", "activity_details", "activity_hr_in_timezones")
# 세트 상세(5.1 수집, 5.4 정규화): `exercise_set` 행을 쓴다.
EXERCISE_SETS = "activity_exercise_sets"
# 기본 합성 하루(`_day`)가 담는 3.1의 4종.
BASE_ENDPOINTS = ("hrv_data", "rhr_day", "training_readiness", "user_summary")

NEW_COLUMNS = (
    *daily.SLEEP_DATA_COLUMNS,
    *daily.STRESS_DATA_COLUMNS,
    *daily.BODY_BATTERY_COLUMNS,
)
ALL_COLUMNS = (
    *daily.USER_SUMMARY_COLUMNS,
    *daily.RHR_DAY_COLUMNS,
    *daily.HRV_DATA_COLUMNS,
    *daily.TRAINING_READINESS_COLUMNS,
    *NEW_COLUMNS,
)
# `activity` 테이블의 값 열(키·`day_key` 제외).
ACTIVITY_VALUE_COLUMNS = (
    *activity.ACTIVITY_COLUMNS,
    *activity.ACTIVITY_HR_IN_TIMEZONES_COLUMNS,
)


def _ms(text: str) -> int:
    return int(datetime.fromisoformat(text).replace(tzinfo=UTC).timestamp() * 1000)


SLEEP_START = _ms("2026-10-14T21:30:00")
SLEEP_END = _ms("2026-10-15T05:00:00")
MINUTE_MS = 60_000


# --- 합성 원문 ------------------------------------------------------------------------------


def _user_summary(**overrides: object) -> dict[str, object]:
    payload: dict[str, object] = {
        "calendarDate": D1,
        "totalSteps": 8123,
        "totalDistanceMeters": 6543.6,
        "activeKilocalories": 412.4,
        "moderateIntensityMinutes": 12,
        "vigorousIntensityMinutes": 3.5,
        "minHeartRate": 48,
        "maxHeartRate": 151,
        "restingHeartRate": 55,
        "메모": MARKER,
    }
    return payload | overrides


def _rhr_day(day: str = D1, entries: list[object] | None = None) -> dict[str, object]:
    if entries is None:
        entries = [
            {"value": 60.0, "calendarDate": D0},
            {"value": 52.0, "calendarDate": day},
        ]
    return {
        "userProfileId": 1,
        "statisticsStartDate": day,
        "allMetrics": {"metricsMap": {"WELLNESS_RESTING_HEART_RATE": entries}},
    }


def _hrv_data(**summary_overrides: object) -> dict[str, object]:
    summary: dict[str, object] = {
        "calendarDate": D1,
        "weeklyAvg": 41,
        "lastNightAvg": 38.6,
        "lastNight5MinHigh": 60,
        "status": "BALANCED",
        "baseline": {
            "lowUpper": 30,
            "balancedLow": 35,
            "balancedUpper": 48.2,
            "markerValue": 0.4,
        },
        "feedbackPhrase": MARKER,
    }
    return {"userProfilePk": 1, "hrvSummary": summary | summary_overrides}


def _readiness() -> list[dict[str, object]]:
    return [
        {"timestamp": f"{D1}T09:30:00.0", "score": 70, "level": "MODERATE"},
        {"timestamp": f"{D1}T06:45:00.0", "score": 81.4, "level": "HIGH"},
    ]


def _sleep_data(**dto_overrides: object) -> dict[str, object]:
    dto: dict[str, object] = {
        "id": 1,
        "calendarDate": D1,
        "sleepTimeSeconds": 26100,
        "deepSleepSeconds": 5400.4,
        "lightSleepSeconds": 14400,
        "remSleepSeconds": 6300,
        "awakeSleepSeconds": 900,
        "sleepStartTimestampGMT": SLEEP_START,
        "sleepEndTimestampGMT": SLEEP_END,
        "sleepScores": {"overall": {"value": 82, "qualifierKey": "GOOD"}},
        "sleepScoreFeedback": MARKER,
    }
    return {"dailySleepDTO": dto | dto_overrides, "remSleepData": True}


STRESS_DESCRIPTORS = [
    {"key": "timestamp", "index": 0},
    {"key": "stressLevel", "index": 1},
]


def _stress_data(levels: list[object] | None = None, **overrides: object) -> dict:
    if levels is None:
        levels = [30, -1, 50, -2, None]
    payload: dict[str, object] = {
        "calendarDate": D1,
        # Garmin 요약 값은 쓰지 않는다(유효 샘플에서 계산한다).
        "maxStressLevel": 99,
        "avgStressLevel": 77,
        "stressValueDescriptorsDTOList": STRESS_DESCRIPTORS,
        "stressValuesArray": [
            [SLEEP_START + i * 3 * MINUTE_MS, level] for i, level in enumerate(levels)
        ],
    }
    return payload | overrides


BB_DESCRIPTORS = [
    {
        "bodyBatteryValueDescriptorIndex": 0,
        "bodyBatteryValueDescriptorKey": "timestamp",
    },
    {
        "bodyBatteryValueDescriptorIndex": 1,
        "bodyBatteryValueDescriptorKey": "bodyBatteryLevel",
    },
]
# 4개 중 하나(기상 시각)는 level이 null이다. 기상 값 후보는 그 직전 샘플(61)이다.
BB_VALUES = [
    [SLEEP_START, 20],
    [SLEEP_END - 30 * MINUTE_MS, 61],
    [SLEEP_END, None],
    [SLEEP_END + 60 * MINUTE_MS, 55.5],
]
BB_SAMPLES = [
    (SLEEP_START, 20),
    (SLEEP_END - 30 * MINUTE_MS, 61),
    (SLEEP_END, None),
    (SLEEP_END + 60 * MINUTE_MS, 56),
]


def _body_battery(
    day: str = D1, values: list[object] | None = None, **overrides: object
) -> list[dict[str, object]]:
    entry: dict[str, object] = {
        "date": day,
        "charged": 45,
        "drained": 38.6,
        "startTimestampGMT": f"{D0}T15:00:00.0",
        "bodyBatteryValuesArray": BB_VALUES if values is None else values,
        "bodyBatteryValueDescriptorDTOList": BB_DESCRIPTORS,
        "메모": MARKER,
    }
    return [entry | overrides]


HR_DESCRIPTORS = [
    {"key": "timestamp", "index": 0},
    {"key": "heartrate", "index": 1},
]
HR_START = SLEEP_END + 90 * MINUTE_MS
TWO_MINUTES_MS = 2 * MINUTE_MS
# 2분 간격 5개. 하나는 bpm이 null(결측), 하나는 61.6(→ 62)이다.
HR_VALUES = [
    [HR_START + i * TWO_MINUTES_MS, bpm]
    for i, bpm in enumerate([58, None, 61.6, 70, 64])
]
HR_SAMPLES = [
    (HR_START, 58),
    (HR_START + TWO_MINUTES_MS, None),
    (HR_START + 2 * TWO_MINUTES_MS, 62),
    (HR_START + 3 * TWO_MINUTES_MS, 70),
    (HR_START + 4 * TWO_MINUTES_MS, 64),
]


def _heart_rates(
    values: list[object] | None = None, **overrides: object
) -> dict[str, object]:
    payload: dict[str, object] = {
        "userProfilePK": 1,
        "calendarDate": D1,
        # 요약 값은 읽지 않는다(user_summary·rhr_day 몫).
        "maxHeartRate": 151,
        "restingHeartRate": 55,
        "heartRateValueDescriptors": HR_DESCRIPTORS,
        "heartRateValues": HR_VALUES if values is None else values,
        "메모": MARKER,
    }
    return payload | overrides


def _sleep_stress_bb(day: str = D1) -> list[tuple[str, str, str, object]]:
    return [
        ("day", day, "sleep_data", _sleep_data()),
        ("day", day, "stress_data", _stress_data()),
        ("day", day, "body_battery", _body_battery(day)),
    ]


SLEEP_EXPECTED = {
    "sleep_s": 26100,
    "deep_sleep_s": 5400,
    "light_sleep_s": 14400,
    "rem_sleep_s": 6300,
    "awake_sleep_s": 900,
    "sleep_score": 82,
    "sleep_start_ms": SLEEP_START,
    "sleep_end_ms": SLEEP_END,
}
STRESS_EXPECTED = {"stress_avg": 40, "stress_max": 50}
BB_EXPECTED = {"bb_charged": 45, "bb_drained": 39, "bb_high": 61, "bb_low": 20}


def _day(day: str = D1) -> list[tuple[str, str, str, object]]:
    return [
        ("day", day, "user_summary", _user_summary()),
        ("day", day, "rhr_day", _rhr_day(day)),
        ("day", day, "hrv_data", _hrv_data()),
        ("day", day, "training_readiness", _readiness()),
    ]


EXPECTED = {
    "steps": 8123,
    "distance_m": 6544,
    "active_kcal": 412,
    "moderate_intensity_s": 720,
    "vigorous_intensity_s": 210,
    "min_hr": 48,
    "max_hr": 151,
    "resting_hr": 52,
    "hrv_last_night_avg": 39,
    "hrv_weekly_avg": 41,
    "hrv_baseline_low": 35,
    "hrv_baseline_high": 48,
    "hrv_status": "BALANCED",
    "readiness_score": 81,
    "readiness_level": "HIGH",
} | dict.fromkeys(NEW_COLUMNS)


# 활동 2개(문자열 순서 "1999" < "2001"). 달리기는 D1 로컬 07:30(Asia/Seoul) = D0 22:30 UTC에 시작했다.
RUN_ID, WALK_ID = 2001, 1999
ACT_START = _ms(f"{D0}T22:30:00")
SECOND_MS = 1000


def _activity_summary(
    type_key: object = "running", **summary_overrides: object
) -> dict[str, object]:
    summary: dict[str, object] = {
        "startTimeLocal": f"{D1}T07:30:00.0",
        "startTimeGMT": f"{D0}T22:30:00.0",
        "duration": 1800.4,
        # 저장하지 않는 값.
        "elapsedDuration": 1900.0,
        "movingDuration": 1750.0,
        "distance": 5012.6,
        "averageHR": 141.5,
        "maxHR": 170,
        "calories": 400,
    }
    return {
        "activityId": RUN_ID,
        "activityName": MARKER,
        "activityTypeDTO": {"typeId": 1, "typeKey": type_key},
        "summaryDTO": summary | summary_overrides,
    }


ACTIVITY_EXPECTED = {
    "type_key": "running",
    "start_ms": ACT_START,
    "duration_s": 1800,
    "distance_m": 5013,
    "avg_hr": 142,
    "max_hr": 170,
}


def _hr_zones(seconds: Mapping[object, object] | None = None) -> list[object]:
    if seconds is None:
        seconds = {1: 120, 2: None, 3: 61.6, 4: 900, 5: 30}
    return [
        {"zoneNumber": zone, "secsInZone": secs, "zoneLowBoundary": 100}
        for zone, secs in seconds.items()
    ]


ZONES_EXPECTED = {
    "hr_zone1_s": 120,
    "hr_zone2_s": None,
    "hr_zone3_s": 62,
    "hr_zone4_s": 900,
    "hr_zone5_s": 30,
    **{f"hr_zone{zone}_low_bpm": 100 for zone in range(1, 6)},
}

# activity_details 채널(원래 순서): 시각·심박·다른 채널(속도).
DETAIL_KEYS = ("directTimestamp", "directHeartRate", "directSpeed")
# 4개 중 하나는 bpm이 null, 시각은 float(반올림)이다. 150.5 → 150(짝수 쪽 반올림).
DETAIL_ROWS = [
    (float(ACT_START), 120, 2.5),
    (ACT_START + 1000.4, None, 2.6),
    (ACT_START + 2000.6, 150.5, 2.7),
    (ACT_START + 3 * SECOND_MS, 171, None),
]
ACT_HR_SAMPLES = [
    (ACT_START, 120),
    (ACT_START + 1000, None),
    (ACT_START + 2001, 150),
    (ACT_START + 3000, 171),
]
"""DB의 `(ts_ms, bpm)`(`_activity_hr_samples`). 파서 행은 `body_battery`가 붙은 `ACT_HR_ROWS`다."""
ACT_HR_ROWS = [(*sample, None) for sample in ACT_HR_SAMPLES]
"""`DETAIL_KEYS`에는 `directBodyBattery`가 없어 파서 행의 `body_battery`가 모두 `None`이다."""
BB_DETAIL_KEYS = ("directTimestamp", "directHeartRate", "directBodyBattery")
# 운동 중 Body Battery 채널(5.9): 정수 값 float(실제 fixture 모양), null, 음수, 0, 소수(61.4 → 61, 0.4 → 0).
BB_DETAIL_ROWS = [
    (float(ACT_START), 120, 62.0),
    (ACT_START + 1000, 121, None),
    (ACT_START + 2000, 122, -1),
    (ACT_START + 3000, 123, 61.4),
    (ACT_START + 4000, 0, 0.4),
    (ACT_START + 5000, 125, 0),
]
BB_ROWS = [
    (ACT_START, 120, 62),
    (ACT_START + 1000, 121, None),
    (ACT_START + 2000, 122, None),
    (ACT_START + 3000, 123, 61),
    (ACT_START + 4000, None, 0),
    (ACT_START + 5000, 125, 0),
]
"""`BB_DETAIL_ROWS`의 파서 행. bpm 0은 `None`이지만 Body Battery 0은 0으로 남는다."""


def _activity_details(
    rows: Sequence[Sequence[object]] | None = None,
    *,
    order: Sequence[int] = (0, 1, 2),
    keys: Sequence[str] = DETAIL_KEYS,
    **overrides: object,
) -> dict[str, object]:
    """채널 `keys[i]`를 `metrics[order[i]]`에 둔다. 섞으면 descriptor 목록도 거꾸로 나열한다."""
    if rows is None:
        rows = DETAIL_ROWS
    descriptors = [
        {"metricsIndex": order[i], "key": key, "unit": {"id": i, "key": MARKER}}
        for i, key in enumerate(keys)
    ]
    if tuple(order) != tuple(range(len(keys))):
        descriptors.reverse()
    metrics = []
    for row in rows:
        placed: list[object] = [None] * len(keys)
        for i, value in enumerate(row):
            placed[order[i]] = value
        metrics.append({"metrics": placed})
    payload: dict[str, object] = {
        "activityId": RUN_ID,
        "measurementCount": len(keys),
        "metricsCount": len(rows),
        "metricDescriptors": descriptors,
        "activityDetailMetrics": metrics,
        "geoPolylineDTO": None,
        "메모": MARKER,
    }
    return payload | overrides


def _list_entry(
    activity_id: int,
    local: str = f"{D1} 07:30:00",
    gmt: str = f"{D0} 22:30:00",
) -> dict[str, object]:
    return {
        "activityId": activity_id,
        "activityName": MARKER,
        "startTimeLocal": local,
        "startTimeGMT": gmt,
        "beginTimestamp": ACT_START,
    }


def _activity_list(day: str, *ids: int) -> tuple[str, str, str, object]:
    """`day` 목록(`activities_by_date`): 각 활동은 그날 로컬 07:30에 시작했다."""
    return (
        "day",
        day,
        "activities_by_date",
        [_list_entry(i, local=f"{day} 07:30:00") for i in ids],
    )


def _activity_rows(activity_id: int = RUN_ID) -> list[tuple[str, str, str, object]]:
    key = str(activity_id)
    return [
        ("activity", key, "activity", _activity_summary()),
        ("activity", key, "activity_hr_in_timezones", _hr_zones()),
        ("activity", key, "activity_details", _activity_details()),
    ]


def _activity_expected(day_key: str | None = D1) -> dict[str, object]:
    return {"day_key": day_key} | ACTIVITY_EXPECTED | ZONES_EXPECTED


# --- 준비 ----------------------------------------------------------------------------------


@pytest.fixture
def clock(monkeypatch: pytest.MonkeyPatch) -> list[datetime]:
    current = [CLOCK]
    monkeypatch.setattr(dates, "_utc_now", lambda: current[0])
    return current


@pytest.fixture
def cfg(write_config: Callable[..., Path], clock: list[datetime]) -> config.Config:
    return config.load(write_config(lock_wait_seconds=0))


def _put(
    cfg: config.Config,
    rows: list[tuple[str, str, str, object]],
    *,
    now_ms: int = FETCHED,
) -> None:
    with store.write_session(cfg) as conn:
        for scope, key, endpoint, payload in rows:
            store.upsert_raw(
                conn,
                scope=scope,
                key=key,
                endpoint=endpoint,
                payload=payload,
                library_version=VERSION,
                now_ms=now_ms,
            )


def _put_text(
    cfg: config.Config,
    key: str,
    endpoint: str,
    raw: str,
    *,
    now_ms: int = FETCHED,
    scope: str = "day",
) -> None:
    """`upsert_raw`가 만들 수 없는 원문(JSON 아님, 이미 있는 원문을 'null'로 등)을 그대로 넣거나 바꾼다."""
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO raw_response"
            " (scope, key, endpoint, raw, fetched_at, checked_at, library_version)"
            " VALUES (?, ?, ?, ?, ?, ?, ?)"
            " ON CONFLICT DO UPDATE SET raw = excluded.raw, fetched_at = excluded.fetched_at",
            (scope, key, endpoint, raw, now_ms, now_ms, VERSION),
        )


def _run(cfg: config.Config, *, rebuild: bool = False) -> normalize.Summary:
    with store.write_session(cfg) as conn:
        return normalize.run(conn, rebuild=rebuild)


def _set_version(cfg: config.Config, value: str | None = None) -> None:
    """`meta.normalize_version`을 `value`(기본: 코드 값)로 맞춘다. 증분만 보는 시험이 먼저 부른다."""
    value = str(normalize.NORMALIZE_VERSION) if value is None else value
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO meta (key, value) VALUES (?, ?)"
            " ON CONFLICT (key) DO UPDATE SET value = excluded.value",
            (normalize.NORMALIZE_VERSION_KEY, value),
        )


def _query(
    cfg: config.Config,
    sql: str,
    params: Sequence[object] | Mapping[str, object] = (),
) -> list:
    conn = sqlite3.connect(cfg.db_path)
    try:
        return conn.execute(sql, params).fetchall()
    finally:
        conn.close()


def _metrics(cfg: config.Config) -> dict[str, dict[str, object]]:
    conn = sqlite3.connect(cfg.db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute("SELECT * FROM daily_metric ORDER BY day_key").fetchall()
    finally:
        conn.close()
    return {row["day_key"]: {c: row[c] for c in ALL_COLUMNS} for row in rows}


def _results(cfg: config.Config) -> list[tuple]:
    return _query(
        cfg,
        "SELECT scope, key, endpoint, ok, error_code, raw_fetched_at, normalized_at"
        " FROM normalize_result ORDER BY scope, key, endpoint",
    )


def _raw_snapshot(cfg: config.Config) -> list[tuple]:
    return _query(cfg, "SELECT * FROM raw_response ORDER BY scope, key, endpoint")


def _samples(cfg: config.Config, day: str = D1) -> list[tuple]:
    return _query(
        cfg,
        "SELECT ts_ms, level FROM body_battery_sample WHERE day_key = ? ORDER BY ts_ms",
        (day,),
    )


def _hr_samples(cfg: config.Config, day: str = D1) -> list[tuple]:
    return _query(
        cfg,
        "SELECT ts_ms, bpm FROM hr_sample WHERE day_key = ? ORDER BY ts_ms",
        (day,),
    )


def _activities(cfg: config.Config) -> dict[int, dict[str, object]]:
    conn = sqlite3.connect(cfg.db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = conn.execute("SELECT * FROM activity ORDER BY activity_id").fetchall()
    finally:
        conn.close()
    return {
        row["activity_id"]: {c: row[c] for c in ("day_key", *ACTIVITY_VALUE_COLUMNS)}
        for row in rows
    }


def _activity_hr_samples(cfg: config.Config, activity_id: int) -> list[tuple]:
    return _query(
        cfg,
        "SELECT ts_ms, bpm FROM activity_hr_sample WHERE activity_id = ? ORDER BY ts_ms",
        (activity_id,),
    )


def _activity_body_battery(cfg: config.Config, activity_id: int) -> list[tuple]:
    """활동 샘플의 `(ts_ms, bpm, body_battery)`(시각 순)."""
    return _query(
        cfg,
        "SELECT ts_ms, bpm, body_battery FROM activity_hr_sample"
        " WHERE activity_id = ? ORDER BY ts_ms",
        (activity_id,),
    )


def _nulls(columns: tuple[str, ...]) -> dict[str, object]:
    return dict.fromkeys(columns)


# --- 마이그레이션 ----------------------------------------------------------------------------


def test_migration_creates_tables(cfg: config.Config):
    with store.write_session(cfg) as conn:
        assert conn.execute("PRAGMA user_version").fetchone() == (
            schema_version.LATEST,
        )
        result_cols = conn.execute("PRAGMA table_info(normalize_result)").fetchall()
        metric_cols = conn.execute("PRAGMA table_info(daily_metric)").fetchall()
        sample_cols = conn.execute("PRAGMA table_info(body_battery_sample)").fetchall()
        hr_cols = conn.execute("PRAGMA table_info(hr_sample)").fetchall()
        activity_cols = conn.execute("PRAGMA table_info(activity)").fetchall()
        activity_hr_cols = conn.execute(
            "PRAGMA table_info(activity_hr_sample)"
        ).fetchall()
        tables = {
            name
            for (name,) in conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            )
        }
        hr_indexes = conn.execute("PRAGMA index_list(hr_sample)").fetchall()
        ts_index_cols = conn.execute("PRAGMA index_info(hr_sample_ts_ms)").fetchall()

    assert [
        (name, kind, notnull, pk) for _, name, kind, notnull, _, pk in result_cols
    ] == [
        ("scope", "TEXT", 1, 1),
        ("key", "TEXT", 1, 2),
        ("endpoint", "TEXT", 1, 3),
        ("ok", "INTEGER", 1, 0),
        ("error_code", "TEXT", 0, 0),
        ("raw_fetched_at", "INTEGER", 1, 0),
        ("normalized_at", "INTEGER", 1, 0),
    ]
    text_columns = {"hrv_status", "readiness_level"}
    assert [
        (name, kind, notnull, pk) for _, name, kind, notnull, _, pk in metric_cols
    ] == [
        ("day_key", "TEXT", 1, 1),
        *(
            (column, "TEXT" if column in text_columns else "INTEGER", 0, 0)
            for column in ALL_COLUMNS
        ),
    ]
    assert len(NEW_COLUMNS) == 14
    assert [
        (name, kind, notnull, pk) for _, name, kind, notnull, _, pk in sample_cols
    ] == [
        ("day_key", "TEXT", 1, 1),
        ("ts_ms", "INTEGER", 1, 2),
        ("level", "INTEGER", 0, 0),
    ]
    assert [(name, kind, notnull, pk) for _, name, kind, notnull, _, pk in hr_cols] == [
        ("day_key", "TEXT", 1, 1),
        ("ts_ms", "INTEGER", 1, 2),
        ("bpm", "INTEGER", 0, 0),
    ]
    assert [
        (name, kind, notnull, pk) for _, name, kind, notnull, _, pk in activity_cols
    ] == [
        ("activity_id", "INTEGER", 0, 1),
        ("day_key", "TEXT", 0, 0),
        *(
            (column, "TEXT" if column == "type_key" else "INTEGER", 0, 0)
            for column in ACTIVITY_VALUE_COLUMNS
        ),
    ]
    assert [
        (name, kind, notnull, pk) for _, name, kind, notnull, _, pk in activity_hr_cols
    ] == [
        ("activity_id", "INTEGER", 1, 1),
        ("ts_ms", "INTEGER", 1, 2),
        ("bpm", "INTEGER", 0, 0),
        # 0013(5.9)이 더한 운동 중 Body Battery.
        ("body_battery", "INTEGER", 0, 0),
    ]
    # 0012가 activity_recovery를 drop했다(5.7).
    assert "activity_recovery" not in tables
    # hr_sample의 PK는 그대로이고 시각 창 조회용 ts_ms 인덱스(0010)는 0012 뒤에도 남는다.
    assert {(name, unique, origin) for _, name, unique, origin, _ in hr_indexes} == {
        ("sqlite_autoindex_hr_sample_1", 1, "pk"),
        ("hr_sample_ts_ms", 0, "c"),
    }
    assert [name for _, _, name in ts_index_cols] == ["ts_ms"]


@pytest.mark.parametrize(
    ("scope", "ok", "error_code"),
    [
        pytest.param("day", 1, "parse_error", id="ok-with-code"),
        pytest.param("day", 0, None, id="failed-without-code"),
        pytest.param("day", 2, None, id="ok-not-boolean"),
        pytest.param("week", 1, None, id="bad-scope"),
    ],
)
def test_normalize_result_checks(
    cfg: config.Config, scope: str, ok: int, error_code: str | None
):
    with store.write_session(cfg) as conn, pytest.raises(sqlite3.IntegrityError):
        conn.execute(
            "INSERT INTO normalize_result VALUES (?, ?, 'rhr_day', ?, ?, 1, 2)",
            (scope, D1, ok, error_code),
        )


def test_normalize_result_primary_key(cfg: config.Config):
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO normalize_result VALUES ('day', ?, 'rhr_day', 1, NULL, 1, 2)",
            (D1,),
        )
        with pytest.raises(sqlite3.IntegrityError):
            conn.execute(
                "INSERT INTO normalize_result VALUES ('day', ?, 'rhr_day', 0, 'internal', 3, 4)",
                (D1,),
            )


# --- 기본·다시 실행·원본 바뀜 ------------------------------------------------------------------


def test_basic_day_is_normalized(cfg: config.Config):
    _put(cfg, _day())
    before = _raw_snapshot(cfg)

    assert _run(cfg) == normalize.Summary(processed=4, failed=0)

    assert _metrics(cfg) == {D1: EXPECTED}
    assert _results(cfg) == [
        ("day", D1, endpoint, 1, None, FETCHED, CLOCK_MS) for endpoint in BASE_ENDPOINTS
    ]
    assert _raw_snapshot(cfg) == before


def test_rerun_without_changes_does_nothing(cfg: config.Config, clock: list[datetime]):
    _put(cfg, _day())
    _run(cfg)
    clock[0] = CLOCK + timedelta(hours=1)

    assert _run(cfg) == normalize.Summary(processed=0, failed=0)

    assert {row[6] for row in _results(cfg)} == {CLOCK_MS}
    assert _metrics(cfg) == {D1: EXPECTED}


def test_changed_raw_reprocesses_only_that_item(
    cfg: config.Config, clock: list[datetime]
):
    _put(cfg, _day())
    _run(cfg)
    later = CLOCK + timedelta(hours=1)
    clock[0] = later
    _put(
        cfg,
        [("day", D1, "user_summary", _user_summary(totalSteps=9000))],
        now_ms=FETCHED + 5,
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _metrics(cfg) == {D1: EXPECTED | {"steps": 9000}}
    later_ms = int(later.timestamp() * 1000)
    assert _results(cfg) == [
        ("day", D1, "hrv_data", 1, None, FETCHED, CLOCK_MS),
        ("day", D1, "rhr_day", 1, None, FETCHED, CLOCK_MS),
        ("day", D1, "training_readiness", 1, None, FETCHED, CLOCK_MS),
        ("day", D1, "user_summary", 1, None, FETCHED + 5, later_ms),
    ]


def test_unchanged_upsert_keeps_work_set_empty(cfg: config.Config):
    # 같은 원문을 다시 받으면 `checked_at`만 바뀌고 `fetched_at`은 그대로라 다시 처리하지 않는다.
    _put(cfg, _day())
    _run(cfg)
    _put(cfg, _day(), now_ms=FETCHED + 99)

    assert _run(cfg) == normalize.Summary(processed=0, failed=0)


def test_items_are_processed_in_key_endpoint_order(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
):
    seen: list[tuple[str, str]] = []
    for endpoint, rule in list(normalize.NORMALIZERS.items()):

        def spy(raw: str, key: str, *, _endpoint=endpoint, _parse=rule.parse):
            seen.append((key, _endpoint))
            return _parse(raw, key)

        # `_replace`로 다른 필드(`sample_table`)를 보존한다.
        monkeypatch.setitem(normalize.NORMALIZERS, endpoint, rule._replace(parse=spy))
    _put(
        cfg,
        [
            *_day(D2),
            *_sleep_stress_bb(D2),
            ("day", D2, "heart_rates", _heart_rates()),
            *_day(D1),
            *_sleep_stress_bb(D1),
            ("day", D1, "heart_rates", _heart_rates()),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=16, failed=0)

    assert seen == [(day, endpoint) for day in (D1, D2) for endpoint in ENDPOINTS]
    assert _samples(cfg, D1) == _samples(cfg, D2) == BB_SAMPLES
    assert _hr_samples(cfg, D1) == _hr_samples(cfg, D2) == HR_SAMPLES


# --- null·센티넬·빈 준비도 ---------------------------------------------------------------------


def test_null_raw_without_row_creates_no_row(cfg: config.Config):
    _put(cfg, [("day", D1, "hrv_data", None)])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _metrics(cfg) == {}
    assert _results(cfg) == [("day", D1, "hrv_data", 1, None, FETCHED, CLOCK_MS)]


def test_null_raw_clears_only_its_columns(cfg: config.Config):
    _put(cfg, [*_day(), ("day", D2, "hrv_data", None)])

    assert _run(cfg) == normalize.Summary(processed=5, failed=0)

    assert _metrics(cfg) == {D1: EXPECTED}


def test_null_raw_after_data_clears_existing_values(cfg: config.Config):
    # 일시적인 빈 응답은 `upsert_raw`가 원문을 지우지 않으므로 직접 'null'로 바꿔 본다.
    _put(cfg, _day())
    _run(cfg)
    _put_text(cfg, D1, "hrv_data", "null", now_ms=FETCHED + 1)

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _metrics(cfg) == {D1: EXPECTED | _nulls(daily.HRV_DATA_COLUMNS)}


def test_negative_sentinels_and_missing_resting_value_are_null(cfg: config.Config):
    _put(
        cfg,
        [
            (
                "day",
                D1,
                "user_summary",
                _user_summary(minHeartRate=-1, totalSteps=None),
            ),
            ("day", D1, "rhr_day", _rhr_day(D1, [{"value": 60.0, "calendarDate": D0}])),
            ("day", D2, "rhr_day", _rhr_day(D2, [{"value": None, "calendarDate": D2}])),
            ("day", D0, "rhr_day", _rhr_day(D0, [])),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=4, failed=0)

    metrics = _metrics(cfg)
    assert metrics[D1]["min_hr"] is None
    assert metrics[D1]["steps"] is None
    assert metrics[D1]["max_hr"] == 151
    assert metrics[D1]["resting_hr"] is None
    assert metrics[D2]["resting_hr"] is None
    assert metrics[D0]["resting_hr"] is None
    assert {row[3] for row in _results(cfg)} == {1}


def test_empty_readiness_is_null(cfg: config.Config):
    _put(cfg, [("day", D1, "training_readiness", [])])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _metrics(cfg) == {D1: _nulls(ALL_COLUMNS)}
    assert _results(cfg) == [
        ("day", D1, "training_readiness", 1, None, FETCHED, CLOCK_MS)
    ]


# --- 실패 격리·복구 ----------------------------------------------------------------------------


def test_structure_change_fails_only_that_item(
    cfg: config.Config, caplog: pytest.LogCaptureFixture
):
    caplog.set_level(logging.INFO, logger="garmin_pipeline.normalize")
    broken = {"userProfileId": 1, "메모": MARKER}
    _put(cfg, [*_day(D1), *_day(D2), ("day", D1, "rhr_day", broken)])
    # 위 _put은 같은 행을 두 번 쓰지만 마지막 원문(broken)이 남는다(다른 내용이라 교체된다).

    assert _run(cfg) == normalize.Summary(processed=8, failed=1)

    metrics = _metrics(cfg)
    assert metrics[D1] == EXPECTED | {"resting_hr": None}
    assert metrics[D2] == EXPECTED
    results = _results(cfg)
    assert ("day", D1, "rhr_day", 0, "parse_error", FETCHED, CLOCK_MS) in results
    assert sum(row[3] for row in results) == 7
    warnings = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert warnings == [
        f"정규화 실패: scope=day key={D1} endpoint=rhr_day error_code=parse_error"
    ]
    assert MARKER not in caplog.text
    assert "allMetrics" not in caplog.text


def test_failure_clears_previous_values_and_refills(cfg: config.Config):
    _put(cfg, _day())
    _run(cfg)
    _put(cfg, [("day", D1, "rhr_day", {"userProfileId": 1})], now_ms=FETCHED + 1)

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)
    assert _metrics(cfg) == {D1: EXPECTED | {"resting_hr": None}}
    assert ("day", D1, "rhr_day", 0, "parse_error", FETCHED + 1, CLOCK_MS) in _results(
        cfg
    )

    # 실패한 항목은 원문이 바뀌기 전에는 다시 처리하지 않는다.
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)

    _put(cfg, [("day", D1, "rhr_day", _rhr_day(D1))], now_ms=FETCHED + 2)

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)
    assert _metrics(cfg) == {D1: EXPECTED}
    assert ("day", D1, "rhr_day", 1, None, FETCHED + 2, CLOCK_MS) in _results(cfg)


def test_failure_without_row_creates_no_row(cfg: config.Config):
    _put_text(cfg, D1, "user_summary", f"not json {MARKER}")

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    assert _metrics(cfg) == {}
    assert _results(cfg) == [
        ("day", D1, "user_summary", 0, "parse_error", FETCHED, CLOCK_MS)
    ]


def test_unexpected_exception_is_internal_and_rolled_back(
    cfg: config.Config,
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
):
    caplog.set_level(logging.WARNING, logger="garmin_pipeline.normalize")
    _put(cfg, _day())
    _run(cfg)
    _put(cfg, [("day", D1, "hrv_data", _hrv_data(weeklyAvg=50))], now_ms=FETCHED + 1)

    def explode(raw: str, key: str) -> dict[str, daily.Value]:
        raise RuntimeError(f"boom {MARKER}")

    monkeypatch.setitem(
        normalize.NORMALIZERS,
        "hrv_data",
        normalize.Normalizer(daily.HRV_DATA_COLUMNS, explode),
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    assert _metrics(cfg) == {D1: EXPECTED | _nulls(daily.HRV_DATA_COLUMNS)}
    assert ("day", D1, "hrv_data", 0, "internal", FETCHED + 1, CLOCK_MS) in _results(
        cfg
    )
    assert MARKER not in caplog.text
    assert "error_code=internal" in caplog.text


def test_parser_returning_wrong_columns_is_internal(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
):
    # 파서가 돌려준 열이 소유 열과 다르면 아무것도 쓰기 전에 `internal`로 실패한다(행을 만들지 않는다).
    def wrong(raw: str, key: str) -> dict[str, daily.Value]:
        return {"steps": 1}

    monkeypatch.setitem(
        normalize.NORMALIZERS,
        "rhr_day",
        normalize.Normalizer(daily.RHR_DAY_COLUMNS, wrong),
    )
    _put(cfg, [("day", D1, "rhr_day", _rhr_day())])

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    assert _metrics(cfg) == {}
    assert _results(cfg)[0][3:5] == (0, "internal")


def test_failure_after_write_rolls_back_the_item(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
):
    # `daily_metric`을 쓴 뒤 결과 기록에서 실패해도 그 항목의 쓰기는 모두 롤백된다.
    real_record = normalize._record

    def failing_record(conn, item, *, ok, error_code):
        if ok:
            raise sqlite3.OperationalError("disk I/O error")
        real_record(conn, item, ok=ok, error_code=error_code)

    # 새 날: 행이 생기지 않는다.
    _put(cfg, [("day", D2, "user_summary", _user_summary())])
    monkeypatch.setattr(normalize, "_record", failing_record)
    with pytest.raises(sqlite3.OperationalError):
        _run(cfg)
    assert _metrics(cfg) == {}
    assert _results(cfg) == []

    # 있는 날: 이전 값이 그대로 남는다.
    monkeypatch.setattr(normalize, "_record", real_record)
    _put(cfg, _day(D1))
    _run(cfg)
    before = _metrics(cfg)
    assert before[D1] == EXPECTED
    _put(
        cfg,
        [("day", D1, "user_summary", _user_summary(totalSteps=9000))],
        now_ms=FETCHED + 1,
    )
    monkeypatch.setattr(normalize, "_record", failing_record)
    with pytest.raises(sqlite3.OperationalError):
        _run(cfg)
    assert _metrics(cfg) == before
    assert ("day", D1, "user_summary", 1, None, FETCHED, CLOCK_MS) in _results(cfg)


def test_sqlite_error_propagates(cfg: config.Config, monkeypatch: pytest.MonkeyPatch):
    def broken_db(raw: str, key: str) -> dict[str, daily.Value]:
        raise sqlite3.OperationalError("disk I/O error")

    monkeypatch.setitem(
        normalize.NORMALIZERS,
        "user_summary",
        normalize.Normalizer(daily.USER_SUMMARY_COLUMNS, broken_db),
    )
    _put(cfg, _day())
    _set_version(cfg)

    with pytest.raises(sqlite3.OperationalError):
        _run(cfg)

    # 증분: 앞선 항목(hrv_data·rhr_day·training_readiness)은 커밋됐고 실패 항목은 기록이 없다.
    assert [row[2] for row in _results(cfg)] == [
        "hrv_data",
        "rhr_day",
        "training_readiness",
    ]


# --- 수면·스트레스·Body Battery -----------------------------------------------------------------

WAKE_CANDIDATE_SQL = (
    "SELECT s.level FROM body_battery_sample s JOIN daily_metric d ON d.day_key = s.day_key"
    " WHERE s.day_key = :day AND s.level IS NOT NULL AND s.ts_ms <= d.sleep_end_ms"
    " ORDER BY s.ts_ms DESC LIMIT 1"
)


def test_sleep_stress_body_battery_day_is_normalized(cfg: config.Config):
    _put(cfg, [*_day(), *_sleep_stress_bb()])

    assert _run(cfg) == normalize.Summary(processed=7, failed=0)

    assert _metrics(cfg) == {
        D1: EXPECTED | SLEEP_EXPECTED | STRESS_EXPECTED | BB_EXPECTED
    }
    assert _samples(cfg) == BB_SAMPLES
    assert _results(cfg) == [
        ("day", D1, endpoint, 1, None, FETCHED, CLOCK_MS)
        for endpoint in ENDPOINTS
        if endpoint != "heart_rates"
    ]


def test_wake_body_battery_candidate_query(cfg: config.Config):
    # 기상 시각 샘플은 level이 null이라 그 직전(30분 전) 샘플 61이 후보다. 기상 뒤 샘플(56)은 빠진다.
    _put(cfg, _sleep_stress_bb())
    _run(cfg)

    assert _query(cfg, WAKE_CANDIDATE_SQL, {"day": D1}) == [(61,)]


def test_no_sleep_day_is_null_and_ok(cfg: config.Config):
    _put(
        cfg, [("day", D1, "sleep_data", {"dailySleepDTO": {"sleepTimeSeconds": None}})]
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _metrics(cfg) == {D1: _nulls(ALL_COLUMNS)}
    assert _results(cfg) == [("day", D1, "sleep_data", 1, None, FETCHED, CLOCK_MS)]


def test_missing_sleep_score_keeps_other_values(cfg: config.Config):
    _put(cfg, [("day", D1, "sleep_data", _sleep_data(sleepScores=None))])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _metrics(cfg)[D1] == _nulls(ALL_COLUMNS) | SLEEP_EXPECTED | {
        "sleep_score": None
    }


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param(_stress_data([-1, -2]), id="all-sentinels"),
        pytest.param(_stress_data(stressValuesArray=None), id="array-null"),
    ],
)
def test_stress_without_valid_samples_is_null(cfg: config.Config, payload: dict):
    _put(cfg, [("day", D1, "stress_data", payload)])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _metrics(cfg) == {D1: _nulls(ALL_COLUMNS)}
    assert _results(cfg)[0][3:5] == (1, None)


def test_daily_stress_average_skips_null_day(cfg: config.Config):
    _put(
        cfg,
        [
            ("day", D0, "stress_data", _stress_data([20, 40])),
            ("day", D1, "stress_data", _stress_data([-1, -2, None])),
            ("day", D2, "stress_data", _stress_data([50, -1, 70])),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=3, failed=0)

    assert _query(
        cfg, "SELECT day_key, stress_avg FROM daily_metric ORDER BY day_key"
    ) == [
        (D0, 30),
        (D1, None),
        (D2, 60),
    ]
    assert _query(cfg, "SELECT AVG(stress_avg) FROM daily_metric") == [(45.0,)]


def test_renormalize_replaces_samples_of_that_day_only(cfg: config.Config):
    _put(
        cfg,
        [
            ("day", D1, "body_battery", _body_battery(D1)),
            ("day", D2, "body_battery", _body_battery(D2)),
        ],
    )
    _run(cfg)
    fewer = [[SLEEP_START + MINUTE_MS, 33], [SLEEP_END, 70]]
    _put(
        cfg, [("day", D1, "body_battery", _body_battery(D1, fewer))], now_ms=FETCHED + 1
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _samples(cfg, D1) == [(SLEEP_START + MINUTE_MS, 33), (SLEEP_END, 70)]
    assert _samples(cfg, D2) == BB_SAMPLES
    assert _metrics(cfg)[D1] == _nulls(ALL_COLUMNS) | BB_EXPECTED | {
        "bb_high": 70,
        "bb_low": 33,
    }


def test_null_body_battery_clears_samples_and_columns(cfg: config.Config):
    _put(cfg, _sleep_stress_bb())
    _run(cfg)
    _put_text(cfg, D1, "body_battery", "null", now_ms=FETCHED + 1)

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _samples(cfg) == []
    assert _metrics(cfg)[D1] == _nulls(ALL_COLUMNS) | SLEEP_EXPECTED | STRESS_EXPECTED
    assert ("day", D1, "body_battery", 1, None, FETCHED + 1, CLOCK_MS) in _results(cfg)


def test_failed_body_battery_clears_samples_and_columns(cfg: config.Config):
    _put(cfg, _sleep_stress_bb())
    _run(cfg)
    broken = _body_battery(bodyBatteryValueDescriptorDTOList=None)
    _put(cfg, [("day", D1, "body_battery", broken)], now_ms=FETCHED + 1)

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    assert _samples(cfg) == []
    assert _metrics(cfg)[D1] == _nulls(ALL_COLUMNS) | SLEEP_EXPECTED | STRESS_EXPECTED
    assert ("day", D1, "body_battery", 0, "parse_error", FETCHED + 1, CLOCK_MS) in (
        _results(cfg)
    )


def test_internal_failure_clears_samples(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
):
    _put(cfg, _sleep_stress_bb())
    _run(cfg)
    rule = normalize.NORMALIZERS["body_battery"]
    assert rule.sample_table is not None

    def explode(raw: str, key: str) -> list[daily.Sample]:
        raise RuntimeError(f"boom {MARKER}")

    monkeypatch.setitem(
        normalize.NORMALIZERS,
        "body_battery",
        rule._replace(sample_table=rule.sample_table._replace(parse=explode)),
    )
    _put(
        cfg, [("day", D1, "body_battery", _body_battery(charged=1))], now_ms=FETCHED + 1
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    assert _samples(cfg) == []
    assert _metrics(cfg)[D1]["bb_charged"] is None
    assert ("day", D1, "body_battery", 0, "internal", FETCHED + 1, CLOCK_MS) in (
        _results(cfg)
    )


def test_duplicate_timestamp_fails_only_that_item(cfg: config.Config):
    duplicated = [[SLEEP_START, 20], [SLEEP_END, 30], [SLEEP_START, 40]]
    _put(
        cfg,
        [
            *_sleep_stress_bb(D1),
            ("day", D1, "body_battery", _body_battery(D1, duplicated)),
            ("day", D2, "body_battery", _body_battery(D2)),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=4, failed=1)

    assert ("day", D1, "body_battery", 0, "parse_error", FETCHED, CLOCK_MS) in (
        _results(cfg)
    )
    assert _samples(cfg, D1) == []
    assert _samples(cfg, D2) == BB_SAMPLES
    metrics = _metrics(cfg)
    assert metrics[D1] == _nulls(ALL_COLUMNS) | SLEEP_EXPECTED | STRESS_EXPECTED
    assert metrics[D2] == _nulls(ALL_COLUMNS) | BB_EXPECTED


# --- 실제 Garmin 응답 모양(완전 중복 샘플·빈 모양 응답) ---------------------------------------

# 시계를 안 찬 날의 빈 모양: descriptor 목록이 null이고 행은 `[ts, null]`이다.
EMPTY_BB_VALUES = [[SLEEP_START, None], [SLEEP_END, None]]
EMPTY_RHR_DAY = {"userProfileId": 1, "allMetrics": {"metricsMap": {}}}


def _empty_body_battery(
    day: str = D1, values: list[object] | None = None
) -> list[dict[str, object]]:
    return _body_battery(
        day,
        EMPTY_BB_VALUES if values is None else values,
        charged=None,
        drained=None,
        bodyBatteryValueDescriptorDTOList=None,
    )


def _sleep_without_scores() -> dict[str, object]:
    payload = _sleep_data()
    dto = payload["dailySleepDTO"]
    assert isinstance(dto, dict)
    del dto["sleepScores"]
    return payload


# 같은 시각·같은 원문 값이 인접하거나 떨어져 다시 온다(null끼리도 같다).
BB_EXACT_DUPLICATES = [
    BB_VALUES[0],
    BB_VALUES[0],
    BB_VALUES[1],
    BB_VALUES[2],
    BB_VALUES[3],
    BB_VALUES[2],
    BB_VALUES[1],
]


def test_exact_duplicate_samples_keep_first():
    raw = json.dumps(_body_battery(values=BB_EXACT_DUPLICATES))
    assert daily.body_battery_samples(raw, D1) == BB_SAMPLES
    assert daily.body_battery(raw, D1) == BB_EXPECTED
    # 55와 55.0은 원문 값이 같다(`==`). 첫 샘플을 남긴다.
    same = _body_battery(values=[[SLEEP_START, 55], [SLEEP_START, 55.0]])
    assert daily.body_battery_samples(json.dumps(same), D1) == [(SLEEP_START, 55)]
    hr = _heart_rates([*HR_VALUES, HR_VALUES[0], HR_VALUES[1]])
    assert daily.heart_rate_samples(json.dumps(hr), D1) == HR_SAMPLES


@pytest.mark.parametrize(
    ("first", "second"),
    [
        pytest.param(20, 40, id="numbers"),
        pytest.param(None, -1, id="null-vs-sentinel"),
        pytest.param(-1, None, id="sentinel-vs-null"),
        pytest.param(-1, -2, id="two-sentinels"),
        pytest.param(55.2, 55.4, id="same-after-round"),
        pytest.param(None, 55, id="null-vs-number"),
        pytest.param([55, 1], [55, 2], id="other-column-differs"),
    ],
)
def test_duplicate_with_different_values_fails(first: object, second: object):
    # 리스트면 `[값, 다른 열]`이다. 값은 같아도 다른 열이 다르면 완전 중복이 아니다.
    def row(value: object) -> list[object]:
        return (
            [SLEEP_START, *value] if isinstance(value, list) else [SLEEP_START, value]
        )

    values = [row(first), [SLEEP_END, 30, 0], row(second)]
    with pytest.raises(daily.NormalizeParseError, match="시각이 중복이다"):
        daily.body_battery_samples(json.dumps(_body_battery(values=values)), D1)
    with pytest.raises(daily.NormalizeParseError, match="시각이 중복이다"):
        daily.heart_rate_samples(json.dumps(_heart_rates(values)), D1)


@pytest.mark.parametrize(
    "values",
    [
        pytest.param(EMPTY_BB_VALUES, id="ts-null"),
        pytest.param([[SLEEP_START], [SLEEP_END]], id="ts-only"),
        pytest.param([[0, None]], id="ts-zero"),
    ],
)
def test_empty_shape_samples_are_no_samples(values: list[object]):
    raw = json.dumps(_empty_body_battery(values=values))
    assert daily.body_battery_samples(raw, D1) == []
    assert daily.body_battery(raw, D1) == _nulls(daily.BODY_BATTERY_COLUMNS)
    hr = _heart_rates(values, heartRateValueDescriptors=None)
    assert daily.heart_rate_samples(json.dumps(hr), D1) == []


@pytest.mark.parametrize(
    "values",
    [
        pytest.param([[None, 55]], id="null-ts-with-value"),
        pytest.param([["x", None]], id="string-ts"),
        pytest.param([[True, None]], id="bool-ts"),
        pytest.param([[-5, None]], id="negative-ts"),
        pytest.param([[1.5, None]], id="float-ts"),
        pytest.param([[]], id="empty-row"),
        pytest.param([[None]], id="null-only-row"),
        pytest.param([5], id="row-not-list"),
        pytest.param([[SLEEP_START, None, 3]], id="extra-value"),
        pytest.param(BB_VALUES, id="values-with-numbers"),
        pytest.param([[SLEEP_START, None], [SLEEP_END, 55]], id="one-row-with-value"),
    ],
)
def test_values_with_null_descriptors_still_fail(values: list[object]):
    raw = json.dumps(_empty_body_battery(values=values))
    with pytest.raises(daily.NormalizeParseError, match="DescriptorDTOList"):
        daily.body_battery_samples(raw, D1)
    hr = _heart_rates(values, heartRateValueDescriptors=None)
    with pytest.raises(daily.NormalizeParseError, match="heartRateValueDescriptors"):
        daily.heart_rate_samples(json.dumps(hr), D1)


def test_empty_resting_heart_rate_map_is_null():
    assert daily.rhr_day(json.dumps(EMPTY_RHR_DAY), D1) == {"resting_hr": None}
    renamed = {"allMetrics": {"metricsMap": {"WELLNESS_OTHER": []}}}
    with pytest.raises(
        daily.NormalizeParseError,
        match="allMetrics.metricsMap.WELLNESS_RESTING_HEART_RATE 키가 없다",
    ):
        daily.rhr_day(json.dumps(renamed), D1)


def test_missing_sleep_scores_key_is_null_score():
    assert daily.sleep_data(json.dumps(_sleep_without_scores()), D1) == (
        SLEEP_EXPECTED | {"sleep_score": None}
    )


def test_real_garmin_shapes_normalize_ok(cfg: config.Config):
    _put(
        cfg,
        [
            ("day", D1, "body_battery", _body_battery(D1, BB_EXACT_DUPLICATES)),
            ("day", D1, "heart_rates", _heart_rates([*HR_VALUES, HR_VALUES[2]])),
            ("day", D2, "body_battery", _empty_body_battery(D2)),
            ("day", D2, "rhr_day", EMPTY_RHR_DAY),
            ("day", D2, "sleep_data", _sleep_without_scores()),
            (
                "day",
                D2,
                "heart_rates",
                _heart_rates(EMPTY_BB_VALUES, heartRateValueDescriptors=None),
            ),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=6, failed=0)

    assert all(row[3] == 1 and row[4] is None for row in _results(cfg))
    # 완전 중복은 중복이 없을 때와 같은 열·샘플이다.
    assert _samples(cfg, D1) == BB_SAMPLES
    assert _hr_samples(cfg, D1) == HR_SAMPLES
    assert _samples(cfg, D2) == []
    assert _hr_samples(cfg, D2) == []
    assert _metrics(cfg) == {
        D1: _nulls(ALL_COLUMNS) | BB_EXPECTED,
        D2: _nulls(ALL_COLUMNS) | SLEEP_EXPECTED | {"sleep_score": None},
    }


@pytest.mark.parametrize(
    ("endpoint", "payload"),
    [
        pytest.param(
            "body_battery",
            _body_battery(D1, [[SLEEP_START, None], [SLEEP_START, -1]]),
            id="bb-different-duplicate",
        ),
        pytest.param(
            "body_battery",
            _empty_body_battery(D1, [[None, 55]]),
            id="bb-value-with-null-descriptors",
        ),
        pytest.param(
            "heart_rates",
            _heart_rates([[HR_START, -1], [HR_START, -2]]),
            id="hr-different-duplicate",
        ),
        pytest.param(
            "rhr_day",
            {"allMetrics": {"metricsMap": {"WELLNESS_OTHER": []}}},
            id="rhr-renamed",
        ),
    ],
)
def test_shapes_outside_the_rule_fail_only_that_item(
    cfg: config.Config, endpoint: str, payload: object
):
    _put(
        cfg,
        [
            ("day", D1, endpoint, payload),
            ("day", D1, "sleep_data", _sleep_data()),
            ("day", D2, "body_battery", _empty_body_battery(D2)),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=3, failed=1)

    assert ("day", D1, endpoint, 0, "parse_error", FETCHED, CLOCK_MS) in _results(cfg)
    assert ("day", D1, "sleep_data", 1, None, FETCHED, CLOCK_MS) in _results(cfg)
    assert ("day", D2, "body_battery", 1, None, FETCHED, CLOCK_MS) in _results(cfg)
    assert _samples(cfg, D1) == []
    assert _hr_samples(cfg, D1) == []
    assert _metrics(cfg)[D1] == _nulls(ALL_COLUMNS) | SLEEP_EXPECTED


def test_version_bump_rebuild_fills_previous_shape_failures(cfg: config.Config):
    # 버전 1 코드가 실패로 남긴 DB: 원문은 그대로이고 결과가 `ok=0`, 파생 값은 비어 있다.
    _put(
        cfg,
        [
            ("day", D1, "body_battery", _body_battery(D1, BB_EXACT_DUPLICATES)),
            ("day", D2, "body_battery", _empty_body_battery(D2)),
            ("day", D2, "rhr_day", EMPTY_RHR_DAY),
            ("day", D2, "sleep_data", _sleep_without_scores()),
        ],
    )
    _run(cfg)
    with store.write_session(cfg) as conn:
        conn.execute("UPDATE normalize_result SET ok = 0, error_code = 'parse_error'")
        conn.execute("DELETE FROM body_battery_sample")
        conn.execute("DELETE FROM daily_metric")
    _set_version(cfg, "1")
    assert {row[3] for row in _results(cfg)} == {0}

    assert _run(cfg) == normalize.Summary(processed=4, failed=0)

    assert {(row[3], row[4]) for row in _results(cfg)} == {(1, None)}
    assert _samples(cfg, D1) == BB_SAMPLES
    assert _metrics(cfg)[D1] == _nulls(ALL_COLUMNS) | BB_EXPECTED
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}


def test_morning_readiness_is_chosen(cfg: config.Config):
    readiness = [
        {"timestamp": f"{D1}T05:10:00.0", "score": 40, "level": "LOW"},
        {
            "timestamp": f"{D1}T06:45:00.0",
            "score": 77.6,
            "level": "MODERATE",
            "inputContext": "AFTER_WAKEUP_RESET",
        },
    ]
    _put(cfg, [("day", D1, "training_readiness", readiness)])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _metrics(cfg)[D1] == _nulls(ALL_COLUMNS) | {
        "readiness_score": 78,
        "readiness_level": "MODERATE",
    }


def test_version_6_db_migrates_and_normalizes_new_endpoints(cfg: config.Config):
    # 3.1까지의 DB: 0001~0006만 적용되고 정규화된 3.1 행과 아직 정규화하지 않은 3.2 원문이 있다.
    migrations = Path(store.__file__).parent / "migrations"
    cfg.data_dir.mkdir(parents=True)
    raw = sqlite3.connect(cfg.db_path)
    try:
        for name in (
            "0001_auth_event.sql",
            "0002_raw_response.sql",
            "0003_run_fetch_error.sql",
            "0004_meta.sql",
            "0005_notification.sql",
            "0006_normalize.sql",
        ):
            raw.executescript((migrations / name).read_text(encoding="utf-8"))
        old = {c: v for c, v in EXPECTED.items() if c not in NEW_COLUMNS}
        raw.execute(
            f"INSERT INTO daily_metric (day_key, {', '.join(old)})"
            f" VALUES (?, {', '.join('?' for _ in old)})",
            (D1, *old.values()),
        )
        for _, key, endpoint, payload in [*_day(D1), *_sleep_stress_bb(D1)]:
            raw.execute(
                "INSERT INTO raw_response VALUES ('day', ?, ?, ?, ?, ?, ?)",
                (key, endpoint, json.dumps(payload), FETCHED, FETCHED, VERSION),
            )
        for endpoint in BASE_ENDPOINTS:
            raw.execute(
                "INSERT INTO normalize_result VALUES ('day', ?, ?, 1, NULL, ?, ?)",
                (D1, endpoint, FETCHED, FETCHED),
            )
        # 증분을 보려고 정규화 버전을 코드 값으로 맞춘다(없으면 재구성한다).
        raw.execute(
            "INSERT INTO meta VALUES (?, ?)",
            (normalize.NORMALIZE_VERSION_KEY, str(normalize.NORMALIZE_VERSION)),
        )
        raw.execute("PRAGMA user_version = 6")
        raw.commit()
    finally:
        raw.close()

    assert _run(cfg) == normalize.Summary(processed=3, failed=0)

    assert _query(cfg, "PRAGMA user_version") == [(schema_version.LATEST,)]
    assert _metrics(cfg) == {
        D1: EXPECTED | SLEEP_EXPECTED | STRESS_EXPECTED | BB_EXPECTED
    }
    assert _samples(cfg) == BB_SAMPLES
    assert _results(cfg) == [
        (
            "day",
            D1,
            endpoint,
            1,
            None,
            FETCHED,
            FETCHED if endpoint in BASE_ENDPOINTS else CLOCK_MS,
        )
        for endpoint in ENDPOINTS
        if endpoint != "heart_rates"
    ]


def test_body_battery_samples_parser():
    raw = json.dumps(_body_battery())

    assert daily.body_battery_samples(raw, D1) == BB_SAMPLES
    assert daily.body_battery_samples(raw, D0) == []
    reordered = _body_battery(
        values=[[61, SLEEP_END], [None, SLEEP_START]],
        bodyBatteryValueDescriptorDTOList=[
            {
                "bodyBatteryValueDescriptorIndex": 1,
                "bodyBatteryValueDescriptorKey": "timestamp",
            },
            {
                "bodyBatteryValueDescriptorIndex": 0,
                "bodyBatteryValueDescriptorKey": "bodyBatteryLevel",
            },
        ],
    )
    assert daily.body_battery_samples(json.dumps(reordered), D1) == [
        (SLEEP_END, 61),
        (SLEEP_START, None),
    ]
    assert (
        daily.body_battery_samples(
            json.dumps(_body_battery(bodyBatteryValuesArray=None)), D1
        )
        == []
    )


# --- 일일 심박 시계열 -------------------------------------------------------------------------

# README `## normalize`에 그대로 적는 샘플 간격 측정 SQL.
GAP_SQL = """SELECT gap_ms, COUNT(*) AS n FROM (
  SELECT ts_ms - LAG(ts_ms) OVER (PARTITION BY day_key ORDER BY ts_ms) AS gap_ms
  FROM hr_sample WHERE bpm IS NOT NULL
) WHERE gap_ms IS NOT NULL GROUP BY gap_ms ORDER BY n DESC, gap_ms LIMIT 5"""


def test_heart_rates_day_is_normalized_without_daily_metric_row(cfg: config.Config):
    _put(cfg, [("day", D1, "heart_rates", _heart_rates())])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _hr_samples(cfg) == HR_SAMPLES
    assert _metrics(cfg) == {}
    assert _results(cfg) == [("day", D1, "heart_rates", 1, None, FETCHED, CLOCK_MS)]


def test_heart_rates_leaves_existing_daily_metric_row_unchanged(cfg: config.Config):
    _put(cfg, _day())
    _run(cfg)
    _put(cfg, [("day", D1, "heart_rates", _heart_rates())])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)
    assert _metrics(cfg) == {D1: EXPECTED}

    # 실패해도 daily_metric은 그대로다.
    broken = _heart_rates(heartRateValueDescriptors=None)
    _put(cfg, [("day", D1, "heart_rates", broken)], now_ms=FETCHED + 1)

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)
    assert _metrics(cfg) == {D1: EXPECTED}
    assert _hr_samples(cfg) == []

    # 샘플이 있던 날 원문이 null이 돼도 daily_metric은 그대로이고 샘플만 지운다.
    _put(cfg, [("day", D1, "heart_rates", _heart_rates())], now_ms=FETCHED + 2)
    assert _run(cfg) == normalize.Summary(processed=1, failed=0)
    assert _hr_samples(cfg) == HR_SAMPLES
    _put_text(cfg, D1, "heart_rates", "null", now_ms=FETCHED + 3)

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)
    assert _metrics(cfg) == {D1: EXPECTED}
    assert _hr_samples(cfg) == []


def test_heart_rate_sentinel_and_zero_are_null(cfg: config.Config):
    values = [[HR_START, -1], [HR_START + TWO_MINUTES_MS, 0]]
    _put(cfg, [("day", D1, "heart_rates", _heart_rates(values))])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _hr_samples(cfg) == [(HR_START, None), (HR_START + TWO_MINUTES_MS, None)]


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param(
            _heart_rates(heartRateValues=None, heartRateValueDescriptors=None),
            id="values-null",
        ),
        pytest.param(
            _heart_rates(heartRateValues=[], heartRateValueDescriptors=None),
            id="values-empty",
        ),
    ],
)
def test_heart_rates_without_samples_is_ok(cfg: config.Config, payload: dict):
    _put(cfg, [("day", D1, "heart_rates", payload)])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _hr_samples(cfg) == []
    assert _metrics(cfg) == {}
    assert _results(cfg)[0][3:5] == (1, None)


def test_renormalize_replaces_heart_rate_samples_of_that_day_only(cfg: config.Config):
    _put(
        cfg,
        [
            ("day", D1, "heart_rates", _heart_rates()),
            ("day", D2, "heart_rates", _heart_rates()),
        ],
    )
    _run(cfg)
    fewer = [[HR_START, 90], [HR_START + 3 * MINUTE_MS, 80.4]]
    _put(cfg, [("day", D1, "heart_rates", _heart_rates(fewer))], now_ms=FETCHED + 1)

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _hr_samples(cfg, D1) == [(HR_START, 90), (HR_START + 3 * MINUTE_MS, 80)]
    assert _hr_samples(cfg, D2) == HR_SAMPLES


def test_null_heart_rates_clears_samples(cfg: config.Config):
    _put(cfg, [("day", D1, "heart_rates", _heart_rates())])
    _run(cfg)
    _put_text(cfg, D1, "heart_rates", "null", now_ms=FETCHED + 1)

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _hr_samples(cfg) == []
    assert _metrics(cfg) == {}
    assert ("day", D1, "heart_rates", 1, None, FETCHED + 1, CLOCK_MS) in _results(cfg)


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param(
            {k: v for k, v in _heart_rates().items() if k != "heartRateValues"},
            id="values-key-missing",
        ),
        pytest.param(
            {
                k: v
                for k, v in _heart_rates().items()
                if k != "heartRateValueDescriptors"
            },
            id="descriptors-key-missing",
        ),
        pytest.param(
            _heart_rates(heartRateValueDescriptors=None), id="descriptors-null"
        ),
        pytest.param(_heart_rates([[HR_START, 60], [HR_START + 1]]), id="short-sample"),
        pytest.param(_heart_rates([[1760000000000.0, 60]]), id="timestamp-float"),
        pytest.param(_heart_rates([[-1, 60]]), id="timestamp-negative"),
        pytest.param(_heart_rates([[True, 60]]), id="timestamp-bool"),
        pytest.param(
            _heart_rates([[HR_START, 60], [HR_START + 1, 61], [HR_START, 62]]),
            id="duplicate-timestamp",
        ),
    ],
)
def test_broken_heart_rates_fails_only_that_item(cfg: config.Config, payload: dict):
    _put(
        cfg,
        [
            ("day", D1, "heart_rates", _heart_rates()),
            ("day", D2, "heart_rates", _heart_rates()),
        ],
    )
    _run(cfg)
    _put(
        cfg,
        [
            ("day", D1, "heart_rates", payload),
            ("day", D1, "rhr_day", _rhr_day(D1)),
        ],
        now_ms=FETCHED + 1,
    )

    assert _run(cfg) == normalize.Summary(processed=2, failed=1)

    assert ("day", D1, "heart_rates", 0, "parse_error", FETCHED + 1, CLOCK_MS) in (
        _results(cfg)
    )
    assert ("day", D1, "rhr_day", 1, None, FETCHED + 1, CLOCK_MS) in _results(cfg)
    assert _hr_samples(cfg, D1) == []
    assert _hr_samples(cfg, D2) == HR_SAMPLES
    assert _metrics(cfg)[D1]["resting_hr"] == 52


def test_heart_rate_samples_parser():
    raw = json.dumps(_heart_rates())

    assert daily.heart_rate_samples(raw, D1) == HR_SAMPLES
    # 일 키 범위로 거르지 않는다: 다른 일 키로 읽어도 원문 샘플 그대로다.
    assert daily.heart_rate_samples(raw, D0) == HR_SAMPLES
    reordered = _heart_rates(
        [[bpm, ts] for ts, bpm in HR_VALUES],
        heartRateValueDescriptors=[
            {"key": "heartrate", "index": 0},
            {"key": "timestamp", "index": 1},
        ],
    )
    assert daily.heart_rate_samples(json.dumps(reordered), D1) == HR_SAMPLES
    # 원문 순서를 지킨다.
    shuffled = _heart_rates([HR_VALUES[2], HR_VALUES[0]])
    assert daily.heart_rate_samples(json.dumps(shuffled), D1) == [
        HR_SAMPLES[2],
        HR_SAMPLES[0],
    ]
    # bpm 0·음수·0.4(round → 0)는 None이다.
    edge = _heart_rates([[1, 0], [2, -1], [3, 0.4], [4, 0.6]])
    assert daily.heart_rate_samples(json.dumps(edge), D1) == [
        (1, None),
        (2, None),
        (3, None),
        (4, 1),
    ]
    assert daily.heart_rates(raw, D1) == {}
    assert daily.HEART_RATES_COLUMNS == ()


def test_heart_rate_gap_query(cfg: config.Config):
    # D1: 유효 샘플 사이 간격 120000 ms 4개 + 240000 ms 1개(가운데 null 샘플은 건너뛴다).
    # D2: 샘플 하나뿐이라 간격이 없다(날을 넘는 간격은 세지 않는다).
    two = 2 * MINUTE_MS
    d1 = [
        [HR_START, 60],
        [HR_START + two, 61],
        [HR_START + 2 * two, 62],
        [HR_START + 3 * two, 63],
        [HR_START + 4 * two, 64],
        [HR_START + 5 * two, None],
        [HR_START + 6 * two, 66],
    ]
    _put(
        cfg,
        [
            ("day", D1, "heart_rates", _heart_rates(d1)),
            ("day", D2, "heart_rates", _heart_rates([[HR_START + 7 * two, 70]])),
        ],
    )
    _run(cfg)

    rows = _query(cfg, GAP_SQL)
    assert rows[0] == (120_000, 4)
    assert rows == [(120_000, 4), (240_000, 1)]


def test_readme_documents_gap_query():
    readme = (ROOT / "README.md").read_text(encoding="utf-8")

    # README 목록 안의 코드 블록이라 4칸 들여 쓴다.
    assert textwrap.indent(GAP_SQL, "    ") in readme
    assert "0008_hr_sample" in readme
    assert "0009_activity" in readme
    assert "0010_activity_recovery" in readme
    assert "0012_drop_activity_recovery" in readme
    assert "0013_activity_body_battery" in readme


def test_console_script_normalizes_heart_rates(cfg: config.Config, tmp_path: Path):
    _put(
        cfg,
        [
            ("day", D1, "heart_rates", _heart_rates()),
            ("day", D2, "heart_rates", _heart_rates()),
        ],
    )
    script = shutil.which("garmin-pipeline", path=sysconfig.get_path("scripts"))
    assert script is not None, "콘솔 스크립트가 없다. `uv sync`를 먼저 실행한다."
    env = {key: value for key, value in os.environ.items() if key != "FORCE_COLOR"}
    env |= {"NO_COLOR": "1", "PYTHON_COLORS": "0"}

    def run() -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [script, "normalize", "--config", str(cfg.path)],
            cwd=tmp_path,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )

    first = run()

    assert first.returncode == 0, first.stderr
    assert first.stdout == "normalize: processed=2 failed=0\n"
    assert _hr_samples(cfg, D1) == _hr_samples(cfg, D2) == HR_SAMPLES
    assert _metrics(cfg) == {}

    changed = [[HR_START, 99], [HR_START + MINUTE_MS, 98.5], [HR_START + 5, None]]
    _put(cfg, [("day", D1, "heart_rates", _heart_rates(changed))], now_ms=FETCHED + 1)
    second = run()

    assert second.returncode == 0, second.stderr
    assert second.stdout == "normalize: processed=1 failed=0\n"
    assert _hr_samples(cfg, D1) == [
        (HR_START, 99),
        (HR_START + 5, None),
        (HR_START + MINUTE_MS, 98),
    ]
    assert _hr_samples(cfg, D2) == HR_SAMPLES


# --- 활동 요약·존별 시간·활동 심박 ----------------------------------------------------------


def _activity_results(cfg: config.Config) -> list[tuple]:
    return [row for row in _results(cfg) if row[0] == "activity"]


def test_activity_is_normalized_with_day_key_from_list(cfg: config.Config):
    _put(cfg, [_activity_list(D1, RUN_ID), *_activity_rows()])
    before = _raw_snapshot(cfg)

    assert _run(cfg) == normalize.Summary(processed=3, failed=0)

    assert _activities(cfg) == {RUN_ID: _activity_expected(D1)}
    assert _activity_hr_samples(cfg, RUN_ID) == ACT_HR_SAMPLES
    assert _results(cfg) == [
        ("activity", str(RUN_ID), endpoint, 1, None, FETCHED, CLOCK_MS)
        for endpoint in ACTIVITY_ENDPOINTS
    ]
    # 일일 테이블은 건드리지 않는다.
    assert _metrics(cfg) == {}
    assert _hr_samples(cfg) == []
    assert _raw_snapshot(cfg) == before


def test_activity_day_key_follows_local_list_date(cfg: config.Config):
    # 날짜 기준(합성): D1 로컬 07:30 = D0 22:30 UTC. 일 키는 목록의 로컬 날짜 D1이고, start_ms는 UTC
    # 시각이며 config 시간대(Asia/Seoul)로 바꾼 날짜도 D1이다.
    entry = _list_entry(RUN_ID, local=f"{D1} 07:30:00", gmt=f"{D0} 22:30:00")
    _put(
        cfg,
        [
            ("day", D1, "activities_by_date", [entry]),
            ("activity", str(RUN_ID), "activity", _activity_summary()),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    row = _activities(cfg)[RUN_ID]
    assert row["day_key"] == D1
    assert row["start_ms"] == _ms(f"{D0}T22:30:00")
    assert cfg.timezone == "Asia/Seoul"
    assert dates.day_key(row["start_ms"], cfg) == D1


def test_activity_optional_summary_keys_missing_are_null(cfg: config.Config):
    payload = _activity_summary("strength_training")
    summary = payload["summaryDTO"]
    assert isinstance(summary, dict)
    for name in ("distance", "averageHR", "maxHR"):
        del summary[name]
    _put(cfg, [("activity", str(RUN_ID), "activity", payload)])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _activities(cfg) == {
        RUN_ID: _nulls(("day_key", *ACTIVITY_VALUE_COLUMNS))
        | ACTIVITY_EXPECTED
        | {
            "type_key": "strength_training",
            "distance_m": None,
            "avg_hr": None,
            "max_hr": None,
        }
    }


def _without(payload: dict[str, object], *path: str) -> dict[str, object]:
    """`payload`의 복사본에서 `path` 마지막 키를 뺀다."""
    copied = json.loads(json.dumps(payload))
    container = copied
    for name in path[:-1]:
        container = container[name]
    del container[path[-1]]
    return copied


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param(_without(_activity_summary(), "summaryDTO"), id="no-summary"),
        pytest.param(
            _without(_activity_summary(), "activityTypeDTO"), id="no-type-dto"
        ),
        pytest.param(
            _without(_activity_summary(), "activityTypeDTO", "typeKey"),
            id="no-type-key",
        ),
        pytest.param(
            _without(_activity_summary(), "summaryDTO", "duration"), id="no-duration"
        ),
        pytest.param(
            _without(_activity_summary(), "summaryDTO", "startTimeGMT"),
            id="no-start",
        ),
        pytest.param(_activity_summary(startTimeGMT=D0), id="start-date-only"),
        pytest.param(_activity_summary(startTimeGMT="garbage"), id="start-garbage"),
        pytest.param(
            _activity_summary(startTimeGMT=f"{D0}T22:30:00.0Z"), id="start-zulu"
        ),
        pytest.param(_activity_summary(startTimeGMT=ACT_START), id="start-number"),
        pytest.param(_activity_summary(duration="1800"), id="duration-string"),
        pytest.param(_activity_summary(distance=True), id="distance-bool"),
        pytest.param(_activity_summary(type_key=1), id="type-key-number"),
        pytest.param(
            _activity_summary() | {"summaryDTO": [1]}, id="summary-not-object"
        ),
        pytest.param([_activity_summary()], id="top-list"),
    ],
)
def test_broken_activity_summary_fails_only_that_item(
    cfg: config.Config, payload: object
):
    _put(
        cfg,
        [
            _activity_list(D1, RUN_ID, WALK_ID),
            *_activity_rows(RUN_ID),
            *_activity_rows(WALK_ID),
        ],
    )
    _run(cfg)
    _put(cfg, [("activity", str(RUN_ID), "activity", payload)], now_ms=FETCHED + 1)

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    activities = _activities(cfg)
    # 그 endpoint 열만 NULL이다. 존별 시간·일 키·샘플·다른 활동은 그대로다.
    assert activities[RUN_ID] == _activity_expected(D1) | _nulls(
        activity.ACTIVITY_COLUMNS
    )
    assert activities[WALK_ID] == _activity_expected(D1)
    assert _activity_hr_samples(cfg, RUN_ID) == ACT_HR_SAMPLES
    assert (
        "activity",
        str(RUN_ID),
        "activity",
        0,
        "parse_error",
        FETCHED + 1,
        CLOCK_MS,
    ) in _results(cfg)


def test_activity_without_list_has_null_day_key(cfg: config.Config):
    _put(cfg, [_activity_list(D1, WALK_ID), *_activity_rows(RUN_ID)])

    assert _run(cfg) == normalize.Summary(processed=3, failed=0)

    assert _activities(cfg) == {RUN_ID: _activity_expected(None)}


def test_broken_list_is_skipped_with_warning(
    cfg: config.Config, caplog: pytest.LogCaptureFixture
):
    caplog.set_level(logging.WARNING, logger="garmin_pipeline.normalize")
    # D0 목록은 형식이 틀렸다(같은 활동이 있어도 건너뛴다). D2 목록이 일 키를 정한다.
    _put(
        cfg,
        [
            ("day", D0, "activities_by_date", [{"activityId": RUN_ID, "메모": MARKER}]),
            _activity_list(D2, RUN_ID),
            *_activity_rows(RUN_ID),
        ],
    )
    _put_text(cfg, D1, "activities_by_date", f"not json {MARKER}")

    assert _run(cfg) == normalize.Summary(processed=3, failed=0)

    assert _activities(cfg)[RUN_ID]["day_key"] == D2
    warnings = [r.getMessage() for r in caplog.records if r.levelno == logging.WARNING]
    assert warnings == [
        f"활동 목록 원문 형식 오류: key={D0}",
        f"활동 목록 원문 형식 오류: key={D1}",
        f"day values failed: date={D1}",
    ]
    assert MARKER not in caplog.text


def test_lists_are_not_read_without_activity_items(
    cfg: config.Config, caplog: pytest.LogCaptureFixture
):
    # 일 키 지도는 작업 집합에 activity-scope 항목이 있을 때만 만든다. 없으면 목록을 읽지 않는다.
    caplog.set_level(logging.WARNING, logger="garmin_pipeline.normalize")
    _put(cfg, _day(D1))
    _put_text(cfg, D1, "activities_by_date", f"not json {MARKER}")

    assert _run(cfg) == normalize.Summary(processed=4, failed=0)

    assert "활동 목록 원문 형식 오류" not in caplog.text


def test_first_list_in_key_order_wins(cfg: config.Config):
    _put(
        cfg,
        [
            _activity_list(D2, RUN_ID),
            _activity_list(D1, WALK_ID, RUN_ID),
            ("activity", str(RUN_ID), "activity", _activity_summary()),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _activities(cfg)[RUN_ID]["day_key"] == D1


def test_day_key_refreshes_only_when_activity_rows_are_written(cfg: config.Config):
    key = str(RUN_ID)
    _put(cfg, _activity_rows())
    _run(cfg)
    assert _activities(cfg)[RUN_ID]["day_key"] is None

    # 목록 원문만 바뀌면 다시 계산하지 않는다(목록은 등록되지 않아 작업 집합이 비어 있다).
    _put(cfg, [_activity_list(D1, RUN_ID)])
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)
    assert _activities(cfg)[RUN_ID]["day_key"] is None

    # 행을 쓰는 activity-scope 항목(존별 시간)이 성공하면 day_key를 고친다.
    _put(
        cfg,
        [("activity", key, "activity_hr_in_timezones", _hr_zones({1: 5}))],
        now_ms=FETCHED + 1,
    )
    assert _run(cfg) == normalize.Summary(processed=1, failed=0)
    assert _activities(cfg)[RUN_ID]["day_key"] == D1
    assert _activities(cfg)[RUN_ID]["hr_zone1_s"] == 5

    # 더 이른 목록(D0)이 생기면 지도는 D0이지만, null 원문·실패·열 없는 details는 day_key를 건드리지 않는다.
    _put(cfg, [_activity_list(D0, RUN_ID)])
    _put_text(cfg, key, "activity", "null", now_ms=FETCHED + 2, scope="activity")
    _put(
        cfg,
        [
            ("activity", key, "activity_hr_in_timezones", {"zones": []}),
            ("activity", key, "activity_details", _activity_details(DETAIL_ROWS[:1])),
        ],
        now_ms=FETCHED + 2,
    )
    assert _run(cfg) == normalize.Summary(processed=3, failed=1)
    assert _activities(cfg)[RUN_ID] == _nulls(("day_key", *ACTIVITY_VALUE_COLUMNS)) | {
        "day_key": D1
    }
    assert _activity_hr_samples(cfg, RUN_ID) == ACT_HR_SAMPLES[:1]

    # 요약이 다시 성공하면 그때의 지도 값(D0)으로 고친다.
    _put(cfg, [("activity", key, "activity", _activity_summary())], now_ms=FETCHED + 3)
    assert _run(cfg) == normalize.Summary(processed=1, failed=0)
    assert _activities(cfg)[RUN_ID]["day_key"] == D0


def test_partial_hr_zones_leave_other_zones_null(cfg: config.Config):
    _put(
        cfg,
        [
            (
                "activity",
                str(RUN_ID),
                "activity_hr_in_timezones",
                _hr_zones({3: 400, 2: 300.5}),
            )
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _activities(cfg) == {
        RUN_ID: _nulls(("day_key", *ACTIVITY_VALUE_COLUMNS))
        | {
            "hr_zone2_s": 300,
            "hr_zone3_s": 400,
            "hr_zone2_low_bpm": 100,
            "hr_zone3_low_bpm": 100,
        }
    }


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param(_hr_zones({0: 10}), id="zone-0"),
        pytest.param(_hr_zones({6: 10}), id="zone-6"),
        pytest.param(_hr_zones({True: 10}), id="zone-bool"),
        pytest.param(_hr_zones({"1": 10}), id="zone-string"),
        pytest.param(_hr_zones({1.0: 10}), id="zone-float"),
        pytest.param(_hr_zones({None: 10}), id="zone-null"),
        pytest.param(
            [*_hr_zones({1: 10, 2: 20}), *_hr_zones({1: 30})], id="zone-duplicate"
        ),
        pytest.param([{"secsInZone": 10}], id="zone-missing"),
        pytest.param([{"zoneNumber": 1}], id="secs-missing"),
        pytest.param(_hr_zones({1: "10"}), id="secs-string"),
        pytest.param([[1, 10]], id="entry-not-object"),
        pytest.param({"zones": _hr_zones()}, id="top-object"),
    ],
)
def test_broken_hr_zones_fail_only_that_item(cfg: config.Config, payload: object):
    _put(cfg, [*_activity_rows(RUN_ID), *_activity_rows(WALK_ID)])
    _run(cfg)
    _put(
        cfg,
        [("activity", str(RUN_ID), "activity_hr_in_timezones", payload)],
        now_ms=FETCHED + 1,
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    activities = _activities(cfg)
    assert activities[RUN_ID] == _activity_expected(None) | _nulls(
        activity.ACTIVITY_HR_IN_TIMEZONES_COLUMNS
    )
    assert activities[WALK_ID] == _activity_expected(None)
    assert _activity_results(cfg)[-1:] == [
        (
            "activity",
            str(RUN_ID),
            "activity_hr_in_timezones",
            0,
            "parse_error",
            FETCHED + 1,
            CLOCK_MS,
        )
    ]


def test_activity_hr_samples_with_shuffled_descriptors(cfg: config.Config):
    shuffled = _activity_details(order=(2, 0, 1))
    assert shuffled["metricDescriptors"] != _activity_details()["metricDescriptors"]
    _put(cfg, [("activity", str(RUN_ID), "activity_details", shuffled)])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _activity_hr_samples(cfg, RUN_ID) == ACT_HR_SAMPLES
    # 소유 열이 없어 activity 행을 만들지 않는다.
    assert _activities(cfg) == {}


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param(
            _activity_details(keys=("directTimestamp", "directSpeed", "sumDistance")),
            id="no-heart-channel",
        ),
        pytest.param(
            _activity_details(activityDetailMetrics=None, metricDescriptors=None),
            id="metrics-null",
        ),
        pytest.param(
            _activity_details(activityDetailMetrics=[], metricDescriptors=None),
            id="metrics-empty",
        ),
    ],
)
def test_activity_details_without_heart_samples_is_ok(
    cfg: config.Config, payload: dict
):
    _put(cfg, [("activity", str(RUN_ID), "activity_details", payload)])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _activity_hr_samples(cfg, RUN_ID) == []
    assert _activities(cfg) == {}
    assert _activity_results(cfg)[0][3:5] == (1, None)


def _details_with(*rows: Sequence[object]) -> dict[str, object]:
    return _activity_details(list(rows))


@pytest.mark.parametrize(
    "payload",
    [
        pytest.param(
            _activity_details(keys=("directHeartRate", "directSpeed", "sumDistance")),
            id="no-timestamp-channel",
        ),
        pytest.param(
            _activity_details(
                activityDetailMetrics=[{"metrics": [ACT_START, 120]}],
                keys=("directSpeed", "directTimestamp", "directHeartRate"),
            ),
            id="metrics-short",
        ),
        pytest.param(_details_with((None, 120, 1)), id="timestamp-null"),
        pytest.param(_details_with((True, 120, 1)), id="timestamp-bool"),
        pytest.param(_details_with((-1, 120, 1)), id="timestamp-negative"),
        pytest.param(_details_with((str(ACT_START), 120, 1)), id="timestamp-string"),
        pytest.param(_details_with((float("inf"), 120, 1)), id="timestamp-inf"),
        pytest.param(
            _details_with((ACT_START + 1000.2, 120, 1), (ACT_START + 999.6, 121, 1)),
            id="timestamp-duplicate-after-round",
        ),
        pytest.param(_details_with((ACT_START, "120", 1)), id="bpm-string"),
        pytest.param(_details_with((ACT_START, True, 1)), id="bpm-bool"),
        pytest.param(
            _activity_details(activityDetailMetrics=[[ACT_START, 120, 1]]),
            id="sample-not-object",
        ),
        pytest.param(
            _activity_details(activityDetailMetrics=[{"values": [ACT_START, 1, 1]}]),
            id="sample-metrics-missing",
        ),
        pytest.param(
            _activity_details(activityDetailMetrics=[{"metrics": None}]),
            id="sample-metrics-null",
        ),
        pytest.param(_activity_details(metricDescriptors=None), id="descriptors-null"),
        pytest.param(
            _without(_activity_details(), "metricDescriptors"),
            id="descriptors-key-missing",
        ),
        pytest.param(
            _without(_activity_details(), "activityDetailMetrics"),
            id="metrics-key-missing",
        ),
        pytest.param(
            _activity_details(
                metricDescriptors=[{"key": "directHeartRate", "metricsIndex": "1"}]
            ),
            id="descriptor-index-string",
        ),
        pytest.param([_activity_details()], id="top-list"),
        pytest.param(
            _activity_details(
                activityDetailMetrics=[{"metrics": [ACT_START, 120]}],
                metricDescriptors=[
                    {"key": "directTimestamp", "metricsIndex": 0},
                    {"key": "directHeartRate", "metricsIndex": 1},
                    {"key": "directBodyBattery", "metricsIndex": 2},
                ],
            ),
            id="metrics-short-for-body-battery",
        ),
    ],
)
def test_broken_activity_details_fail_only_that_item(
    cfg: config.Config, payload: object
):
    _put(cfg, [*_activity_rows(RUN_ID), *_activity_rows(WALK_ID)])
    _run(cfg)
    _put(
        cfg,
        [("activity", str(RUN_ID), "activity_details", payload)],
        now_ms=FETCHED + 1,
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    assert _activity_hr_samples(cfg, RUN_ID) == []
    assert _activity_hr_samples(cfg, WALK_ID) == ACT_HR_SAMPLES
    # 소유 열이 없으므로 activity 행은 그대로다.
    assert _activities(cfg)[RUN_ID] == _activity_expected(None)
    assert (
        "activity",
        str(RUN_ID),
        "activity_details",
        0,
        "parse_error",
        FETCHED + 1,
        CLOCK_MS,
    ) in _activity_results(cfg)


def test_renormalize_replaces_samples_of_that_activity_only(cfg: config.Config):
    _put(cfg, [*_activity_rows(RUN_ID), *_activity_rows(WALK_ID)])
    _run(cfg)
    fewer = [(ACT_START + 5 * SECOND_MS, 99, 1.0), (ACT_START + 7 * SECOND_MS, 0, 1.0)]
    _put(
        cfg,
        [("activity", str(RUN_ID), "activity_details", _activity_details(fewer))],
        now_ms=FETCHED + 1,
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _activity_hr_samples(cfg, RUN_ID) == [
        (ACT_START + 5 * SECOND_MS, 99),
        (ACT_START + 7 * SECOND_MS, None),
    ]
    assert _activity_hr_samples(cfg, WALK_ID) == ACT_HR_SAMPLES


def test_null_activity_raws_clear_columns_and_samples(cfg: config.Config):
    _put(cfg, [_activity_list(D1, RUN_ID), *_activity_rows(RUN_ID)])
    _run(cfg)
    key = str(RUN_ID)
    _put_text(cfg, key, "activity", "null", now_ms=FETCHED + 1, scope="activity")
    _put_text(
        cfg, key, "activity_details", "null", now_ms=FETCHED + 1, scope="activity"
    )

    assert _run(cfg) == normalize.Summary(processed=2, failed=0)

    assert _activities(cfg) == {
        RUN_ID: _activity_expected(D1) | _nulls(activity.ACTIVITY_COLUMNS)
    }
    assert _activity_hr_samples(cfg, RUN_ID) == []

    _put_text(
        cfg,
        key,
        "activity_hr_in_timezones",
        "null",
        now_ms=FETCHED + 2,
        scope="activity",
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _activities(cfg) == {
        RUN_ID: _nulls(("day_key", *ACTIVITY_VALUE_COLUMNS)) | {"day_key": D1}
    }
    assert {row[3:5] for row in _activity_results(cfg)} == {(1, None)}


def test_null_activity_raw_without_row_creates_no_row(cfg: config.Config):
    _put(cfg, [("activity", str(RUN_ID), "activity", None)])

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _activities(cfg) == {}


@pytest.mark.parametrize(
    "key",
    [
        pytest.param("abc", id="letters"),
        pytest.param("007", id="leading-zero"),
        pytest.param("-1", id="negative"),
        pytest.param("1.5", id="fraction"),
        pytest.param(" 12", id="space"),
        pytest.param("", id="empty"),
        pytest.param("١٢", id="non-ascii-digits"),
        pytest.param(str(2**63), id="beyond-sqlite-integer"),
    ],
)
def test_bad_activity_key_is_parse_error(
    cfg: config.Config, caplog: pytest.LogCaptureFixture, key: str
):
    caplog.set_level(logging.WARNING, logger="garmin_pipeline.normalize")
    _put(
        cfg,
        [
            ("activity", key, "activity", _activity_summary()),
            ("activity", key, "activity_details", _activity_details()),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=2, failed=2)

    assert _results(cfg) == [
        ("activity", key, endpoint, 0, "parse_error", FETCHED, CLOCK_MS)
        for endpoint in ("activity", "activity_details")
    ]
    assert _activities(cfg) == {}
    assert _query(cfg, "SELECT COUNT(*) FROM activity_hr_sample") == [(0,)]
    assert (
        f"정규화 실패: scope=activity key={key} endpoint=activity error_code=parse_error"
        in caplog.text
    )


def test_activity_items_are_processed_in_scope_key_endpoint_order(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
):
    seen: list[tuple[str, str]] = []
    for endpoint, rule in list(normalize.NORMALIZERS.items()):

        def spy(raw: str, key: str, *, _endpoint=endpoint, _parse=rule.parse):
            seen.append((key, _endpoint))
            return _parse(raw, key)

        # `_replace`로 다른 필드(`sample_table`·`scope`)를 보존한다.
        monkeypatch.setitem(normalize.NORMALIZERS, endpoint, rule._replace(parse=spy))
    _put(
        cfg,
        [
            ("day", D1, "user_summary", _user_summary()),
            *_activity_rows(RUN_ID),
            *_activity_rows(WALK_ID),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=7, failed=0)

    # scope "activity" < "day", key는 문자열 순서("1999" < "2001")다.
    assert seen == [
        *(
            (str(i), endpoint)
            for i in (WALK_ID, RUN_ID)
            for endpoint in ACTIVITY_ENDPOINTS
        ),
        (D1, "user_summary"),
    ]
    assert _activity_hr_samples(cfg, RUN_ID) == _activity_hr_samples(cfg, WALK_ID)
    assert _activity_hr_samples(cfg, RUN_ID) == ACT_HR_SAMPLES


def test_activity_internal_failure_clears_samples(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
):
    _put(cfg, _activity_rows())
    _run(cfg)
    rule = normalize.NORMALIZERS["activity_details"]
    assert rule.sample_table is not None and rule.scope == "activity"

    def explode(raw: str, key: str) -> list[daily.Sample]:
        raise RuntimeError(f"boom {MARKER}")

    monkeypatch.setitem(
        normalize.NORMALIZERS,
        "activity_details",
        rule._replace(sample_table=rule.sample_table._replace(parse=explode)),
    )
    _put(
        cfg,
        [
            (
                "activity",
                str(RUN_ID),
                "activity_details",
                _activity_details(DETAIL_ROWS[:2]),
            )
        ],
        now_ms=FETCHED + 1,
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    assert _activity_hr_samples(cfg, RUN_ID) == []
    assert _activities(cfg)[RUN_ID] == _activity_expected(None)
    assert _activity_results(cfg)[1][2:5] == ("activity_details", 0, "internal")


def test_normalizer_scope_defaults_to_day():
    rule = normalize.Normalizer(daily.RHR_DAY_COLUMNS, daily.rhr_day)

    assert rule.scope == "day"
    assert rule.sample_table is None
    assert rule._replace(scope="activity").columns == daily.RHR_DAY_COLUMNS
    assert {r.scope for r in normalize.NORMALIZERS.values()} == {"day", "activity"}


def test_activity_parsers():
    key = str(RUN_ID)

    assert activity.activity(json.dumps(_activity_summary()), key) == ACTIVITY_EXPECTED
    assert activity.activity(
        json.dumps(_activity_summary(None, startTimeGMT=None, duration=None)), key
    ) == ACTIVITY_EXPECTED | {"type_key": None, "start_ms": None, "duration_s": None}
    assert activity.activity_hr_in_timezones(json.dumps(_hr_zones()), key) == (
        ZONES_EXPECTED
    )
    assert activity.activity_hr_in_timezones("[]", key) == _nulls(
        activity.ACTIVITY_HR_IN_TIMEZONES_COLUMNS
    )
    assert activity.activity_details(json.dumps(_activity_details()), key) == {}
    assert activity.ACTIVITY_DETAILS_COLUMNS == ()
    assert activity.activity_hr_samples(json.dumps(_activity_details()), key) == (
        ACT_HR_ROWS
    )
    for order in ((1, 2, 0), (2, 0, 1), (0, 2, 1)):
        shuffled = json.dumps(_activity_details(order=order))
        assert activity.activity_hr_samples(shuffled, key) == ACT_HR_ROWS
    # 원문 순서를 지킨다. bpm 0·음수·0.4(round → 0)는 None이다.
    edge = _activity_details([(3, 0, 1), (1, -1, 1), (2, 0.4, 1), (0, 0.6, 1)])
    assert activity.activity_hr_samples(json.dumps(edge), key) == [
        (3, None, None),
        (1, None, None),
        (2, None, None),
        (0, 1, None),
    ]


def test_activity_body_battery_channel():
    # 5.9: directBodyBattery 위치는 descriptor로 찾는다(섞인 순서도 같다). null·음수 → None, 0은 0, round.
    key = str(RUN_ID)
    for order in ((0, 1, 2), (1, 2, 0), (2, 0, 1), (0, 2, 1)):
        raw = json.dumps(
            _activity_details(BB_DETAIL_ROWS, order=order, keys=BB_DETAIL_KEYS)
        )
        assert activity.activity_hr_samples(raw, key) == BB_ROWS, order
    # 행이 생기는 조건은 심박 채널뿐이다: Body Battery 채널만 있으면 빈 목록이다.
    only_bb = _activity_details(
        BB_DETAIL_ROWS, keys=("directTimestamp", "directSpeed", "directBodyBattery")
    )
    assert activity.activity_hr_samples(json.dumps(only_bb), key) == []


@pytest.mark.parametrize(
    ("value", "kind"),
    [
        pytest.param(MARKER, "str", id="string"),
        pytest.param(True, "bool", id="bool"),
    ],
)
def test_activity_body_battery_bad_value_names_location_only(value: object, kind: str):
    raw = json.dumps(
        _activity_details(
            [(ACT_START, 120, 62), (ACT_START + 1000, 151, value)],
            keys=BB_DETAIL_KEYS,
        )
    )

    with pytest.raises(daily.NormalizeParseError) as excinfo:
        activity.activity_hr_samples(raw, str(RUN_ID))

    message = str(excinfo.value)
    assert message.startswith(
        "activity_details: activityDetailMetrics[1].metrics[2]가 숫자가 아니다"
    )
    assert kind in message
    assert MARKER not in message
    assert "151" not in message


def test_activity_body_battery_is_stored(cfg: config.Config):
    # 채널이 있으면 같은 행의 body_battery에 값, 없으면(다른 활동) 모두 NULL이다.
    _put(
        cfg,
        [
            _activity_list(D1, RUN_ID, WALK_ID),
            *_activity_rows(RUN_ID),
            *_activity_rows(WALK_ID)[:2],
            (
                "activity",
                str(WALK_ID),
                "activity_details",
                _activity_details(BB_DETAIL_ROWS, keys=BB_DETAIL_KEYS),
            ),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=6, failed=0)

    assert _activity_body_battery(cfg, WALK_ID) == BB_ROWS
    assert _activity_body_battery(cfg, RUN_ID) == ACT_HR_ROWS


def test_activity_body_battery_bad_value_is_parse_error(cfg: config.Config):
    _put(
        cfg,
        [
            _activity_list(D1, RUN_ID),
            (
                "activity",
                str(RUN_ID),
                "activity_details",
                _activity_details([(ACT_START, 120, "62")], keys=BB_DETAIL_KEYS),
            ),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    assert _activity_body_battery(cfg, RUN_ID) == []
    assert _results(cfg)[0][:5] == (
        "activity",
        str(RUN_ID),
        "activity_details",
        0,
        "parse_error",
    )


@pytest.mark.parametrize(
    ("parser", "raw", "location"),
    [
        pytest.param(
            activity.activity,
            json.dumps(_activity_summary(startTimeGMT=f"garbage {MARKER}")),
            "activity: summaryDTO.startTimeGMT",
            id="start-garbage",
        ),
        pytest.param(
            activity.activity,
            json.dumps(_without(_activity_summary(), "summaryDTO", "duration")),
            "activity: summaryDTO.duration",
            id="no-duration",
        ),
        pytest.param(
            activity.activity,
            f"not json {MARKER}",
            "activity: 원문이 JSON이 아니다",
            id="not-json",
        ),
        pytest.param(
            activity.activity_hr_in_timezones,
            json.dumps(_hr_zones({1: 10, 7: 151})),
            "activity_hr_in_timezones: [1].zoneNumber",
            id="zone-range",
        ),
        pytest.param(
            activity.activity_hr_in_timezones,
            json.dumps([*_hr_zones({2: 10}), *_hr_zones({2: 151})]),
            "activity_hr_in_timezones: [1].zoneNumber",
            id="zone-duplicate",
        ),
        pytest.param(
            activity.activity_hr_samples,
            json.dumps(_details_with((ACT_START, 120, 1), (MARKER, 151, 1))),
            "activity_details: activityDetailMetrics[1].metrics[0]",
            id="timestamp-string",
        ),
        pytest.param(
            activity.activity_hr_samples,
            json.dumps(_details_with((ACT_START, 120, 1), (ACT_START, 151, 1))),
            "activity_details: activityDetailMetrics[1].metrics[0] 시각이 중복이다",
            id="timestamp-duplicate",
        ),
        pytest.param(
            activity.activity_hr_samples,
            json.dumps(_activity_details(keys=("directHeartRate", "directSpeed", "x"))),
            "activity_details: metricDescriptors에 directTimestamp 항목이 없다",
            id="no-timestamp-channel",
        ),
    ],
)
def test_activity_parser_errors_name_location_only(
    parser: daily.Parser, raw: str, location: str
):
    with pytest.raises(daily.NormalizeParseError) as excinfo:
        parser(raw, str(RUN_ID))

    message = str(excinfo.value)
    assert message.startswith(location)
    assert MARKER not in message
    assert "151" not in message
    assert excinfo.value.__context__ is None


def test_console_script_normalizes_activities(cfg: config.Config, tmp_path: Path):
    _put(
        cfg,
        [
            _activity_list(D1, RUN_ID, WALK_ID),
            *_activity_rows(RUN_ID),
            *_activity_rows(WALK_ID),
        ],
    )
    script = shutil.which("garmin-pipeline", path=sysconfig.get_path("scripts"))
    assert script is not None, "콘솔 스크립트가 없다. `uv sync`를 먼저 실행한다."
    env = {key: value for key, value in os.environ.items() if key != "FORCE_COLOR"}
    env |= {"NO_COLOR": "1", "PYTHON_COLORS": "0"}

    def run() -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [script, "normalize", "--config", str(cfg.path)],
            cwd=tmp_path,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )

    first = run()

    assert first.returncode == 0, first.stderr
    assert first.stdout == "normalize: processed=6 failed=0\n"
    assert _activities(cfg) == {
        RUN_ID: _activity_expected(D1),
        WALK_ID: _activity_expected(D1),
    }
    assert _activity_hr_samples(cfg, RUN_ID) == ACT_HR_SAMPLES
    assert _activity_hr_samples(cfg, WALK_ID) == ACT_HR_SAMPLES
    assert _metrics(cfg) == {}

    changed = [
        (ACT_START + 10 * SECOND_MS, 101.5, 3.0),
        (ACT_START + 4 * SECOND_MS + 0.5, None, 3.1),
    ]
    _put(
        cfg,
        [("activity", str(RUN_ID), "activity_details", _activity_details(changed))],
        now_ms=FETCHED + 1,
    )
    second = run()

    assert second.returncode == 0, second.stderr
    assert second.stdout == "normalize: processed=1 failed=0\n"
    assert _activity_hr_samples(cfg, RUN_ID) == [
        (ACT_START + 4 * SECOND_MS, None),
        (ACT_START + 10 * SECOND_MS, 102),
    ]
    assert _activity_hr_samples(cfg, WALK_ID) == ACT_HR_SAMPLES
    assert _activities(cfg)[RUN_ID] == _activity_expected(D1)


# --- 등록되지 않은 endpoint ------------------------------------------------------------------


def test_unregistered_endpoints_get_no_result_rows(cfg: config.Config):
    _put(cfg, [("day", D1, "activities_by_date", [])])

    assert _run(cfg) == normalize.Summary(processed=0, failed=0)

    assert _results(cfg) == []
    assert _metrics(cfg) == {}
    assert _activities(cfg) == {}


def test_registered_endpoint_in_other_scope_is_not_in_work_set(cfg: config.Config):
    # 작업 집합은 등록된 (scope, endpoint) 쌍이다. 같은 endpoint 이름이라도 scope가 다르면 들지 않는다.
    _put(
        cfg,
        [
            ("activity", "123", "user_summary", _user_summary()),
            ("day", D1, "activity", {"activityId": 123}),
        ],
    )

    assert _run(cfg) == normalize.Summary(processed=0, failed=0)

    assert _results(cfg) == []


# --- 파서 단위 ------------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("parser", "payload", "expected"),
    [
        pytest.param(
            daily.user_summary,
            _user_summary(moderateIntensityMinutes=None, vigorousIntensityMinutes=-1),
            {"moderate_intensity_s": None, "vigorous_intensity_s": None},
            id="intensity-null-and-sentinel",
        ),
        pytest.param(
            daily.user_summary,
            _user_summary(totalSteps=0, activeKilocalories=0.4),
            {"steps": 0, "active_kcal": 0},
            id="zero-is-a-value",
        ),
        pytest.param(
            daily.hrv_data,
            _hrv_data(baseline=None, status=None),
            {"hrv_baseline_low": None, "hrv_baseline_high": None, "hrv_status": None},
            id="hrv-baseline-null",
        ),
        pytest.param(
            daily.training_readiness,
            [
                {"timestamp": f"{D1}T07:00:00.0", "score": None, "level": None},
                {"timestamp": f"{D1}T08:00:00.0", "score": 90, "level": "PRIME"},
            ],
            {"readiness_score": None, "readiness_level": None},
            id="readiness-earliest-even-if-null",
        ),
        pytest.param(
            daily.training_readiness,
            [
                {"timestamp": f"{D1}T07:00:00.0", "score": 60, "level": "MODERATE"},
                {"timestamp": f"{D1}T07:00:00.0", "score": 90, "level": "PRIME"},
            ],
            {"readiness_score": 60, "readiness_level": "MODERATE"},
            id="readiness-tie-keeps-first",
        ),
        pytest.param(
            daily.rhr_day,
            _rhr_day(
                D1,
                [
                    {"calendarDate": D1, "value": 51.5},
                    {"calendarDate": D1, "value": 70},
                ],
            ),
            {"resting_hr": 52},
            id="rhr-first-matching-entry",
        ),
        pytest.param(
            daily.training_readiness,
            [
                {"timestamp": f"{D1}T05:10:00.0", "score": 40, "level": "LOW"},
                {
                    "timestamp": f"{D1}T06:45:00.0",
                    "score": 77,
                    "level": "MODERATE",
                    "inputContext": "AFTER_WAKEUP_RESET",
                },
                {
                    "timestamp": f"{D1}T09:00:00.0",
                    "score": 90,
                    "level": "PRIME",
                    "inputContext": "AFTER_WAKEUP_RESET",
                },
            ],
            {"readiness_score": 77, "readiness_level": "MODERATE"},
            id="readiness-morning-first",
        ),
        pytest.param(
            daily.training_readiness,
            [
                {
                    "timestamp": f"{D1}T09:00:00.0",
                    "score": 90,
                    "level": "PRIME",
                    "inputContext": "UPDATE_REALTIME_VARIABLES",
                },
                {
                    "timestamp": f"{D1}T05:10:00.0",
                    "score": 40,
                    "level": "LOW",
                    "inputContext": None,
                },
            ],
            {"readiness_score": 40, "readiness_level": "LOW"},
            id="readiness-no-morning-falls-back-to-earliest",
        ),
        pytest.param(
            daily.sleep_data,
            _sleep_data(),
            SLEEP_EXPECTED,
            id="sleep",
        ),
        pytest.param(
            daily.sleep_data,
            {"dailySleepDTO": {"sleepTimeSeconds": None}},
            _nulls(daily.SLEEP_DATA_COLUMNS),
            id="sleep-none-other-keys-absent",
        ),
        pytest.param(
            daily.sleep_data,
            {"dailySleepDTO": {"sleepTimeSeconds": -1}},
            _nulls(daily.SLEEP_DATA_COLUMNS),
            id="sleep-sentinel-total",
        ),
        pytest.param(
            daily.sleep_data,
            _sleep_data(sleepScores=None),
            SLEEP_EXPECTED | {"sleep_score": None},
            id="sleep-scores-null",
        ),
        pytest.param(
            daily.sleep_data,
            _sleep_data(sleepScores={"overall": None}),
            SLEEP_EXPECTED | {"sleep_score": None},
            id="sleep-overall-null",
        ),
        pytest.param(
            daily.sleep_data,
            _sleep_data(remSleepSeconds=None, awakeSleepSeconds=-2),
            SLEEP_EXPECTED | {"rem_sleep_s": None, "awake_sleep_s": None},
            id="sleep-stage-null-and-sentinel",
        ),
        pytest.param(
            daily.stress_data,
            _stress_data(),
            STRESS_EXPECTED,
            id="stress-sentinels-excluded",
        ),
        pytest.param(
            daily.stress_data,
            _stress_data([-1, -2]),
            _nulls(daily.STRESS_DATA_COLUMNS),
            id="stress-all-sentinels",
        ),
        pytest.param(
            daily.stress_data,
            _stress_data(stressValuesArray=None, stressValueDescriptorsDTOList=None),
            _nulls(daily.STRESS_DATA_COLUMNS),
            id="stress-array-null",
        ),
        pytest.param(
            daily.stress_data,
            _stress_data(stressValuesArray=[], stressValueDescriptorsDTOList=None),
            _nulls(daily.STRESS_DATA_COLUMNS),
            id="stress-array-empty-without-descriptors",
        ),
        pytest.param(
            daily.stress_data,
            _stress_data(
                stressValueDescriptorsDTOList=[
                    {"key": "stressLevel", "index": 0},
                    {"key": "timestamp", "index": 1},
                ],
                stressValuesArray=[[25, 1], [27.5, 2], [None, 3]],
            ),
            {"stress_avg": 26, "stress_max": 28},
            id="stress-descriptor-position",
        ),
        pytest.param(
            daily.body_battery,
            _body_battery(),
            BB_EXPECTED,
            id="bb",
        ),
        pytest.param(
            daily.body_battery,
            [
                *_body_battery(D0, charged=1),
                *_body_battery(D1),
                *_body_battery(D1, charged=3),
            ],
            BB_EXPECTED,
            id="bb-first-entry-of-day",
        ),
        pytest.param(
            daily.body_battery,
            _body_battery(D0),
            _nulls(daily.BODY_BATTERY_COLUMNS),
            id="bb-no-entry-of-day",
        ),
        pytest.param(
            daily.body_battery,
            _body_battery(
                bodyBatteryValuesArray=None, bodyBatteryValueDescriptorDTOList=None
            ),
            BB_EXPECTED | {"bb_high": None, "bb_low": None},
            id="bb-values-null",
        ),
        pytest.param(
            daily.body_battery,
            _body_battery(values=[[SLEEP_START, -1], [SLEEP_END, None]]),
            BB_EXPECTED | {"bb_high": None, "bb_low": None},
            id="bb-no-valid-level",
        ),
        pytest.param(
            daily.heart_rates,
            _heart_rates(),
            {},
            id="hr-no-columns",
        ),
    ],
)
def test_parser_values(
    parser: daily.Parser, payload: object, expected: dict[str, daily.Value]
):
    values = parser(json.dumps(payload, ensure_ascii=False), D1)

    assert {key: values[key] for key in expected} == expected


@pytest.mark.parametrize(
    ("parser", "raw", "location"),
    [
        pytest.param(
            daily.user_summary, "[]", "user_summary: $", id="summary-not-object"
        ),
        pytest.param(
            daily.user_summary,
            json.dumps({k: v for k, v in _user_summary().items() if k != "totalSteps"}),
            "user_summary: totalSteps",
            id="summary-missing-key",
        ),
        pytest.param(
            daily.user_summary,
            json.dumps(_user_summary(totalSteps=True)),
            "user_summary: totalSteps",
            id="summary-bool",
        ),
        pytest.param(
            daily.user_summary,
            json.dumps(_user_summary(maxHeartRate=f"151 {MARKER}")),
            "user_summary: maxHeartRate",
            id="summary-string-number",
        ),
        pytest.param(
            daily.user_summary,
            json.dumps(_user_summary(minHeartRate=float("nan"))),
            "user_summary: minHeartRate",
            id="summary-nan",
        ),
        pytest.param(
            daily.user_summary, f"not json {MARKER}", "user_summary: ", id="not-json"
        ),
        pytest.param(
            daily.rhr_day,
            # 빈 map은 빈 모양으로 받는다. 다른 키만 있으면 이름이 바뀐 것으로 보고 실패한다.
            json.dumps({"allMetrics": {"metricsMap": {"WELLNESS_OTHER": []}}}),
            "rhr_day: allMetrics.metricsMap.WELLNESS_RESTING_HEART_RATE",
            id="rhr-missing-list",
        ),
        pytest.param(
            daily.rhr_day,
            json.dumps({"allMetrics": None}),
            "rhr_day: allMetrics",
            id="rhr-null-container",
        ),
        pytest.param(
            daily.rhr_day,
            json.dumps(_rhr_day(D1, [{"value": 50}])),
            "rhr_day: allMetrics.metricsMap.WELLNESS_RESTING_HEART_RATE[0].calendarDate",
            id="rhr-entry-missing-date",
        ),
        pytest.param(
            daily.rhr_day,
            json.dumps(_rhr_day(D1, [{"calendarDate": 20261015, "value": 50}])),
            "rhr_day: allMetrics.metricsMap.WELLNESS_RESTING_HEART_RATE[0].calendarDate",
            id="rhr-entry-date-not-string",
        ),
        pytest.param(
            daily.rhr_day,
            json.dumps(_rhr_day(D1, [{"calendarDate": D1}])),
            "rhr_day: allMetrics.metricsMap.WELLNESS_RESTING_HEART_RATE[0].value",
            id="rhr-entry-missing-value",
        ),
        pytest.param(
            daily.rhr_day,
            json.dumps(_rhr_day(D1, [MARKER])),
            "rhr_day: allMetrics.metricsMap.WELLNESS_RESTING_HEART_RATE[0]",
            id="rhr-entry-not-object",
        ),
        pytest.param(
            daily.hrv_data,
            json.dumps(_hrv_data(baseline=[35, 48])),
            "hrv_data: hrvSummary.baseline",
            id="hrv-baseline-list",
        ),
        pytest.param(
            daily.hrv_data,
            json.dumps(_hrv_data(baseline={"balancedLow": 35})),
            "hrv_data: hrvSummary.baseline.balancedUpper",
            id="hrv-baseline-missing-key",
        ),
        pytest.param(
            daily.hrv_data,
            json.dumps(_hrv_data(status=3)),
            "hrv_data: hrvSummary.status",
            id="hrv-status-not-string",
        ),
        pytest.param(
            daily.hrv_data,
            json.dumps({"hrvReadings": []}),
            "hrv_data: hrvSummary",
            id="hrv-missing-summary",
        ),
        pytest.param(
            daily.training_readiness,
            json.dumps({"score": 1}),
            "training_readiness: $",
            id="readiness-not-list",
        ),
        pytest.param(
            daily.training_readiness,
            json.dumps([{"timestamp": 1760000000, "score": 1, "level": "LOW"}]),
            "training_readiness: [0].timestamp",
            id="readiness-timestamp-not-string",
        ),
        pytest.param(
            daily.training_readiness,
            json.dumps([{"timestamp": "2026", "level": "LOW"}]),
            "training_readiness: [0].score",
            id="readiness-missing-score",
        ),
        pytest.param(
            daily.training_readiness,
            json.dumps(
                [{"timestamp": "2026", "score": 1, "level": "LOW", "inputContext": 3}]
            ),
            "training_readiness: [0].inputContext",
            id="readiness-context-not-string",
        ),
        pytest.param(
            daily.sleep_data,
            json.dumps({"sleepTimeSeconds": 1}),
            "sleep_data: dailySleepDTO",
            id="sleep-missing-dto",
        ),
        pytest.param(
            daily.sleep_data,
            json.dumps({"dailySleepDTO": None}),
            "sleep_data: dailySleepDTO",
            id="sleep-null-dto",
        ),
        pytest.param(
            daily.sleep_data,
            json.dumps({"dailySleepDTO": {}}),
            "sleep_data: dailySleepDTO.sleepTimeSeconds",
            id="sleep-missing-total",
        ),
        pytest.param(
            daily.sleep_data,
            json.dumps(
                {
                    "dailySleepDTO": {
                        k: v
                        for k, v in _sleep_data()["dailySleepDTO"].items()
                        if k != "remSleepSeconds"
                    }
                }
            ),
            "sleep_data: dailySleepDTO.remSleepSeconds",
            id="sleep-missing-stage",
        ),
        pytest.param(
            daily.sleep_data,
            json.dumps(_sleep_data(sleepScores={"overall": [82]})),
            "sleep_data: dailySleepDTO.sleepScores.overall",
            id="sleep-overall-list",
        ),
        pytest.param(
            daily.sleep_data,
            json.dumps(_sleep_data(sleepScores={"overall": {"qualifierKey": MARKER}})),
            "sleep_data: dailySleepDTO.sleepScores.overall.value",
            id="sleep-overall-missing-value",
        ),
        pytest.param(
            daily.sleep_data,
            json.dumps(_sleep_data(sleepScores={})),
            "sleep_data: dailySleepDTO.sleepScores.overall",
            id="sleep-scores-missing-overall",
        ),
        pytest.param(
            daily.stress_data,
            json.dumps(
                {k: v for k, v in _stress_data().items() if k != "stressValuesArray"}
            ),
            "stress_data: stressValuesArray",
            id="stress-missing-array",
        ),
        pytest.param(
            daily.stress_data,
            json.dumps(_stress_data(stressValueDescriptorsDTOList=None)),
            "stress_data: stressValueDescriptorsDTOList",
            id="stress-descriptors-null",
        ),
        pytest.param(
            daily.stress_data,
            json.dumps(
                _stress_data(
                    stressValueDescriptorsDTOList=[{"key": "timestamp", "index": 0}]
                )
            ),
            "stress_data: stressValueDescriptorsDTOList",
            id="stress-level-descriptor-missing",
        ),
        pytest.param(
            daily.stress_data,
            json.dumps(_stress_data(stressValuesArray=[[1, 30], [2]])),
            "stress_data: stressValuesArray[1]",
            id="stress-sample-too-short",
        ),
        pytest.param(
            daily.stress_data,
            json.dumps(_stress_data(stressValuesArray=[{"151": 30}])),
            "stress_data: stressValuesArray[0]",
            id="stress-sample-not-list",
        ),
        pytest.param(
            daily.stress_data,
            json.dumps(_stress_data(stressValuesArray=[[1, MARKER]])),
            "stress_data: stressValuesArray[0][1]",
            id="stress-level-not-number",
        ),
        pytest.param(
            daily.stress_data,
            json.dumps(_stress_data(stressValuesArray="[]")),
            "stress_data: stressValuesArray",
            id="stress-array-not-list",
        ),
        pytest.param(
            daily.body_battery,
            json.dumps({"date": D1}),
            "body_battery: $",
            id="bb-not-list",
        ),
        pytest.param(
            daily.body_battery,
            json.dumps([{"charged": 1}]),
            "body_battery: [0].date",
            id="bb-entry-missing-date",
        ),
        pytest.param(
            daily.body_battery,
            json.dumps(
                [{k: v for k, v in _body_battery()[0].items() if k != "drained"}]
            ),
            "body_battery: [0].drained",
            id="bb-missing-drained",
        ),
        pytest.param(
            daily.body_battery,
            json.dumps(_body_battery(bodyBatteryValueDescriptorDTOList=None)),
            "body_battery: [0].bodyBatteryValueDescriptorDTOList",
            id="bb-descriptors-null",
        ),
        pytest.param(
            daily.body_battery,
            json.dumps(
                _body_battery(bodyBatteryValueDescriptorDTOList=BB_DESCRIPTORS[:1])
            ),
            "body_battery: [0].bodyBatteryValueDescriptorDTOList",
            id="bb-level-descriptor-missing",
        ),
        pytest.param(
            daily.body_battery,
            json.dumps(_body_battery(values=[[SLEEP_START, 20], [SLEEP_START, 30]])),
            "body_battery: [0].bodyBatteryValuesArray[1][0]",
            id="bb-duplicate-timestamp",
        ),
        pytest.param(
            daily.body_battery,
            json.dumps(_body_battery(values=[[None, 20]])),
            "body_battery: [0].bodyBatteryValuesArray[0][0]",
            id="bb-timestamp-null",
        ),
        pytest.param(
            daily.body_battery,
            json.dumps(_body_battery(values=[[1760000000000.0, 20]])),
            "body_battery: [0].bodyBatteryValuesArray[0][0]",
            id="bb-timestamp-float",
        ),
        pytest.param(
            daily.body_battery,
            json.dumps(_body_battery(values=[[True, 20]])),
            "body_battery: [0].bodyBatteryValuesArray[0][0]",
            id="bb-timestamp-bool",
        ),
        pytest.param(
            daily.body_battery,
            json.dumps(_body_battery(values=[[-5, 20]])),
            "body_battery: [0].bodyBatteryValuesArray[0][0]",
            id="bb-timestamp-negative",
        ),
        pytest.param(
            daily.body_battery,
            json.dumps(_body_battery(values=[[SLEEP_START]])),
            "body_battery: [0].bodyBatteryValuesArray[0]",
            id="bb-sample-too-short",
        ),
        pytest.param(
            daily.body_battery_samples,
            json.dumps(_body_battery(values=[[SLEEP_START, "151"]])),
            "body_battery: [0].bodyBatteryValuesArray[0][1]",
            id="bb-samples-level-not-number",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps([_heart_rates()]),
            "heart_rates: $",
            id="hr-not-object",
        ),
        pytest.param(
            daily.heart_rate_samples,
            f"not json {MARKER}",
            "heart_rates: ",
            id="hr-not-json",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(
                {k: v for k, v in _heart_rates().items() if k != "heartRateValues"}
            ),
            "heart_rates: heartRateValues",
            id="hr-missing-values",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(
                {
                    k: v
                    for k, v in _heart_rates().items()
                    if k != "heartRateValueDescriptors"
                }
            ),
            "heart_rates: heartRateValueDescriptors",
            id="hr-missing-descriptors",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(_heart_rates(heartRateValues={"151": 1})),
            "heart_rates: heartRateValues",
            id="hr-values-not-list",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(_heart_rates(heartRateValueDescriptors=None)),
            "heart_rates: heartRateValueDescriptors",
            id="hr-descriptors-null",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(_heart_rates(heartRateValueDescriptors=HR_DESCRIPTORS[:1])),
            "heart_rates: heartRateValueDescriptors",
            id="hr-heartrate-descriptor-missing",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(_heart_rates(heartRateValueDescriptors=HR_DESCRIPTORS[1:])),
            "heart_rates: heartRateValueDescriptors",
            id="hr-timestamp-descriptor-missing",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(
                _heart_rates(
                    heartRateValueDescriptors=[
                        HR_DESCRIPTORS[0],
                        {"key": "heartrate", "index": "1"},
                    ]
                )
            ),
            "heart_rates: heartRateValueDescriptors[1].index",
            id="hr-descriptor-index-string",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(_heart_rates([[HR_START, 60], [HR_START + 1]])),
            "heart_rates: heartRateValues[1]",
            id="hr-sample-too-short",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(_heart_rates([{"151": 60}])),
            "heart_rates: heartRateValues[0]",
            id="hr-sample-not-list",
        ),
        *(
            pytest.param(
                daily.heart_rate_samples,
                json.dumps(_heart_rates([[bad, 60]])),
                "heart_rates: heartRateValues[0][0]",
                id=f"hr-timestamp-{name}",
            )
            for name, bad in (
                ("null", None),
                ("float", 1760000000000.0),
                ("bool", True),
                ("negative", -5),
                ("string", "151"),
            )
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(_heart_rates([[HR_START, 60], [HR_START, 61]])),
            "heart_rates: heartRateValues[1][0]",
            id="hr-duplicate-timestamp",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(_heart_rates([[HR_START, "151"]])),
            "heart_rates: heartRateValues[0][1]",
            id="hr-bpm-not-number",
        ),
        pytest.param(
            daily.heart_rate_samples,
            json.dumps(_heart_rates([[HR_START, True]])),
            "heart_rates: heartRateValues[0][1]",
            id="hr-bpm-bool",
        ),
        *(
            pytest.param(
                daily.stress_data,
                json.dumps(
                    _stress_data(
                        stressValueDescriptorsDTOList=[
                            {"key": "timestamp", "index": 0},
                            {"key": "stressLevel", "index": bad},
                        ]
                    )
                ),
                "stress_data: stressValueDescriptorsDTOList[1].index",
                id=f"stress-descriptor-index-{name}",
            )
            for name, bad in (("negative", -1), ("bool", True), ("string", "1"))
        ),
        *(
            pytest.param(
                daily.body_battery,
                json.dumps(
                    _body_battery(
                        bodyBatteryValueDescriptorDTOList=[
                            BB_DESCRIPTORS[0],
                            {
                                "bodyBatteryValueDescriptorIndex": bad,
                                "bodyBatteryValueDescriptorKey": "bodyBatteryLevel",
                            },
                        ]
                    )
                ),
                "body_battery: [0].bodyBatteryValueDescriptorDTOList[1]"
                ".bodyBatteryValueDescriptorIndex",
                id=f"bb-descriptor-index-{name}",
            )
            for name, bad in (("negative", -1), ("bool", True), ("string", "1"))
        ),
    ],
)
def test_parser_errors_name_location_only(
    parser: daily.Parser, raw: str, location: str
):
    with pytest.raises(daily.NormalizeParseError) as excinfo:
        parser(raw, D1)

    message = str(excinfo.value)
    assert message.startswith(location)
    assert MARKER not in message
    assert "151" not in message
    assert excinfo.value.__context__ is None


def test_parse_error_is_value_error_and_exported():
    assert issubclass(daily.NormalizeParseError, ValueError)
    assert normalize.NormalizeParseError is daily.NormalizeParseError
    assert [code.value for code in normalize.NormalizeErrorCode] == [
        "parse_error",
        "internal",
    ]


def test_registered_endpoints_and_columns_are_disjoint():
    assert len(normalize.NORMALIZERS) == 14
    scopes = {
        scope: sorted(
            name for name, rule in normalize.NORMALIZERS.items() if rule.scope == scope
        )
        for scope in ("day", "activity")
    }
    assert scopes == {
        "day": sorted((*ENDPOINTS, "daily_weigh_ins", "lifestyle_logging_data")),
        "activity": sorted((*ACTIVITY_ENDPOINTS, EXERCISE_SETS)),
    }
    for scope, columns in (("day", ALL_COLUMNS), ("activity", ACTIVITY_VALUE_COLUMNS)):
        owned = [
            c
            for rule in normalize.NORMALIZERS.values()
            if rule.scope == scope
            for c in rule.columns
        ]
        assert len(owned) == len(set(owned)) == len(columns)
        assert set(owned) == set(columns)


# --- 근력 세트 정규화(5.4) ----------------------------------------------------------------------


OTHER_ID = 3001
SET_ROWS_SQL = (
    "SELECT set_index, category, exercise_name, reps, weight_g, duration_s, is_rest"
    " FROM exercise_set WHERE activity_id = ? ORDER BY set_index"
)


def _set(
    set_type: object = "ACTIVE",
    exercises: object = None,
    reps: object = None,
    weight: object = None,
    duration: object = None,
    **overrides: object,
) -> dict[str, object]:
    """합성 세트 원소 하나. 저장하지 않는 키(`startTime`·`messageIndex`·속도 등)도 실제 모양대로 담는다."""
    payload: dict[str, object] = {
        "exercises": [] if exercises is None else exercises,
        "duration": duration,
        "repetitionCount": reps,
        "weight": weight,
        "setType": set_type,
        "startTime": "2026-10-15T07:30:00.0",
        "wktStepIndex": None,
        "messageIndex": None,
        "avgConcentricMeanVelocity": None,
        "maxConcentricRom": None,
        "메모": MARKER,
    }
    return payload | overrides


def _candidate(
    category: object, name: object = None, probability: object = 50.0
) -> dict[str, object]:
    return {"category": category, "name": name, "probability": probability}


def _exercise_sets(
    sets: object, activity_id: int = RUN_ID, **overrides: object
) -> dict[str, object]:
    return {"activityId": activity_id, "exerciseSets": sets} | overrides


# 실제 모양(I/O 매트릭스 1행): 후보 둘인 ACTIVE, 휴식, 후보 하나·이름 null·무게 센티넬인 ACTIVE.
REAL_SHAPE_SETS = [
    _set(
        exercises=[
            _candidate("SQUAT", "BARBELL_BACK_SQUAT", 41.0),
            _candidate("DEADLIFT", "BARBELL_DEADLIFT", 40.6),
        ],
        reps=10,
        weight=40000.0,
        duration=61.588,
    ),
    _set("REST", exercises=[], duration=59.5),
    _set(
        exercises=[_candidate("PUSH_UP", None, 70.0)],
        reps=12,
        weight=-1.0,
        duration=30.2,
    ),
]
# (set_index, category, exercise_name, reps, weight_g, duration_s, is_rest). 손 계산:
# 61.588 → 62, 59.5 → 60(짝수 쪽 반올림), 30.2 → 30, 무게 40000.0 g → 40000, -1.0 → NULL(음수 센티넬).
REAL_SHAPE_ROWS = [
    (0, "SQUAT", "BARBELL_BACK_SQUAT", 10, 40000, 62, 0),
    (1, None, None, None, None, 60, 1),
    (2, "PUSH_UP", None, 12, None, 30, 0),
]


def _set_rows(cfg: config.Config, activity_id: int = RUN_ID) -> list[tuple]:
    return _query(cfg, SET_ROWS_SQL, (activity_id,))


def _put_sets(
    cfg: config.Config,
    payload: object,
    activity_id: int = RUN_ID,
    *,
    now_ms: int = FETCHED,
) -> None:
    _put(cfg, [("activity", str(activity_id), EXERCISE_SETS, payload)], now_ms=now_ms)


def _sets_result(cfg: config.Config, activity_id: int = RUN_ID) -> tuple:
    (row,) = [
        row[3:5]
        for row in _results(cfg)
        if row[1] == str(activity_id) and row[2] == EXERCISE_SETS
    ]
    return row


def test_exercise_sets_registration():
    assert activity.ACTIVITY_EXERCISE_SETS_COLUMNS == ()
    assert activity.activity_exercise_sets("not json", "1") == {}
    rule = normalize.NORMALIZERS[EXERCISE_SETS]
    assert rule.columns == ()
    assert rule.scope == "activity"
    assert rule.sample_table == normalize.SampleTable(
        "exercise_set", activity.EXERCISE_SET_COLUMNS, activity.exercise_set_rows
    )
    assert activity.EXERCISE_SET_COLUMNS == (
        "set_index",
        "category",
        "exercise_name",
        "reps",
        "weight_g",
        "duration_s",
        "is_rest",
    )


def test_exercise_set_table_shape(cfg: config.Config):
    _run(cfg)
    columns = _query(cfg, "PRAGMA table_info(exercise_set)")
    assert [(name, kind, notnull, pk) for _, name, kind, notnull, _, pk in columns] == [
        ("activity_id", "INTEGER", 1, 1),
        ("set_index", "INTEGER", 1, 2),
        ("category", "TEXT", 0, 0),
        ("exercise_name", "TEXT", 0, 0),
        ("reps", "INTEGER", 0, 0),
        ("weight_g", "INTEGER", 0, 0),
        ("duration_s", "INTEGER", 0, 0),
        ("is_rest", "INTEGER", 1, 0),
    ]
    assert _query(cfg, "PRAGMA foreign_key_list(exercise_set)") == []
    with pytest.raises(sqlite3.IntegrityError), store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO exercise_set (activity_id, set_index, is_rest) VALUES (1, 0, 2)"
        )


def test_real_shape_sets_are_normalized(cfg: config.Config):
    _put(cfg, [_activity_list(D1, RUN_ID)])
    _put_sets(cfg, _exercise_sets(REAL_SHAPE_SETS))
    before_raw = _raw_snapshot(cfg)

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _set_rows(cfg) == REAL_SHAPE_ROWS
    assert _results(cfg) == [
        ("activity", str(RUN_ID), EXERCISE_SETS, 1, None, FETCHED, CLOCK_MS)
    ]
    # 세트 원문은 `activity` 행을 만들지 않는다.
    assert _activities(cfg) == {}
    assert _raw_snapshot(cfg) == before_raw
    # 다시 돌려도 할 일이 없다(정규화 밀림이 남지 않는다).
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)
    assert _set_rows(cfg) == REAL_SHAPE_ROWS


def test_zero_weight_is_null_and_zero_reps_stay_zero(cfg: config.Config):
    # 무게 0은 "입력 안 함"(실제 fixture에서 바벨 종목에도 나온다)이라 NULL이다. 0.4 g도 `round()` 뒤 0이라 NULL,
    # 0.6 g는 1 g다. 반복·시간의 0은 0이다.
    _put_sets(
        cfg,
        _exercise_sets(
            [
                _set(exercises=[_candidate("PLANK")], reps=0, weight=0.0, duration=0),
                _set(exercises=[_candidate("PLANK")], reps=1, weight=0.4, duration=1),
                _set(exercises=[_candidate("PLANK")], reps=2, weight=0.6, duration=2),
            ]
        ),
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _set_rows(cfg) == [
        (0, "PLANK", None, 0, None, 0, 0),
        (1, "PLANK", None, 1, None, 1, 0),
        (2, "PLANK", None, 2, 1, 2, 0),
    ]
    assert _sets_result(cfg) == (1, None)


@pytest.mark.parametrize(
    "sets", [pytest.param([], id="empty"), pytest.param(None, id="null")]
)
def test_empty_or_null_exercise_sets_have_no_rows(cfg: config.Config, sets: object):
    _put_sets(cfg, _exercise_sets(REAL_SHAPE_SETS))
    _run(cfg)
    _put_sets(cfg, _exercise_sets(sets), now_ms=FETCHED + 1)

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _set_rows(cfg) == []
    assert _sets_result(cfg) == (1, None)


def test_null_raw_clears_sets(cfg: config.Config):
    _put_sets(cfg, _exercise_sets(REAL_SHAPE_SETS))
    _run(cfg)
    _put_text(
        cfg, str(RUN_ID), EXERCISE_SETS, "null", now_ms=FETCHED + 1, scope="activity"
    )

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _set_rows(cfg) == []
    assert _sets_result(cfg) == (1, None)
    assert _activities(cfg) == {}


def test_refetched_sets_replace_only_that_activity(cfg: config.Config):
    four = [
        _set(exercises=[_candidate("SQUAT")], reps=5, weight=60000.0, duration=20.0),
        _set("REST", duration=90.0),
        _set(exercises=[_candidate("SQUAT")], reps=5, weight=60000.0, duration=20.0),
        _set("REST", duration=90.0),
    ]
    _put_sets(cfg, _exercise_sets(four))
    _put_sets(cfg, _exercise_sets(REAL_SHAPE_SETS, OTHER_ID), OTHER_ID)
    assert _run(cfg) == normalize.Summary(processed=2, failed=0)
    assert len(_set_rows(cfg)) == 4

    two = [
        _set(exercises=[_candidate("LUNGE")], reps=8, weight=10000.0, duration=25.0),
        _set("REST", duration=45.0),
    ]
    _put_sets(cfg, _exercise_sets(two), now_ms=FETCHED + 1)

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _set_rows(cfg) == [
        (0, "LUNGE", None, 8, 10000, 25, 0),
        (1, None, None, None, None, 45, 1),
    ]
    assert _set_rows(cfg, OTHER_ID) == REAL_SHAPE_ROWS


def _without_key(payload: dict[str, object], key: str) -> dict[str, object]:
    return {k: v for k, v in payload.items() if k != key}


BAD_EXERCISE_SETS = [
    pytest.param(
        {"activityId": RUN_ID, "메모": MARKER},
        "activity_exercise_sets: exerciseSets 키",
        id="no-key",
    ),
    pytest.param(
        _exercise_sets({"0": MARKER}),
        "activity_exercise_sets: exerciseSets가 리스트",
        id="sets-dict",
    ),
    pytest.param(
        _exercise_sets([REAL_SHAPE_SETS[0], MARKER]),
        "activity_exercise_sets: exerciseSets[1]가 객체",
        id="element-not-dict",
    ),
    pytest.param(
        _exercise_sets([_without_key(REAL_SHAPE_SETS[0], "setType")]),
        "activity_exercise_sets: exerciseSets[0].setType 키",
        id="no-set-type",
    ),
    pytest.param(
        _exercise_sets([_set("WARMUP", duration=10.0)]),
        "activity_exercise_sets: exerciseSets[0].setType이 ACTIVE·REST",
        id="warmup",
    ),
    pytest.param(
        _exercise_sets([_set(None, duration=10.0)]),
        "activity_exercise_sets: exerciseSets[0].setType이 ACTIVE·REST",
        id="set-type-null",
    ),
    pytest.param(
        _exercise_sets([_set(reps=3, weight="40000")]),
        "activity_exercise_sets: exerciseSets[0].weight가 숫자",
        id="weight-string",
    ),
    pytest.param(
        _exercise_sets([_set(reps=True)]),
        "activity_exercise_sets: exerciseSets[0].repetitionCount가 숫자",
        id="reps-bool",
    ),
    pytest.param(
        _exercise_sets([_without_key(_set(), "duration")]),
        "activity_exercise_sets: exerciseSets[0].duration 키",
        id="no-duration",
    ),
    pytest.param(
        _exercise_sets([_set(exercises={"category": "SQUAT"})]),
        "activity_exercise_sets: exerciseSets[0].exercises가 리스트",
        id="exercises-dict",
    ),
    pytest.param(
        _exercise_sets([_set(exercises=[{"category": "SQUAT", "probability": 1.0}])]),
        "activity_exercise_sets: exerciseSets[0].exercises[0].name 키",
        id="candidate-no-name",
    ),
    pytest.param(
        _exercise_sets(
            [_set(exercises=[_without_key(_candidate("SQUAT"), "probability")])]
        ),
        "activity_exercise_sets: exerciseSets[0].exercises[0].probability 키",
        id="candidate-no-probability",
    ),
    pytest.param(
        _exercise_sets(
            [_set(exercises=[_without_key(_candidate("SQUAT"), "category")])]
        ),
        "activity_exercise_sets: exerciseSets[0].exercises[0].category 키",
        id="candidate-no-category",
    ),
    pytest.param(
        _exercise_sets([_without_key(_set(), "exercises")]),
        "activity_exercise_sets: exerciseSets[0].exercises 키",
        id="no-exercises",
    ),
    pytest.param(
        _exercise_sets([_without_key(_set(), "repetitionCount")]),
        "activity_exercise_sets: exerciseSets[0].repetitionCount 키",
        id="no-repetition-count",
    ),
    pytest.param(
        _exercise_sets([_without_key(_set(), "weight")]),
        "activity_exercise_sets: exerciseSets[0].weight 키",
        id="no-weight",
    ),
    pytest.param(
        _exercise_sets(
            [_set(exercises=[_candidate("SQUAT"), _candidate(7, probability=1.0)])]
        ),
        "activity_exercise_sets: exerciseSets[0].exercises[1].category가 문자열",
        id="unchosen-candidate-bad-category",
    ),
    pytest.param(
        _exercise_sets([_set(exercises=[_candidate("SQUAT", probability="high")])]),
        "activity_exercise_sets: exerciseSets[0].exercises[0].probability가 숫자",
        id="probability-string",
    ),
    pytest.param(
        _exercise_sets([_set(duration=float("nan"))]),
        "activity_exercise_sets: exerciseSets[0].duration가 유한한",
        id="duration-nan",
    ),
]


@pytest.mark.parametrize(("payload", "location"), BAD_EXERCISE_SETS)
def test_bad_exercise_sets_fail_only_that_item(
    cfg: config.Config,
    payload: dict[str, object],
    location: str,
    caplog: pytest.LogCaptureFixture,
):
    _put_sets(cfg, _exercise_sets(REAL_SHAPE_SETS))
    _put_sets(cfg, _exercise_sets(REAL_SHAPE_SETS, OTHER_ID), OTHER_ID)
    _run(cfg)
    _put(cfg, [_activity_list(D1, RUN_ID), *_activity_rows()])
    _put_sets(cfg, payload, now_ms=FETCHED + 1)

    with caplog.at_level(logging.WARNING, logger="garmin_pipeline.normalize"):
        # 실패한 세트 원문 하나 + 같은 활동의 3종(다른 항목은 계속된다).
        assert _run(cfg) == normalize.Summary(processed=4, failed=1)

    assert _set_rows(cfg) == []
    assert _sets_result(cfg) == (0, "parse_error")
    assert _set_rows(cfg, OTHER_ID) == REAL_SHAPE_ROWS
    assert _sets_result(cfg, OTHER_ID) == (1, None)
    # 실패 경로도 `activity` 행을 바꾸지 않는다.
    assert _activities(cfg) == {RUN_ID: _activity_expected(D1)}
    assert MARKER not in caplog.text

    with pytest.raises(daily.NormalizeParseError) as excinfo:
        activity.exercise_set_rows(json.dumps(payload), str(RUN_ID))
    message = str(excinfo.value)
    assert message.startswith(location)
    assert MARKER not in message
    assert "40000" not in message
    assert excinfo.value.__context__ is None


def test_exercise_sets_not_json_is_parse_error(cfg: config.Config):
    _put_text(cfg, str(RUN_ID), EXERCISE_SETS, "not json", scope="activity")

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    assert _sets_result(cfg) == (0, "parse_error")


@pytest.mark.parametrize(
    ("candidates", "expected"),
    [
        pytest.param(
            [_candidate("A", "a", 10.0), _candidate("B", "b", 30.0)],
            ("B", "b"),
            id="larger-later",
        ),
        pytest.param(
            [_candidate("A", "a", 30.0), _candidate("B", "b", 30.0)],
            ("A", "a"),
            id="tie-first",
        ),
        pytest.param(
            [_candidate("A", "a", None), _candidate("B", "b", 0.0)],
            ("B", "b"),
            id="null-below-zero",
        ),
        pytest.param(
            [_candidate("A", "a", 5.0), _candidate("B", "b", None)],
            ("A", "a"),
            id="null-never-wins",
        ),
        pytest.param(
            [_candidate("A", "a", None), _candidate("B", "b", None)],
            ("A", "a"),
            id="all-null-first",
        ),
        pytest.param(
            [_candidate("A", "a", -1.0), _candidate("B", "b", 0.5)],
            ("B", "b"),
            id="negative-is-null",
        ),
        pytest.param(
            [_candidate(None, None, 99.0), _candidate("B", "b", 1.0)],
            (None, None),
            id="chosen-null-category",
        ),
        pytest.param(None, (None, None), id="exercises-null"),
        pytest.param([], (None, None), id="no-candidates"),
    ],
)
def test_exercise_choice_is_highest_probability(
    candidates: object, expected: tuple[object, object]
):
    raw = json.dumps(
        _exercise_sets(
            [_set(reps=1, duration=1.0, exercises=None) | {"exercises": candidates}]
        )
    )

    (row,) = activity.exercise_set_rows(raw, str(RUN_ID))

    assert row[1:3] == expected


def test_set_index_is_list_position_not_message_index_or_start_time():
    sets = [
        _set(reps=1, duration=1.0, messageIndex=5, startTime="2026-10-15T08:00:00.0"),
        _set(
            "REST", duration=2.0, messageIndex=None, startTime="2026-10-15T07:00:00.0"
        ),
        _set(reps=3, duration=3.0, messageIndex=0, startTime="2026-10-15T06:00:00.0"),
    ]

    rows = activity.exercise_set_rows(json.dumps(_exercise_sets(sets)), str(RUN_ID))

    assert [(row[0], row[3], row[5]) for row in rows] == [
        (0, 1, 1),
        (1, None, 2),
        (2, 3, 3),
    ]


def test_existing_activity_row_is_untouched_by_sets(cfg: config.Config):
    _put(cfg, [_activity_list(D1, RUN_ID), *_activity_rows()])
    _run(cfg)
    before = _activities(cfg)
    before_samples = _activity_hr_samples(cfg, RUN_ID)

    _put_sets(cfg, _exercise_sets(REAL_SHAPE_SETS))
    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _activities(cfg) == before == {RUN_ID: _activity_expected(D1)}
    assert _activity_hr_samples(cfg, RUN_ID) == before_samples
    assert _set_rows(cfg) == REAL_SHAPE_ROWS


def test_internal_failure_clears_sets(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
):
    _put_sets(cfg, _exercise_sets(REAL_SHAPE_SETS))
    _run(cfg)
    rule = normalize.NORMALIZERS[EXERCISE_SETS]
    assert rule.sample_table is not None

    def explode(raw: str, key: str) -> list[daily.Sample]:
        raise RuntimeError(f"boom {MARKER}")

    monkeypatch.setitem(
        normalize.NORMALIZERS,
        EXERCISE_SETS,
        rule._replace(sample_table=rule.sample_table._replace(parse=explode)),
    )
    _put_sets(cfg, _exercise_sets(REAL_SHAPE_SETS[:1]), now_ms=FETCHED + 1)

    assert _run(cfg) == normalize.Summary(processed=1, failed=1)

    assert _set_rows(cfg) == []
    assert _sets_result(cfg) == (0, "internal")


def test_wrong_row_width_is_internal_failure(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
):
    # 파서 결함(열 수와 다른 행)은 sqlite 오류로 실행 전체를 멈추지 않고 그 항목만 `internal`이다.
    rule = normalize.NORMALIZERS[EXERCISE_SETS]
    assert rule.sample_table is not None
    monkeypatch.setitem(
        normalize.NORMALIZERS,
        EXERCISE_SETS,
        rule._replace(
            sample_table=rule.sample_table._replace(parse=lambda raw, key: [(0, 1)])
        ),
    )
    _put_sets(cfg, _exercise_sets(REAL_SHAPE_SETS))
    _put(cfg, [("day", D1, "rhr_day", _rhr_day())])

    assert _run(cfg) == normalize.Summary(processed=2, failed=1)

    assert _set_rows(cfg) == []
    assert _sets_result(cfg) == (0, "internal")
    assert _metrics(cfg)[D1]["resting_hr"] == EXPECTED["resting_hr"]


# --- 실제 fixture(있으면) ---------------------------------------------------------------------


def _fixture_files(root: Path) -> list[Path]:
    """`root/<endpoint>/*.json`(capture-fixtures 출력 구조) 중 등록된 endpoint(두 scope)의 파일."""
    return [
        path
        for endpoint in (*ENDPOINTS, *ACTIVITY_ENDPOINTS, EXERCISE_SETS)
        for path in sorted((root / endpoint).glob("*.json"))
    ]


def _check_fixture_file(cfg: config.Config, path: Path) -> None:
    """fixture 파일 하나를 원문으로 넣고 정규화하면 ok=1이고, data면 그 키 행이 생긴다.

    scope는 등록된 규칙(`Normalizer.scope`)을 따른다. 소유 열이 없는 endpoint(`heart_rates`·
    `activity_details`·`activity_exercise_sets`)는 대상 테이블 행을 만들지 않는다. 세트 원문이면
    `_check_fixture_sets`도 본다.
    """
    key, endpoint = path.stem, path.parent.name
    rule = normalize.NORMALIZERS[endpoint]
    raw = path.read_text(encoding="utf-8")
    _put_text(cfg, key, endpoint, raw, scope=rule.scope)

    assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _results(cfg)[0][:5] == (rule.scope, key, endpoint, 1, None)
    rows = _metrics(cfg) if rule.scope == "day" else _activities(cfg)
    row_key = key if rule.scope == "day" else int(key)
    if not rule.columns:
        assert row_key not in rows
    if endpoint == "heart_rates" and raw != "null":
        values = json.loads(raw)["heartRateValues"] or []
        assert len(_hr_samples(cfg, key)) == len(values)
    elif endpoint == "activity_details" and raw != "null":
        details = json.loads(raw)
        keys = {d.get("key") for d in details["metricDescriptors"] or []}
        expected = (
            len(details["activityDetailMetrics"] or [])
            if "directHeartRate" in keys
            else 0
        )
        samples = _activity_body_battery(cfg, int(key))
        assert len(samples) == expected
        # 5.9: 샘플마다 저장한 body_battery = 원문 directBodyBattery 값(null·음수 → None, 아니면 round).
        # 채널이 없으면 모두 None이다. 반올림한 시각으로 맞춘다.
        positions = {
            d.get("key"): d.get("metricsIndex")
            for d in details["metricDescriptors"] or []
        }
        if expected:
            ts_at, bb_at = (
                positions["directTimestamp"],
                positions.get("directBodyBattery"),
            )
            wanted: dict[int, int | None] = {}
            for sample in details["activityDetailMetrics"]:
                value = None if bb_at is None else sample["metrics"][bb_at]
                wanted[round(sample["metrics"][ts_at])] = (
                    None if value is None or value < 0 else round(value)
                )
            assert {row[0]: row[2] for row in samples} == wanted
    elif endpoint == EXERCISE_SETS:
        _check_fixture_sets(cfg, int(key), raw)
    elif rule.columns and raw != "null":
        assert row_key in rows


def _check_fixture_sets(cfg: config.Config, activity_id: int, raw: str) -> None:
    """세트 행 수 = `len(exerciseSets)`, REST 행은 반복·무게가 NULL, ACTIVE 행은 종목이 있고, 무게는 NULL 또는 양수다."""
    sets = [] if raw == "null" else json.loads(raw)["exerciseSets"] or []
    rows = _set_rows(cfg, activity_id)
    assert len(rows) == len(sets)
    for set_index, category, _, reps, weight_g, _, is_rest in rows:
        if is_rest:
            assert (reps, weight_g) == (None, None), set_index
        else:
            assert category is not None, set_index
        # 무게 0은 NULL로 정규화한다(음수 센티넬도 NULL): 남는 무게는 양수뿐이다.
        assert weight_g is None or weight_g > 0, set_index


def _real_fixture_params() -> list[object]:
    params = [
        pytest.param(path, id=f"{path.parent.name}/{path.name}")
        for path in _fixture_files(REAL_FIXTURES)
    ]
    return params or [pytest.param(None, id="no-real-fixtures")]


@pytest.mark.parametrize("path", _real_fixture_params())
def test_real_fixture_normalizes(cfg: config.Config, path: Path | None):
    if path is None:
        pytest.skip("실제 fixture(tests/fixtures/garmin/<endpoint>/*.json)가 없다")
    _check_fixture_file(cfg, path)


def _real_lists() -> list[Path]:
    return sorted((REAL_FIXTURES / "activities_by_date").glob("*.json"))


def test_real_activity_lists_use_local_date(cfg: config.Config):
    # 날짜 기준 확인(사람 확인 단계의 자동 부분): 목록 ref의 일 키가 파일 이름의 day와 같으면 목록은 로컬
    # 날짜 기준이다. 같은 id의 activity fixture가 있으면 그 startTimeLocal 날짜도 day와 같고, 정규화한
    # activity.day_key도 그 day다.
    lists = _real_lists()
    if not lists:
        pytest.skip(
            "실제 fixture(tests/fixtures/garmin/activities_by_date/*.json)가 없다"
        )
    checked: list[tuple[int, str]] = []
    for path in lists:
        day = path.stem
        raw = path.read_text(encoding="utf-8")
        refs = rawparse.activity_refs(raw)
        assert {ref.day_key for ref in refs} <= {day}, path.name
        _put_text(cfg, day, "activities_by_date", raw)
        for ref in refs:
            summary_path = REAL_FIXTURES / "activity" / f"{ref.activity_id}.json"
            if not summary_path.exists():
                continue
            summary_raw = summary_path.read_text(encoding="utf-8")
            if summary_raw == "null":
                continue
            local = json.loads(summary_raw)["summaryDTO"]["startTimeLocal"]
            assert local[:10] == day, summary_path.name
            _put_text(
                cfg, str(ref.activity_id), "activity", summary_raw, scope="activity"
            )
            checked.append((ref.activity_id, day))
    _run(cfg)
    activities = _activities(cfg)
    # 로컬 날짜 기준과 GMT 날짜 기준은 로컬 날짜와 GMT 날짜가 다른 활동(예: KST 09:00 전 시작)이 fixture에
    # 하나라도 있어야 구별된다. 그런 활동이 없으면 위 검사는 두 기준 모두에서 통과한다.
    for activity_id, day in checked:
        row = activities[activity_id]
        assert row["day_key"] == day
        assert dates.day_key(row["start_ms"], cfg) == day, (
            f"{activity_id}: UTC 시작 시각(start_ms)을 config 시간대로 바꾼 날짜가 목록의 day와"
            " 다르다(목록이 로컬 날짜 기준이 아니거나 startTimeGMT를 잘못 읽었다)"
        )


def test_real_activity_heart_rate_samples_is_not_empty(cfg: config.Config):
    # 심박 채널 키(`directHeartRate`) 가정 확인: 요약에 averageHR가 있고 details에 샘플이 있으면 시계열이
    # 비지 않아야 한다(키 이름이 틀리면 조용히 빈 시계열이 된다). 시각 단위(`directTimestamp`가 ms) 가정
    # 확인: 샘플 시각은 요약의 시작 시각(`start_ms`)에서 24시간 안이어야 한다(초 단위면 1970년 근처가 된다).
    pairs = [
        (path, REAL_FIXTURES / "activity" / path.name)
        for path in sorted((REAL_FIXTURES / "activity_details").glob("*.json"))
    ]
    candidates = []
    for details_path, summary_path in pairs:
        if not summary_path.exists():
            continue
        details_raw = details_path.read_text(encoding="utf-8")
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        if details_raw == "null" or summary is None:
            continue
        if summary["summaryDTO"].get("averageHR") is None:
            continue
        if not json.loads(details_raw)["activityDetailMetrics"]:
            continue
        summary_raw = summary_path.read_text(encoding="utf-8")
        candidates.append((details_path.stem, details_raw, summary_raw))
    if not candidates:
        pytest.skip("심박이 있는 실제 활동 fixture(activity + activity_details)가 없다")
    for key, details_raw, summary_raw in candidates:
        _put_text(cfg, key, "activity_details", details_raw, scope="activity")
        _put_text(cfg, key, "activity", summary_raw, scope="activity")
    _run(cfg)
    day_ms = 24 * 60 * MINUTE_MS
    for key, _, _ in candidates:
        samples = _activity_hr_samples(cfg, int(key))
        assert samples, key
        start_ms = _activities(cfg)[int(key)]["start_ms"]
        if start_ms is None:
            continue
        far = [ts for ts, _ in samples if abs(ts - start_ms) > day_ms]
        assert not far, f"activity_id={key}: start_ms에서 24시간 밖인 샘플 {len(far)}개"


def _set_groups(rows: list[tuple]) -> dict[tuple[object, object], list[int]]:
    """REST가 아닌 세트 행을 (category, exercise_name)로 묶은 [세트 수, Σreps, Σ(reps × weight_g)].

    reps·weight_g가 NULL이면 0으로 더한다(무게 없는 세트는 볼륨에 들지 않는다).
    """
    groups: dict[tuple[object, object], list[int]] = {}
    for _, category, name, reps, weight_g, _, is_rest in rows:
        if is_rest:
            continue
        group = groups.setdefault((category, name), [0, 0, 0])
        group[0] += 1
        group[1] += reps or 0
        group[2] += (reps or 0) * (weight_g or 0)
    return groups


def test_real_sets_match_garmin_summary(cfg: config.Config):
    # 근거(5.4): Garmin 앱 요약 화면과 같은 출처인 목록의 `summarizedExerciseSets`가 (category, subCategory)별
    # sets·reps·volume을 준다. 정규화한 세트를 최대 확률 후보의 (category, exercise_name)로 묶은 세트 수·
    # Σ반복·Σ반복×무게(g)가 그 값과 같으면 무게 단위(g)·센티넬(-1.0 → NULL)·휴식 표현·종목 선택이 맞다.
    # 값은 커밋하지 않고 실패 메시지로만 남긴다.
    pairs: list[tuple[str, str, int, list[object]]] = []
    for path in _real_lists():
        entries = json.loads(path.read_text(encoding="utf-8")) or []
        for entry in entries:
            sets_path = REAL_FIXTURES / EXERCISE_SETS / f"{entry['activityId']}.json"
            if entry.get("summarizedExerciseSets") and sets_path.exists():
                pairs.append(
                    (
                        path.stem,
                        path.read_text(encoding="utf-8"),
                        entry["activityId"],
                        entry["summarizedExerciseSets"],
                    )
                )
    if not pairs:
        pytest.skip(
            "같은 활동의 실제 세트 fixture와 목록 fixture(summarizedExerciseSets)가 없다"
        )
    for day, list_raw, activity_id, summarized in pairs:
        _put_text(cfg, day, "activities_by_date", list_raw)
        sets_raw = (REAL_FIXTURES / EXERCISE_SETS / f"{activity_id}.json").read_text(
            encoding="utf-8"
        )
        _put_text(cfg, str(activity_id), EXERCISE_SETS, sets_raw, scope="activity")
    summary = _run(cfg)
    assert summary.failed == 0
    for _, _, activity_id, summarized in pairs:
        expected = {
            (item["category"], item.get("subCategory")): [
                item["sets"],
                item["reps"],
                item["volume"],
            ]
            for item in summarized
        }
        # 요약 키가 겹치면 dict가 조용히 덮어써 비교가 약해진다.
        assert len(expected) == len(summarized), activity_id
        groups = _set_groups(_set_rows(cfg, activity_id))
        assert groups == expected, activity_id


def test_synthetic_fixture_dir_normalizes(
    write_config: Callable[..., Path], clock: list[datetime], tmp_path: Path
):
    # 실제 fixture가 없을 때도 같은 탐색·검사 경로가 돌게, capture-fixtures와 같은 구조의 합성
    # 폴더(day 8종 data + null 하나 + activity 3종 data + 세트 상세 하나 + 미등록 endpoint 하나)로 시험한다.
    root = tmp_path / "fixtures" / "garmin"
    rows = [
        *_day(D1),
        *_sleep_stress_bb(D1),
        ("day", D1, "heart_rates", _heart_rates()),
        ("day", D2, "hrv_data", None),
        *_activity_rows(RUN_ID),
        ("activity", str(RUN_ID), EXERCISE_SETS, _exercise_sets(REAL_SHAPE_SETS)),
    ]
    for _, key, endpoint, payload in rows:
        (root / endpoint).mkdir(parents=True, exist_ok=True)
        (root / endpoint / f"{key}.json").write_text(
            json.dumps(payload, ensure_ascii=False), encoding="utf-8"
        )
    (root / "activities_by_date").mkdir()
    (root / "activities_by_date" / f"{D1}.json").write_text("[]", encoding="utf-8")

    files = _fixture_files(root)
    assert len(files) == len(ENDPOINTS) + 1 + len(ACTIVITY_ENDPOINTS) + 1
    for index, path in enumerate(files):
        # 파일마다 빈 DB에서 시작한다(실제 fixture 시험과 같은 조건).
        cfg = config.load(
            write_config(lock_wait_seconds=0, data_dir=str(tmp_path / f"d{index}"))
        )
        _check_fixture_file(cfg, path)


# --- 네트워크 차단·어댑터 미로드 --------------------------------------------------------------


def test_works_with_sockets_blocked(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
):
    _put(cfg, _day())

    class Blocked(socket.socket):
        # 함수가 아니라 하위 클래스로 바꿔 `ssl.SSLSocket(socket)` 같은 상속은 깨지지 않게 한다.
        def __init__(self, *args: object, **kwargs: object) -> None:
            raise OSError("소켓 차단")

    monkeypatch.setattr(socket, "socket", Blocked)

    assert _run(cfg) == normalize.Summary(processed=4, failed=0)
    assert _metrics(cfg) == {D1: EXPECTED}


def test_does_not_load_garmin_adapter(cfg: config.Config, tmp_path: Path):
    _put(cfg, _day())
    probe = (
        "import socket, sys\n"
        "class Blocked(socket.socket):\n"
        "    def __init__(self, *args, **kwargs):\n"
        "        raise OSError('socket blocked')\n"
        "socket.socket = Blocked\n"
        "from garmin_pipeline import cli\n"
        f"code = cli.main(['normalize', '--config', {str(cfg.path)!r}])\n"
        "loaded = sorted(name for name in sys.modules if name == 'garmin_pipeline.garmin'"
        " or name.startswith(('garmin_pipeline.garmin.', 'garminconnect', 'curl_cffi')))\n"
        "print('PROBE', code, loaded)\n"
    )

    result = subprocess.run(
        [sys.executable, "-c", probe],
        cwd=tmp_path,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.stdout.splitlines()[-1:] == ["PROBE 0 []"], result.stderr
    assert "normalize: processed=4 failed=0" in result.stdout
    assert _metrics(cfg) == {D1: EXPECTED}


# --- CLI ------------------------------------------------------------------------------------


def _main(cfg: config.Config) -> int:
    return cli.main(["normalize", "--config", str(cfg.path)])


def test_cli_prints_summary_and_logs(
    cfg: config.Config, capsys: pytest.CaptureFixture[str]
):
    _put(cfg, [*_day(), ("day", D2, "rhr_day", {"메모": MARKER})])

    assert _main(cfg) == 0

    out, err = capsys.readouterr()
    assert out == "normalize: processed=5 failed=1\n"
    assert err == ""
    log = (cfg.data_dir / "logs" / "normalize.log").read_text(encoding="utf-8")
    assert (
        f"정규화 실패: scope=day key={D2} endpoint=rhr_day error_code=parse_error"
        in log
    )
    assert "normalize 끝: processed=5 failed=1" in log
    assert MARKER not in log


def test_cli_config_error_exits_2(tmp_path: Path, capsys: pytest.CaptureFixture[str]):
    assert cli.main(["normalize", "--config", str(tmp_path / "nowhere.toml")]) == 2

    assert capsys.readouterr().err.startswith("설정 오류: ")
    assert not (tmp_path / "data").exists()


def test_cli_lock_held_exits_1(cfg: config.Config, capsys: pytest.CaptureFixture[str]):
    _put(cfg, _day())
    fd = os.open(cfg.data_dir / store.LOCK_FILENAME, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        assert _main(cfg) == 1
    finally:
        os.close(fd)

    out, err = capsys.readouterr()
    assert out == ""
    assert err.startswith("normalize 실패: ")
    assert _results(cfg) == []


def test_cli_sqlite_error_exits_1(
    cfg: config.Config,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    _put(cfg, _day())

    def broken(
        conn: sqlite3.Connection, *, rebuild: bool, timezone: str
    ) -> normalize.Summary:
        raise sqlite3.OperationalError("database disk image is malformed")

    monkeypatch.setattr(normalize, "run", broken)

    assert _main(cfg) == 1

    out, err = capsys.readouterr()
    assert out == ""
    assert err == "normalize 실패: database disk image is malformed\n"


def test_cli_lock_file_os_error_exits_1(
    cfg: config.Config, capsys: pytest.CaptureFixture[str]
):
    # 락 파일을 열 수 없으면(여기서는 디렉터리) 추적 없이 `normalize 실패`로 1이다.
    (cfg.data_dir / store.LOCK_FILENAME).mkdir(parents=True)

    assert _main(cfg) == 1

    out, err = capsys.readouterr()
    assert out == ""
    assert err.startswith("normalize 실패: ")
    assert "Traceback" not in err


def test_cli_log_open_error_exits_1(
    cfg: config.Config, capsys: pytest.CaptureFixture[str]
):
    cfg.data_dir.mkdir(parents=True, exist_ok=True)
    (cfg.data_dir / "logs").write_text("not a directory", encoding="utf-8")

    assert _main(cfg) == 1

    assert capsys.readouterr().err.startswith(
        "normalize 실패: 로그 파일을 열지 못했다: "
    )
    assert not cfg.db_path.exists()


def test_cli_help_lists_config(capsys: pytest.CaptureFixture[str]):
    with pytest.raises(SystemExit) as exit_info:
        cli.main(["normalize", "--help"])

    assert exit_info.value.code == 0
    assert "--config PATH" in capsys.readouterr().out


# --- 인수 기준: 콘솔 스크립트 ------------------------------------------------------------------


def test_console_script_normalizes_then_finds_nothing(
    cfg: config.Config, tmp_path: Path
):
    _put(cfg, _day())
    before = _raw_snapshot(cfg)
    script = shutil.which("garmin-pipeline", path=sysconfig.get_path("scripts"))
    assert script is not None, "콘솔 스크립트가 없다. `uv sync`를 먼저 실행한다."
    env = {key: value for key, value in os.environ.items() if key != "FORCE_COLOR"}
    env |= {"NO_COLOR": "1", "PYTHON_COLORS": "0"}

    def run() -> subprocess.CompletedProcess[str]:
        return subprocess.run(
            [script, "normalize", "--config", str(cfg.path)],
            cwd=tmp_path,
            env=env,
            capture_output=True,
            text=True,
            check=False,
        )

    first = run()

    assert first.returncode == 0, first.stderr
    assert first.stdout == "normalize: processed=4 failed=0\n"
    assert D1 in _metrics(cfg)
    assert _raw_snapshot(cfg) == before

    second = run()

    assert second.returncode == 0, second.stderr
    assert second.stdout == "normalize: processed=0 failed=0\n"
    assert _raw_snapshot(cfg) == before


def test_console_script_normalizes_sleep_stress_body_battery(
    cfg: config.Config, tmp_path: Path
):
    _put(cfg, _sleep_stress_bb())
    script = shutil.which("garmin-pipeline", path=sysconfig.get_path("scripts"))
    assert script is not None, "콘솔 스크립트가 없다. `uv sync`를 먼저 실행한다."
    env = {key: value for key, value in os.environ.items() if key != "FORCE_COLOR"}
    env |= {"NO_COLOR": "1", "PYTHON_COLORS": "0"}

    result = subprocess.run(
        [script, "normalize", "--config", str(cfg.path)],
        cwd=tmp_path,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout == "normalize: processed=3 failed=0\n"
    assert _metrics(cfg) == {
        D1: _nulls(ALL_COLUMNS) | SLEEP_EXPECTED | STRESS_EXPECTED | BB_EXPECTED
    }
    assert _samples(cfg) == BB_SAMPLES


# --- 재구성과 정규화 버전(3.6) --------------------------------------------------------------------

PRIMARY_TABLES = frozenset(
    {
        "auth_event",
        "raw_response",
        "run",
        "fetch_error",
        "meta",
        "notification",
        "delivery",
        "evaluation",
    }
)
# 등록된 원문 12개(일 8종 + 활동 3종 + 세트 상세)와 등록되지 않은 활동 목록 하나.
REBUILD_ROWS = [
    *_day(D1),
    *_sleep_stress_bb(D1),
    ("day", D1, "heart_rates", _heart_rates()),
    _activity_list(D1, RUN_ID),
    *_activity_rows(),
    ("activity", str(RUN_ID), EXERCISE_SETS, _exercise_sets(REAL_SHAPE_SETS)),
]
REBUILD_REGISTERED = 12
CODE_VERSION = str(normalize.NORMALIZE_VERSION)
"""`meta.normalize_version`에 기대하는 값. 버전 값 자체는 `test_version_constants`만 고정한다."""


def _derived_snapshot(cfg: config.Config) -> dict[str, list[tuple]]:
    """코드가 지우는 테이블 전부의 행(`normalized_at` 제외, 정렬)."""
    snapshot: dict[str, list[tuple]] = {}
    for table in normalize._DERIVED_TABLES:
        columns = [
            row[1]
            for row in _query(cfg, f"PRAGMA table_info({table})")
            if row[1] != "normalized_at"
        ]
        rows = (
            _query(cfg, f"SELECT {', '.join(columns)} FROM {table}") if columns else []
        )
        snapshot[table] = sorted(rows, key=repr)
    return snapshot


def _meta(cfg: config.Config) -> dict[str, str]:
    return dict(_query(cfg, "SELECT key, value FROM meta"))


def _fresh_snapshot(cfg: config.Config, tmp_path: Path) -> dict[str, list[tuple]]:
    """같은 원문(`REBUILD_ROWS`)을 새 DB에서 처음 정규화한 결과."""
    fresh = dataclasses.replace(cfg, data_dir=tmp_path / "fresh")
    _put(fresh, REBUILD_ROWS)
    _run(fresh)
    return _derived_snapshot(fresh)


def _add_garbage(cfg: config.Config) -> None:
    """파생 테이블에 원문과 맞지 않는 행·값과 묵은 `activity.day_key`를 넣는다."""
    with store.write_session(cfg) as conn:
        conn.execute("UPDATE daily_metric SET steps = -1 WHERE day_key = ?", (D1,))
        conn.execute("INSERT INTO daily_metric (day_key, steps) VALUES (?, 1)", (D2,))
        conn.execute("INSERT INTO hr_sample VALUES (?, 1, 1)", (D2,))
        conn.execute("INSERT INTO body_battery_sample VALUES (?, 1, 1)", (D2,))
        conn.execute("INSERT INTO stress_bb_sample VALUES (?, 1, 1)", (D2,))
        conn.execute(
            "INSERT INTO activity (activity_id, day_key) VALUES (999, ?)", (D2,)
        )
        conn.execute("INSERT INTO activity_hr_sample VALUES (999, 1, 1, 1)")
        conn.execute(
            "INSERT INTO exercise_set (activity_id, set_index, is_rest) VALUES (999, 0, 0)"
        )
        conn.execute(
            "UPDATE exercise_set SET reps = -1 WHERE activity_id = ?", (RUN_ID,)
        )
        conn.execute(
            "UPDATE activity SET day_key = 'stale' WHERE activity_id = ?", (RUN_ID,)
        )
        conn.execute(
            "INSERT INTO normalize_result VALUES ('day', ?, 'user_summary', 1, NULL, 1, 1)",
            (D2,),
        )


def _script(
    cfg: config.Config, tmp_path: Path, *args: str
) -> subprocess.CompletedProcess[str]:
    script = shutil.which("garmin-pipeline", path=sysconfig.get_path("scripts"))
    assert script is not None, "콘솔 스크립트가 없다. `uv sync`를 먼저 실행한다."
    env = {key: value for key, value in os.environ.items() if key != "FORCE_COLOR"}
    env |= {"NO_COLOR": "1", "PYTHON_COLORS": "0"}
    return subprocess.run(
        [script, "normalize", "--config", str(cfg.path), *args],
        cwd=tmp_path,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )


def test_version_constants():
    assert normalize.NORMALIZE_VERSION == 8
    assert normalize.NORMALIZE_VERSION_KEY == "normalize_version"
    # 정의는 store에 있고 normalize는 같은 객체를 다시 내보낸다(3.7, day values의 밀림 판정과 같은 값).
    assert normalize.NORMALIZE_VERSION is store.NORMALIZE_VERSION
    assert normalize.NORMALIZE_VERSION_KEY is store.NORMALIZE_VERSION_KEY
    assert {"NORMALIZE_VERSION", "NORMALIZE_VERSION_KEY"} <= set(normalize.__all__)


def test_derived_tables_are_every_non_primary_table(cfg: config.Config):
    # 파생 테이블을 더하고 재구성의 지우기에 빠뜨리면 여기서 잡힌다.
    with store.write_session(cfg) as conn:
        tables = {
            name
            for (name,) in conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table'"
            )
            if not name.startswith("sqlite_")
        }
    assert PRIMARY_TABLES <= tables
    assert tables - PRIMARY_TABLES == set(normalize._DERIVED_TABLES)


def test_incremental_with_current_version_keeps_meta(
    cfg: config.Config, caplog: pytest.LogCaptureFixture
):
    _put(cfg, _day())
    _set_version(cfg)
    assert _run(cfg) == normalize.Summary(processed=4, failed=0)
    _put(cfg, [("day", D2, "rhr_day", _rhr_day(D2))])

    with caplog.at_level(logging.INFO, logger="garmin_pipeline.normalize"):
        assert _run(cfg) == normalize.Summary(processed=1, failed=0)

    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}
    assert "재구성" not in caplog.text


def test_rebuild_flag_redoes_everything_like_a_fresh_db(
    cfg: config.Config, tmp_path: Path, caplog: pytest.LogCaptureFixture
):
    _put(cfg, REBUILD_ROWS)
    _run(cfg)
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}
    _add_garbage(cfg)
    assert _activities(cfg)[RUN_ID]["day_key"] == "stale"

    with caplog.at_level(logging.INFO, logger="garmin_pipeline.normalize"):
        summary = _run(cfg, rebuild=True)

    assert summary == normalize.Summary(processed=REBUILD_REGISTERED, failed=0)
    assert _derived_snapshot(cfg) == _fresh_snapshot(cfg, tmp_path)
    assert _activities(cfg)[RUN_ID]["day_key"] == D1
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}
    assert (
        f"normalize 재구성: reason=flag stored={CODE_VERSION} code={CODE_VERSION}"
        in caplog.text
    )
    # 바로 다시 돌리면 증분이라 할 일이 없다.
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)


def test_missing_version_rebuilds(
    cfg: config.Config, tmp_path: Path, caplog: pytest.LogCaptureFixture
):
    # 3.5까지 정규화된 DB(버전 10, meta에 키 없음).
    _put(cfg, REBUILD_ROWS)
    _run(cfg)
    _add_garbage(cfg)
    with store.write_session(cfg) as conn:
        conn.execute(
            "DELETE FROM meta WHERE key = ?", (normalize.NORMALIZE_VERSION_KEY,)
        )

    with caplog.at_level(logging.INFO, logger="garmin_pipeline.normalize"):
        summary = _run(cfg)

    assert summary == normalize.Summary(processed=REBUILD_REGISTERED, failed=0)
    assert _derived_snapshot(cfg) == _fresh_snapshot(cfg, tmp_path)
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}
    assert (
        f"normalize 재구성: reason=version stored=None code={CODE_VERSION}"
        in caplog.text
    )


def test_version_2_db_gets_exercise_sets_on_rebuild(
    cfg: config.Config, tmp_path: Path, caplog: pytest.LogCaptureFixture
):
    # 5.4 전(버전 2)의 DB: 세트 원문은 "원문 보존 등록"이라 `ok=1` 결과만 있고 `exercise_set` 행이 없다.
    _put(cfg, REBUILD_ROWS)
    _run(cfg)
    with store.write_session(cfg) as conn:
        conn.execute("DELETE FROM exercise_set")
    _set_version(cfg, "2")
    assert _set_rows(cfg) == []

    with caplog.at_level(logging.INFO, logger="garmin_pipeline.normalize"):
        summary = _run(cfg)

    assert summary == normalize.Summary(processed=REBUILD_REGISTERED, failed=0)
    assert _set_rows(cfg) == REAL_SHAPE_ROWS
    assert _derived_snapshot(cfg) == _fresh_snapshot(cfg, tmp_path)
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}
    assert (
        f"normalize 재구성: reason=version stored=2 code={CODE_VERSION}" in caplog.text
    )
    # 재구성은 한 번뿐이다.
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)


def test_different_version_rebuilds(
    cfg: config.Config, tmp_path: Path, caplog: pytest.LogCaptureFixture
):
    _put(cfg, REBUILD_ROWS)
    _run(cfg)
    _add_garbage(cfg)
    _set_version(cfg, "0")

    with caplog.at_level(logging.INFO, logger="garmin_pipeline.normalize"):
        summary = _run(cfg)

    assert summary == normalize.Summary(processed=REBUILD_REGISTERED, failed=0)
    assert _derived_snapshot(cfg) == _fresh_snapshot(cfg, tmp_path)
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}
    assert (
        f"normalize 재구성: reason=version stored=0 code={CODE_VERSION}" in caplog.text
    )


def test_reader_sees_previous_rows_during_rebuild(
    cfg: config.Config, monkeypatch: pytest.MonkeyPatch
):
    _put(cfg, REBUILD_ROWS)
    _run(cfg)
    _add_garbage(cfg)
    original = normalize._process
    seen: list[tuple[int, int, int]] = []

    def spy(
        conn: sqlite3.Connection, unit: normalize._Unit, **kwargs
    ) -> normalize.Summary:
        summary = original(conn, unit, **kwargs)
        # 재구성 트랜잭션 안, 모든 항목을 다시 쓴 뒤(버전 기록 전)다.
        reader = store.read_connection(cfg)
        try:
            (old_days,) = reader.execute("SELECT count(*) FROM daily_metric").fetchone()
            (old_results,) = reader.execute(
                "SELECT count(*) FROM normalize_result"
            ).fetchone()
        finally:
            reader.close()
        (new_days,) = conn.execute("SELECT count(*) FROM daily_metric").fetchone()
        seen.append((old_days, old_results, new_days))
        return summary

    monkeypatch.setattr(normalize, "_process", spy)

    _run(cfg, rebuild=True)

    # 읽는 쪽은 쓰레기 행까지 있는 이전 스냅샷(D1·D2, 결과 12행)을, 쓰는 쪽은 새 행(D1)만 본다.
    assert seen == [(2, REBUILD_REGISTERED + 1, 1)]


def test_sqlite_error_during_rebuild_keeps_everything(
    cfg: config.Config,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    _put(cfg, REBUILD_ROWS)
    _run(cfg)
    _add_garbage(cfg)
    _set_version(cfg, "0")
    before = _derived_snapshot(cfg)
    results = _results(cfg)

    original = normalize._process

    def broken(
        conn: sqlite3.Connection, unit: normalize._Unit, **kwargs
    ) -> normalize.Summary:
        # 모든 항목을 다시 쓴 뒤(버전 기록 전) 환경 오류가 난다.
        original(conn, unit, **kwargs)
        raise sqlite3.OperationalError("disk I/O error")

    monkeypatch.setattr(normalize, "_process", broken)

    with pytest.raises(sqlite3.OperationalError):
        _run(cfg)

    assert _derived_snapshot(cfg) == before
    assert _results(cfg) == results
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: "0"}

    assert cli.main(["normalize", "--rebuild", "--config", str(cfg.path)]) == 1
    out, err = capsys.readouterr()
    assert out == ""
    assert err == "normalize 실패: disk I/O error\n"
    assert _derived_snapshot(cfg) == before
    assert _results(cfg) == results
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: "0"}


def test_item_failure_during_rebuild_is_isolated(cfg: config.Config):
    _put(cfg, REBUILD_ROWS)
    _run(cfg)
    _put_text(cfg, D1, "user_summary", "not json", now_ms=FETCHED + 1)
    _set_version(cfg)

    assert _run(cfg, rebuild=True) == normalize.Summary(
        processed=REBUILD_REGISTERED, failed=1
    )

    results = _results(cfg)
    assert len(results) == REBUILD_REGISTERED
    failed = [row for row in results if not row[3]]
    assert failed == [
        ("day", D1, "user_summary", 0, "parse_error", FETCHED + 1, CLOCK_MS)
    ]
    metrics = _metrics(cfg)[D1]
    assert all(metrics[c] is None for c in daily.USER_SUMMARY_COLUMNS)
    assert metrics["resting_hr"] == EXPECTED["resting_hr"]
    assert _activities(cfg)[RUN_ID] == _activity_expected()
    assert _meta(cfg) == {
        normalize.NORMALIZE_VERSION_KEY: CODE_VERSION,
        "day_values_pending": json.dumps([D1]),
    }


def test_rebuild_leaves_primary_tables_alone(cfg: config.Config):
    _put(cfg, REBUILD_ROWS)
    _run(cfg)
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO auth_event (local_date, logged_in_at) VALUES (?, 1)", (D1,)
        )
        run_id = conn.execute(
            "INSERT INTO run (local_date, started_at, finished_at, status, detail)"
            " VALUES (?, 1, 2, 'partial', 'transient=1')",
            (D1,),
        ).lastrowid
        conn.execute(
            "INSERT INTO fetch_error (run_id, scope, key, endpoint, kind, local_date,"
            " occurred_at, error_code) VALUES (?, 'day', ?, 'hrv_data', 'transient', ?, 1, 'x')",
            (run_id, D1, D1),
        )
        conn.execute(
            "INSERT INTO notification VALUES (?, 'normalize_failed', 'hrv_data=1', 1)",
            (D1,),
        )
        conn.executemany(
            "INSERT INTO delivery(local_date,kind,event,ok,reason,at)"
            " VALUES (?, 'notify', 'normalize_failed', ?, ?, 1)",
            [(D1, 1, None), (D1, 0, "network")],
        )
        conn.execute("INSERT INTO meta VALUES ('history_start', ?)", (D0,))
    primary = {
        table: _query(cfg, f"SELECT * FROM {table} ORDER BY 1, 2")
        for table in sorted(PRIMARY_TABLES - {"meta"})
    }

    _run(cfg, rebuild=True)

    assert {
        table: _query(cfg, f"SELECT * FROM {table} ORDER BY 1, 2")
        for table in sorted(PRIMARY_TABLES - {"meta"})
    } == primary
    assert _meta(cfg) == {
        "history_start": D0,
        normalize.NORMALIZE_VERSION_KEY: CODE_VERSION,
    }


def test_console_script_rebuild(cfg: config.Config, tmp_path: Path):
    _put(cfg, REBUILD_ROWS)
    _run(cfg)
    _add_garbage(cfg)

    result = _script(cfg, tmp_path, "--rebuild")

    assert result.returncode == 0, result.stderr
    assert result.stdout == f"normalize: processed={REBUILD_REGISTERED} failed=0\n"
    assert _derived_snapshot(cfg) == _fresh_snapshot(cfg, tmp_path)


def test_console_script_rebuilds_on_version_change(cfg: config.Config, tmp_path: Path):
    _put(cfg, REBUILD_ROWS)
    _run(cfg)
    _add_garbage(cfg)
    _set_version(cfg, "0")

    first = _script(cfg, tmp_path)

    assert first.returncode == 0, first.stderr
    assert first.stdout == f"normalize: processed={REBUILD_REGISTERED} failed=0\n"
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}
    assert _derived_snapshot(cfg) == _fresh_snapshot(cfg, tmp_path)

    second = _script(cfg, tmp_path)

    assert second.returncode == 0, second.stderr
    assert second.stdout == "normalize: processed=0 failed=0\n"


def test_cli_help_lists_rebuild(capsys: pytest.CaptureFixture[str]):
    with pytest.raises(SystemExit) as exit_info:
        cli.main(["normalize", "--help"])

    assert exit_info.value.code == 0
    assert "--rebuild" in capsys.readouterr().out


def test_console_script_creates_missing_db_and_records_version(
    cfg: config.Config, tmp_path: Path
):
    assert not cfg.db_path.exists()

    result = _script(cfg, tmp_path)

    assert result.returncode == 0, result.stderr
    assert result.stdout == "normalize: processed=0 failed=0\n"
    assert _query(cfg, "PRAGMA user_version") == [(schema_version.LATEST,)]
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}


# --- HRR 제거(5.7) ------------------------------------------------------------------------------

DROPPED_TABLE = "activity_recovery"
"""0010이 만들고 0012가 drop한 HRR 테이블(5.7). 이 절의 시험은 이 테이블이 없음을 확인한다."""


def _table_names(cfg: config.Config) -> set[str]:
    return {
        name
        for (name,) in _query(
            cfg, "SELECT name FROM sqlite_master WHERE type = 'table'"
        )
    }


def _copy_ref_rows(raw: sqlite3.Connection) -> None:
    """붙인 `ref` DB의 원문·파생 행을 `main`에 복사한다(`main`에 있는 열만. 옛 스키마에는 새 열이 없다)."""
    for table in ("raw_response", *normalize._DERIVED_TABLES):
        columns = ", ".join(
            row[1] for row in raw.execute(f"PRAGMA main.table_info({table})")
        )
        if columns:
            raw.execute(
                f"INSERT INTO main.{table} ({columns}) SELECT {columns} FROM ref.{table}"
            )


def _version_11_db(cfg: config.Config, tmp_path: Path) -> dict[str, list[tuple]]:
    """0001~0011만 적용한 DB: 원문(`REBUILD_ROWS`)과 그 파생 행, HRR 행, `meta.normalize_version` "3".

    파생 행은 같은 원문을 지금 코드로 새 DB에서 정규화한 결과를 복사한다(5.7 전과 값이 같다). 그 스냅샷을 돌려준다.
    """
    ref = dataclasses.replace(cfg, data_dir=tmp_path / "ref")
    _put(ref, REBUILD_ROWS)
    _run(ref)
    expected = _derived_snapshot(ref)

    migrations = store._load_migrations()
    assert [m.number for m in migrations][:11] == list(range(1, 12))
    assert migrations[11].name == "0012_drop_activity_recovery.sql"
    cfg.data_dir.mkdir(parents=True)
    raw = sqlite3.connect(cfg.db_path)
    try:
        for migration in migrations[:11]:
            raw.executescript(migration.source.read_text(encoding="utf-8"))
        raw.execute("ATTACH DATABASE ? AS ref", (str(ref.db_path),))
        _copy_ref_rows(raw)
        raw.execute(
            f"INSERT INTO {DROPPED_TABLE} (activity_id, end_ms, end_bpm, hrr1)"
            " VALUES (?, ?, 150, 30)",
            (RUN_ID, ACT_START),
        )
        raw.execute(
            "INSERT INTO meta VALUES (?, '3')", (normalize.NORMALIZE_VERSION_KEY,)
        )
        raw.execute("PRAGMA user_version = 11")
        raw.commit()
        raw.execute("DETACH DATABASE ref")
    finally:
        raw.close()
    assert DROPPED_TABLE in _table_names(cfg)
    return expected


def test_version_11_db_drops_table_then_rebuilds_once(
    cfg: config.Config, tmp_path: Path, caplog: pytest.LogCaptureFixture
):
    expected = _version_11_db(cfg, tmp_path)
    # 0013 전이라 activity_hr_sample에는 body_battery 열이 없다(기대값도 그 열이 NULL뿐이다).
    assert _derived_snapshot(cfg) == expected | {
        "day_summary": [],
        "workout": [],
        "exercise_log": [],
        "activity_hr_sample": [row[:3] for row in expected["activity_hr_sample"]],
        "activity": [row[:-5] for row in expected["activity"]],
    }

    # 다음 쓰기 세션은 0012부터 최신까지 적용한다: 테이블만 없어지고 인덱스·다른 테이블 행·meta는 그대로다
    # (0013이 더한 body_battery는 NULL이고, REBUILD_ROWS에는 그 채널이 없어 기대값도 NULL이다).
    with store.write_session(cfg):
        pass
    assert _query(cfg, "PRAGMA user_version") == [(schema_version.LATEST,)]
    assert DROPPED_TABLE not in _table_names(cfg)
    assert _query(cfg, "PRAGMA index_info(hr_sample_ts_ms)")[0][2] == "ts_ms"
    assert _derived_snapshot(cfg) == expected | {
        "day_summary": [],
        "workout": [],
        "exercise_log": [],
        "activity": [
            (*row[:-5], None, None, None, None, None) for row in expected["activity"]
        ],
    }
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: "3"}

    # 그다음 normalize는 버전 사유로 한 번 재구성하고, 남은 파생 행 값은 같다.
    with caplog.at_level(logging.INFO, logger="garmin_pipeline.normalize"):
        assert _run(cfg) == normalize.Summary(processed=REBUILD_REGISTERED, failed=0)
    assert f"normalize 재구성: reason=version stored=3 code={CODE_VERSION}" in (
        caplog.text
    )
    assert _derived_snapshot(cfg) == expected
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)


# --- 운동 중 Body Battery(5.9) ------------------------------------------------------------------

BB_REBUILD_ROWS = [
    *REBUILD_ROWS,
    _activity_list(D1, WALK_ID),
    *_activity_rows(WALK_ID)[:2],
    (
        "activity",
        str(WALK_ID),
        "activity_details",
        _activity_details(BB_DETAIL_ROWS, keys=BB_DETAIL_KEYS),
    ),
]
"""`REBUILD_ROWS`에 Body Battery 채널이 있는 걷기 활동을 더한 원문."""


def _version_12_db(cfg: config.Config, tmp_path: Path) -> dict[str, list[tuple]]:
    """0001~0012만 적용한 DB: 원문(`BB_REBUILD_ROWS`)과 그 파생 행(body_battery 열 없음), `meta` "4".

    파생 행은 같은 원문을 지금 코드로 새 DB에서 정규화한 결과에서 옛 열만 복사한다. 그 (새 코드) 스냅샷을 돌려준다.
    """
    ref = dataclasses.replace(cfg, data_dir=tmp_path / "ref")
    _put(ref, BB_REBUILD_ROWS)
    _run(ref)
    expected = _derived_snapshot(ref)

    migrations = store._load_migrations()
    assert [m.number for m in migrations][:12] == list(range(1, 13))
    assert migrations[12].name == "0013_activity_body_battery.sql"
    cfg.data_dir.mkdir(parents=True)
    raw = sqlite3.connect(cfg.db_path)
    try:
        for migration in migrations[:12]:
            raw.executescript(migration.source.read_text(encoding="utf-8"))
        raw.execute("ATTACH DATABASE ? AS ref", (str(ref.db_path),))
        _copy_ref_rows(raw)
        raw.execute(
            "INSERT INTO meta VALUES (?, '4')", (normalize.NORMALIZE_VERSION_KEY,)
        )
        raw.execute("PRAGMA user_version = 12")
        raw.commit()
        raw.execute("DETACH DATABASE ref")
    finally:
        raw.close()
    return expected


def test_version_12_db_adds_column_then_rebuild_fills_it(
    cfg: config.Config, tmp_path: Path, caplog: pytest.LogCaptureFixture
):
    expected = _version_12_db(cfg, tmp_path)
    assert _activity_hr_samples(cfg, WALK_ID) == [row[:2] for row in BB_ROWS]

    # 다음 쓰기 세션은 0013만 적용한다: 열이 생기고 값은 모두 NULL, 다른 행·meta는 그대로다.
    with store.write_session(cfg):
        pass
    assert _query(cfg, "PRAGMA user_version") == [(schema_version.LATEST,)]
    assert _activity_body_battery(cfg, WALK_ID) == [(*row[:2], None) for row in BB_ROWS]
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: "4"}

    # 그다음 normalize는 버전 사유로 한 번 재구성해 값을 채우고 코드 버전을 남긴다.
    with caplog.at_level(logging.INFO, logger="garmin_pipeline.normalize"):
        assert _run(cfg) == normalize.Summary(
            processed=REBUILD_REGISTERED + 3, failed=0
        )
    assert f"normalize 재구성: reason=version stored=4 code={CODE_VERSION}" in (
        caplog.text
    )
    assert _activity_body_battery(cfg, WALK_ID) == BB_ROWS
    assert _derived_snapshot(cfg) == expected
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)


# --- 무게 0은 무게 없음(5.10 후속, 버전 6) -------------------------------------------------------


def test_version_5_db_rebuild_turns_zero_weight_into_null(
    cfg: config.Config, caplog: pytest.LogCaptureFixture
):
    # 버전 5 DB: 무게 0 세트가 `weight_g` 0으로 정규화돼 있고 `meta`는 "5"다(5 규칙의 결과를 손으로 만든다).
    _put_sets(
        cfg,
        _exercise_sets(
            [
                _set(exercises=[_candidate("SHRUG")], reps=10, weight=0.0, duration=30),
                _set(exercises=[_candidate("SHRUG")], reps=8, weight=20000.0),
            ]
        ),
    )
    _run(cfg)
    with store.write_session(cfg) as conn:
        conn.execute("UPDATE exercise_set SET weight_g = 0 WHERE set_index = 0")
        conn.execute(
            "UPDATE meta SET value = '5' WHERE key = ?",
            (normalize.NORMALIZE_VERSION_KEY,),
        )
    assert _set_rows(cfg)[0][4] == 0
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: "5"}

    # 다음 쓰기 명령(normalize)이 버전 사유로 재구성해 무게 0을 NULL로 바꾸고 현재 버전을 남긴다.
    with caplog.at_level(logging.INFO, logger="garmin_pipeline.normalize"):
        assert _run(cfg) == normalize.Summary(processed=1, failed=0)
    assert "normalize 재구성: reason=version stored=5 code=8" in caplog.text
    assert _set_rows(cfg) == [
        (0, "SHRUG", None, 10, None, 30, 0),
        (1, "SHRUG", None, 8, 20000, None, 0),
    ]
    assert _meta(cfg) == {normalize.NORMALIZE_VERSION_KEY: CODE_VERSION}
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)


def test_normalize_writes_no_hrr_table(cfg: config.Config):
    # 활동 + 일일 심박 원문: Summary는 원문 항목(일 키 목록 제외 12개)만 센다.
    _put(cfg, REBUILD_ROWS)

    assert _run(cfg) == normalize.Summary(processed=REBUILD_REGISTERED, failed=0)
    assert len(_results(cfg)) == REBUILD_REGISTERED
    assert DROPPED_TABLE not in _table_names(cfg)
    assert DROPPED_TABLE not in normalize._DERIVED_TABLES
    assert importlib.util.find_spec("garmin_pipeline.normalize.recovery") is None
    assert not hasattr(normalize, "recovery")


def test_rebuild_deletes_only_existing_derived_tables(cfg: config.Config):
    _put(cfg, REBUILD_ROWS)
    _run(cfg)
    statements: list[str] = []

    with store.write_session(cfg) as conn:
        conn.set_trace_callback(statements.append)
        summary = normalize.run(conn, rebuild=True)
        conn.set_trace_callback(None)

    assert summary == normalize.Summary(processed=REBUILD_REGISTERED, failed=0)
    deletes = [
        s for s in statements if s.startswith("DELETE FROM") and " WHERE " not in s
    ]
    assert deletes == [f"DELETE FROM {table}" for table in normalize._DERIVED_TABLES]
    assert not any(DROPPED_TABLE in s for s in statements)


@pytest.mark.parametrize("argv", [["--help"], ["normalize", "--help"]])
def test_cli_help_has_no_hrr(argv: list[str], capsys: pytest.CaptureFixture[str]):
    # 서브커맨드 `help=`는 최상위 `--help`에만, `description=`은 `normalize --help`에만 나온다.
    with pytest.raises(SystemExit) as exit_info:
        cli.main(argv)

    assert exit_info.value.code == 0
    out = capsys.readouterr().out
    assert "normalize" in out
    assert "HRR" not in out
    assert "심박 회복" not in out
    assert DROPPED_TABLE not in out


# --- 5.12 후속: 존 하한·stress Body Battery ---------------------------------------------------


def _stress_bb(values=None, descriptors=BB_DESCRIPTORS):
    return _stress_data(
        bodyBatteryValuesArray=values,
        bodyBatteryValueDescriptorsDTOList=descriptors,
    )


@pytest.mark.parametrize(
    ("value", "expected"),
    [(93.0, 93), (111, 111), (130.5, 130), (None, None), (-1, None)],
)
def test_zone_low_boundary_numbers(value, expected):
    zones = _hr_zones({1: 20, 2: 30, 3: 40})
    zones[0]["zoneLowBoundary"] = value
    result = activity.activity_hr_in_timezones(json.dumps(zones), "1")
    assert [result[f"hr_zone{z}_low_bpm"] for z in range(1, 6)] == [
        expected,
        100,
        100,
        None,
        None,
    ]
    assert result["hr_zone1_s"] == 20


@pytest.mark.parametrize("value", [True, "93", float("nan")])
def test_zone_low_boundary_bad_number(value):
    zones = _hr_zones({1: 20})
    zones[0]["zoneLowBoundary"] = value
    with pytest.raises(daily.NormalizeParseError, match="zoneLowBoundary"):
        activity.activity_hr_in_timezones(json.dumps(zones), "1")


def test_missing_zone_boundary_clears_all_zone_columns(cfg):
    _put(cfg, _activity_rows(RUN_ID))
    assert _run(cfg).failed == 0
    zones = _hr_zones()
    del zones[0]["zoneLowBoundary"]
    _put(
        cfg,
        [("activity", str(RUN_ID), "activity_hr_in_timezones", zones)],
        now_ms=FETCHED + 1,
    )
    assert _run(cfg) == normalize.Summary(processed=1, failed=1)
    row = _activities(cfg)[RUN_ID]
    assert all(
        row[column] is None for column in activity.ACTIVITY_HR_IN_TIMEZONES_COLUMNS
    )
    assert row["type_key"] == ACTIVITY_EXPECTED["type_key"]
    assert _activity_results(cfg)[-1][3:5] == (0, "parse_error")


def test_stress_bb_descriptor_positions_nulls_rounding_and_duplicates(cfg):
    descriptors = [
        {
            "bodyBatteryValueDescriptorKey": "bodyBatteryLevel",
            "bodyBatteryValueDescriptorIndex": 2,
        },
        {
            "bodyBatteryValueDescriptorKey": "timestamp",
            "bodyBatteryValueDescriptorIndex": 0,
        },
    ]
    values = [
        [1, "MEASURED", 55, 3.0],
        [2, None, None, 3.0],
        [3, None, -1, 3.0],
        [4, None, 56.5, 3.0],
        [1, "MEASURED", 55.0, 3.0],
        [5, None, 0, 3.0],
    ]
    payload = _stress_bb(values, descriptors)
    expected = [(1, 55), (2, None), (3, None), (4, 56), (5, 0)]
    assert daily.stress_body_battery_samples(json.dumps(payload), D1) == expected
    _put(cfg, [("day", D1, "stress_data", payload)])
    assert _run(cfg) == normalize.Summary(processed=1, failed=0)
    assert (
        _query(cfg, "SELECT ts_ms, level FROM stress_bb_sample ORDER BY ts_ms")
        == expected
    )
    assert _metrics(cfg)[D1]["stress_avg"] == 40
    assert _metrics(cfg)[D1]["stress_max"] == 50
    assert _samples(cfg) == []


@pytest.mark.parametrize(
    ("values", "descriptors"),
    [
        (None, BB_DESCRIPTORS),
        ([], BB_DESCRIPTORS),
        (None, None),
        ([], []),
        ([[1, None]], None),
        ([[1, None, None], [2, None]], None),
    ],
)
def test_stress_bb_empty_containers_keep_stress_metrics(cfg, values, descriptors):
    _put(cfg, [("day", D1, "stress_data", _stress_bb(values, descriptors))])
    assert _run(cfg) == normalize.Summary(processed=1, failed=0)
    assert _query(cfg, "SELECT * FROM stress_bb_sample") == []
    assert _metrics(cfg)[D1]["stress_avg"] == 40


def test_stress_bb_both_keys_absent_keeps_stress_metrics_and_clears_samples(cfg):
    _put(cfg, [("day", D1, "stress_data", _stress_bb([[1, 55]]))])
    assert _run(cfg).failed == 0
    payload = _stress_bb()
    del payload["bodyBatteryValuesArray"]
    del payload["bodyBatteryValueDescriptorsDTOList"]
    _put(cfg, [("day", D1, "stress_data", payload)], now_ms=FETCHED + 1)
    assert _run(cfg) == normalize.Summary(processed=1, failed=0)
    assert _query(cfg, "SELECT * FROM stress_bb_sample") == []
    assert _metrics(cfg)[D1]["stress_avg"] == 40
    assert _metrics(cfg)[D1]["stress_max"] == 50
    assert _query(cfg, "SELECT ok, error_code FROM normalize_result") == [(1, None)]


@pytest.mark.parametrize(
    "payload",
    [
        _stress_bb([[1, 55], [1, 56]]),
        _stress_bb([[1, 55]], None),
        _stress_bb([[1, "MEASURED", 55, 3.0]], None),
        _stress_bb([[1, None, None, 3.0]], None),
        _stress_bb([[1, None], [2, 55]], None),
        _stress_bb([[True, None]], None),
        _stress_bb([[1, 55]], []),
        _stress_bb([[1, None]], []),
        _stress_bb([[1, None], [1, -1]]),
        _stress_bb([[1, 55, 3], [1, 55, 4]]),
        _stress_bb([[True, 55]]),
        _stress_bb([[1.0, 55]]),
        _stress_bb([[None, 55]]),
        _stress_bb([[-1, 55]]),
        _stress_bb([[1, True]]),
        _stress_bb([[1, "55"]]),
        _stress_bb([[1, float("nan")]]),
        _stress_bb([[1]]),
        _stress_bb([{"timestamp": 1}]),
        _stress_bb("wrong"),
        _stress_bb(None, "wrong"),
        _stress_bb(
            [[1, 55]],
            [
                {
                    "bodyBatteryValueDescriptorKey": "timestamp",
                    "bodyBatteryValueDescriptorIndex": 0,
                }
            ],
        ),
        _stress_bb([[1, 55]], [{"key": "timestamp", "index": 0}]),
        {k: v for k, v in _stress_bb().items() if k != "bodyBatteryValuesArray"},
        {
            k: v
            for k, v in _stress_bb().items()
            if k != "bodyBatteryValueDescriptorsDTOList"
        },
    ],
)
def test_bad_stress_bb_fails_entire_item_and_clears_old_samples(cfg, payload):
    _put(cfg, [("day", D1, "stress_data", _stress_bb([[1, 55]]))])
    assert _run(cfg).failed == 0
    _put(cfg, [("day", D1, "stress_data", payload)], now_ms=FETCHED + 1)
    assert _run(cfg) == normalize.Summary(processed=1, failed=1)
    assert _query(cfg, "SELECT * FROM stress_bb_sample") == []
    assert _metrics(cfg)[D1]["stress_avg"] is None
    assert _metrics(cfg)[D1]["stress_max"] is None
    assert _query(cfg, "SELECT ok, error_code FROM normalize_result") == [
        (0, "parse_error")
    ]


def test_stress_bb_samples_replace_and_nodata_clears(cfg):
    for i, payload in enumerate(
        [_stress_bb([[1, 55], [2, 56]]), _stress_bb([[3, 57]]), None]
    ):
        _put_text(cfg, D1, "stress_data", json.dumps(payload), now_ms=FETCHED + i)
        assert _run(cfg) == normalize.Summary(processed=1, failed=0)
        assert (
            _query(cfg, "SELECT ts_ms, level FROM stress_bb_sample ORDER BY ts_ms")
            == [
                [(1, 55), (2, 56)],
                [(3, 57)],
                [],
            ][i]
        )


def test_version_6_schema_13_migrates_and_rebuilds_zone_bounds_and_stress_bb(
    cfg, tmp_path, caplog
):
    ref = dataclasses.replace(cfg, data_dir=tmp_path / "ref-512")
    zones = [
        {"zoneNumber": z, "secsInZone": z * 10, "zoneLowBoundary": b}
        for z, b in enumerate([93.0, 111, 130, 148, 167], 1)
    ]
    _put(
        ref,
        [
            ("activity", str(RUN_ID), "activity_hr_in_timezones", zones),
            ("day", D1, "stress_data", _stress_bb([[1, 55]])),
        ],
    )
    assert _run(ref).failed == 0
    cfg.data_dir.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(cfg.db_path) as raw:
        for migration in store._load_migrations()[:13]:
            raw.executescript(migration.source.read_text(encoding="utf-8"))
        raw.execute("ATTACH DATABASE ? AS ref", (str(ref.db_path),))
        _copy_ref_rows(raw)
        raw.execute("INSERT INTO meta VALUES ('normalize_version', '6')")
        raw.execute("PRAGMA user_version = 13")
    with caplog.at_level(logging.INFO, logger="garmin_pipeline.normalize"):
        assert _run(cfg) == normalize.Summary(processed=2, failed=0)
    assert "stored=6 code=8" in caplog.text
    assert _query(cfg, "PRAGMA user_version") == [(schema_version.LATEST,)]
    assert _meta(cfg) == {"normalize_version": "8"}
    assert [_activities(cfg)[RUN_ID][f"hr_zone{z}_low_bpm"] for z in range(1, 6)] == [
        93,
        111,
        130,
        148,
        167,
    ]
    assert _query(cfg, "SELECT ts_ms, level FROM stress_bb_sample") == [(1, 55)]
    assert _query(cfg, "PRAGMA index_info(stress_bb_sample_ts_ms)")[0][2] == "ts_ms"
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)


def test_real_zone_bounds_and_stress_bb(cfg):
    zones = sorted((REAL_FIXTURES / "activity_hr_in_timezones").glob("*.json"))
    stress = sorted((REAL_FIXTURES / "stress_data").glob("*.json"))
    if not zones or not stress:
        pytest.skip("실제 존·stress fixture가 없다")
    for path in [*zones, *stress]:
        endpoint = path.parent.name
        _put_text(
            cfg,
            path.stem,
            endpoint,
            path.read_text(),
            scope=normalize.NORMALIZERS[endpoint].scope,
        )
    assert _run(cfg) == normalize.Summary(processed=len(zones) + len(stress), failed=0)
    for path in zones:
        raw = json.loads(path.read_text())
        if raw:
            bounds = [
                _activities(cfg)[int(path.stem)][f"hr_zone{z}_low_bpm"]
                for z in range(1, 6)
            ]
            assert all(type(value) is int for value in bounds)
            assert bounds == [93, 111, 130, 148, 167]
    assert (
        _query(cfg, "SELECT count(*) FROM stress_bb_sample WHERE level IS NOT NULL")[0][
            0
        ]
        > 0
    )


def test_day_values_refresh_only_changed_date_and_failure_isolation(cfg, monkeypatch):
    _put(cfg, [*_day(D1), *_day(D2)])
    _run(cfg)
    with store.write_session(cfg) as conn:
        conn.execute("UPDATE day_summary SET steps=999 WHERE date=?", (D2,))
    _put(
        cfg,
        [("day", D1, "user_summary", _user_summary(totalSteps=123))],
        now_ms=FETCHED + 1,
    )
    _run(cfg)
    assert _query(cfg, "SELECT date,steps FROM day_summary ORDER BY date") == [
        (D1, 123),
        (D2, 999),
    ]
    original = normalize.digest.day_values

    def broken(key, *args):
        if key == D1:
            raise ValueError("private health details")
        return original(key, *args)

    monkeypatch.setattr(normalize.digest, "day_values", broken)
    _put(
        cfg,
        [
            ("day", D1, "user_summary", _user_summary(totalSteps=456)),
            ("day", D2, "user_summary", _user_summary(totalSteps=789)),
        ],
        now_ms=FETCHED + 2,
    )
    _run(cfg)
    assert _query(cfg, "SELECT date,steps FROM day_summary ORDER BY date") == [
        (D1, 123),
        (D2, 789),
    ]
    assert _meta(cfg)["day_values_pending"] == json.dumps([D1])
    monkeypatch.setattr(normalize.digest, "day_values", original)
    refreshed = []

    def recovered(key, *args):
        refreshed.append(key)
        return original(key, *args)

    monkeypatch.setattr(normalize.digest, "day_values", recovered)
    # No raw changes or stale normalize_result rows: retry just the failed date.
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)
    assert refreshed == [D1]
    assert _query(cfg, "SELECT date,steps FROM day_summary ORDER BY date") == [
        (D1, 456),
        (D2, 789),
    ]
    assert "day_values_pending" not in _meta(cfg)


def test_day_values_rebuild_history_start_preserves_evaluations(cfg):
    _put(cfg, [*_day(D0), *_day(D1), *_day(D2)])
    with store.write_session(cfg) as conn:
        conn.execute("INSERT INTO meta(key,value) VALUES ('history_start',?)", (D1,))
        conn.execute(
            "INSERT INTO evaluation VALUES (?,'day','s','[]','[]','[]','md','model',1)",
            (D1,),
        )
    _run(cfg, rebuild=True)
    assert _query(cfg, "SELECT date FROM day_summary ORDER BY date") == [(D1,), (D2,)]
    assert _query(cfg, "SELECT summary FROM evaluation") == [("s",)]


def test_day_values_rebuild_omits_gap_dates_without_raw_or_activities(cfg):
    _put(cfg, [*_day(D0), *_day(D2)])
    with store.write_session(cfg) as conn:
        conn.execute("INSERT INTO meta(key,value) VALUES ('history_start',?)", (D0,))
        conn.execute("INSERT INTO day_summary(date,steps) VALUES (?,999)", (D1,))

    _run(cfg, rebuild=True)

    assert _query(cfg, "SELECT date FROM day_summary ORDER BY date") == [(D0,), (D2,)]
    assert _query(cfg, "SELECT * FROM workout WHERE date=?", (D1,)) == []


@pytest.mark.parametrize("destination", [D0, D2])
def test_workout_moves_across_dates_without_workout_or_exercise_pk_collision(
    cfg, destination
):
    _put(
        cfg,
        [
            *_day(D0),
            *_day(D1),
            *_day(D2),
            *_activity_rows(),
            ("activity", str(RUN_ID), EXERCISE_SETS, _exercise_sets(REAL_SHAPE_SETS)),
        ],
    )
    _run(cfg)
    exercises = _query(cfg, "SELECT * FROM exercise_log ORDER BY exercise")
    assert exercises
    assert _query(cfg, "SELECT date FROM workout") == [(D1,)]
    start = (datetime.fromisoformat(destination) - timedelta(days=1)).strftime(
        "%Y-%m-%dT22:30:00.0"
    )
    _put(
        cfg,
        [("activity", str(RUN_ID), "activity", _activity_summary(startTimeGMT=start))],
        now_ms=FETCHED + 1,
    )
    assert _run(cfg) == normalize.Summary(processed=1, failed=0)
    assert _query(cfg, "SELECT activity_id,date FROM workout") == [
        (RUN_ID, destination)
    ]
    assert _query(cfg, "SELECT * FROM exercise_log ORDER BY exercise") == exercises
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)


def test_moved_workout_replacement_rolls_back_old_workout_and_exercises_on_insert_failure(
    cfg, monkeypatch
):
    _put(
        cfg,
        [
            *_day(D0),
            *_day(D1),
            *_activity_rows(),
            ("activity", str(RUN_ID), EXERCISE_SETS, _exercise_sets(REAL_SHAPE_SETS)),
        ],
    )
    _run(cfg)
    before = {
        table: _query(cfg, f"SELECT * FROM {table}")
        for table in ("day_summary", "workout", "exercise_log")
    }
    start = (datetime.fromisoformat(D0) - timedelta(days=1)).strftime(
        "%Y-%m-%dT22:30:00.0"
    )
    _put(
        cfg,
        [("activity", str(RUN_ID), "activity", _activity_summary(startTimeGMT=start))],
        now_ms=FETCHED + 1,
    )
    original = normalize.digest.day_values

    def broken(key, *args):
        values = original(key, *args)
        if key == D0:
            values["exercise_logs"][0]["exercise"] = None
        return values

    monkeypatch.setattr(normalize.digest, "day_values", broken)
    with pytest.raises(sqlite3.IntegrityError):
        _run(cfg)
    for table, rows in before.items():
        assert _query(cfg, f"SELECT * FROM {table}") == rows


def test_failed_old_date_retries_after_its_workout_has_already_moved(cfg, monkeypatch):
    _put(cfg, [*_day(D0), *_day(D1), *_activity_rows()])
    _run(cfg)
    start = (datetime.fromisoformat(D0) - timedelta(days=1)).strftime(
        "%Y-%m-%dT22:30:00.0"
    )
    _put(
        cfg,
        [("activity", str(RUN_ID), "activity", _activity_summary(startTimeGMT=start))],
        now_ms=FETCHED + 1,
    )
    original = normalize.digest.day_values

    def broken(key, *args):
        if key == D1:
            raise ValueError("old date refresh failed")
        return original(key, *args)

    monkeypatch.setattr(normalize.digest, "day_values", broken)
    _run(cfg)
    assert _query(cfg, "SELECT date FROM workout") == [(D0,)]
    assert _meta(cfg)["day_values_pending"] == json.dumps([D1])
    refreshed = []

    def recovered(key, *args):
        refreshed.append(key)
        return original(key, *args)

    monkeypatch.setattr(normalize.digest, "day_values", recovered)
    assert _run(cfg) == normalize.Summary(processed=0, failed=0)
    assert refreshed == [D1]
    assert _query(cfg, "SELECT date FROM workout") == [(D0,)]
    assert "day_values_pending" not in _meta(cfg)
