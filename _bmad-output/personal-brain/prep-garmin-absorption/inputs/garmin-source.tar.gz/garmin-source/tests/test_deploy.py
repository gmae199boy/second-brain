"""`scripts/deploy.sh`와 `config.runtime.example.toml`의 정적 검사(2.8·4.6, FR39·AD-14).

저장소의 `deploy.sh`는 실제 `runtime/`·`launchctl`에 닿으므로 여기서 실행하지 않는다. 동작 시험은
스크립트, 예시 config, skill 원본을 `tmp_path` 저장소 모양으로 복사하고, `PATH` 앞에 가짜 `uv`를 두어
돌린다.
가짜 `uv`는 `runtime/.venv/bin/python`(버전만 출력)과 호출마다 argv를 한 줄(탭 구분)로 덧붙여 기록하는
`garmin-pipeline`만 만든다. `DEPLOY_TEST_NORMALIZE_EXIT`가 있으면 가짜 `normalize`는 그 코드로 끝난다.
진짜 uv·launchctl은 부르지 않는다.
"""

import os
import shutil
import stat
import subprocess
import tomllib
from pathlib import Path

import pytest

from garmin_pipeline import config

ROOT = Path(__file__).resolve().parents[1]
DEPLOY = ROOT / "scripts" / "deploy.sh"
EXAMPLE = ROOT / "config.runtime.example.toml"
SKILL = ROOT / "skill" / "garmin-daily-analysis"
SNAPSHOT = (
    "UV_PROJECT_ENVIRONMENT=runtime/.venv uv sync --frozen --no-editable --no-dev"
)
INSTALL = 'runtime/.venv/bin/garmin-pipeline install-schedule --config "$CONFIG"'
NORMALIZE = 'runtime/.venv/bin/garmin-pipeline normalize --config "$CONFIG"'
SKILL_COPY = 'cp -R "$source/." "$staging/$name/"'
INBOX_LOOP = (
    'for dir in "$RUNTIME/inbox" "$RUNTIME/inbox/inbody" '
    '"$RUNTIME/inbox/inbody/processed" "$RUNTIME/inbox/inbody/unreadable"; do'
)
INBOX_DIRS = (
    "inbox",
    "inbox/inbody",
    "inbox/inbody/processed",
    "inbox/inbody/unreadable",
)


def _script() -> str:
    return DEPLOY.read_text(encoding="utf-8")


def _commands() -> list[str]:
    """주석과 빈 줄을 뺀 스크립트 줄."""
    return [
        line.strip()
        for line in _script().splitlines()
        if line.strip() and not line.lstrip().startswith("#")
    ]


def test_deploy_script_parses_and_is_executable():
    result = subprocess.run(
        ["bash", "-n", str(DEPLOY)], capture_output=True, text=True, check=False
    )

    assert result.returncode == 0, result.stderr
    assert os.access(DEPLOY, os.X_OK)
    assert _script().startswith("#!/usr/bin/env bash\n")
    assert "set -euo pipefail" in _commands()


def test_deploy_script_cds_to_repo_root():
    commands = _commands()

    assert 'REPO="$(cd "$(dirname "$0")/.." && pwd)"' in commands
    assert 'cd "$REPO"' in commands
    assert 'RUNTIME="$REPO/runtime"' in commands
    assert 'CONFIG="$RUNTIME/config.toml"' in commands


def test_deploy_script_installs_frozen_non_editable_snapshot():
    assert SNAPSHOT in _commands()


def test_deploy_script_checks_snapshot_python_patch_version():
    pinned = (ROOT / ".python-version").read_text(encoding="utf-8").strip()

    assert f'EXPECTED_PYTHON="{pinned}"' in _commands()
    assert pinned == "3.14.8"
    assert 'if [ "$actual_python" != "$EXPECTED_PYTHON" ]; then' in _commands()


def test_deploy_script_copies_example_only_when_config_is_missing():
    commands = _commands()
    guard = 'if [ ! -e "$CONFIG" ] && [ ! -L "$CONFIG" ]; then'

    assert guard in commands
    assert commands[commands.index(guard) + 1] == 'cp "$EXAMPLE" "$CONFIG"'
    assert 'EXAMPLE="$REPO/config.runtime.example.toml"' in commands
    # config 복사는 이 한 곳뿐이다(덮어쓰는 다른 경로가 없다).
    assert [line for line in commands if line.startswith('cp "$EXAMPLE"')] == [
        'cp "$EXAMPLE" "$CONFIG"'
    ]
    assert [line for line in commands if "$CONFIG" in line and "cp " in line] == [
        'cp "$EXAMPLE" "$CONFIG"'
    ]


def test_deploy_script_order_normalizes_before_schedule():
    commands = _commands()
    positions = [
        commands.index(SNAPSHOT),
        commands.index('cp "$EXAMPLE" "$CONFIG"'),
        commands.index(SKILL_COPY),
        commands.index(INBOX_LOOP),
        commands.index(NORMALIZE),
        commands.index(INSTALL),
    ]

    assert positions == sorted(positions)
    assert commands[-2:] == [NORMALIZE, INSTALL]


def test_deploy_script_replaces_skill_through_staging_folder():
    commands = _commands()
    start = commands.index('SKILLS="$RUNTIME/.agents/skills"')

    assert commands[start : start + 4] == [
        'SKILLS="$RUNTIME/.agents/skills"',
        'mkdir -p "$SKILLS"',
        'staging="$(mktemp -d "$RUNTIME/.agents/.skill-staging.XXXXXX")"',
        "trap 'rm -rf \"$staging\"' EXIT",
    ]
    assert commands.index(SKILL_COPY) < commands.index('rm -rf "$installed"')
    assert 'mv "$staged" "$SKILLS/$name"' in commands


def test_deploy_script_creates_only_missing_inbox_folders():
    commands = _commands()
    start = commands.index(INBOX_LOOP)

    assert commands[start + 1 : start + 4] == [
        'if [ ! -d "$dir" ]; then',
        'mkdir -m 700 "$dir"',
        "fi",
    ]


def test_deploy_script_avoids_deprecated_launchctl_and_dev_paths():
    commands = "\n".join(_commands())

    assert "launchctl" not in commands
    assert "uv run" not in commands


def test_runtime_example_config_is_runtime_without_tokenstore():
    raw = tomllib.loads(EXAMPLE.read_text(encoding="utf-8"))

    assert raw["environment"] == "runtime"
    assert "tokenstore" not in raw
    for key in ("data_dir", "reports_dir", "inbox_dir"):
        assert not Path(raw[key]).is_absolute()


def test_runtime_example_config_loads(tmp_path: Path):
    # pytest 가드를 지나도록 environment는 dev로, tokenstore는 tmp로 바꾼 사본을 읽는다.
    text = EXAMPLE.read_text(encoding="utf-8")
    assert text.count('environment = "runtime"') == 1
    text = text.replace('environment = "runtime"', 'environment = "dev"')
    text += f'\ntokenstore = "{tmp_path / "tokens"}"\n'
    path = tmp_path / "runtime" / "config.toml"
    path.parent.mkdir()
    path.write_text(text, encoding="utf-8")

    cfg = config.load(path)

    assert cfg.data_dir == tmp_path / "runtime" / "data"
    assert cfg.reports_dir == tmp_path / "runtime" / "reports"
    assert cfg.inbox_dir == tmp_path / "runtime" / "inbox"
    assert cfg.timezone == "Asia/Seoul"
    assert cfg.collect_time < cfg.retry_time < cfg.report_time


def test_src_changes_invalidate_the_snapshot_build():
    # 기본 cache-keys로는 src/ 수정 뒤 다시 배포해도 uv가 스냅샷을 다시 설치하지 않는다.
    uv = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))["tool"][
        "uv"
    ]

    assert {"file": "pyproject.toml"} in uv["cache-keys"]
    assert {"file": "src/**/*"} in uv["cache-keys"]


# --- 가짜 uv로 실행 -------------------------------------------------------------------------

_FAKE_UV = """#!/bin/sh
printf '%s|%s|%s\\n' "$(pwd)" "$UV_PROJECT_ENVIRONMENT" "$*" >> "$DEPLOY_TEST_UV_LOG"
mkdir -p runtime/.venv/bin
cat > runtime/.venv/bin/python <<PY
#!/bin/sh
echo "$DEPLOY_TEST_PYTHON_VERSION"
PY
cat > runtime/.venv/bin/garmin-pipeline <<'GP'
#!/bin/sh
(IFS="$(printf '\\t')"; printf '%s\\n' "$*") >> "$DEPLOY_TEST_RECORD"
if [ "$1" = normalize ] && [ -n "${DEPLOY_TEST_NORMALIZE_EXIT:-}" ]; then
  exit "$DEPLOY_TEST_NORMALIZE_EXIT"
fi
GP
chmod +x runtime/.venv/bin/python runtime/.venv/bin/garmin-pipeline
"""


@pytest.fixture
def fake_repo(tmp_path: Path) -> Path:
    repo = tmp_path / "repo"
    (repo / "scripts").mkdir(parents=True)
    shutil.copy2(DEPLOY, repo / "scripts" / "deploy.sh")
    shutil.copy2(EXAMPLE, repo / EXAMPLE.name)
    shutil.copytree(ROOT / "skill", repo / "skill")
    shim = tmp_path / "shim"
    shim.mkdir()
    (shim / "uv").write_text(_FAKE_UV, encoding="utf-8")
    (shim / "uv").chmod(0o755)
    return repo


def _deploy(
    repo: Path, *, python_version: str = "3.14.8", normalize_exit: int | None = None
) -> subprocess.CompletedProcess[str]:
    shim = repo.parent / "shim"
    env = {
        key: value
        for key, value in os.environ.items()
        if key != "DEPLOY_TEST_NORMALIZE_EXIT"
    } | {
        "PATH": f"{shim}{os.pathsep}{os.environ['PATH']}",
        "DEPLOY_TEST_PYTHON_VERSION": python_version,
        "DEPLOY_TEST_RECORD": str(repo.parent / "garmin-pipeline.calls"),
        "DEPLOY_TEST_UV_LOG": str(repo.parent / "uv.log"),
    }
    if normalize_exit is not None:
        env["DEPLOY_TEST_NORMALIZE_EXIT"] = str(normalize_exit)
    return subprocess.run(
        ["bash", str(repo / "scripts" / "deploy.sh")],
        cwd=repo.parent,
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )


def _recorded_calls(repo: Path) -> list[list[str]]:
    """가짜 `garmin-pipeline` 호출의 argv 목록(호출 순서)."""
    record = repo.parent / "garmin-pipeline.calls"
    if not record.exists():
        return []
    return [
        line.split("\t") for line in record.read_text(encoding="utf-8").splitlines()
    ]


def _expected_calls(repo: Path) -> list[list[str]]:
    config_path = f"{repo}/runtime/config.toml"
    return [
        ["normalize", "--config", config_path],
        ["install-schedule", "--config", config_path],
    ]


def test_deploy_first_run_creates_runtime_and_installs_schedule(fake_repo: Path):
    result = _deploy(fake_repo)

    assert result.returncode == 0, result.stderr
    runtime = fake_repo / "runtime"
    assert stat.S_IMODE(runtime.stat().st_mode) == 0o700
    assert (runtime / "config.toml").read_bytes() == EXAMPLE.read_bytes()
    uv_calls = (fake_repo.parent / "uv.log").read_text(encoding="utf-8").splitlines()
    # 저장소 밖(repo.parent)에서 불러도 uv와 스냅샷은 저장소 루트 기준이다.
    [(cwd, rest)] = [call.split("|", 1) for call in uv_calls]
    assert Path(cwd).resolve() == fake_repo.resolve()
    assert rest == "runtime/.venv|sync --frozen --no-editable --no-dev"
    assert (runtime / ".venv" / "bin" / "garmin-pipeline").is_file()
    assert not (fake_repo.parent / "runtime").exists()
    assert _recorded_calls(fake_repo) == _expected_calls(fake_repo)


@pytest.mark.parametrize("state", ["file", "symlink", "broken-symlink"])
def test_deploy_leaves_existing_runtime_config_untouched(
    fake_repo: Path, tmp_path: Path, state: str
):
    runtime = fake_repo / "runtime"
    runtime.mkdir()
    target = runtime / "config.toml"
    elsewhere = tmp_path / "operator.toml"
    if state == "file":
        target.write_text("# 운영자가 고친 설정\n", encoding="utf-8")
    else:
        if state == "symlink":
            elsewhere.write_text("# 다른 곳의 설정\n", encoding="utf-8")
        target.symlink_to(elsewhere)

    result = _deploy(fake_repo)

    assert result.returncode == 0, result.stderr
    if state == "file":
        assert target.read_text(encoding="utf-8") == "# 운영자가 고친 설정\n"
    else:
        assert target.is_symlink()
        assert target.readlink() == elsewhere
        if state == "symlink":
            assert elsewhere.read_text(encoding="utf-8") == "# 다른 곳의 설정\n"
        else:
            assert not elsewhere.exists()
    assert _recorded_calls(fake_repo) == _expected_calls(fake_repo)


def test_deploy_stops_when_snapshot_python_is_not_pinned(fake_repo: Path):
    result = _deploy(fake_repo, python_version="3.14.7")

    assert result.returncode != 0
    assert "3.14.7" in result.stderr
    assert _recorded_calls(fake_repo) == []
    assert not (fake_repo / "runtime" / ".agents").exists()
    assert not (fake_repo / "runtime" / "inbox").exists()


def test_deploy_stops_before_schedule_when_normalize_fails(fake_repo: Path):
    result = _deploy(fake_repo, normalize_exit=1)

    assert result.returncode != 0
    assert _recorded_calls(fake_repo) == _expected_calls(fake_repo)[:1]


# --- skill 복사와 inbox(4.6) -----------------------------------------------------------------


def _tree(root: Path) -> dict[str, bytes | None]:
    """폴더 아래 모든 항목의 상대경로 → 파일 바이트(폴더는 None)."""
    return {
        path.relative_to(root).as_posix(): (
            path.read_bytes() if path.is_file() else None
        )
        for path in sorted(root.rglob("*"))
    }


def _copy(repo: Path) -> Path:
    return repo / "runtime" / ".agents" / "skills" / "garmin-daily-analysis"


def test_deploy_first_run_copies_skill_and_creates_inbox(fake_repo: Path):
    result = _deploy(fake_repo)

    assert result.returncode == 0, result.stderr
    copy = _copy(fake_repo)
    assert (copy / "SKILL.md").read_bytes() == (SKILL / "SKILL.md").read_bytes()
    assert _tree(copy) == _tree(SKILL)
    # 임시 폴더가 남지 않는다. skills/에는 이 skill 하나뿐이다.
    assert sorted(path.name for path in copy.parents[1].iterdir()) == ["skills"]
    assert sorted(path.name for path in copy.parent.iterdir()) == [
        "garmin-body-intake",
        "garmin-daily-analysis",
        "garmin-period-review",
    ]
    runtime = fake_repo / "runtime"
    for name in INBOX_DIRS:
        folder = runtime / name
        assert folder.is_dir(), name
        assert stat.S_IMODE(folder.stat().st_mode) == 0o700, name
    assert _recorded_calls(fake_repo) == _expected_calls(fake_repo)


def test_deploy_again_replaces_skill_and_keeps_inbox(fake_repo: Path):
    assert _deploy(fake_repo).returncode == 0
    copy = _copy(fake_repo)
    (copy / "old.md").write_text("옛 파일\n", encoding="utf-8")
    (copy / "SKILL.md").write_text("고친 복사본\n", encoding="utf-8")
    inbody = fake_repo / "runtime" / "inbox" / "inbody"
    (inbody / "2026-10-17.png").write_bytes(b"screenshot")
    (inbody / "processed" / "2026-10-01.md").write_text("처리됨\n", encoding="utf-8")
    (inbody / "unreadable").chmod(0o755)
    before = {name: _tree(fake_repo / "runtime" / name) for name in INBOX_DIRS}
    (fake_repo.parent / "garmin-pipeline.calls").unlink()

    result = _deploy(fake_repo)

    assert result.returncode == 0, result.stderr
    assert _tree(copy) == _tree(SKILL)
    assert not (copy / "garmin-daily-analysis").exists()
    assert sorted(path.name for path in copy.parents[1].iterdir()) == ["skills"]
    assert {name: _tree(fake_repo / "runtime" / name) for name in INBOX_DIRS} == before
    assert stat.S_IMODE((inbody / "unreadable").stat().st_mode) == 0o755
    assert stat.S_IMODE((inbody / "processed").stat().st_mode) == 0o700
    assert _recorded_calls(fake_repo) == _expected_calls(fake_repo)


@pytest.mark.parametrize("empty_source", [False, True], ids=["missing", "empty"])
def test_deploy_stops_when_skill_source_is_missing(fake_repo: Path, empty_source: bool):
    assert _deploy(fake_repo).returncode == 0
    copy = _copy(fake_repo)
    previous = _tree(copy.parent)
    shutil.rmtree(fake_repo / "skill")
    if empty_source:
        (fake_repo / "skill").mkdir()
    (fake_repo.parent / "garmin-pipeline.calls").unlink()

    result = _deploy(fake_repo)

    assert result.returncode != 0
    assert _recorded_calls(fake_repo) == []
    assert _tree(copy.parent) == previous
    # 실패로 끝나도 EXIT trap이 임시 폴더를 지운다.
    assert sorted(path.name for path in copy.parents[1].iterdir()) == ["skills"]


def test_deploy_leaves_skill_discoverable_once(fake_repo: Path):
    result = _deploy(fake_repo)

    assert result.returncode == 0, result.stderr
    skills = sorted(
        path.relative_to(fake_repo).as_posix() for path in fake_repo.rglob("SKILL.md")
    )
    assert skills == [
        "runtime/.agents/skills/garmin-body-intake/SKILL.md",
        "runtime/.agents/skills/garmin-daily-analysis/SKILL.md",
        "runtime/.agents/skills/garmin-period-review/SKILL.md",
        "skill/garmin-body-intake/SKILL.md",
        "skill/garmin-daily-analysis/SKILL.md",
        "skill/garmin-period-review/SKILL.md",
    ]
    agents = [
        path.relative_to(fake_repo).as_posix() for path in fake_repo.rglob(".agents")
    ]
    assert agents == ["runtime/.agents"]


def test_deploy_syncs_all_skills_removes_obsolete_and_preserves_profile(fake_repo):
    custom = fake_repo / "skill/custom-analysis"
    custom.mkdir()
    (custom / "SKILL.md").write_text("custom skill")
    obsolete = fake_repo / "runtime/.agents/skills/garmin-daily-report"
    obsolete.mkdir(parents=True)
    (obsolete / "SKILL.md").write_text("old")
    profile = fake_repo / "runtime/profile.md"
    profile.write_text("personal preferences")
    assert _deploy(fake_repo).returncode == 0
    installed = fake_repo / "runtime/.agents/skills"
    assert sorted(p.name for p in installed.iterdir()) == [
        "custom-analysis",
        "garmin-body-intake",
        "garmin-daily-analysis",
        "garmin-period-review",
    ]
    assert (installed / "custom-analysis/SKILL.md").read_text() == "custom skill"
    assert profile.read_text() == "personal preferences"
