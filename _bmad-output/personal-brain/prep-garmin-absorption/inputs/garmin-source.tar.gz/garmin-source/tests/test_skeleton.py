"""프로젝트 골격이 지켜야 할 고정 사항: 의존성, 콘솔 스크립트, import 범위, gitignore, 로컬 시각 금지."""

import ast
import json
import os
import shutil
import subprocess
import sys
import sysconfig
import tomllib
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = sysconfig.get_path("scripts")

# `cli`가 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, cli, 공통 계층.
CLI_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline",
    "garmin_pipeline.cli",
    "garmin_pipeline.config",
    "garmin_pipeline.dates",
    "garmin_pipeline.errors",
}

# 공통 계층 모듈별로 import해도 되는 패키지 모듈. 공통 계층 안에서는 dates → config만 허용한다.
COMMON_LAYER_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline.config": {"garmin_pipeline", "garmin_pipeline.config"},
    "garmin_pipeline.dates": {
        "garmin_pipeline",
        "garmin_pipeline.config",
        "garmin_pipeline.dates",
    },
    "garmin_pipeline.errors": {"garmin_pipeline", "garmin_pipeline.errors"},
}

# `store`가 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, config, errors, `store`와 그 하위.
STORE_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline",
    "garmin_pipeline.config",
    "garmin_pipeline.errors",
}

# `garmin`이 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, 공통 계층, `garmin`과 그 하위.
# 이 검사는 패키지 모듈만 본다. 패키지 밖 모듈(garminconnect·curl_cffi와 그 의존성)은 제한하지 않는다.
GARMIN_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline",
    "garmin_pipeline.config",
    "garmin_pipeline.dates",
    "garmin_pipeline.errors",
}

# `auth`가 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, 공통 계층, garmin·store와 그 하위.
AUTH_ALLOWED_PACKAGES = (
    "garmin_pipeline.auth",
    "garmin_pipeline.garmin",
    "garmin_pipeline.store",
)
AUTH_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline",
    "garmin_pipeline.config",
    "garmin_pipeline.dates",
    "garmin_pipeline.errors",
}

# `coverage`가 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, 공통 계층, rawparse.
# `garmin`(어댑터)·`store`·`cli`·`auth`는 로드되면 안 된다.
COVERAGE_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline",
    "garmin_pipeline.config",
    "garmin_pipeline.dates",
    "garmin_pipeline.errors",
    "garmin_pipeline.rawparse",
    "garmin_pipeline.coverage",
}
# `coverage`가 최상위에서 import해도 되는 stdlib 모듈(AST 검사).
COVERAGE_ALLOWED_STDLIB = {"sqlite3", "datetime", "enum", "typing", "logging"}

# `collect`가 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, 공통 계층, coverage(→ rawparse),
# ports, garmin·store·normalize와 그 하위. `cli`·`auth`는 로드되면 안 된다.
COLLECT_ALLOWED_PACKAGES = (
    "garmin_pipeline.garmin",
    "garmin_pipeline.store",
    "garmin_pipeline.normalize",
)
COLLECT_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline.digest",
    "garmin_pipeline",
    "garmin_pipeline.config",
    "garmin_pipeline.dates",
    "garmin_pipeline.errors",
    "garmin_pipeline.coverage",
    "garmin_pipeline.rawparse",
    "garmin_pipeline.ports",
    "garmin_pipeline.telegram",
    "garmin_pipeline.collect",
}

# `ports`가 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, 공통 계층(dates → config), ports.
PORTS_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline",
    "garmin_pipeline.config",
    "garmin_pipeline.dates",
    "garmin_pipeline.errors",
    "garmin_pipeline.ports",
    "garmin_pipeline.telegram",
}

# `schedule`이 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, 공통 계층(dates → config), schedule.
SCHEDULE_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline",
    "garmin_pipeline.config",
    "garmin_pipeline.dates",
    "garmin_pipeline.schedule",
}

# `capture`가 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, 공통 계층, rawparse, coverage, capture,
# `store`와 그 하위. `garmin`(어댑터)·`cli`·`auth`·`collect`·`ports`·`schedule`은 로드되면 안 된다.
CAPTURE_ALLOWED_PACKAGES = ("garmin_pipeline.store",)
CAPTURE_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline",
    "garmin_pipeline.config",
    "garmin_pipeline.dates",
    "garmin_pipeline.errors",
    "garmin_pipeline.rawparse",
    "garmin_pipeline.coverage",
    "garmin_pipeline.capture",
}

# `normalize`가 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, 공통 계층, rawparse, `store`·`normalize`와
# 그 하위. `garmin`(어댑터)·`cli`·`auth`·`coverage`·`collect`·`ports`·`schedule`·`capture`는 로드되면 안 되고,
# 패키지 밖 모듈(garminconnect 등)도 로드되면 안 된다.
NORMALIZE_ALLOWED_PACKAGES = ("garmin_pipeline.store", "garmin_pipeline.normalize")
NORMALIZE_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline.digest",
    "garmin_pipeline",
    "garmin_pipeline.config",
    "garmin_pipeline.dates",
    "garmin_pipeline.errors",
    "garmin_pipeline.rawparse",
}

# `body`가 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, config, dates, body. `store`·`garmin`(어댑터)·
# `cli` 같은 모듈과 패키지 밖 모듈(jsonschema는 검증 함수 안에서 늦게 import한다)은 로드되면 안 된다.
BODY_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline",
    "garmin_pipeline.config",
    "garmin_pipeline.dates",
    "garmin_pipeline.body",
}

# `report`가 최상위에서 import해도 되는 패키지 모듈: 패키지 자신, 공통 계층, coverage(→ rawparse), body, ports, report,
# `store`와 그 하위. `garmin`(어댑터)·`normalize`·`cli`·`auth`·`collect`·`schedule`·
# `capture`는 로드되면 안 되고, 패키지 밖 모듈(garminconnect 등)도 로드되면 안 된다.
REPORT_ALLOWED_PACKAGES = ("garmin_pipeline.store",)
REPORT_ALLOWED_PACKAGE_MODULES = {
    "garmin_pipeline",
    "garmin_pipeline.config",
    "garmin_pipeline.dates",
    "garmin_pipeline.errors",
    "garmin_pipeline.coverage",
    "garmin_pipeline.rawparse",
    "garmin_pipeline.body",
    "garmin_pipeline.ports",
    "garmin_pipeline.telegram",
    "garmin_pipeline.report",
    "garmin_pipeline.charts",
    "garmin_pipeline.digest",
    "garmin_pipeline.report_input",
}

# `rawparse`가 최상위에서 import해도 되는 모듈: stdlib 셋뿐이다. 패키지 모듈은 하나도 안 된다.
# 계약 `rawparse-is-pure`가 막는 모듈 밖(예: `os`·`pathlib`)도 여기서 막아 순수성을 고정한다.
RAWPARSE_ALLOWED = {"json", "datetime", "typing"}
# `rawparse`를 import해도 로드되면 안 되는 DB·네트워크 stdlib(전이 import 포함).
RAWPARSE_FORBIDDEN_LOADED = {"sqlite3", "socket", "urllib", "http"}

# 시스템 로컬 시각을 쓰는 `time` API. ruff TID251(banned-api)로 막는다.
BANNED_TIME_APIS = [
    "localtime",
    "mktime",
    "ctime",
    "asctime",
    "strftime",
    "timezone",
    "tzname",
    "altzone",
    "daylight",
]

HEALTH_DATA_PATHS = [
    "runtime/",
    "data/",
    "reports/",
    "inbox/",
    "tests/fixtures/garmin/",
]

# 위 경로 밖에 생긴 SQLite DB·WAL·쓰기 락을 막는 백스톱 패턴.
DB_BACKSTOP_PATTERNS = [
    "*.db",
    "*.db-wal",
    "*.db-shm",
    "*.db-journal",
    ".write.lock",
    ".report.lock",
]


def test_lock_has_no_garth_or_openai():
    lock = tomllib.loads((ROOT / "uv.lock").read_text(encoding="utf-8"))
    names = {package["name"] for package in lock["package"]}

    assert "garminconnect" in names
    assert names.isdisjoint({"garth", "openai"})


def _run_console_script(*args: str) -> subprocess.CompletedProcess[str]:
    script = shutil.which("garmin-pipeline", path=SCRIPTS)
    assert script is not None, (
        f"콘솔 스크립트가 {SCRIPTS}에 없다. `uv sync`를 먼저 실행한다."
    )
    # 출력 문자열을 비교하므로 argparse(3.14+)의 색 출력을 끈다.
    env = {key: value for key, value in os.environ.items() if key != "FORCE_COLOR"}
    env |= {"NO_COLOR": "1", "PYTHON_COLORS": "0"}
    return subprocess.run(
        [script, *args], env=env, capture_output=True, text=True, check=False
    )


def test_console_script_help_exits_0():
    result = _run_console_script("--help")

    assert result.returncode == 0
    assert result.stdout.startswith("usage: garmin-pipeline")


def test_console_script_without_command_is_usage_error():
    result = _run_console_script()

    assert result.returncode == 2
    assert result.stderr.startswith("usage: garmin-pipeline")


def _modules_loaded_by_import(module: str) -> list[str]:
    probe = (
        "import sys\n"
        "before = set(sys.modules)\n"
        f"import {module}\n"
        "print('\\n'.join(sorted(set(sys.modules) - before)))\n"
    )
    result = subprocess.run(
        [sys.executable, "-c", probe], capture_output=True, text=True, check=True
    )
    return result.stdout.split()


def test_package_init_imports_nothing():
    assert _modules_loaded_by_import("garmin_pipeline") == ["garmin_pipeline"]


def _is_stdlib(name: str) -> bool:
    # zoneinfo → sysconfig가 읽는 `_sysconfigdata_<abi>_<platform>`은 플랫폼별로 생성되는
    # stdlib 모듈이라 `sys.stdlib_module_names`에 없다.
    top = name.split(".")[0]
    return top in sys.stdlib_module_names or top.startswith("_sysconfigdata_")


def _split_loaded(loaded: list[str]) -> tuple[set[str], set[str]]:
    """(패키지 모듈, stdlib·패키지 밖 모듈)로 나눈다."""
    package_modules = {
        name for name in loaded if name.split(".")[0] == "garmin_pipeline"
    }
    third_party = {
        name
        for name in loaded
        if not _is_stdlib(name) and name.split(".")[0] != "garmin_pipeline"
    }
    return package_modules, third_party


def test_cli_imports_only_stdlib_and_common_layer():
    package_modules, third_party = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.cli")
    )

    assert "garmin_pipeline.cli" in package_modules
    assert package_modules <= CLI_ALLOWED_PACKAGE_MODULES
    assert third_party == set()


@pytest.mark.parametrize("module", sorted(COMMON_LAYER_ALLOWED_PACKAGE_MODULES))
def test_common_layer_imports_only_stdlib(module: str):
    package_modules, third_party = _split_loaded(_modules_loaded_by_import(module))

    assert module in package_modules
    assert package_modules <= COMMON_LAYER_ALLOWED_PACKAGE_MODULES[module]
    assert third_party == set()


def test_store_imports_only_stdlib_config_errors():
    package_modules, third_party = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.store")
    )
    outside = {
        name
        for name in package_modules - STORE_ALLOWED_PACKAGE_MODULES
        if name != "garmin_pipeline.store"
        and not name.startswith("garmin_pipeline.store.")
    }

    assert "garmin_pipeline.store" in package_modules
    assert outside == set()
    assert third_party == set()


def test_ports_imports_only_stdlib_dates_errors():
    package_modules, third_party = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.ports")
    )

    assert "garmin_pipeline.ports" in package_modules
    assert package_modules <= PORTS_ALLOWED_PACKAGE_MODULES
    assert third_party == set()


def test_schedule_imports_only_stdlib_config_dates():
    package_modules, third_party = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.schedule")
    )

    assert "garmin_pipeline.schedule" in package_modules
    assert package_modules <= SCHEDULE_ALLOWED_PACKAGE_MODULES
    assert third_party == set()


def test_garmin_imports_only_common_layer_package_modules():
    package_modules, _ = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.garmin")
    )
    outside = {
        name
        for name in package_modules - GARMIN_ALLOWED_PACKAGE_MODULES
        if name != "garmin_pipeline.garmin"
        and not name.startswith("garmin_pipeline.garmin.")
    }

    assert "garmin_pipeline.garmin" in package_modules
    assert outside == set()


def test_auth_imports_only_allowed_package_modules():
    package_modules, _ = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.auth")
    )
    outside = {
        name
        for name in package_modules - AUTH_ALLOWED_PACKAGE_MODULES
        if not any(
            name == package or name.startswith(f"{package}.")
            for package in AUTH_ALLOWED_PACKAGES
        )
    }

    assert "garmin_pipeline.auth" in package_modules
    assert outside == set()


def test_coverage_imports_only_stdlib_common_layer_and_rawparse():
    package_modules, third_party = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.coverage")
    )

    assert "garmin_pipeline.coverage" in package_modules
    assert package_modules <= COVERAGE_ALLOWED_PACKAGE_MODULES
    assert third_party == set()


def test_collect_imports_only_allowed_package_modules():
    package_modules, _ = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.collect")
    )
    outside = {
        name
        for name in package_modules - COLLECT_ALLOWED_PACKAGE_MODULES
        if not any(
            name == package or name.startswith(f"{package}.")
            for package in COLLECT_ALLOWED_PACKAGES
        )
    }

    assert "garmin_pipeline.collect" in package_modules
    assert outside == set()


def test_capture_imports_only_allowed_package_modules():
    package_modules, third_party = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.capture")
    )
    outside = {
        name
        for name in package_modules - CAPTURE_ALLOWED_PACKAGE_MODULES
        if not any(
            name == package or name.startswith(f"{package}.")
            for package in CAPTURE_ALLOWED_PACKAGES
        )
    }

    assert "garmin_pipeline.capture" in package_modules
    assert outside == set()
    assert third_party == set()


def test_normalize_imports_only_allowed_package_modules():
    package_modules, third_party = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.normalize")
    )
    outside = {
        name
        for name in package_modules - NORMALIZE_ALLOWED_PACKAGE_MODULES
        if not any(
            name == package or name.startswith(f"{package}.")
            for package in NORMALIZE_ALLOWED_PACKAGES
        )
    }

    assert {
        "garmin_pipeline.normalize",
        "garmin_pipeline.normalize.daily",
        "garmin_pipeline.normalize.activity",
    } <= package_modules
    assert outside == set()
    assert third_party == set()


def test_body_imports_only_stdlib_config_dates():
    package_modules, third_party = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.body")
    )

    assert "garmin_pipeline.body" in package_modules
    assert package_modules <= BODY_ALLOWED_PACKAGE_MODULES
    assert third_party == set()


def test_report_imports_only_allowed_package_modules():
    package_modules, third_party = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.report")
    )
    outside = {
        name
        for name in package_modules - REPORT_ALLOWED_PACKAGE_MODULES
        if not any(
            name == package or name.startswith(f"{package}.")
            for package in REPORT_ALLOWED_PACKAGES
        )
    }

    assert "garmin_pipeline.report" in package_modules
    assert outside == set()
    assert third_party == set()


def _top_level_imports(path: Path) -> set[str]:
    """모듈 본문 바로 아래(함수·클래스 밖)의 import가 가져오는 모듈 이름."""
    tree = ast.parse(path.read_text(encoding="utf-8"))
    names: set[str] = set()
    for node in tree.body:
        if isinstance(node, ast.Import):
            names.update(alias.name for alias in node.names)
        elif isinstance(node, ast.ImportFrom):
            assert node.level == 0, f"{path.name}는 상대 import를 쓰지 않는다"
            assert node.module is not None
            names.add(node.module)
    return names


def test_rawparse_top_level_imports_only_allowed_stdlib():
    path = ROOT / "src" / "garmin_pipeline" / "rawparse.py"

    assert _top_level_imports(path) <= RAWPARSE_ALLOWED


def test_coverage_top_level_imports_only_allowed_stdlib_and_package():
    path = ROOT / "src" / "garmin_pipeline" / "coverage.py"

    assert _top_level_imports(path) <= COVERAGE_ALLOWED_STDLIB | {"garmin_pipeline"}


def test_rawparse_loads_no_package_module_or_db_network():
    loaded = _modules_loaded_by_import("garmin_pipeline.rawparse")
    package_modules, third_party = _split_loaded(loaded)

    assert package_modules == {"garmin_pipeline", "garmin_pipeline.rawparse"}
    assert third_party == set()
    assert {name.split(".")[0] for name in loaded}.isdisjoint(RAWPARSE_FORBIDDEN_LOADED)


def _check_ignore(path: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        ["git", "check-ignore", "--no-index", "--verbose", path],
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )


@pytest.mark.parametrize(
    "path",
    [
        *HEALTH_DATA_PATHS,
        "runtime/tokens/oauth2_token.json",
        "data/garmin.db",
        "reports/2026-10-15.md",
        "inbox/export.zip",
        "tests/fixtures/garmin/sleep.json",
        "tests/fixtures/garmin/sleep_data/2026-10-01.json",
        "tests/fixtures/garmin/activity/12345.json",
        # 앵커가 없으므로 어느 깊이에 있어도 무시한다.
        "nested/inbox/export.zip",
        "nested/data/garmin.db",
    ],
)
def test_health_data_paths_are_gitignored(path: str):
    result = _check_ignore(path)

    assert result.returncode == 0, result.stderr
    assert result.stdout.startswith(".gitignore:")


@pytest.mark.parametrize(
    "path",
    [
        "garmin.db",
        "garmin.db-wal",
        "garmin.db-shm",
        "garmin.db-journal",
        ".write.lock",
        ".report.lock",
        "scratch/copy.db",
        "scratch/copy.db-wal",
        "scratch/copy.db-shm",
        "scratch/copy.db-journal",
        "scratch/.write.lock",
        "scratch/.report.lock",
    ],
)
def test_db_backstop_paths_are_gitignored(path: str):
    result = _check_ignore(path)

    assert result.returncode == 0, result.stderr
    assert result.stdout.startswith(".gitignore:")
    # 위 다섯 경로가 아니라 백스톱 패턴이 잡는다.
    pattern = result.stdout.split("\t")[0].rsplit(":", 1)[1]
    assert pattern in DB_BACKSTOP_PATTERNS


@pytest.mark.parametrize(
    "path",
    [
        "src/garmin_pipeline/cli.py",
        "src/garmin_pipeline/store/migrations/.gitkeep",
        "src/garmin_pipeline/store/migrations/0001_auth_event.sql",
        "src/garmin_pipeline/store/migrations/0002_raw_response.sql",
        "src/garmin_pipeline/store/migrations/0003_run_fetch_error.sql",
        "src/garmin_pipeline/store/migrations/0004_meta.sql",
        "src/garmin_pipeline/store/migrations/0005_notification.sql",
        "src/garmin_pipeline/store/migrations/0006_normalize.sql",
        "src/garmin_pipeline/store/migrations/0007_sleep_stress_body_battery.sql",
        "src/garmin_pipeline/store/migrations/0008_hr_sample.sql",
        "src/garmin_pipeline/store/migrations/0009_activity.sql",
        "src/garmin_pipeline/store/migrations/0010_activity_recovery.sql",
        "src/garmin_pipeline/store/migrations/0011_exercise_set.sql",
        "src/garmin_pipeline/store/migrations/0012_drop_activity_recovery.sql",
        "src/garmin_pipeline/store/migrations/0013_activity_body_battery.sql",
        "src/garmin_pipeline/store/migrations/0014_zone_bounds_stress_bb.sql",
        "src/garmin_pipeline/store/migrations/0015_delivery.sql",
        "src/garmin_pipeline/store/migrations/0016_day_values_evaluation.sql",
        "src/garmin_pipeline/ports.py",
        "src/garmin_pipeline/telegram.py",
        "src/garmin_pipeline/rawparse.py",
        "src/garmin_pipeline/coverage.py",
        "src/garmin_pipeline/collect.py",
        "src/garmin_pipeline/schedule.py",
        "src/garmin_pipeline/capture.py",
        "src/garmin_pipeline/normalize/__init__.py",
        "src/garmin_pipeline/normalize/daily.py",
        "src/garmin_pipeline/normalize/activity.py",
        "src/garmin_pipeline/labels/exercise_types_ko.json",
        "scripts/build_exercise_labels.py",
        "tests/test_build_exercise_labels.py",
        "src/garmin_pipeline/body.py",
        "src/garmin_pipeline/schemas/body.schema.json",
        "tests/fixtures/body/measurement.json",
        "src/garmin_pipeline/schemas/daily_analysis_output.schema.json",
        "src/garmin_pipeline/schemas/body_intake_output.schema.json",
        "src/garmin_pipeline/digest.py",
        "src/garmin_pipeline/report_input.py",
        "tests/test_digest.py",
        "tests/test_report_input.py",
        "src/garmin_pipeline/report.py",
        "src/garmin_pipeline/charts.py",
        "tests/test_charts.py",
        "tests/chart_db.py",
        "tests/test_report.py",
        "tests/test_report_codex.py",
        "skill/garmin-daily-analysis/SKILL.md",
        "skill/garmin-body-intake/SKILL.md",
        "tests/test_skill.py",
        "scripts/deploy.sh",
        "config.runtime.example.toml",
        "tests/test_skeleton.py",
        "tests/test_acceptance_report.py",
        "tests/test_operations_guide.py",
        "tests/fixtures/inbody/make_inbody_png.swift",
        "tests/fixtures/inbody/inbody-synthetic.png",
        "tests/fixtures/inbody/inbody-synthetic.md",
        "tests/fixtures/sample.json",
        "uv.lock",
        "config.toml",
    ],
)
def test_source_paths_are_not_gitignored(path: str):
    assert _check_ignore(path).returncode == 1


def _ruff_codes(source: str) -> list[str]:
    """`src/` 안 파일로 보고 ruff를 돌려 진단 코드를 돌려준다."""
    result = subprocess.run(
        [
            sys.executable,
            "-m",
            "ruff",
            "check",
            "--no-cache",
            "--output-format",
            "json",
            "--stdin-filename",
            "src/garmin_pipeline/clock.py",
            "-",
        ],
        input=source,
        cwd=ROOT,
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode in (0, 1), result.stderr
    return [diagnostic["code"] for diagnostic in json.loads(result.stdout)]


def test_ruff_flags_naive_local_now():
    assert "DTZ005" in _ruff_codes("import datetime\n\nNOW = datetime.datetime.now()\n")


@pytest.mark.parametrize("name", BANNED_TIME_APIS)
def test_ruff_bans_time_local_api(name: str):
    assert "TID251" in _ruff_codes(f"import time\n\nVALUE = time.{name}\n")


@pytest.mark.parametrize(
    "source",
    [
        "import time\n\nNOW = time.localtime()\n",
        "from time import localtime\n\nNOW = localtime()\n",
        "from time import strftime as fmt\n\nTEXT = fmt('%Y')\n",
    ],
    ids=["call", "from-import", "aliased"],
)
def test_ruff_bans_time_local_api_imports(source: str):
    assert "TID251" in _ruff_codes(source)


def test_ruff_allows_utc_time_apis():
    source = "import time\n\nNOW = time.time()\nUTC_NOW = time.gmtime()\nTICK = time.monotonic()\n"

    assert "TID251" not in _ruff_codes(source)


def _local_astimezone_lines(source: str) -> list[int]:
    """`.astimezone()`·`.astimezone(None)`처럼 시스템 시간대로 바꾸는 호출의 줄 번호."""
    lines = []
    for node in ast.walk(ast.parse(source)):
        if not (
            isinstance(node, ast.Call)
            and isinstance(node.func, ast.Attribute)
            and node.func.attr == "astimezone"
        ):
            continue
        arguments = [*node.args, *(keyword.value for keyword in node.keywords)]
        if not arguments or (
            len(arguments) == 1
            and isinstance(arguments[0], ast.Constant)
            and arguments[0].value is None
        ):
            lines.append(node.lineno)
    return lines


@pytest.mark.parametrize(
    "source",
    [
        "x.astimezone()\n",
        "x.astimezone(None)\n",
        "x.astimezone(tz=None)\n",
        "datetime.now(UTC).astimezone()\n",
    ],
)
def test_astimezone_check_catches_system_zone(source: str):
    assert _local_astimezone_lines(source) == [1]


def test_astimezone_check_allows_explicit_zone():
    source = "x.astimezone(ZoneInfo('Asia/Seoul'))\nx.astimezone(tz=UTC)\n"

    assert _local_astimezone_lines(source) == []


def test_src_never_converts_to_system_zone():
    offenders = [
        f"{path.relative_to(ROOT)}:{line}"
        for path in sorted((ROOT / "src").rglob("*.py"))
        for line in _local_astimezone_lines(path.read_text(encoding="utf-8"))
    ]

    assert offenders == []


# --- 인수 테스트(4.7)는 기본 실행에서 빠진다 -----------------------------------------------------


ACCEPTANCE_MODULE = ROOT / "tests" / "test_acceptance_report.py"


def _pytest_config() -> dict[str, object]:
    pyproject = tomllib.loads((ROOT / "pyproject.toml").read_text(encoding="utf-8"))
    return pyproject["tool"]["pytest"]


def test_pytest_deselects_acceptance_by_default():
    assert _pytest_config()["addopts"] == ["-m", "not acceptance"]


def test_acceptance_marker_is_registered():
    markers = _pytest_config()["markers"]

    assert isinstance(markers, list)
    assert [m for m in markers if m.split(":", 1)[0].strip() == "acceptance"]


def test_acceptance_module_marks_every_test():
    tree = ast.parse(ACCEPTANCE_MODULE.read_text(encoding="utf-8"))
    marks = [
        ast.unparse(node.value)
        for node in tree.body
        if isinstance(node, ast.Assign)
        and [ast.unparse(target) for target in node.targets] == ["pytestmark"]
    ]

    assert marks == ["pytest.mark.acceptance"]


def test_charts_imports_only_stdlib_config():
    package_modules, third_party = _split_loaded(
        _modules_loaded_by_import("garmin_pipeline.charts")
    )
    assert package_modules == {
        "garmin_pipeline",
        "garmin_pipeline.config",
        "garmin_pipeline.charts",
        "garmin_pipeline.body",
        "garmin_pipeline.dates",
        "garmin_pipeline.store",
    }
    assert third_party == set()
