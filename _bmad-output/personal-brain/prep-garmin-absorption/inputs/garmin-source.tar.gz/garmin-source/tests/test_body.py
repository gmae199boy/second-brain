"""체성분 입력 장부 `garmin-pipeline body {pending,write,reject}`(4.1).

모든 시험은 `cli.main`으로 명령을 부르고, 운영 루트는 `tmp_path/runtime`(config 파일이 있는 폴더)이다.
in-process 시험은 소켓을 막고 시계를 2026-10-18(Asia/Seoul)로 고정한다.
"""

import io
import json
import os
import socket
import stat
import subprocess
import sys
from datetime import UTC, datetime
from pathlib import Path

import jsonschema
import pytest

from garmin_pipeline import body, cli, dates

ROOT = Path(__file__).resolve().parents[1]
SCHEMA_PATH = ROOT / "src" / "garmin_pipeline" / "schemas" / "body.schema.json"
SCHEMA = json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))
SAMPLE = ROOT / "tests" / "fixtures" / "body" / "measurement.json"
NOW = datetime(2026, 10, 18, 3, 0, tzinfo=UTC)  # Asia/Seoul 2026-10-18 12:00
DAY = "2026-10-14"


# --- 준비 ----------------------------------------------------------------------------------


class _BlockedSocket(socket.socket):
    def __init__(self, *args: object, **kwargs: object) -> None:
        raise OSError("소켓 차단")


@pytest.fixture(autouse=True)
def _block_sockets(monkeypatch: pytest.MonkeyPatch) -> None:
    """이 파일의 in-process 시험은 소켓을 막은 채 돈다(하위 프로세스 시험은 따로 막는다)."""
    monkeypatch.setattr(socket, "socket", _BlockedSocket)


@pytest.fixture(autouse=True)
def _fixed_clock(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(dates, "_utc_now", lambda: NOW)


@pytest.fixture
def root(tmp_path: Path) -> Path:
    """운영 루트 `tmp_path/runtime`(config.toml만 있음). tokenstore는 루트 밖이지만 쓰지 않는다."""
    root = tmp_path / "runtime"
    root.mkdir()
    tokens = json.dumps(str(tmp_path / "tokens"))
    (root / "config.toml").write_text(
        f'environment = "dev"\ntokenstore = {tokens}\n', encoding="utf-8"
    )
    return root


class Run:
    def __init__(
        self, monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]
    ):
        self._monkeypatch = monkeypatch
        self._capsys = capsys

    def __call__(self, root: Path, *argv: str, stdin: str = "") -> tuple[int, str, str]:
        stream = io.TextIOWrapper(io.BytesIO(stdin.encode("utf-8")), encoding="utf-8")
        self._monkeypatch.setattr(sys, "stdin", stream)
        self._capsys.readouterr()
        code = cli.main(["body", *argv, "--config", str(root / "config.toml")])
        out, err = self._capsys.readouterr()
        return code, out, err


@pytest.fixture
def run(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str]) -> Run:
    return Run(monkeypatch, capsys)


def _inbox(root: Path) -> Path:
    inbox = root / "inbox" / "inbody"
    inbox.mkdir(parents=True, exist_ok=True)
    return inbox


def _put(root: Path, name: str, mtime_ns: int = 1_000, content: bytes = b"img") -> Path:
    path = _inbox(root) / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(content)
    os.utime(path, ns=(mtime_ns, mtime_ns))
    return path


def _sidecar_path(root: Path, day: str = DAY) -> Path:
    return root / "data" / "body" / f"{day}.json"


def _put_sidecar(root: Path, doc: object, day: str = DAY) -> Path:
    path = _sidecar_path(root, day)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(doc), encoding="utf-8")
    return path


def _snapshot(base: Path) -> dict[str, tuple[int, object, int]]:
    """`base` 아래 모든 항목의 (종류, 내용 또는 링크 대상, mtime_ns). 링크는 따라가지 않는다."""
    result: dict[str, tuple[int, object, int]] = {}
    for dirpath, dirnames, filenames in os.walk(base):
        for name in [*dirnames, *filenames]:
            path = Path(dirpath) / name
            info = path.lstat()
            if stat.S_ISREG(info.st_mode):
                content: object = path.read_bytes()
            elif stat.S_ISLNK(info.st_mode):
                content = os.readlink(path)
            else:
                content = None
            key = path.relative_to(base).as_posix()
            result[key] = (stat.S_IFMT(info.st_mode), content, info.st_mtime_ns)
    return result


def _without_logs(tree: dict[str, tuple[int, object, int]]) -> dict[str, object]:
    """명령마다 생기는 로그(`data/logs`)와 그 부모 `data`의 항목을 뺀다(`data/body`는 남긴다)."""
    return {
        key: value
        for key, value in tree.items()
        if key != "data" and not key.startswith("data/logs")
    }


def _without_runtime_logs(
    tree: dict[str, tuple[int, object, int]],
) -> dict[str, object]:
    """`tmp_path` 기준 스냅숏에서 운영 루트 폴더 자신과 로그 항목을 뺀다."""
    return {
        key: value
        for key, value in tree.items()
        if key not in ("runtime", "runtime/data")
        and not key.startswith("runtime/data/logs")
    }


def _mode(path: Path) -> int:
    return stat.S_IMODE(path.stat().st_mode)


# --- 도움말·설정 ----------------------------------------------------------------------------


def test_help_lists_body_and_its_subcommands(capsys: pytest.CaptureFixture[str]):
    with pytest.raises(SystemExit) as top:
        cli.main(["--help"])
    top_help = capsys.readouterr().out
    with pytest.raises(SystemExit) as sub:
        cli.main(["body", "--help"])
    body_help = capsys.readouterr().out

    assert top.value.code == 0
    assert sub.value.code == 0
    assert "body" in top_help
    for name in ("pending", "write", "reject"):
        assert name in body_help


def test_config_error_is_2(tmp_path: Path, capsys: pytest.CaptureFixture[str]):
    code = cli.main(["body", "pending", "--config", str(tmp_path / "missing.toml")])

    assert code == 2
    assert "설정 오류" in capsys.readouterr().err


def test_write_requires_source(root: Path, run: Run):
    with pytest.raises(SystemExit) as raised:
        run(root, "write", DAY, stdin='{"weight_kg": 70}')

    assert raised.value.code == 2


def test_write_bad_date_format_is_usage_error(root: Path, run: Run):
    _put(root, "a.png")
    with pytest.raises(SystemExit) as raised:
        run(root, "write", "2026-13-01", "--source", "inbox/inbody/a.png", stdin="{}")

    assert raised.value.code == 2
    assert (_inbox(root) / "a.png").exists()


# --- pending -------------------------------------------------------------------------------


def test_pending_lists_only_regular_files_directly_under_inbox(root: Path, run: Run):
    _put(root, "b.md")
    _put(root, "a.png")
    _put(root, ".DS_Store")
    _put(root, "processed/old.png")
    _put(root, "unreadable/bad.png")
    (_inbox(root) / "link.png").symlink_to(_inbox(root) / "a.png")

    code, out, err = run(root, "pending")

    assert code == 0
    assert out == "inbox/inbody/a.png\ninbox/inbody/b.md\n"
    assert err == ""


def test_pending_without_inbox_prints_nothing_and_creates_nothing(root: Path, run: Run):
    code, out, _ = run(root, "pending")

    assert code == 0
    assert out == ""
    assert not (root / "inbox").exists()


def test_pending_refuses_inbox_outside_root(tmp_path: Path, root: Path, run: Run):
    outside = tmp_path / "elsewhere"
    (outside / "inbody").mkdir(parents=True)
    (outside / "inbody" / "a.png").write_bytes(b"img")
    config = root / "config.toml"
    config.write_text(
        config.read_text(encoding="utf-8")
        + f"inbox_dir = {json.dumps(str(outside))}\n",
        encoding="utf-8",
    )

    code, out, err = run(root, "pending")

    assert code == 1
    assert out == ""
    assert "운영 루트 밖" in err


# --- write ---------------------------------------------------------------------------------


def test_write_new_sidecar_and_moves_input(root: Path, run: Run):
    source = _put(root, "a.png", mtime_ns=1_760_400_000_000_000_000)

    code, out, err = run(
        root, "write", DAY, "--source", "inbox/inbody/a.png", stdin=SAMPLE.read_text()
    )

    assert code == 0, err
    assert json.loads(out) == {
        "measured_on": DAY,
        "body_path": f"data/body/{DAY}.json",
        "processed": ["inbox/inbody/processed/a.png"],
    }
    assert out.count("\n") == 1
    sidecar = _sidecar_path(root)
    doc = json.loads(sidecar.read_text(encoding="utf-8"))
    sample = json.loads(SAMPLE.read_text(encoding="utf-8"))
    assert list(doc) == [
        "schema_version",
        "measured_on",
        "values",
        "value_mtime_ns",
        "source_files",
    ]
    assert doc["schema_version"] == 1
    assert doc["measured_on"] == DAY
    assert doc["values"] == sample
    order = list(SCHEMA["$defs"]["measurement"]["properties"])
    assert list(doc["values"]) == [key for key in order if key in sample]
    assert list(doc["value_mtime_ns"]) == list(doc["values"])
    assert set(doc["value_mtime_ns"].values()) == {1_760_400_000_000_000_000}
    assert doc["source_files"] == ["inbox/inbody/a.png"]
    jsonschema.Draft202012Validator(SCHEMA).validate(doc)

    moved = _inbox(root) / "processed" / "a.png"
    assert not source.exists()
    assert moved.read_bytes() == b"img"
    assert moved.stat().st_mtime_ns == 1_760_400_000_000_000_000
    assert _mode(root / "data") == 0o700
    assert _mode(root / "data" / "body") == 0o700
    assert _mode(sidecar) == 0o600
    assert _mode(_inbox(root) / "processed") == 0o700
    assert [p.name for p in sidecar.parent.iterdir()] == [sidecar.name]


@pytest.mark.parametrize(
    ("input_mtime", "weight"),
    [
        pytest.param(100, 70, id="existing-newer-kept"),
        pytest.param(200, 71, id="tie-new-wins"),
        pytest.param(300, 71, id="input-newer-wins"),
    ],
)
def test_write_merges_per_key_by_mtime(
    root: Path, run: Run, input_mtime: int, weight: int
):
    _put_sidecar(
        root,
        {
            "schema_version": 1,
            "measured_on": DAY,
            "values": {"weight_kg": 70, "inbody_score": 80},
            "value_mtime_ns": {"weight_kg": 200, "inbody_score": 200},
            "source_files": ["inbox/inbody/old.png"],
        },
    )
    _put(root, "a.png", mtime_ns=input_mtime)

    code, _, err = run(
        root,
        "write",
        DAY,
        "--source",
        "inbox/inbody/a.png",
        stdin='{"body_fat_percent": 18, "weight_kg": 71}',
    )

    assert code == 0, err
    doc = json.loads(_sidecar_path(root).read_text(encoding="utf-8"))
    assert doc["values"] == {
        "weight_kg": weight,
        "body_fat_percent": 18,
        "inbody_score": 80,
    }
    assert list(doc["values"]) == ["weight_kg", "body_fat_percent", "inbody_score"]
    assert doc["value_mtime_ns"] == {
        "weight_kg": 200 if weight == 70 else input_mtime,
        "body_fat_percent": input_mtime,
        "inbody_score": 200,
    }
    assert doc["source_files"] == ["inbox/inbody/old.png", "inbox/inbody/a.png"]


def test_write_uses_latest_source_mtime_and_dedupes_sources(root: Path, run: Run):
    _put(root, "a.png", mtime_ns=100)
    _put(root, "b.md", mtime_ns=300, content=b"# memo")

    code, out, err = run(
        root,
        "write",
        DAY,
        "--source",
        "inbox/inbody/a.png",
        "--source",
        "inbox/inbody/b.md",
        "--source",
        "inbox/inbody/a.png",
        stdin='{"weight_kg": 70.5}',
    )

    assert code == 0, err
    assert json.loads(out)["processed"] == [
        "inbox/inbody/processed/a.png",
        "inbox/inbody/processed/b.md",
    ]
    doc = json.loads(_sidecar_path(root).read_text(encoding="utf-8"))
    assert doc["value_mtime_ns"] == {"weight_kg": 300}
    assert doc["source_files"] == ["inbox/inbody/a.png", "inbox/inbody/b.md"]


def test_write_accumulates_source_files_without_duplicates(root: Path, run: Run):
    _put(root, "a.png", mtime_ns=100)
    assert (
        run(
            root, "write", DAY, "--source", "inbox/inbody/a.png", stdin='{"bmi": 22.1}'
        )[0]
        == 0
    )
    # 같은 이름의 새 입력이 다시 들어와도 source_files에는 한 번만 남는다.
    _put(root, "a.png", mtime_ns=200)

    code, out, err = run(
        root, "write", DAY, "--source", "inbox/inbody/a.png", stdin='{"bmi": 22.4}'
    )

    assert code == 0, err
    assert json.loads(out)["processed"] == ["inbox/inbody/processed/a-2.png"]
    doc = json.loads(_sidecar_path(root).read_text(encoding="utf-8"))
    assert doc["values"] == {"bmi": 22.4}
    assert doc["source_files"] == ["inbox/inbody/a.png"]


def test_write_allows_today_in_config_timezone(
    root: Path, run: Run, monkeypatch: pytest.MonkeyPatch
):
    # UTC로는 아직 10-17이지만 Asia/Seoul로는 10-18이다.
    monkeypatch.setattr(
        dates, "_utc_now", lambda: datetime(2026, 10, 17, 16, 0, tzinfo=UTC)
    )
    _put(root, "a.png")

    code, _, err = run(
        root,
        "write",
        "2026-10-18",
        "--source",
        "inbox/inbody/a.png",
        stdin='{"bmi": 22}',
    )

    assert code == 0, err
    assert _sidecar_path(root, "2026-10-18").exists()


@pytest.mark.parametrize("day", ["2026-10-19", "2099-01-01"])
def test_write_refuses_future_date(root: Path, run: Run, day: str):
    _put(root, "a.png")
    before = _snapshot(root)

    code, out, err = run(
        root, "write", day, "--source", "inbox/inbody/a.png", stdin='{"bmi": 22}'
    )

    assert code == 1
    assert out == ""
    assert "오늘보다 뒤" in err
    assert _without_logs(_snapshot(root)) == _without_logs(before)


@pytest.mark.parametrize(
    "stdin",
    [
        pytest.param('{"height_cm": 175}', id="unknown-key"),
        pytest.param('{"weight_kg": -1}', id="negative"),
        pytest.param('{"weight_kg": 501}', id="over-maximum"),
        pytest.param('{"weight_kg": "70"}', id="string"),
        pytest.param('{"weight_kg": true}', id="boolean"),
        pytest.param('{"weight_kg": null}', id="null"),
        pytest.param('{"inbody_score": 78.5}', id="integer-key-fraction"),
        pytest.param("{}", id="empty-object"),
        pytest.param('[{"weight_kg": 70}]', id="array"),
        pytest.param('{"weight_kg": NaN}', id="nan"),
        pytest.param('{"weight_kg": Infinity}', id="infinity"),
        pytest.param('{"weight_kg": 1e400}', id="overflow-float"),
        pytest.param('{"weight_kg": 70, "weight_kg": 71}', id="duplicate-key"),
        pytest.param("weight 70kg", id="not-json"),
        pytest.param("", id="empty"),
        pytest.param("[" * 100_000 + "]" * 100_000, id="deeply-nested"),
    ],
)
def test_write_rejects_invalid_stdin_and_changes_nothing(
    root: Path, run: Run, stdin: str
):
    _put(root, "a.png")
    before = _snapshot(root)

    code, out, err = run(
        root, "write", DAY, "--source", "inbox/inbody/a.png", stdin=stdin
    )

    assert code == 1
    assert out == ""
    assert err.startswith("body write 거부: stdin")
    assert _without_logs(_snapshot(root)) == _without_logs(before)


_BAD_PATHS = [
    pytest.param(None, id="absolute"),
    pytest.param("../x.png", id="parent-outside-root"),
    pytest.param("config.toml", id="config"),
    pytest.param("inbox/inbody/../../config.toml", id="dotdot-to-config"),
    pytest.param("inbox/inbody/processed/a.png", id="processed"),
    pytest.param("inbox/inbody/processed", id="directory"),
    pytest.param("inbox/inbody/missing.png", id="missing"),
    pytest.param("inbox/inbody/link.png", id="symlink"),
    pytest.param("inbox/inbody/A.png", id="case-mismatch"),
    pytest.param("", id="empty"),
]


def _bad_path_layout(tmp_path: Path, root: Path) -> Path:
    """거부 시험용 배치를 만들고 `inbox/inbody/a.png`의 절대경로를 돌려준다."""
    source = _put(root, "a.png")
    _put(root, "processed/a.png")
    (_inbox(root) / "link.png").symlink_to(source)
    (tmp_path / "x.png").write_bytes(b"outside")
    return source


@pytest.mark.parametrize("raw", _BAD_PATHS)
def test_write_refuses_bad_source_path(
    tmp_path: Path, root: Path, run: Run, raw: str | None
):
    source = _bad_path_layout(tmp_path, root)
    before = _snapshot(tmp_path)

    code, out, err = run(
        root,
        "write",
        DAY,
        "--source",
        str(source) if raw is None else raw,
        stdin='{"weight_kg": 70}',
    )

    assert code == 1
    assert out == ""
    assert err.startswith("body write 거부: ")
    assert _without_runtime_logs(_snapshot(tmp_path)) == _without_runtime_logs(before)


@pytest.mark.parametrize("raw", _BAD_PATHS)
def test_reject_refuses_bad_path(tmp_path: Path, root: Path, run: Run, raw: str | None):
    source = _bad_path_layout(tmp_path, root)
    before = _snapshot(tmp_path)

    code, out, err = run(root, "reject", str(source) if raw is None else raw)

    assert code == 1
    assert out == ""
    assert err.startswith("body reject 거부: ")
    assert _without_runtime_logs(_snapshot(tmp_path)) == _without_runtime_logs(before)
    assert not (_inbox(root) / "unreadable").exists()


_VALID = {
    "schema_version": 1,
    "measured_on": DAY,
    "values": {"weight_kg": 70},
    "value_mtime_ns": {"weight_kg": 200},
    "source_files": ["inbox/inbody/old.png"],
}


def test_write_refuses_symlinked_sidecar(root: Path, run: Run, tmp_path: Path):
    # 날짜가 맞는 유효한 사이드카라도 심링크면 읽지 않는다(루트 밖 파일을 장부로 쓰지 않게).
    elsewhere = tmp_path / "elsewhere.json"
    elsewhere.write_text(
        json.dumps(
            {
                "schema_version": 1,
                "measured_on": DAY,
                "values": {"weight_kg": 70},
                "value_mtime_ns": {"weight_kg": 100},
                "source_files": ["inbox/inbody/old.png"],
            }
        ),
        encoding="utf-8",
    )
    path = _sidecar_path(root)
    path.parent.mkdir(parents=True)
    path.symlink_to(elsewhere)
    _put(root, "a.png", mtime_ns=300)
    before = _snapshot(root)
    outside = elsewhere.read_bytes()

    code, out, err = run(
        root, "write", DAY, "--source", "inbox/inbody/a.png", stdin='{"weight_kg": 71}'
    )

    assert code == 1
    assert out == ""
    assert "기존 사이드카가 일반 파일이 아니다" in err
    assert _without_logs(_snapshot(root)) == _without_logs(before)
    assert elsewhere.read_bytes() == outside


def test_write_rejects_non_utf8_stdin_without_locale(root: Path):
    # launchd처럼 로캘이 없으면(C) Python UTF-8 모드가 stdin을 surrogateescape로 읽는다. 그래도 거부한다.
    _put(root, "a.png")
    before = _snapshot(root)
    env = {k: v for k, v in os.environ.items() if not k.startswith(("LC_", "LANG"))}
    env["LC_ALL"] = "C"

    completed = subprocess.run(
        [
            sys.executable,
            "-c",
            "import sys; from garmin_pipeline import cli; sys.exit(cli.main(sys.argv[1:]))",
            "body",
            "write",
            DAY,
            "--source",
            "inbox/inbody/a.png",
            "--config",
            str(root / "config.toml"),
        ],
        input=b'{"weight_kg": "\xff"}',
        capture_output=True,
        env=env,
        check=False,
    )

    assert completed.returncode == 1
    assert completed.stdout == b""
    assert completed.stderr.decode("utf-8").startswith(
        "body write 거부: stdin이 UTF-8 텍스트가 아니다"
    )
    assert _without_logs(_snapshot(root)) == _without_logs(before)


@pytest.mark.parametrize("command", [("pending",), ("reject", "inbox/inbody/a.png")])
def test_body_log_open_failure_exits_1(root: Path, run: Run, command: tuple[str, ...]):
    # 로그 폴더 자리에 파일이 있으면 로그를 열지 못한다. 명령은 아무것도 하지 않고 1이다.
    _put(root, "a.png")
    (root / "data").write_text("", encoding="utf-8")
    before = _snapshot(root)

    code, out, err = run(root, *command)

    assert code == 1
    assert out == ""
    assert err.startswith(f"body {command[0]} 실패: 로그 파일을 열지 못했다")
    assert _snapshot(root) == before


@pytest.mark.parametrize(
    "content",
    [
        pytest.param("{not json", id="broken-json"),
        pytest.param(json.dumps({**_VALID, "extra": 1}), id="extra-key"),
        pytest.param(
            json.dumps({**_VALID, "values": {"weight_kg": -5}}), id="bad-value"
        ),
        pytest.param(
            json.dumps({**_VALID, "measured_on": "2026-10-13"}), id="other-date"
        ),
        pytest.param(
            json.dumps({**_VALID, "value_mtime_ns": {"weight_kg": 1, "bmi": 1}}),
            id="mtime-keys-differ",
        ),
        pytest.param(json.dumps({**_VALID, "source_files": []}), id="no-sources"),
    ],
)
def test_write_refuses_corrupt_sidecar(root: Path, run: Run, content: str):
    path = _sidecar_path(root)
    path.parent.mkdir(parents=True)
    path.write_text(content, encoding="utf-8")
    _put(root, "a.png", mtime_ns=300)
    before = _snapshot(root)

    code, out, err = run(
        root, "write", DAY, "--source", "inbox/inbody/a.png", stdin='{"weight_kg": 71}'
    )

    assert code == 1
    assert out == ""
    assert "기존 사이드카" in err
    assert _without_logs(_snapshot(root)) == _without_logs(before)


def test_write_name_collision_uses_next_free_suffix(root: Path, run: Run):
    _put(root, "a.png", content=b"new")
    _put(root, "processed/a.png", content=b"first")
    _put(root, "processed/a-2.png", content=b"second")

    code, out, err = run(
        root, "write", DAY, "--source", "inbox/inbody/a.png", stdin='{"weight_kg": 70}'
    )

    assert code == 0, err
    assert json.loads(out)["processed"] == ["inbox/inbody/processed/a-3.png"]
    processed = _inbox(root) / "processed"
    assert (processed / "a.png").read_bytes() == b"first"
    assert (processed / "a-2.png").read_bytes() == b"second"
    assert (processed / "a-3.png").read_bytes() == b"new"


def test_write_refuses_processed_symlink(tmp_path: Path, root: Path, run: Run):
    _put(root, "a.png")
    outside = tmp_path / "outside"
    outside.mkdir()
    (_inbox(root) / "processed").symlink_to(outside)

    code, _, err = run(
        root, "write", DAY, "--source", "inbox/inbody/a.png", stdin='{"weight_kg": 70}'
    )

    assert code == 1
    assert "폴더가 아니다" in err
    assert list(outside.iterdir()) == []
    assert not _sidecar_path(root).exists()


def test_write_log_has_paths_and_counts_but_no_values(root: Path, run: Run):
    _put(root, "a.png")
    _put(root, "b.png")
    run(
        root,
        "write",
        DAY,
        "--source",
        "inbox/inbody/a.png",
        stdin='{"weight_kg": 70.25}',
    )
    run(
        root,
        "write",
        DAY,
        "--source",
        "inbox/inbody/b.png",
        stdin='{"weight_kg": -3.75}',
    )

    log = (root / "data" / "logs" / "body.log").read_text(encoding="utf-8")

    assert f"data/body/{DAY}.json" in log
    assert "거부: input" in log
    assert "70.25" not in log
    assert "3.75" not in log


# --- reject --------------------------------------------------------------------------------


def test_reject_moves_input_to_unreadable(root: Path, run: Run):
    source = _put(root, "c.jpg", mtime_ns=123_456)

    code, out, err = run(root, "reject", "inbox/inbody/c.jpg")

    assert code == 0, err
    assert out == "inbox/inbody/unreadable/c.jpg\n"
    moved = _inbox(root) / "unreadable" / "c.jpg"
    assert not source.exists()
    assert moved.read_bytes() == b"img"
    assert moved.stat().st_mtime_ns == 123_456
    assert _mode(moved.parent) == 0o700


def test_reject_name_collision(root: Path, run: Run):
    _put(root, "c.jpg", content=b"new")
    _put(root, "unreadable/c.jpg", content=b"old")

    code, out, _ = run(root, "reject", "inbox/inbody/c.jpg")

    assert code == 0
    assert out == "inbox/inbody/unreadable/c-2.jpg\n"
    assert (_inbox(root) / "unreadable" / "c.jpg").read_bytes() == b"old"


# --- 운영 루트 경계 -------------------------------------------------------------------------


def test_symlinked_runtime_root_uses_resolved_paths(
    tmp_path: Path, root: Path, run: Run
):
    link = tmp_path / "link"
    link.symlink_to(root)
    _put(root, "a.png")
    _put(root, "c.jpg")

    assert run(link, "pending") == (
        0,
        "inbox/inbody/a.png\ninbox/inbody/c.jpg\n",
        "",
    )
    code, out, err = run(
        link, "write", DAY, "--source", "inbox/inbody/a.png", stdin='{"weight_kg": 70}'
    )
    assert code == 0, err
    assert json.loads(out)["body_path"] == f"data/body/{DAY}.json"
    assert (
        run(link, "reject", "inbox/inbody/c.jpg")[1]
        == "inbox/inbody/unreadable/c.jpg\n"
    )


def test_body_commands_write_nothing_outside_root(tmp_path: Path, root: Path, run: Run):
    (tmp_path / "x.png").write_bytes(b"outside")
    _put(root, "a.png")
    _put(root, "b.png")
    _put(root, "c.jpg")

    def outside() -> dict[str, object]:
        return {
            key: value
            for key, value in _snapshot(tmp_path).items()
            if key != "runtime" and not key.startswith("runtime/")
        }

    before = outside()

    assert run(root, "pending")[0] == 0
    assert (
        run(root, "write", DAY, "--source", "inbox/inbody/a.png", stdin='{"bmi": 22}')[
            0
        ]
        == 0
    )
    assert (
        run(root, "write", DAY, "--source", "inbox/inbody/b.png", stdin='{"bmi": -1}')[
            0
        ]
        == 1
    )
    assert run(root, "write", DAY, "--source", "../x.png", stdin='{"bmi": 22}')[0] == 1
    assert run(root, "reject", "inbox/inbody/c.jpg")[0] == 0
    assert run(root, "reject", "../x.png")[0] == 1

    assert outside() == before


def _probe(root: Path, *argv: str, stdin: str = "") -> subprocess.CompletedProcess[str]:
    """하위 프로세스에서 소켓을 막고 명령을 실행한 뒤 로드된 모듈 중 금지 모듈을 stderr 끝줄에 쓴다."""
    probe = (
        "import socket, sys\n"
        "class Blocked(socket.socket):\n"
        "    def __init__(self, *a, **k):\n"
        "        raise OSError('소켓 차단')\n"
        "socket.socket = Blocked\n"
        "from garmin_pipeline import cli\n"
        "code = cli.main(sys.argv[1:])\n"
        "names = ('garminconnect', 'curl_cffi', 'garmin_pipeline.garmin',"
        " 'garmin_pipeline.store', 'garmin_pipeline.charts', 'sqlite3')\n"
        "print('LOADED=' + ','.join(n for n in names if n in sys.modules), file=sys.stderr)\n"
        "sys.exit(code)\n"
    )
    return subprocess.run(
        [
            sys.executable,
            "-c",
            probe,
            "body",
            *argv,
            "--config",
            str(root / "config.toml"),
        ],
        input=stdin,
        capture_output=True,
        text=True,
        check=False,
    )


def test_body_subprocess_loads_no_garmin_or_store(root: Path):
    _put(root, "a.png")
    _put(root, "c.jpg")

    pending = _probe(root, "pending")
    write = _probe(
        root,
        "write",
        "2026-01-01",
        "--source",
        "inbox/inbody/a.png",
        stdin='{"bmi": 22}',
    )
    reject = _probe(root, "reject", "inbox/inbody/c.jpg")

    for result in (pending, write, reject):
        assert result.returncode == 0, result.stderr
        assert result.stderr.splitlines()[-1] == "LOADED="
    assert pending.stdout == "inbox/inbody/a.png\ninbox/inbody/c.jpg\n"


# --- 스키마 --------------------------------------------------------------------------------


def test_schema_is_valid_draft_2020_12():
    jsonschema.Draft202012Validator.check_schema(SCHEMA)
    assert SCHEMA["$schema"] == "https://json-schema.org/draft/2020-12/schema"


def test_packaged_schema_is_the_source_file():
    assert body.load_schema() == SCHEMA


def test_measurement_key_enum_matches_measurement_properties():
    assert SCHEMA["$defs"]["measurement_key"]["enum"] == list(
        SCHEMA["$defs"]["measurement"]["properties"]
    )


def test_synthetic_samples_validate():
    measurement = jsonschema.Draft202012Validator(
        {"$defs": SCHEMA["$defs"], "$ref": "#/$defs/measurement"}
    )
    measurement.validate(json.loads(SAMPLE.read_text(encoding="utf-8")))
    jsonschema.Draft202012Validator(SCHEMA).validate(
        {
            "schema_version": 1,
            "measured_on": "2026-10-14",
            "values": {"weight_kg": 70.2, "body_fat_percent": 18.4},
            "value_mtime_ns": {
                "weight_kg": 1760400000000000000,
                "body_fat_percent": 1760400000000000000,
            },
            "source_files": ["inbox/inbody/a.png"],
        }
    )
    assert not jsonschema.Draft202012Validator(SCHEMA).is_valid(
        {**_VALID, "value_mtime_ns": {"height_cm": 1}}
    )


# --- 리뷰 보강 -----------------------------------------------------------------------------


def test_write_stores_whole_float_for_integer_key_as_int(root: Path, run: Run):
    _put(root, "a.png")

    code, _, err = run(
        root,
        "write",
        DAY,
        "--source",
        "inbox/inbody/a.png",
        stdin='{"inbody_score": 78.0, "weight_kg": 70.0}',
    )

    assert code == 0, err
    text = _sidecar_path(root).read_text(encoding="utf-8")
    doc = json.loads(text)
    assert doc["values"] == {"weight_kg": 70.0, "inbody_score": 78}
    assert type(doc["values"]["inbody_score"]) is int
    assert '"inbody_score": 78\n' in text


def test_write_case_mismatched_duplicate_source_changes_nothing(root: Path, run: Run):
    _put(root, "a.png")
    before = _snapshot(root)

    code, out, err = run(
        root,
        "write",
        DAY,
        "--source",
        "inbox/inbody/A.png",
        "--source",
        "inbox/inbody/a.png",
        stdin='{"weight_kg": 70}',
    )

    assert code == 1
    assert out == ""
    assert "파일이 없다" in err
    assert _without_logs(_snapshot(root)) == _without_logs(before)


def test_reject_refuses_unreadable_symlink(tmp_path: Path, root: Path, run: Run):
    source = _put(root, "c.jpg")
    outside = tmp_path / "outside"
    outside.mkdir()
    (_inbox(root) / "unreadable").symlink_to(outside)

    code, out, err = run(root, "reject", "inbox/inbody/c.jpg")

    assert code == 1
    assert out == ""
    assert "폴더가 아니다" in err
    assert list(outside.iterdir()) == []
    assert source.read_bytes() == b"img"


def test_write_refuses_body_dir_symlink_outside_root(
    tmp_path: Path, root: Path, run: Run
):
    source = _put(root, "a.png")
    outside = tmp_path / "outside"
    outside.mkdir()
    (root / "data").mkdir()
    (root / "data" / "body").symlink_to(outside)

    code, out, err = run(
        root, "write", DAY, "--source", "inbox/inbody/a.png", stdin='{"weight_kg": 70}'
    )

    assert code == 1
    assert out == ""
    assert "운영 루트 밖" in err
    assert list(outside.iterdir()) == []
    assert source.exists()
    assert not (_inbox(root) / "processed").exists()


def test_write_replace_failure_leaves_everything_in_place(
    root: Path, run: Run, monkeypatch: pytest.MonkeyPatch
):
    sidecar = _put_sidecar(root, _VALID)
    original = sidecar.read_bytes()
    source = _put(root, "a.png", mtime_ns=300)

    def refuse(*args: object, **kwargs: object) -> None:
        raise OSError("디스크 오류")

    monkeypatch.setattr(os, "replace", refuse)

    code, out, err = run(
        root, "write", DAY, "--source", "inbox/inbody/a.png", stdin='{"weight_kg": 71}'
    )

    assert code == 1
    assert out == ""
    assert "body write 실패" in err
    assert [p.name for p in sidecar.parent.iterdir()] == [sidecar.name]
    assert sidecar.read_bytes() == original
    assert source.exists()
    assert not (_inbox(root) / "processed").exists()
    log = (root / "data" / "logs" / "body.log").read_text(encoding="utf-8")
    assert "body write 실패: OSError" in log


def test_write_narrows_existing_body_dir_to_0700(root: Path, run: Run):
    ledger = root / "data" / "body"
    ledger.mkdir(parents=True)
    ledger.chmod(0o755)
    _put(root, "a.png")

    code, _, err = run(
        root, "write", DAY, "--source", "inbox/inbody/a.png", stdin='{"weight_kg": 70}'
    )

    assert code == 0, err
    assert _mode(ledger) == 0o700


def test_write_with_one_invalid_source_changes_nothing(root: Path, run: Run):
    _put(root, "a.png")
    before = _snapshot(root)

    code, out, err = run(
        root,
        "write",
        DAY,
        "--source",
        "inbox/inbody/a.png",
        "--source",
        "inbox/inbody/missing.png",
        stdin='{"weight_kg": 70}',
    )

    assert code == 1
    assert out == ""
    assert "파일이 없다" in err
    assert _without_logs(_snapshot(root)) == _without_logs(before)
