"""Codex 실행기: `report.CodexWriter`와 `codex_argv`(FR34·NFR3·AD-16).

실제 `codex`는 띄우지 않는다. 가짜 codex는 `#!<sys.executable>` Python 스크립트이고, 동작은 env로 정한다.
받은 argv·env 키·작업 폴더·pid·자식 pid를 기록 파일에 남기고, `-o`에 쓰고, 자식을 띄우고, SIGTERM을
무시하고, 종료 코드를 정한다. 실제 codex 실행은 `conftest.py`의 autouse fixture가 막는다.
"""

import json
import os
import signal
import sqlite3
import stat
import sys
import threading
import time
from collections.abc import Callable
from datetime import date
from pathlib import Path

import pytest

from garmin_pipeline import body, cli, config, errors, report

REASON = errors.ReportFailReason
SECRET = "섹션6-codex-비밀-문장-5a7c"
OK_OUTPUT = {
    "status": "ok",
    "report_md": f"회복 상태는 양호하다. {SECRET}",
    "summary": "회복 양호. 평소 강도.",
    "judgments": [],
    "evidence": [],
    "next_checks": [],
}
HEADING = "\n## 6. 몸상태 종합\n\n"

FAKE_CODEX = f"""#!{sys.executable}
import json, os, signal, subprocess, sys, time

argv = sys.argv[1:]
mode = os.environ.get("FAKE_CODEX_MODE", "")
if "ignore_term" in mode:
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
child = None
if "child" in mode:
    child = subprocess.Popen([sys.executable, "-c", "import time; time.sleep(60)"]).pid
record = {{
    "argv": argv,
    "env_keys": sorted(os.environ),
    "cwd": os.getcwd(),
    "pid": os.getpid(),
    "pgid": os.getpgid(0),
    "child": child,
    "stdin": sys.stdin.read(),
}}
with open(os.environ["FAKE_CODEX_RECORD"], "w", encoding="utf-8") as file:
    json.dump(record, file)
with open(os.environ["FAKE_CODEX_RECORD"] + ".jsonl", "a", encoding="utf-8") as file:
    file.write(json.dumps(record) + "\\n")
if os.environ.get("FAKE_CODEX_USAGE"):
    print(json.dumps({{"type":"item.completed","item":{{"text":"private health event"}}}}))
    print(json.dumps({{"type":"turn.completed","usage":{{"input_tokens":12,"cached_input_tokens":4,"output_tokens":6}}}}))
output = os.environ.get("FAKE_CODEX_OUTPUT")
if output is not None:
    with open(argv[argv.index("-o") + 1], "w", encoding="utf-8") as file:
        file.write(output)
if "sleep" in mode:
    time.sleep(60)
sys.exit(int(os.environ.get("FAKE_CODEX_EXIT", "0")))
"""


# --- fixture ------------------------------------------------------------------------------


@pytest.fixture
def write_cfg(write_config: Callable[..., Path]) -> Callable[..., config.Config]:
    def make(**overrides: object) -> config.Config:
        values: dict[str, object] = {
            "report_wait_minutes": 0,
            "lock_wait_seconds": 0,
            "report_model": "test-model",
        }
        return config.load(write_config(**(values | overrides)))

    return make


@pytest.fixture
def cfg(write_cfg: Callable[..., config.Config]) -> config.Config:
    return write_cfg()


@pytest.fixture
def record_path(tmp_path: Path) -> Path:
    return tmp_path / "fake-codex-record.json"


@pytest.fixture
def fake_codex(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch, record_path: Path
) -> Callable[..., str]:
    """가짜 codex를 쓰고 env를 정한다. 돌려주는 함수는 실행 파일 경로를 준다."""
    directory = tmp_path / "fake-bin"
    directory.mkdir()
    script = directory / "codex"
    script.write_text(FAKE_CODEX, encoding="utf-8")
    script.chmod(0o755)
    monkeypatch.setenv("FAKE_CODEX_RECORD", str(record_path))

    def configure(
        output: object = OK_OUTPUT, mode: str = "", exit_code: int = 0
    ) -> str:
        if output is None:
            monkeypatch.delenv("FAKE_CODEX_OUTPUT", raising=False)
        else:
            text = output if isinstance(output, str) else json.dumps(output)
            monkeypatch.setenv("FAKE_CODEX_OUTPUT", text)
        monkeypatch.setenv("FAKE_CODEX_MODE", mode)
        monkeypatch.setenv("FAKE_CODEX_EXIT", str(exit_code))
        return str(script)

    return configure


def _record(path: Path) -> dict[str, object]:
    return json.loads(path.read_text(encoding="utf-8"))


def _gone(pid: int, seconds: float = 5.0) -> bool:
    """`pid`가 `seconds` 안에 사라지면 참(`os.kill(pid, 0)`이 `ProcessLookupError`)."""
    deadline = time.monotonic() + seconds
    while True:
        try:
            os.kill(pid, 0)
        except ProcessLookupError:
            return True
        except PermissionError:
            return False
        if time.monotonic() > deadline:
            return False
        time.sleep(0.05)


def _codex_dirs(cfg: config.Config) -> list[str]:
    if not cfg.data_dir.exists():
        return []
    return [name for name in os.listdir(cfg.data_dir) if name.startswith(".codex-")]


def _fail(
    cfg: config.Config, writer: report.CodexWriter, inputs: list[str] | None = None
) -> report.WriterFailed:
    with pytest.raises(report.WriterFailed) as caught:
        writer.write(cfg, inputs or [])
    return caught.value


# --- 실제 codex 차단 ------------------------------------------------------------------------


def test_real_codex_is_blocked_by_default(cfg: config.Config):
    assert report.CODEX_EXECUTABLE != "codex"
    assert not Path(report.CODEX_EXECUTABLE).exists()

    failure = _fail(cfg, report.CodexWriter())

    assert failure.reason is REASON.CODEX_FAILED


def test_unpatched_executable_is_codex_on_path():
    """autouse 차단이 없으면 `codex`를 PATH로 찾는다(모듈 원문으로 확인)."""
    source = Path(report.__file__).read_text(encoding="utf-8")

    assert '\nCODEX_EXECUTABLE = "codex"\n' in source


def test_default_writer_is_codex_writer(cfg: config.Config):
    writer = report.default_writer(cfg)

    assert isinstance(writer, report.CodexWriter)
    assert writer.executable is None
    assert writer.timeout_seconds is None


# --- argv·프롬프트 --------------------------------------------------------------------------


def test_argv_with_images(cfg: config.Config, tmp_path: Path):
    inputs = ["inbox/inbody/a.png", "inbox/inbody/b.jpg", "inbox/inbody/m.md"]
    images = report.codex_images(inputs)
    schema = tmp_path / "schema.json"
    output = tmp_path / "out.json"

    argv = report.codex_argv(cfg, schema, output, images, "codex", intake=True)

    assert images == ["inbox/inbody/a.png", "inbox/inbody/b.jpg"]
    prompt = report.codex_prompt(images, intake=True)
    assert argv == [
        "codex",
        "exec",
        "-C",
        str(tmp_path),
        "-s",
        "workspace-write",
        "--skip-git-repo-check",
        "--ephemeral",
        "--json",
        "-c",
        "project_root_markers=[]",
        "-c",
        "model_reasoning_effort=high",
        "-m",
        "test-model",
        "--output-schema",
        str(schema),
        "-o",
        str(output),
        prompt,
        "-i",
        "inbox/inbody/a.png",
        "inbox/inbody/b.jpg",
    ]
    assert prompt.splitlines()[0] == "$garmin-body-intake"
    assert prompt == (
        "$garmin-body-intake\n"
        "\n"
        "첨부 이미지(첨부 순서, 운영 루트 기준 경로):\n"
        "1. inbox/inbody/a.png\n"
        "2. inbox/inbody/b.jpg"
    )


def test_argv_has_no_forbidden_arguments(cfg: config.Config, tmp_path: Path):
    argv = report.codex_argv(
        cfg, tmp_path / "s.json", tmp_path / "o.json", ["a.png"], "/bin/codex"
    )

    assert argv[0] == "/bin/codex"
    joined = " ".join(argv)
    assert "network_access" not in joined
    assert "--dangerously-bypass-approvals-and-sandbox" not in argv
    assert "-a" not in argv
    assert "--ignore-user-config" not in argv


@pytest.mark.parametrize("inputs", [["inbox/inbody/m.md"], []])
def test_argv_without_images(cfg: config.Config, tmp_path: Path, inputs: list[str]):
    images = report.codex_images(inputs)
    argv = report.codex_argv(cfg, tmp_path / "s.json", tmp_path / "o.json", images)

    assert images == []
    assert "-i" not in argv
    assert argv[-1] == report.codex_prompt([])
    assert argv[-1].splitlines() == [
        "$garmin-daily-analysis",
        "",
        "입력 폴더(운영 루트 기준 경로):",
    ]


def test_images_ignore_case_and_keep_order():
    inputs = [
        "inbox/inbody/c.JPEG",
        "inbox/inbody/x.heic",
        "inbox/inbody/a.Png",
        "inbox/inbody/w.webp",
        "inbox/inbody/n.txt",
        "inbox/inbody/b.jpg",
        "inbox/inbody/p.pdf",
    ]

    assert report.codex_images(inputs) == [
        "inbox/inbody/c.JPEG",
        "inbox/inbody/a.Png",
        "inbox/inbody/b.jpg",
    ]


# --- 실행 ------------------------------------------------------------------------------------


def test_success_returns_daily_analysis_and_cleans_up(
    cfg: config.Config,
    fake_codex: Callable[..., str],
    record_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    monkeypatch.setenv("CODEX_API_KEY", "ck-test")
    monkeypatch.setenv("FAKE_KEEP", "1")
    writer = report.CodexWriter(fake_codex())
    inputs = ["data/report-input/2026-10-18"]

    result = writer.write(cfg, inputs)

    assert result == report.DailyAnalysis(
        "ok", OK_OUTPUT["report_md"], OK_OUTPUT["summary"]
    )
    seen = _record(record_path)
    argv = seen["argv"]
    assert isinstance(argv, list)
    output = Path(argv[argv.index("-o") + 1])
    schema = Path(argv[argv.index("--output-schema") + 1])
    assert argv[argv.index("-C") + 1] == str(body.runtime_root(cfg))
    assert argv[argv.index("-m") + 1] == "test-model"
    assert "-i" not in argv
    assert argv[-1] == report.codex_prompt(inputs)
    assert output.parent.parent == cfg.data_dir
    assert output.parent.name.startswith(".codex-")
    assert schema.name == "daily_analysis_output.schema.json"
    assert Path(seen["cwd"]).resolve() == body.runtime_root(cfg).resolve()
    assert seen["pgid"] == seen["pid"]  # 새 세션(프로세스 그룹)의 리더
    assert seen["stdin"] == ""
    env_keys = seen["env_keys"]
    assert isinstance(env_keys, list)
    assert "OPENAI_API_KEY" not in env_keys
    assert "CODEX_API_KEY" not in env_keys
    assert "FAKE_KEEP" in env_keys
    assert not output.parent.exists()
    assert _codex_dirs(cfg) == []


def test_temporary_dir_is_private(
    cfg: config.Config, fake_codex: Callable[..., str], monkeypatch: pytest.MonkeyPatch
):
    modes: list[int] = []
    real_read = report._read_output

    def spy(output: Path, schema_path: Path) -> report.DailyAnalysis:
        modes.append(stat.S_IMODE(output.parent.stat().st_mode))
        return real_read(output, schema_path)

    monkeypatch.setattr(report, "_read_output", spy)

    report.CodexWriter(fake_codex()).write(cfg, [])

    assert modes == [0o700]


@pytest.mark.parametrize("status", ["ok", "failed"])
def test_returns_any_schema_status(
    cfg: config.Config, fake_codex: Callable[..., str], status: str
):
    output = {
        "status": status,
        "report_md": "짧은 문장",
        "summary": "",
        "judgments": [],
        "evidence": [],
        "next_checks": [],
    }

    result = report.CodexWriter(fake_codex(output)).write(cfg, [])

    assert result == report.DailyAnalysis(status, "짧은 문장")


def test_executable_defaults_to_module_constant(
    cfg: config.Config, fake_codex: Callable[..., str], monkeypatch: pytest.MonkeyPatch
):
    monkeypatch.setattr(report, "CODEX_EXECUTABLE", fake_codex())

    result = report.CodexWriter().write(cfg, [])

    assert result.status == "ok"


def test_timeout_ends_whole_group(
    cfg: config.Config, fake_codex: Callable[..., str], record_path: Path
):
    writer = report.CodexWriter(fake_codex(mode="child sleep"), timeout_seconds=1.5)

    failure = _fail(cfg, writer)

    assert failure.reason is REASON.CODEX_TIMEOUT
    seen = _record(record_path)
    assert isinstance(seen["pid"], int) and isinstance(seen["child"], int)
    assert _gone(seen["pid"])
    assert _gone(seen["child"])
    assert _codex_dirs(cfg) == []


def test_timeout_kills_after_grace_when_sigterm_ignored(
    cfg: config.Config,
    fake_codex: Callable[..., str],
    record_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setattr(report, "KILL_GRACE_SECONDS", 0.5)
    sent: list[signal.Signals] = []
    real_killpg = os.killpg

    def spy(pgid: int, signum: signal.Signals) -> None:
        sent.append(signum)
        real_killpg(pgid, signum)

    monkeypatch.setattr(report.os, "killpg", spy)
    writer = report.CodexWriter(
        fake_codex(mode="ignore_term child sleep"), timeout_seconds=1.5
    )

    failure = _fail(cfg, writer)

    assert failure.reason is REASON.CODEX_TIMEOUT
    assert sent == [signal.SIGTERM, signal.SIGKILL]
    seen = _record(record_path)
    assert isinstance(seen["pid"], int) and isinstance(seen["child"], int)
    assert _gone(seen["pid"])
    assert _gone(seen["child"])


def test_leftover_child_is_ended_after_normal_exit(
    cfg: config.Config, fake_codex: Callable[..., str], record_path: Path
):
    result = report.CodexWriter(fake_codex(mode="child")).write(cfg, [])

    assert result.status == "ok"
    child = _record(record_path)["child"]
    assert isinstance(child, int)
    assert _gone(child)


def test_group_is_ended_when_wait_raises(
    cfg: config.Config,
    fake_codex: Callable[..., str],
    record_path: Path,
    monkeypatch: pytest.MonkeyPatch,
):
    real_wait = report.subprocess.Popen.wait
    calls = [0]

    def interrupted_wait(self: object, timeout: float | None = None) -> int:
        calls[0] += 1
        if calls[0] == 1:
            # 가짜 codex가 기록을 남길 때까지 기다린 뒤 끊는다.
            deadline = time.monotonic() + 10
            while not record_path.exists() and time.monotonic() < deadline:
                time.sleep(0.05)
            raise RuntimeError("wait 중단")
        return real_wait(self, timeout)  # type: ignore[arg-type]

    monkeypatch.setattr(report.subprocess.Popen, "wait", interrupted_wait)
    writer = report.CodexWriter(fake_codex(mode="child sleep"))

    with pytest.raises(RuntimeError):
        writer.write(cfg, [])

    seen = _record(record_path)
    assert isinstance(seen["pid"], int) and isinstance(seen["child"], int)
    assert _gone(seen["pid"])
    assert _gone(seen["child"])
    assert _codex_dirs(cfg) == []


def test_sigterm_to_report_ends_group_and_cleans_up(
    cfg: config.Config, fake_codex: Callable[..., str], record_path: Path
):
    def sentinel(signum: int, frame: object) -> None:
        pass

    original = signal.signal(signal.SIGTERM, sentinel)
    try:
        timer = threading.Timer(1.0, os.kill, (os.getpid(), signal.SIGTERM))
        # 핸들러가 없으면 SIGTERM이 무시되고(sentinel) 10초 뒤 codex_timeout으로 실패한다.
        writer = report.CodexWriter(fake_codex(mode="child sleep"), timeout_seconds=10)
        timer.start()
        try:
            with pytest.raises(SystemExit) as caught:
                writer.write(cfg, [])
        finally:
            timer.cancel()
        assert signal.getsignal(signal.SIGTERM) is sentinel
    finally:
        signal.signal(signal.SIGTERM, original)

    assert caught.value.code == 128 + signal.SIGTERM
    seen = _record(record_path)
    assert isinstance(seen["pid"], int) and isinstance(seen["child"], int)
    assert _gone(seen["pid"])
    assert _gone(seen["child"])
    assert _codex_dirs(cfg) == []


def test_sigterm_handler_is_restored_after_normal_run(
    cfg: config.Config, fake_codex: Callable[..., str]
):
    before = signal.getsignal(signal.SIGTERM)

    report.CodexWriter(fake_codex()).write(cfg, [])

    assert signal.getsignal(signal.SIGTERM) is before


def test_default_timeout_is_config_minutes(
    write_cfg: Callable[..., config.Config],
    fake_codex: Callable[..., str],
    monkeypatch: pytest.MonkeyPatch,
):
    cfg = write_cfg(report_codex_timeout_minutes=1)
    real_wait = report.subprocess.Popen.wait
    timeouts: list[float | None] = []

    def recording_wait(self: object, timeout: float | None = None) -> int:
        timeouts.append(timeout)
        return real_wait(self, timeout)  # type: ignore[arg-type]

    monkeypatch.setattr(report.subprocess.Popen, "wait", recording_wait)

    report.CodexWriter(fake_codex()).write(cfg, [])

    assert timeouts[0] == 60


def test_model_is_stripped(
    write_cfg: Callable[..., config.Config],
    fake_codex: Callable[..., str],
    record_path: Path,
    tmp_path: Path,
):
    cfg = write_cfg(report_model="  test-model \t")

    argv = report.codex_argv(cfg, tmp_path / "s.json", tmp_path / "o.json", [])
    report.CodexWriter(fake_codex()).write(cfg, [])

    assert argv[argv.index("-m") + 1] == "test-model"
    recorded = _record(record_path)["argv"]
    assert isinstance(recorded, list)
    assert recorded[recorded.index("-m") + 1] == "test-model"


def test_nonzero_exit_is_codex_failed(
    cfg: config.Config, fake_codex: Callable[..., str]
):
    failure = _fail(cfg, report.CodexWriter(fake_codex(exit_code=3)))

    assert failure.reason is REASON.CODEX_FAILED
    assert "3" in failure.detail
    assert _codex_dirs(cfg) == []


def test_missing_executable_is_codex_failed(cfg: config.Config, tmp_path: Path):
    failure = _fail(cfg, report.CodexWriter(str(tmp_path / "없는-codex")))

    assert failure.reason is REASON.CODEX_FAILED
    assert _codex_dirs(cfg) == []


@pytest.mark.parametrize("model", [None, "", "   "])
def test_missing_model_does_not_launch(
    write_cfg: Callable[..., config.Config],
    fake_codex: Callable[..., str],
    record_path: Path,
    model: str | None,
):
    cfg = write_cfg(report_model=model)

    failure = _fail(cfg, report.CodexWriter(fake_codex()))

    assert failure.reason is REASON.CODEX_FAILED
    assert failure.detail == "report_model 미설정"
    assert not record_path.exists()


@pytest.mark.parametrize(
    "output",
    [
        pytest.param(None, id="no-file"),
        pytest.param(f"not json {SECRET}", id="not-json"),
        pytest.param({**OK_OUTPUT, "extra": SECRET}, id="extra-key"),
        pytest.param(
            {"status": f"great-{SECRET}", "report_md": "x", "summary": ""}, id="enum"
        ),
        pytest.param({"status": "ok"}, id="missing-key"),
        pytest.param({"status": "ok", "report_md": 7, "summary": ""}, id="not-string"),
        pytest.param([SECRET], id="not-object"),
        pytest.param(
            {"status": "ok", "report_md": " \n\t ", "summary": ""}, id="blank"
        ),
    ],
)
def test_bad_output_is_output_invalid(
    cfg: config.Config, fake_codex: Callable[..., str], output: object
):
    failure = _fail(cfg, report.CodexWriter(fake_codex(output)))

    assert failure.reason is REASON.OUTPUT_INVALID
    assert failure.detail
    assert SECRET not in failure.detail
    assert SECRET not in str(failure)
    assert "great" not in failure.detail
    assert _codex_dirs(cfg) == []


def test_log_has_no_output_values(
    cfg: config.Config,
    fake_codex: Callable[..., str],
    caplog: pytest.LogCaptureFixture,
):
    caplog.set_level("DEBUG", logger="garmin_pipeline.report")

    report.CodexWriter(fake_codex()).write(cfg, [])
    _fail(cfg, report.CodexWriter(fake_codex({**OK_OUTPUT, "extra": SECRET})))

    assert "codex 끝" in caplog.text
    assert SECRET not in caplog.text


# --- CLI ------------------------------------------------------------------------------------


def _only_report(cfg: config.Config) -> Path:
    names = sorted(os.listdir(cfg.reports_dir))
    assert len(names) == 1, names
    (name,) = names
    date.fromisoformat(name.removesuffix(".md"))
    return cfg.reports_dir / name


def _notifications(cfg: config.Config) -> list[tuple[str, str, str]]:
    if not cfg.db_path.exists():
        return []
    conn = sqlite3.connect(cfg.db_path)
    try:
        return conn.execute(
            "SELECT local_date, event, detail FROM notification ORDER BY rowid"
        ).fetchall()
    finally:
        conn.close()


def test_cli_report_uses_codex_writer(
    cfg: config.Config,
    fake_codex: Callable[..., str],
    monkeypatch: pytest.MonkeyPatch,
):
    monkeypatch.setattr(report, "CODEX_EXECUTABLE", fake_codex())
    monkeypatch.setattr(report, "_sleep", lambda seconds: pytest.fail("대기함"))

    assert cli.main(["report", "--config", str(cfg.path)]) == 0

    path = _only_report(cfg)
    content = path.read_text(encoding="utf-8")
    assert content.startswith(OK_OUTPUT["report_md"])
    assert "\n## 그래프\n" in content
    folder = cfg.data_dir / "report-input" / path.stem
    assert (folder / "manifest.json").is_file()
    assert (folder / "digest.json").is_file()
    assert _notifications(cfg) == []
    assert _codex_dirs(cfg) == []
    log = (cfg.data_dir / "logs" / "report.log").read_text(encoding="utf-8")
    assert "codex 끝" in log
    assert SECRET not in log


@pytest.mark.parametrize(
    ("output", "exit_code", "reason"),
    [
        pytest.param(OK_OUTPUT, 3, "codex_failed", id="exit-3"),
        pytest.param(f"not json {SECRET}", 0, "output_invalid", id="invalid-output"),
    ],
)
def test_cli_report_codex_failure_falls_back(
    cfg: config.Config,
    fake_codex: Callable[..., str],
    monkeypatch: pytest.MonkeyPatch,
    output: object,
    exit_code: int,
    reason: str,
):
    monkeypatch.setattr(
        report, "CODEX_EXECUTABLE", fake_codex(output, exit_code=exit_code)
    )
    monkeypatch.setattr(report, "_sleep", lambda seconds: pytest.fail("대기함"))

    assert cli.main(["report", "--config", str(cfg.path)]) == 0

    path = _only_report(cfg)
    content = path.read_text(encoding="utf-8")
    assert report.FALLBACK_MARKER in content
    assert f"(`{reason}`)." in content
    assert SECRET not in content
    assert _notifications(cfg) == [
        (
            path.name.removesuffix(".md"),
            "report_failed",
            reason + " scopes=day,7d,30d,all",
        )
    ]
    assert _codex_dirs(cfg) == []
    log = (cfg.data_dir / "logs" / "report.log").read_text(encoding="utf-8")
    assert reason in log
    assert SECRET not in log


def test_samples_is_absent_from_codex_argv_and_prompt(cfg, tmp_path):
    inputs = ["inbox/inbody/a.png", "data/body/2026-10-18.json"]
    images = report.codex_images(inputs)
    argv = report.codex_argv(
        cfg, tmp_path / "schema.json", tmp_path / "out.json", images, "codex"
    )
    assert images == ["inbox/inbody/a.png"]
    assert all(".samples.json" not in arg for arg in argv)
    assert ".samples.json" not in report.codex_prompt(images)


@pytest.mark.parametrize("summary", [None, 3, "\ud800"])
def test_read_output_rejects_invalid_summary(tmp_path, summary):
    output = tmp_path / "output.json"
    output.write_text(json.dumps(OK_OUTPUT | {"summary": summary}), encoding="utf-8")
    schema = Path(report.__file__).parent / "schemas" / report.REPORT_OUTPUT_SCHEMA
    with pytest.raises(report.WriterFailed) as failure:
        report._read_output(output, schema)
    assert failure.value.reason == REASON.OUTPUT_INVALID


def test_read_output_accepts_blank_summary(tmp_path):
    output = tmp_path / "output.json"
    output.write_text(json.dumps(OK_OUTPUT | {"summary": " \t "}), encoding="utf-8")
    schema = Path(report.__file__).parent / "schemas" / report.REPORT_OUTPUT_SCHEMA
    assert report._read_output(output, schema).summary == " \t "


def test_intake_uses_own_schema_prompt_and_ordered_image_attachments(
    cfg, fake_codex, record_path
):
    writer = report.CodexWriter(fake_codex({"status": "ok", "detail": "done"}))
    inputs = ["inbox/inbody/b.jpg", "inbox/inbody/a.png", "inbox/inbody/note.txt"]
    assert writer.intake(cfg, inputs) == {"status": "ok", "detail": "done"}
    argv = _record(record_path)["argv"]
    assert (
        Path(argv[argv.index("--output-schema") + 1]).name
        == "body_intake_output.schema.json"
    )
    assert argv[-3:] == ["-i", "inbox/inbody/b.jpg", "inbox/inbody/a.png"]
    assert argv[-4].startswith("$garmin-body-intake")
    assert "1. inbox/inbody/b.jpg" in argv[-4]
    assert "2. inbox/inbody/a.png" in argv[-4]
    assert "note.txt" not in argv[-4]
    assert "model_reasoning_effort=high" in argv


def test_usage_events_are_private_and_four_scopes_have_json_prompts_and_metrics(
    cfg, fake_codex, monkeypatch, record_path, caplog
):
    import logging

    monkeypatch.setattr(report, "CODEX_EXECUTABLE", fake_codex())
    monkeypatch.setenv("FAKE_CODEX_USAGE", "1")
    with caplog.at_level(logging.INFO):
        assert report.run(cfg, report.CodexWriter()) == 0
    records = [
        json.loads(line)
        for line in Path(str(record_path) + ".jsonl").read_text().splitlines()
    ]
    assert len(records) == 4
    prompts = [r["argv"][r["argv"].index("-o") + 2] for r in records]
    assert [p.splitlines()[0] for p in prompts] == [
        "$garmin-daily-analysis",
        "$garmin-period-review 7d",
        "$garmin-period-review 30d",
        "$garmin-period-review all",
    ]
    assert all("--json" in r["argv"] for r in records)
    assert "period/30d" in prompts[2] and "profile.md" in prompts[2]
    for scope in ["day", "7d", "30d", "all"]:
        assert f"report session scope={scope}" in caplog.text
    assert "input_tokens=12 cached_input_tokens=4 output_tokens=6" in caplog.text
    assert "input_tokens=48 cached_input_tokens=16 output_tokens=24" in caplog.text
    assert "private health event" not in caplog.text
    assert SECRET not in caplog.text
    assert not _codex_dirs(cfg)
