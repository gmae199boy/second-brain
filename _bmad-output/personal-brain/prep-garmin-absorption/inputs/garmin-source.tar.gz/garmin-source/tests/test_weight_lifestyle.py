"""Weight and lifestyle collection, shared daily measurements, and late-entry refresh."""

import json
from datetime import date, timedelta
from pathlib import Path

import pytest

from garmin_pipeline import (
    collect,
    config,
    coverage,
    digest,
    normalize,
    rawparse,
    store,
)

FIXTURES = Path(__file__).parent / "fixtures"
NEW_ENDPOINTS = ("daily_weigh_ins", "lifestyle_logging_data")
DAY = date(2026, 10, 15)
STAMP = 1_800_000_000_000


def fixture(endpoint, day="2026-10-14"):
    return json.loads((FIXTURES / endpoint / f"{day}.json").read_text())


def put(conn, day, endpoint, payload, now=STAMP):
    store.upsert_raw(
        conn,
        scope="day",
        key=str(day),
        endpoint=endpoint,
        payload=payload,
        library_version="test",
        now_ms=now,
    )


def stats(day, count):
    return {
        "completionStats": [
            {"calendarDate": str(day), "completedTracking": count, "totalTracking": 3}
        ]
    }


@pytest.fixture
def cfg(write_config):
    return config.load(write_config(lock_wait_seconds=0))


@pytest.mark.parametrize(
    "count,rechecked,offset,expected",
    [
        (3, False, 1, False),
        (0, False, 1, True),
        (3, True, 1, True),
        (3, False, 7, True),
    ],
)
@pytest.mark.parametrize("previous_null", [False, True])
def test_completion_stats_refresh_only_affected_lifestyle(
    cfg, count, rechecked, offset, expected, previous_null
):
    day = DAY - timedelta(days=offset)
    with store.write_session(cfg) as conn:
        put(
            conn,
            day,
            "lifestyle_logging_data",
            None if previous_null else stats(day, 0),
        )
        put(conn, day, "daily_weigh_ins", fixture("daily_weigh_ins"))
        put(conn, DAY, "lifestyle_logging_data", stats(day, count), STAMP + 10)
        # A later null must not hide the latest actual report, even outside the queried range.
        put(conn, DAY + timedelta(days=1), "lifestyle_logging_data", None, STAMP + 20)
        if rechecked:
            put(
                conn,
                day,
                "lifestyle_logging_data",
                None if previous_null else stats(day, 0),
                STAMP + 30,
            )
        items = coverage.items(conn, cfg, day, day)
        lifestyle = next(
            item for item in items if item.endpoint == "lifestyle_logging_data"
        )
        assert lifestyle.fresh is expected
        assert coverage.incomplete(lifestyle) is (not expected)
        assert next(item for item in items if item.endpoint == "daily_weigh_ins").fresh


def test_no_lifestyle_reference_is_fresh(cfg):
    with store.write_session(cfg) as conn:
        put(conn, DAY, "lifestyle_logging_data", None)
        assert all(item.fresh for item in coverage.items(conn, cfg, DAY, DAY))


@pytest.mark.parametrize("malformed_first", [False, True])
def test_malformed_previous_lifestyle_keeps_other_date_stale(
    cfg, caplog, malformed_first
):
    valid_day = DAY - timedelta(days=1)
    malformed_day = DAY - timedelta(days=2)
    reference_stats = [
        stats(valid_day, 3)["completionStats"][0],
        stats(malformed_day, 3)["completionStats"][0],
    ]
    if malformed_first:
        reference_stats.reverse()
    with store.write_session(cfg) as conn:
        put(conn, valid_day, "lifestyle_logging_data", stats(valid_day, 0))
        put(conn, malformed_day, "lifestyle_logging_data", {"completionStats": {}})
        put(
            conn,
            DAY,
            "lifestyle_logging_data",
            {"completionStats": reference_stats},
            STAMP + 10,
        )
        items = coverage.items(conn, cfg, malformed_day, valid_day)
        lifestyle = {
            item.key: item for item in items if item.endpoint == "lifestyle_logging_data"
        }
        assert not lifestyle[str(valid_day)].fresh
        assert coverage.incomplete(lifestyle[str(valid_day)])
        assert lifestyle[str(malformed_day)].fresh
    assert f"생활 습관 원문 형식 오류(key={malformed_day})" in caplog.text


def test_completion_stats_parser_is_pure_and_ignores_other_habits():
    assert rawparse.completion_stats(json.dumps(stats(DAY, 3))) == {str(DAY): 3}
    assert rawparse.completion_stats("null") == {}
    assert rawparse.completion_stats("{}") == {}
    with pytest.raises(rawparse.RawParseError):
        rawparse.completion_stats('{"completionStats": {}}')


def test_daily_weight_drinks_match_digest_and_incremental_normalize(cfg):
    days = {
        "2026-10-14": {endpoint: fixture(endpoint) for endpoint in NEW_ENDPOINTS},
        "2026-10-15": {
            endpoint: fixture(endpoint, "2026-10-15") for endpoint in NEW_ENDPOINTS
        },
    }
    manifest = {
        "report_date": str(DAY),
        "yesterday": "2026-10-14",
        "baseline_days": ["2026-10-14"],
        "data_cutoff": "2026-10-15T11:00:00+09:00",
        "workouts": [],
    }
    doc = digest.build(manifest, days, {}, {}, [])
    assert doc["weight"] == {
        "days": [
            {"date": "2026-10-14", "fetched": True, "weight_kg": 80.8},
            {"date": str(DAY), "fetched": True, "weight_kg": None},
        ],
        "avg_7d_kg": 80.8,
        "avg_7d_days": 1,
    }
    with store.write_session(cfg) as conn:
        for day, endpoints in days.items():
            for endpoint, payload in endpoints.items():
                put(conn, day, endpoint, payload)
        assert normalize.run(conn) == (4, 0)
        rows = conn.execute(
            "SELECT date, weight_kg, drinks_json FROM day_summary ORDER BY date"
        ).fetchall()
        for day, weight, drinks in rows:
            daily = digest.day_values(day, days[day], {}, {}, "Asia/Seoul")[
                "day_summary"
            ]
            assert weight == daily["weight_kg"]
            assert drinks == daily["drinks_json"]
        assert (
            json.loads(rows[0][2])
            == doc["drinks_last_8_days"][0]["logged"]
            == [{"item": "Alcohol", "kind": "BEER", "amount": 7}]
        )
        assert rows[1][2] == "[]"
        assert normalize.run(conn) == (0, 0)
        changed = fixture("daily_weigh_ins")
        changed["dateWeightList"][-1]["weight"] = 79000
        put(conn, "2026-10-14", "daily_weigh_ins", changed, STAMP + 10)
        assert normalize.run(conn) == (1, 0)
        assert conn.execute(
            "SELECT weight_kg FROM day_summary WHERE date='2026-10-14'"
        ).fetchone() == (79.0,)


@pytest.mark.parametrize("lifestyle_state", ["missing", "null"])
def test_missing_lifestyle_drinks_stay_null_with_weight(cfg, lifestyle_state):
    day = "2026-10-14"
    day_raw = {"daily_weigh_ins": fixture("daily_weigh_ins", day)}
    if lifestyle_state == "null":
        day_raw["lifestyle_logging_data"] = None

    daily = digest.day_values(day, day_raw, {}, {}, "Asia/Seoul")["day_summary"]
    assert daily["drinks_json"] is None
    assert daily["weight_kg"] == 80.8

    with store.write_session(cfg) as conn:
        for endpoint, payload in day_raw.items():
            put(conn, day, endpoint, payload)
        assert conn.execute(
            "SELECT raw FROM raw_response WHERE scope='day' AND key=?"
            " AND endpoint='lifestyle_logging_data'",
            (day,),
        ).fetchone() == (None if lifestyle_state == "missing" else ("null",))

        assert normalize.run(conn) == (len(day_raw), 0)
        row = conn.execute(
            "SELECT drinks_json, weight_kg FROM day_summary WHERE date=?", (day,)
        ).fetchone()
        assert row is not None
        assert row[0] is None
        assert row[1] == 80.8


@pytest.mark.parametrize(
    "shape", [None, {"dateWeightList": []}, {"dateWeightList": {"bad": 1}}]
)
def test_missing_empty_and_malformed_weight(shape):
    day = str(DAY)
    manifest = {
        "report_date": day,
        "yesterday": "2026-10-14",
        "baseline_days": [],
        "data_cutoff": "2026-10-15T11:00:00+09:00",
        "workouts": [],
    }
    out = digest.build(manifest, {day: {"daily_weigh_ins": shape}}, {}, {}, [])
    assert out["weight"]["days"][0] == {
        "date": day,
        "fetched": shape is not None,
        "weight_kg": None,
    }
    assert out["weight"]["avg_7d_kg"] is None
    assert out["drinks_last_8_days"] == [{"date": day, "fetched": False}]
    if shape and isinstance(shape["dateWeightList"], dict):
        assert any("weight_for" in note for note in out["notes"])


def test_weight_average_includes_today_and_excludes_eighth_day():
    baseline = [(DAY - timedelta(days=n)).isoformat() for n in range(7, 0, -1)]
    days = {
        day: {
            "daily_weigh_ins": {"dateWeightList": [{"date": STAMP, "weight": weight}]}
        }
        for day, weight in [
            (baseline[0], 100000),
            (baseline[1], 80000),
            (str(DAY), 82000),
        ]
    }
    manifest = {
        "report_date": str(DAY),
        "yesterday": baseline[-1],
        "baseline_days": baseline,
        "data_cutoff": "2026-10-15T11:00:00+09:00",
        "workouts": [],
    }
    weight = digest.build(manifest, days, {}, {}, [])["weight"]
    assert len(weight["days"]) == 8
    assert (weight["avg_7d_kg"], weight["avg_7d_days"]) == (81, 2)


@pytest.mark.parametrize("day", ["2026-10-14", "2026-10-15"])
def test_real_lifestyle_normalize_preserves_loaded_amount(cfg, day):
    path = FIXTURES / "garmin" / "lifestyle_logging_data" / f"{day}.json"
    if not path.exists():
        pytest.skip("local Garmin response unavailable")
    payload = json.loads(path.read_text())
    with store.write_session(cfg) as conn:
        put(conn, day, "lifestyle_logging_data", payload)
        assert normalize.run(conn) == (1, 0)
        logged = json.loads(
            conn.execute(
                "SELECT drinks_json FROM day_summary WHERE date=?", (day,)
            ).fetchone()[0]
        )
    alcohol = next(
        item for item in payload["dailyLogsReport"] if item["name"] == "Alcohol"
    )
    assert logged == [
        {"item": "Alcohol", "kind": detail["subTypeName"], "amount": detail["amount"]}
        for detail in alcohol["details"]
    ]


def test_collect_plan_refreshes_only_lifestyle_when_counts_changed(cfg):
    previous = DAY - timedelta(days=1)
    with store.write_session(cfg) as conn:
        for endpoint in coverage.DAY_ENDPOINTS:
            put(conn, previous, endpoint, None)
        put(conn, previous, "lifestyle_logging_data", stats(previous, 0))
        put(conn, DAY, "lifestyle_logging_data", stats(previous, 3), STAMP + 10)
        assert collect._plan(conn, cfg, previous, previous, lambda item: False) == [
            (previous, ["lifestyle_logging_data"])
        ]
        put(conn, previous, "lifestyle_logging_data", stats(previous, 0), STAMP + 20)
        assert collect._plan(conn, cfg, previous, previous, lambda item: False) == []


@pytest.mark.parametrize(
    "invalid_row",
    [{"timestampGMT": stamp, "weight": 90000} for stamp in ("", {}, 1e100)]
    + [None, [], "malformed"],
)
@pytest.mark.parametrize("invalid_first", [False, True])
def test_invalid_weight_entry_preserves_other_measurements(invalid_row, invalid_first):
    day = str(DAY)
    rows = [
        {"timestampGMT": "2026-10-15T01:00:00", "weight": 80000},
        invalid_row,
    ]
    if invalid_first:
        rows.reverse()
    raw = {"daily_weigh_ins": {"dateWeightList": rows}}
    daily = digest.day_values(day, raw, {}, {}, "Asia/Seoul")
    assert daily["day_summary"]["weight_kg"] == 80
    manifest = {
        "report_date": day,
        "yesterday": "2026-10-14",
        "baseline_days": [],
        "data_cutoff": "2026-10-15T11:00:00+09:00",
        "workouts": [],
    }
    out = digest.build(manifest, {day: raw}, {}, {}, [])
    assert out["weight"] == {
        "days": [{"date": day, "fetched": True, "weight_kg": 80}],
        "avg_7d_kg": 80,
        "avg_7d_days": 1,
    }
    assert "weight_for: 원본 모양이 다르다" in out["notes"]
