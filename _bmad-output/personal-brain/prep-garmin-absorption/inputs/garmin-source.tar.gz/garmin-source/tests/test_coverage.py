"""실행 기록·실패 기록(마이그레이션 `0003_run_fetch_error`)과 커버리지 판정(`coverage`)(FR8·16·20).

모두 패키지의 실제 마이그레이션 위에서 `write_session`으로 돈다. 원문은 `store.upsert_raw`로,
`run`·`fetch_error`는 SQL로 넣는다.
"""

import json
import logging
import re
import sqlite3
from collections.abc import Callable
from datetime import date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest
import schema_version

from garmin_pipeline import config, coverage, errors, garmin, store

SEOUL = ZoneInfo("Asia/Seoul")
D = date(2026, 10, 16)
D_PREV = date(2026, 10, 15)
D_NEXT = date(2026, 10, 17)
V1 = "0.3.17"
SECRET = "수면메모-비밀"
BASE_ENDPOINTS = coverage.ACTIVITY_ENDPOINTS[:3]
"""세트가 없는 활동이 내는 3종(세트 상세 `activity_exercise_sets` 제외)."""


def _ms(year: int, month: int, day: int, hour: int, minute: int) -> int:
    """config 기본 시간대(Asia/Seoul) 로컬 시각의 UTC epoch ms."""
    return int(
        datetime(year, month, day, hour, minute, tzinfo=SEOUL).timestamp() * 1000
    )


# 키 D 다음 날 정오(로컬)에 확인했다: day-scope D 항목은 확정이다.
T_FINAL = _ms(2026, 10, 17, 12, 0)
# 키 D 당일 저녁(로컬)에 확인했다: 아직 확정이 아니다.
T_SAME_DAY = _ms(2026, 10, 16, 20, 0)


@pytest.fixture
def cfg(write_config: Callable[..., Path]) -> config.Config:
    return config.load(write_config(lock_wait_seconds=0))


def _upsert(
    conn: sqlite3.Connection,
    scope: str,
    key: str,
    endpoint: str,
    payload: object,
    now_ms: int = T_FINAL,
) -> None:
    store.upsert_raw(
        conn,
        scope=scope,
        key=key,
        endpoint=endpoint,
        payload=payload,
        library_version=V1,
        now_ms=now_ms,
    )


def _upsert_raw_text(
    conn: sqlite3.Connection, key: str, raw: str, now_ms: int = T_FINAL
) -> None:
    """`upsert_raw`가 만들 수 없는 형식 오류 원문을 활동 목록에 직접 넣는다."""
    conn.execute(
        "INSERT INTO raw_response"
        " (scope, key, endpoint, raw, fetched_at, checked_at, library_version)"
        " VALUES ('day', ?, 'activities_by_date', ?, ?, ?, ?)",
        (key, raw, now_ms, now_ms, V1),
    )


def _run(
    conn: sqlite3.Connection,
    local_date: str = D.isoformat(),
    started_at: int = T_SAME_DAY,
    status: str = "success",
    detail: str = "",
    finished_at: int | None = T_SAME_DAY + 1,
) -> int:
    cursor = conn.execute(
        "INSERT INTO run (local_date, started_at, finished_at, status, detail)"
        " VALUES (?, ?, ?, ?, ?)",
        (local_date, started_at, finished_at, status, detail),
    )
    assert cursor.lastrowid is not None
    return cursor.lastrowid


def _fetch_error(
    conn: sqlite3.Connection,
    run_id: int,
    *,
    scope: str = "day",
    key: str = D.isoformat(),
    endpoint: str = "sleep_data",
    kind: str = "transient",
    local_date: str = D.isoformat(),
    occurred_at: int = T_SAME_DAY,
    error_code: str = "e",
) -> None:
    conn.execute(
        "INSERT INTO fetch_error"
        " (run_id, scope, key, endpoint, kind, local_date, occurred_at, error_code)"
        " VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (run_id, scope, key, endpoint, kind, local_date, occurred_at, error_code),
    )


def _activity(activity_id: int, start_local: str) -> dict[str, object]:
    return {"activityId": activity_id, "startTimeLocal": start_local, "메모": SECRET}


def _by_endpoint(
    items: list[coverage.CoverageItem], scope: str = "day", key: str = D.isoformat()
) -> dict[str, coverage.CoverageItem]:
    return {i.endpoint: i for i in items if i.scope == scope and i.key == key}


def _check_values(sql: str, column: str) -> set[str]:
    match = re.search(
        rf"{column} TEXT NOT NULL CHECK \({column} IN \((.*?)\)\)", sql, re.DOTALL
    )
    assert match is not None, sql
    return set(re.findall(r"'([a-z0-9_]+)'", match[1]))


def _table_sql(conn: sqlite3.Connection, name: str) -> str:
    row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type = 'table' AND name = ?", (name,)
    ).fetchone()
    assert row is not None
    return row[0]


# ---- 고정 사항 ----


def test_endpoint_tuples_match_garmin_adapter():
    assert coverage.DAY_ENDPOINTS == garmin.DAY_ENDPOINTS
    assert coverage.ACTIVITY_ENDPOINTS == garmin.ACTIVITY_ENDPOINTS


def test_public_vocabulary():
    assert [s.value for s in coverage.CoverageState] == [
        "data",
        "empty",
        "failed",
        "missing",
    ]
    assert [k.value for k in coverage.FetchErrorKind] == ["transient", "rejected"]
    assert coverage.NOT_RUN == "not_run"
    assert coverage.NOT_RUN not in set(errors.RunStatus)
    assert coverage.CoverageItem._fields == (
        "scope",
        "key",
        "endpoint",
        "day_key",
        "state",
        "final",
        "checked_at",
        "plannable",
        "fresh",
    )
    assert coverage.DayStatus._fields == ("status", "detail", "finished_at")


def test_migration_creates_run_and_fetch_error(cfg: config.Config):
    with store.write_session(cfg) as conn:
        run_columns = conn.execute("PRAGMA table_info(run)").fetchall()
        error_columns = conn.execute("PRAGMA table_info(fetch_error)").fetchall()
        run_sql = _table_sql(conn, "run")
        error_sql = _table_sql(conn, "fetch_error")
        foreign_keys = conn.execute("PRAGMA foreign_key_list(fetch_error)").fetchall()
        indexes = {
            name: [c[2] for c in conn.execute(f"PRAGMA index_info({name})")]
            for (name,) in conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'index'"
                " AND tbl_name IN ('run', 'fetch_error')"
            )
        }

    def shape(columns: list[tuple]) -> list[tuple]:
        return [
            (name, kind, notnull, default, pk)
            for _, name, kind, notnull, default, pk in columns
        ]

    assert shape(run_columns) == [
        ("id", "INTEGER", 0, None, 1),
        ("local_date", "TEXT", 1, None, 0),
        ("started_at", "INTEGER", 1, None, 0),
        ("finished_at", "INTEGER", 0, None, 0),
        ("status", "TEXT", 1, None, 0),
        ("detail", "TEXT", 1, "''", 0),
    ]
    assert shape(error_columns) == [
        ("id", "INTEGER", 0, None, 1),
        ("run_id", "INTEGER", 1, None, 0),
        ("scope", "TEXT", 1, None, 0),
        ("key", "TEXT", 1, None, 0),
        ("endpoint", "TEXT", 1, None, 0),
        ("kind", "TEXT", 1, None, 0),
        ("local_date", "TEXT", 1, None, 0),
        ("occurred_at", "INTEGER", 1, None, 0),
        ("error_code", "TEXT", 1, None, 0),
    ]
    assert _check_values(run_sql, "status") == set(errors.RunStatus)
    assert _check_values(error_sql, "kind") == set(coverage.FetchErrorKind)
    assert _check_values(error_sql, "scope") == {"day", "activity"}
    assert [(table, src, dst) for _, _, table, src, dst, *_ in foreign_keys] == [
        ("run", "run_id", "id")
    ]
    assert sorted(indexes.values()) == [["local_date"], ["scope", "key", "endpoint"]]


def test_write_connection_enforces_foreign_keys_read_connection_unchanged(
    cfg: config.Config,
):
    with store.write_session(cfg) as conn:
        assert conn.execute("PRAGMA foreign_keys").fetchone() == (1,)
        with pytest.raises(sqlite3.IntegrityError):
            _fetch_error(conn, run_id=999)
        assert conn.execute("SELECT COUNT(*) FROM fetch_error").fetchone() == (0,)
        _fetch_error(conn, _run(conn))

    reader = store.read_connection(cfg)
    try:
        assert reader.execute("PRAGMA foreign_keys").fetchone() == (0,)
        assert reader.execute("SELECT COUNT(*) FROM fetch_error").fetchone() == (1,)
    finally:
        reader.close()


def test_every_run_status_is_accepted_and_others_are_rejected(cfg: config.Config):
    with store.write_session(cfg) as conn:
        for status in errors.RunStatus:
            _run(conn, status=status.value)
        with pytest.raises(sqlite3.IntegrityError):
            _run(conn, status="done")
        run_id = _run(conn)
        with pytest.raises(sqlite3.IntegrityError):
            _fetch_error(conn, run_id, kind="fatal")
        with pytest.raises(sqlite3.IntegrityError):
            _fetch_error(conn, run_id, scope="week")
        # running 동안은 finished_at이 NULL이고 detail 기본값은 빈 문자열이다.
        conn.execute(
            "INSERT INTO run (local_date, started_at, status) VALUES (?, ?, 'running')",
            (D.isoformat(), T_SAME_DAY),
        )
        row = conn.execute(
            "SELECT finished_at, detail FROM run WHERE status = 'running' ORDER BY id DESC"
        ).fetchone()

    assert row == (None, "")


def test_version_2_db_migrates_to_latest_and_keeps_rows(cfg: config.Config):
    # 2.1까지의 DB: 0001·0002만 적용되고 auth_event·raw_response 행이 있다.
    migrations = Path(store.__file__).parent / "migrations"
    cfg.data_dir.mkdir(parents=True)
    conn = sqlite3.connect(cfg.db_path)
    try:
        for name in ("0001_auth_event.sql", "0002_raw_response.sql"):
            conn.executescript((migrations / name).read_text(encoding="utf-8"))
        conn.execute("INSERT INTO auth_event VALUES (1, '2026-10-15', ?)", (T_FINAL,))
        conn.execute(
            "INSERT INTO raw_response VALUES ('day', ?, 'sleep_data', '{}', ?, ?, ?)",
            (D.isoformat(), T_FINAL, T_FINAL, V1),
        )
        conn.execute("PRAGMA user_version = 2")
        conn.commit()
    finally:
        conn.close()

    with store.write_session(cfg) as conn:
        assert conn.execute("PRAGMA user_version").fetchone() == (
            schema_version.LATEST,
        )
        assert conn.execute("SELECT COUNT(*) FROM run").fetchone() == (0,)

    reader = store.read_connection(cfg)
    try:
        assert reader.execute("PRAGMA user_version").fetchone() == (
            schema_version.LATEST,
        )
        assert reader.execute("SELECT * FROM auth_event").fetchall() == [
            (1, "2026-10-15", T_FINAL)
        ]
        assert reader.execute("SELECT * FROM raw_response").fetchall() == [
            ("day", D.isoformat(), "sleep_data", "{}", T_FINAL, T_FINAL, V1)
        ]
        assert _by_endpoint(coverage.items(reader, cfg, D, D))["sleep_data"].state == (
            coverage.CoverageState.DATA
        )
    finally:
        reader.close()


# ---- items ----


def test_empty_db_one_day_is_all_missing(cfg: config.Config):
    with store.write_session(cfg) as conn:
        result = coverage.items(conn, cfg, D, D)

    key = D.isoformat()
    assert result == [
        coverage.CoverageItem(
            "day",
            key,
            endpoint,
            key,
            coverage.CoverageState.MISSING,
            False,
            None,
            True,
            True,
        )
        for endpoint in coverage.DAY_ENDPOINTS
    ]


def test_start_after_end_is_value_error(cfg: config.Config):
    with store.write_session(cfg) as conn, pytest.raises(ValueError):
        coverage.items(conn, cfg, D_NEXT, D)


def test_data_and_empty_use_raw_checked_at(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(conn, "day", D.isoformat(), "sleep_data", {"a": 1}, T_SAME_DAY)
        _upsert(conn, "day", D.isoformat(), "hrv_data", None, T_FINAL)
        by_endpoint = _by_endpoint(coverage.items(conn, cfg, D, D))

    sleep, hrv = by_endpoint["sleep_data"], by_endpoint["hrv_data"]
    assert (sleep.state, sleep.checked_at, sleep.final) == (
        coverage.CoverageState.DATA,
        T_SAME_DAY,
        False,
    )
    assert (hrv.state, hrv.checked_at, hrv.final) == (
        coverage.CoverageState.EMPTY,
        T_FINAL,
        True,
    )


def test_failure_without_raw_is_failed(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _fetch_error(conn, _run(conn), endpoint="stress_data")
        stress = _by_endpoint(coverage.items(conn, cfg, D, D))["stress_data"]

    assert stress.state == coverage.CoverageState.FAILED
    assert stress.checked_at is None
    assert stress.final is False
    assert stress.plannable is True


def test_raw_wins_over_failure(cfg: config.Config):
    with store.write_session(cfg) as conn:
        run_id = _run(conn)
        _fetch_error(conn, run_id, endpoint="sleep_data", kind="rejected")
        _fetch_error(conn, run_id, endpoint="hrv_data")
        _upsert(conn, "day", D.isoformat(), "sleep_data", {"a": 1})
        _upsert(conn, "day", D.isoformat(), "hrv_data", None)
        by_endpoint = _by_endpoint(coverage.items(conn, cfg, D, D))

    assert by_endpoint["sleep_data"].state == coverage.CoverageState.DATA
    assert by_endpoint["sleep_data"].checked_at == T_FINAL
    assert by_endpoint["hrv_data"].state == coverage.CoverageState.EMPTY


@pytest.mark.parametrize(
    ("checked_at", "final"),
    [
        # 로컬 D 23:59와 D+1 00:00은 UTC로는 둘 다 10월 16일이다.
        pytest.param(_ms(2026, 10, 16, 23, 59), False, id="local-D-23:59"),
        pytest.param(_ms(2026, 10, 17, 0, 0), True, id="local-D+1-00:00"),
    ],
)
def test_final_boundary_uses_config_timezone(
    cfg: config.Config, checked_at: int, final: bool
):
    assert datetime.fromtimestamp(checked_at / 1000, tz=ZoneInfo("UTC")).date() == D
    with store.write_session(cfg) as conn:
        _upsert(conn, "day", D.isoformat(), "sleep_data", {"a": 1}, checked_at)
        _upsert(conn, "day", D.isoformat(), "activities_by_date", [], checked_at)
        _upsert(
            conn,
            "day",
            D_PREV.isoformat(),
            "activities_by_date",
            [_activity(7, "2026-10-16 08:00:00")],
            checked_at,
        )
        _upsert(conn, "activity", "7", "activity", {"id": 7}, checked_at)
        result = coverage.items(conn, cfg, D, D)

    assert _by_endpoint(result)["sleep_data"].final is final
    assert _by_endpoint(result)["activities_by_date"].final is final
    # activity-scope도 활동의 일 키(D)와 같은 규칙이다.
    assert _by_endpoint(result, "activity", "7")["activity"].final is final


def test_activities_from_neighbouring_lists_land_on_their_day(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(
            conn,
            "day",
            D_PREV.isoformat(),
            "activities_by_date",
            [
                _activity(10, "2026-10-15 07:00:00"),  # D-1: 범위 밖
                _activity(20, "2026-10-16 00:10:00"),  # D-1 목록의 D 활동
                _activity(
                    30, "2026-10-16 06:00:00"
                ),  # D 목록에도 나온다: 여기 것이 먼저
            ],
        )
        _upsert(
            conn,
            "day",
            D.isoformat(),
            "activities_by_date",
            [
                _activity(40, "2026-10-16 23:50:00"),  # D 23:50 시작
                _activity(30, "2026-10-17 06:00:00"),  # 같은 id: D-1 목록 것을 쓴다
            ],
        )
        _upsert(
            conn,
            "day",
            D_NEXT.isoformat(),
            "activities_by_date",
            [
                _activity(50, "2026-10-16 22:00:00"),  # 범위 밖 key의 D 활동
                _activity(40, "2026-10-16 23:50:00"),  # 이미 나온 id: 한 번만 낸다
            ],
        )
        result = coverage.items(conn, cfg, D, D)

    key = D.isoformat()
    assert [(i.scope, i.key, i.endpoint) for i in result] == [
        *(("day", key, endpoint) for endpoint in coverage.DAY_ENDPOINTS),
        *(
            ("activity", activity_id, endpoint)
            for activity_id in ("20", "30", "40", "50")
            for endpoint in BASE_ENDPOINTS
        ),
    ]
    assert {i.day_key for i in result} == {key}
    assert all(
        i.state == coverage.CoverageState.MISSING
        for i in result
        if i.scope == "activity"
    )


def test_first_listing_wins_even_when_out_of_range(cfg: config.Config):
    # id 70은 D-1 목록에 D-1 활동으로 먼저 나오고, D 목록에 D 활동으로 다시 나온다.
    with store.write_session(cfg) as conn:
        _upsert(
            conn,
            "day",
            D_PREV.isoformat(),
            "activities_by_date",
            [_activity(70, "2026-10-15 09:00:00")],
        )
        _upsert(
            conn,
            "day",
            D.isoformat(),
            "activities_by_date",
            [_activity(70, "2026-10-16 09:00:00")],
        )
        on_d = coverage.items(conn, cfg, D, D)
        on_prev = coverage.items(conn, cfg, D_PREV, D_PREV)

    assert [i for i in on_d if i.scope == "activity"] == []
    assert [
        (i.key, i.endpoint, i.day_key) for i in on_prev if i.scope == "activity"
    ] == [("70", endpoint, D_PREV.isoformat()) for endpoint in BASE_ENDPOINTS]


def test_multi_day_order(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(
            conn,
            "day",
            D_PREV.isoformat(),
            "activities_by_date",
            [
                _activity(2, "2026-10-16 09:00:00"),
                _activity(1, "2026-10-15 09:00:00"),
            ],
        )
        result = coverage.items(conn, cfg, D_PREV, D_NEXT)

    def block(day: date, *activity_ids: str) -> list[tuple[str, str, str]]:
        key = day.isoformat()
        return [
            *(("day", key, endpoint) for endpoint in coverage.DAY_ENDPOINTS),
            *(
                ("activity", activity_id, endpoint)
                for activity_id in activity_ids
                for endpoint in BASE_ENDPOINTS
            ),
        ]

    assert [(i.scope, i.key, i.endpoint) for i in result] == [
        *block(D_PREV, "1"),
        *block(D, "2"),
        *block(D_NEXT),
    ]


def test_activity_null_raw_is_empty_and_covered(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(
            conn,
            "day",
            D.isoformat(),
            "activities_by_date",
            [_activity(5, "2026-10-16 10:00:00")],
        )
        _upsert(conn, "activity", "5", "activity", None)
        _upsert(conn, "activity", "5", "activity_details", {"x": 1})
        by_endpoint = _by_endpoint(coverage.items(conn, cfg, D, D), "activity", "5")

    assert by_endpoint["activity"].state == coverage.CoverageState.EMPTY
    assert by_endpoint["activity"].final is True
    assert by_endpoint["activity_details"].state == coverage.CoverageState.DATA
    assert by_endpoint["activity_hr_in_timezones"].state == (
        coverage.CoverageState.MISSING
    )


def test_rejected_on_max_distinct_days_is_not_plannable(cfg: config.Config):
    assert cfg.max_rejected_attempts == 3
    with store.write_session(cfg) as conn:
        _upsert(
            conn,
            "day",
            D.isoformat(),
            "activities_by_date",
            [_activity(5, "2026-10-16 10:00:00")],
        )
        for local_date in ("2026-10-16", "2026-10-17", "2026-10-18"):
            run_id = _run(conn, local_date=local_date)
            _fetch_error(conn, run_id, kind="rejected", local_date=local_date)
            _fetch_error(
                conn,
                run_id,
                scope="activity",
                key="5",
                endpoint="activity_details",
                kind="rejected",
                local_date=local_date,
            )
        result = coverage.items(conn, cfg, D, D)

    for item in (
        _by_endpoint(result)["sleep_data"],
        _by_endpoint(result, "activity", "5")["activity_details"],
    ):
        assert item.state == coverage.CoverageState.FAILED
        assert item.plannable is False
    assert _by_endpoint(result)["hrv_data"].plannable is True


def test_repeated_rejections_on_one_day_stay_plannable(cfg: config.Config):
    with store.write_session(cfg) as conn:
        run_id = _run(conn)
        for _ in range(3):
            _fetch_error(conn, run_id, kind="rejected")
        # transient는 날이 달라도 세지 않는다.
        for local_date in ("2026-10-17", "2026-10-18", "2026-10-19"):
            _fetch_error(conn, run_id, kind="transient", local_date=local_date)
        # 서로 다른 날 두 번(한도 3 미만)도 아직 계획한다.
        for local_date in ("2026-10-16", "2026-10-17"):
            _fetch_error(
                conn,
                run_id,
                endpoint="hrv_data",
                kind="rejected",
                local_date=local_date,
            )
        by_endpoint = _by_endpoint(coverage.items(conn, cfg, D, D))

    assert by_endpoint["sleep_data"].state == coverage.CoverageState.FAILED
    assert by_endpoint["sleep_data"].plannable is True
    assert by_endpoint["hrv_data"].plannable is True


def test_max_rejected_attempts_comes_from_config(write_config: Callable[..., Path]):
    cfg = config.load(write_config(lock_wait_seconds=0, max_rejected_attempts=1))
    with store.write_session(cfg) as conn:
        _fetch_error(conn, _run(conn), kind="rejected")
        sleep = _by_endpoint(coverage.items(conn, cfg, D, D))["sleep_data"]

    assert sleep.plannable is False


def test_malformed_activity_list_is_not_final_and_logged_without_content(
    cfg: config.Config, caplog: pytest.LogCaptureFixture
):
    broken = json.dumps({"activityId": 1, "메모": SECRET}, ensure_ascii=False)
    with store.write_session(cfg) as conn:
        _upsert_raw_text(conn, D.isoformat(), broken)
        _upsert(
            conn,
            "day",
            D_PREV.isoformat(),
            "activities_by_date",
            [_activity(9, "2026-10-15 09:00:00")],
        )
        _upsert(conn, "day", D.isoformat(), "sleep_data", {"a": 1})
        with caplog.at_level(logging.WARNING, logger="garmin_pipeline.coverage"):
            result = coverage.items(conn, cfg, D_PREV, D)

    listing = _by_endpoint(result)["activities_by_date"]
    assert listing.state == coverage.CoverageState.DATA
    assert listing.checked_at == T_FINAL
    assert listing.final is False
    assert _by_endpoint(result)["sleep_data"].final is True
    # 다른 날 목록은 그대로 읽힌다.
    assert _by_endpoint(result, key=D_PREV.isoformat())["activities_by_date"].final
    assert {i.key for i in result if i.scope == "activity"} == {"9"}
    records = [r for r in caplog.records if r.name == "garmin_pipeline.coverage"]
    assert len(records) == 1
    assert records[0].levelno == logging.WARNING
    assert D.isoformat() in records[0].getMessage()
    assert SECRET not in caplog.text


def test_lists_after_a_malformed_list_are_still_read(cfg: config.Config):
    # 형식이 틀린 목록(D_PREV)이 key 오름차순으로 먼저 읽혀도 뒤 목록(D, D_NEXT)의 활동은 그대로 나온다.
    with store.write_session(cfg) as conn:
        _upsert_raw_text(conn, D_PREV.isoformat(), '{"activityId": 1}')
        _upsert(
            conn,
            "day",
            D.isoformat(),
            "activities_by_date",
            [_activity(9, "2026-10-16 09:00:00")],
        )
        _upsert(
            conn,
            "day",
            D_NEXT.isoformat(),
            "activities_by_date",
            [_activity(11, "2026-10-17 07:00:00")],
        )
        result = coverage.items(conn, cfg, D_PREV, D_NEXT)

    activities = [
        (i.key, i.endpoint, i.day_key) for i in result if i.scope == "activity"
    ]
    assert activities == [
        *[("9", endpoint, D.isoformat()) for endpoint in BASE_ENDPOINTS],
        *[("11", endpoint, D_NEXT.isoformat()) for endpoint in BASE_ENDPOINTS],
    ]
    assert (
        _by_endpoint(result, key=D_PREV.isoformat())["activities_by_date"].final
        is False
    )


def test_items_reads_only(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(
            conn,
            "day",
            D.isoformat(),
            "activities_by_date",
            [_activity(5, "2026-10-16 10:00:00")],
        )
        _fetch_error(conn, _run(conn), endpoint="hrv_data")
        before = conn.total_changes
        written = coverage.items(conn, cfg, D, D)
        coverage.day_status(conn, D)
        assert conn.total_changes == before
        assert not conn.in_transaction

    reader = store.read_connection(cfg)
    try:
        assert coverage.items(reader, cfg, D, D) == written
    finally:
        reader.close()


# ---- 세트 상세(activity_exercise_sets)와 fresh ----

SETS = "activity_exercise_sets"


def _strength(
    activity_id: int, start_local: str, total_sets: int = 19
) -> dict[str, object]:
    return {**_activity(activity_id, start_local), "totalSets": total_sets}


def _activity_endpoints(
    items: list[coverage.CoverageItem],
) -> list[tuple[str, str]]:
    return [(i.key, i.endpoint) for i in items if i.scope == "activity"]


def test_sets_item_only_for_activities_that_need_sets(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(
            conn,
            "day",
            D.isoformat(),
            "activities_by_date",
            [
                _strength(1, "2026-10-16 07:00:00"),
                _activity(2, "2026-10-16 08:00:00"),  # 두 키 없음
                {
                    **_activity(3, "2026-10-16 09:00:00"),
                    "totalSets": None,
                    "summarizedExerciseSets": None,
                },
                {
                    **_activity(4, "2026-10-16 10:00:00"),
                    "totalSets": 0,
                    "summarizedExerciseSets": [],
                },
                {
                    **_activity(5, "2026-10-16 11:00:00"),
                    "summarizedExerciseSets": [{"category": "SQUAT"}],
                },
            ],
        )
        result = coverage.items(conn, cfg, D, D)

    assert _activity_endpoints(result) == [
        *(("1", endpoint) for endpoint in coverage.ACTIVITY_ENDPOINTS),
        *(
            (activity_id, endpoint)
            for activity_id in ("2", "3", "4")
            for endpoint in BASE_ENDPOINTS
        ),
        *(("5", endpoint) for endpoint in coverage.ACTIVITY_ENDPOINTS),
    ]
    assert coverage.ACTIVITY_ENDPOINTS[-1] == SETS
    sets = _by_endpoint(result, "activity", "1")[SETS]
    assert (sets.state, sets.day_key, sets.fresh, sets.plannable) == (
        coverage.CoverageState.MISSING,
        D.isoformat(),
        True,
        True,
    )


@pytest.mark.parametrize(
    ("owning", "later", "has_sets"),
    [
        (
            _activity(1, "2026-10-16 07:00:00"),
            _strength(1, "2026-10-16 07:00:00"),
            False,
        ),
        (
            _strength(1, "2026-10-16 07:00:00"),
            _activity(1, "2026-10-16 07:00:00"),
            True,
        ),
    ],
    ids=["owning-without-sets", "owning-with-sets"],
)
def test_needs_sets_comes_from_the_owning_list(
    cfg: config.Config,
    owning: dict[str, object],
    later: dict[str, object],
    has_sets: bool,
):
    # id 1을 처음 낸 목록(D_PREV, key 오름차순)의 항목 값만 본다. 뒤 목록(D)의 값은 쓰지 않는다.
    with store.write_session(cfg) as conn:
        _upsert(conn, "day", D_PREV.isoformat(), "activities_by_date", [owning])
        _upsert(conn, "day", D.isoformat(), "activities_by_date", [later])
        result = coverage.items(conn, cfg, D, D)

    expected = coverage.ACTIVITY_ENDPOINTS if has_sets else BASE_ENDPOINTS
    assert _activity_endpoints(result) == [("1", endpoint) for endpoint in expected]


def test_malformed_sets_field_breaks_the_whole_list(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(
            conn,
            "day",
            D.isoformat(),
            "activities_by_date",
            [
                _strength(1, "2026-10-16 07:00:00"),
                {**_activity(2, "2026-10-16 08:00:00"), "totalSets": "4"},
            ],
        )
        result = coverage.items(conn, cfg, D, D)

    assert _activity_endpoints(result) == []
    assert _by_endpoint(result)["activities_by_date"].final is False


@pytest.mark.parametrize(
    ("sets_checked_at", "fresh"),
    [(T_SAME_DAY - 1, False), (T_SAME_DAY, True), (T_SAME_DAY + 1, True)],
    ids=["before-list", "same-time", "after-list"],
)
def test_sets_fresh_compares_checked_at_with_list_fetched_at(
    cfg: config.Config, sets_checked_at: int, fresh: bool
):
    with store.write_session(cfg) as conn:
        listing = [_strength(1, "2026-10-16 07:00:00")]
        _upsert(conn, "day", D.isoformat(), "activities_by_date", listing, T_SAME_DAY)
        # 같은 내용을 나중에 다시 받아도 fetched_at은 그대로다(checked_at만 바뀐다).
        _upsert(conn, "day", D.isoformat(), "activities_by_date", listing, T_FINAL)
        for endpoint in coverage.ACTIVITY_ENDPOINTS:
            _upsert(conn, "activity", "1", endpoint, {"x": 1}, sets_checked_at)
        result = coverage.items(conn, cfg, D, D)

    by_endpoint = _by_endpoint(result, "activity", "1")
    sets = by_endpoint[SETS]
    assert sets.fresh is fresh
    # fresh는 state를 바꾸지 않는다.
    assert sets.state == coverage.CoverageState.DATA
    assert sets.checked_at == sets_checked_at
    # 다른 endpoint는 원문이 목록보다 앞서도 늘 fresh다.
    for endpoint in BASE_ENDPOINTS:
        assert by_endpoint[endpoint].fresh is True
    assert all(i.fresh for i in result if i.scope == "day")


def test_changed_list_makes_sets_stale(cfg: config.Config):
    # 앱에서 세트를 고치면 목록 원문이 바뀌어 fetched_at이 세트 checked_at보다 뒤가 된다.
    with store.write_session(cfg) as conn:
        _upsert(
            conn,
            "day",
            D.isoformat(),
            "activities_by_date",
            [_strength(1, "2026-10-16 07:00:00")],
            T_SAME_DAY,
        )
        _upsert(conn, "activity", "1", SETS, {"exerciseSets": []}, T_SAME_DAY + 1)
        _upsert(
            conn,
            "day",
            D.isoformat(),
            "activities_by_date",
            [_strength(1, "2026-10-16 07:00:00", total_sets=20)],
            T_FINAL,
        )
        sets = _by_endpoint(coverage.items(conn, cfg, D, D), "activity", "1")[SETS]

    assert (sets.state, sets.fresh) == (coverage.CoverageState.DATA, False)
    assert coverage.incomplete(sets) is True


def test_sets_fresh_uses_the_owning_list(cfg: config.Config):
    # id 1을 처음 낸 목록(D_PREV)이 소속 목록이다. 뒤 목록(D)이 바뀌어도 세트는 fresh다.
    with store.write_session(cfg) as conn:
        _upsert(
            conn,
            "day",
            D_PREV.isoformat(),
            "activities_by_date",
            [_strength(1, "2026-10-16 07:00:00")],
            T_SAME_DAY,
        )
        _upsert(conn, "activity", "1", SETS, {"exerciseSets": []}, T_SAME_DAY + 1)
        _upsert(
            conn,
            "day",
            D.isoformat(),
            "activities_by_date",
            [_activity(1, "2026-10-16 07:00:00")],
            T_FINAL,
        )
        sets = _by_endpoint(coverage.items(conn, cfg, D, D), "activity", "1")[SETS]

    assert sets.fresh is True


def _item(
    scope: str = "day",
    state: coverage.CoverageState = coverage.CoverageState.DATA,
    *,
    final: bool = True,
    plannable: bool = True,
    fresh: bool = True,
) -> coverage.CoverageItem:
    endpoint = "sleep_data" if scope == "day" else SETS
    key = D.isoformat() if scope == "day" else "1"
    return coverage.CoverageItem(
        scope, key, endpoint, D.isoformat(), state, final, 1, plannable, fresh
    )


@pytest.mark.parametrize(
    ("item", "expected"),
    [
        # plannable이 아니면 상태와 상관없이 완료다.
        (_item(state=coverage.CoverageState.MISSING, plannable=False), False),
        (_item("activity", coverage.CoverageState.FAILED, plannable=False), False),
        (_item("activity", fresh=False, plannable=False), False),
        # data·empty가 아니면 미완료다.
        (_item(state=coverage.CoverageState.MISSING), True),
        (_item(state=coverage.CoverageState.FAILED), True),
        (_item("activity", coverage.CoverageState.MISSING), True),
        (_item("activity", coverage.CoverageState.FAILED), True),
        # day-scope는 final이고 fresh여야 완료다.
        (_item(final=True), False),
        (_item(final=False), True),
        (_item(state=coverage.CoverageState.EMPTY, final=False), True),
        (_item(final=True, fresh=False), True),
        # activity-scope는 final과 상관없이 fresh여야 완료다.
        (_item("activity", final=False), False),
        (_item("activity", coverage.CoverageState.EMPTY, final=False), False),
        (_item("activity", final=True, fresh=False), True),
        (_item("activity", coverage.CoverageState.EMPTY, fresh=False), True),
    ],
)
def test_incomplete_rules(item: coverage.CoverageItem, expected: bool):
    assert coverage.incomplete(item) is expected


# ---- day_status ----


def test_day_status_skips_blocked_and_breaks_ties_by_rowid(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _run(conn, started_at=100, status="error", detail="first", finished_at=150)
        _run(conn, started_at=300, status="partial", detail="tie-a", finished_at=310)
        _run(conn, started_at=300, status="success", detail="tie-b", finished_at=320)
        _run(conn, started_at=900, status="skipped_blocked", detail="later")
        _run(conn, local_date=D_NEXT.isoformat(), started_at=999, status="error")
        status = coverage.day_status(conn, D)

    assert status == coverage.DayStatus(errors.RunStatus.SUCCESS, "tie-b", 320)
    assert isinstance(status.status, errors.RunStatus)


def test_day_status_running_has_no_finished_at(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _run(conn, started_at=100, status="error", finished_at=150)
        _run(conn, started_at=200, status="running", finished_at=None)
        status = coverage.day_status(conn, D)

    assert status == coverage.DayStatus(errors.RunStatus.RUNNING, "", None)


@pytest.mark.parametrize("only_blocked", [False, True], ids=["no-rows", "only-skipped"])
def test_day_status_not_run(cfg: config.Config, only_blocked: bool):
    with store.write_session(cfg) as conn:
        _run(conn, local_date=D_PREV.isoformat(), status="success")
        if only_blocked:
            _run(conn, status="skipped_blocked", detail="blocked")
        status = coverage.day_status(conn, D)

    assert status == coverage.DayStatus(coverage.NOT_RUN, "", None)


def test_day_status_prefers_other_rows_over_later_lock_timeout(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _run(conn, started_at=100, status="success", detail="", finished_at=900)
        _run(
            conn, started_at=500, status="error", detail="lock_timeout", finished_at=560
        )
        _run(
            conn,
            started_at=600,
            status="error",
            detail="lock_timeout timezone_mismatch",
            finished_at=660,
        )
        _run(conn, started_at=700, status="skipped_blocked", detail="")
        status = coverage.day_status(conn, D)

    assert status == coverage.DayStatus(errors.RunStatus.SUCCESS, "", 900)


def test_day_status_running_row_wins_over_lock_timeout(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _run(conn, started_at=100, status="running", finished_at=None)
        _run(
            conn, started_at=200, status="error", detail="lock_timeout", finished_at=210
        )
        status = coverage.day_status(conn, D)

    assert status == coverage.DayStatus(errors.RunStatus.RUNNING, "", None)


def test_day_status_uses_latest_lock_timeout_when_it_is_all_there_is(
    cfg: config.Config,
):
    with store.write_session(cfg) as conn:
        _run(
            conn, started_at=100, status="error", detail="lock_timeout", finished_at=110
        )
        _run(
            conn,
            started_at=200,
            status="error",
            detail="lock_timeout timezone_mismatch",
            finished_at=210,
        )
        _run(conn, started_at=300, status="skipped_blocked", detail="")
        status = coverage.day_status(conn, D)

    assert status == coverage.DayStatus(
        errors.RunStatus.ERROR, "lock_timeout timezone_mismatch", 210
    )


@pytest.mark.parametrize(
    "detail",
    ["session_lock_timeout", "lockXtimeout", "lock_timeoutX", "login_transient"],
)
def test_day_status_other_error_details_are_not_lock_timeout(
    cfg: config.Config, detail: str
):
    with store.write_session(cfg) as conn:
        _run(conn, started_at=100, status="success", detail="", finished_at=110)
        _run(conn, started_at=200, status="error", detail=detail, finished_at=210)
        status = coverage.day_status(conn, D)

    assert status == coverage.DayStatus(errors.RunStatus.ERROR, detail, 210)


def test_day_status_lock_timeout_detail_on_other_status_is_a_normal_row(
    cfg: config.Config,
):
    with store.write_session(cfg) as conn:
        _run(conn, started_at=100, status="success", detail="", finished_at=110)
        _run(
            conn,
            started_at=200,
            status="partial",
            detail="lock_timeout",
            finished_at=210,
        )
        status = coverage.day_status(conn, D)

    assert status == coverage.DayStatus(errors.RunStatus.PARTIAL, "lock_timeout", 210)


def test_day_status_same_started_at_lock_timeout_loses_despite_larger_rowid(
    cfg: config.Config,
):
    with store.write_session(cfg) as conn:
        _run(
            conn,
            started_at=100,
            status="partial",
            detail="transient=1",
            finished_at=150,
        )
        _run(
            conn, started_at=100, status="error", detail="lock_timeout", finished_at=110
        )
        status = coverage.day_status(conn, D)

    assert status == coverage.DayStatus(errors.RunStatus.PARTIAL, "transient=1", 150)
