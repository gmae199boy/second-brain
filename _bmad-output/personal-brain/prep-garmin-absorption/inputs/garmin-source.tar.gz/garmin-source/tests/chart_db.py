"""Synthetic raw inputs normalized through the production migrations."""

import json
from collections.abc import Callable
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from typing import Any
from zoneinfo import ZoneInfo

from garmin_pipeline import body, config, normalize, store

EXERCISE_SETS = "activity_exercise_sets"
FETCHED = 1_760_000_000_000

VERSION = "0.3.17"

D1 = "2026-10-17"

CLOCK = datetime(2026, 10, 17, 21, 0, tzinfo=UTC)

REPORT_DATE = "2026-10-18"

DROP = object()

TODAY_PARTIAL_STARTED = int(
    datetime(2026, 10, 17, 20, 0, tzinfo=UTC).timestamp() * 1000
)


def _user_summary(day: str = D1, steps: int = 8123) -> dict[str, object]:
    return {
        "calendarDate": day,
        "totalSteps": steps,
        "averageStressLevel": 40,
        "totalDistanceMeters": 6543.6,
        "activeKilocalories": 412.4,
        "moderateIntensityMinutes": 12,
        "vigorousIntensityMinutes": 3,
        "minHeartRate": 48,
        "maxHeartRate": 151,
    }


def _rhr_day(day: str = D1, entries: list[object] | None = None) -> dict[str, object]:
    if entries is None:
        entries = [{"value": 52.0, "calendarDate": day}]
    return {
        "statisticsStartDate": day,
        "allMetrics": {"metricsMap": {"WELLNESS_RESTING_HEART_RATE": entries}},
    }


SLEEP_START = int(datetime(2026, 10, 17, 13, 15, tzinfo=UTC).timestamp() * 1000)

SLEEP_END = SLEEP_START + 27000 * 1000

MINUTE_MS = 60_000

TODAY_FETCHED = TODAY_PARTIAL_STARTED + MINUTE_MS


def _sleep_data(day: str = REPORT_DATE, **dto_overrides: object) -> dict[str, object]:
    dto: dict[str, object] = {
        "calendarDate": day,
        "sleepTimeSeconds": 26100,
        "deepSleepSeconds": 5400,
        "lightSleepSeconds": 14400,
        "remSleepSeconds": 6300,
        "awakeSleepSeconds": 900,
        "sleepStartTimestampGMT": SLEEP_START,
        "sleepEndTimestampGMT": SLEEP_END,
        "sleepScores": {"overall": {"value": 82, "qualifierKey": "GOOD"}},
    }
    return {
        "dailySleepDTO": dto | dto_overrides,
        "avgOvernightHrv": 39,
        "sleepHeartRate": [{"startGMT": "2026-10-17T14:00:00", "value": 48}],
    }


def _hrv_data(day: str = REPORT_DATE, **summary_overrides: object) -> dict[str, object]:
    summary: dict[str, object] = {
        "calendarDate": day,
        "weeklyAvg": 41,
        "lastNightAvg": 38.6,
        "status": "BALANCED",
        "baseline": {"balancedLow": 35, "balancedUpper": 48.2},
    }
    return {"hrvSummary": summary | summary_overrides}


def _stress_data(day: str = REPORT_DATE) -> dict[str, object]:
    levels = [30, -1, 50, None]
    return {
        "calendarDate": day,
        "stressValueDescriptorsDTOList": [
            {"key": "timestamp", "index": 0},
            {"key": "stressLevel", "index": 1},
        ],
        "stressValuesArray": [
            [SLEEP_END + i * 3 * MINUTE_MS, level] for i, level in enumerate(levels)
        ],
    }


BB_VALUES: list[object] = [
    [SLEEP_START - 30 * MINUTE_MS, 70],
    [SLEEP_START, 20],
    [SLEEP_END - 30 * MINUTE_MS, 61],
    [SLEEP_END, None],
    [SLEEP_END + 30 * MINUTE_MS, 55],
]


def _body_battery(
    day: str = REPORT_DATE, values: list[object] | None = None
) -> list[dict[str, object]]:
    return [
        {
            "date": day,
            "charged": 45,
            "drained": 38,
            "bodyBatteryValuesArray": BB_VALUES if values is None else values,
            "bodyBatteryValueDescriptorDTOList": [
                {
                    "bodyBatteryValueDescriptorIndex": 0,
                    "bodyBatteryValueDescriptorKey": "timestamp",
                },
                {
                    "bodyBatteryValueDescriptorIndex": 1,
                    "bodyBatteryValueDescriptorKey": "bodyBatteryLevel",
                },
            ],
        }
    ]


def _readiness(day: str = REPORT_DATE, level: str = "HIGH") -> list[dict[str, object]]:
    return [
        {"timestamp": f"{day}T09:30:00.0", "score": 70, "level": "MODERATE"},
        {"timestamp": f"{day}T05:45:00.0", "score": 81.4, "level": level},
    ]


def _today_raws(
    day: str = REPORT_DATE, **payloads: object
) -> list[tuple[str, str, str, object]]:
    """`day`의 원본 6종(`sleep_data`·`hrv_data`·`rhr_day`·`stress_data`·`body_battery`·
    `training_readiness`). `payloads`로 endpoint 원문을 바꾼다."""
    raws: dict[str, object] = {
        "sleep_data": _sleep_data(day),
        "hrv_data": _hrv_data(day),
        "rhr_day": _rhr_day(day),
        "stress_data": _stress_data(day),
        "body_battery": _body_battery(day),
        "training_readiness": _readiness(day),
    } | payloads
    return [("day", day, endpoint, payload) for endpoint, payload in raws.items()]


def _put(
    cfg: config.Config,
    rows: list[tuple[str, str, str, object]],
    *,
    now_ms: int = FETCHED,
) -> None:
    with store.write_session(cfg) as conn:
        for scope, key, endpoint, payload in rows:
            store.upsert_raw(
                conn,
                scope=scope,
                key=key,
                endpoint=endpoint,
                payload=payload,
                library_version=VERSION,
                now_ms=now_ms,
            )


def _normalize(cfg: config.Config) -> normalize.Summary:
    with store.write_session(cfg) as conn:
        return normalize.run(conn)


def _set_history_start(cfg: config.Config, value: str) -> None:
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO meta (key, value) VALUES (?, ?)"
            " ON CONFLICT (key) DO UPDATE SET value = excluded.value",
            ("history_start", value),
        )


def _sidecar(day: str, values: dict[str, Any]) -> dict[str, Any]:
    """body 스키마 루트에 맞는 합성 사이드카(`body write`가 쓰는 모양)."""
    return {
        "schema_version": 1,
        "measured_on": day,
        "values": values,
        "value_mtime_ns": dict.fromkeys(values, 1_000),
        "source_files": [f"inbox/inbody/{day}.png"],
    }


def _put_sidecar(
    cfg: config.Config, day: str, values: dict[str, Any], *, name: str | None = None
) -> Path:
    """장부 폴더(없으면 만든다)에 사이드카를 쓴다. `name`이 없으면 `<day>.json`이다."""
    directory = body.body_dir(cfg)
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / (f"{day}.json" if name is None else name)
    path.write_text(json.dumps(_sidecar(day, values)), encoding="utf-8")
    return path


def _day(offset: int) -> str:
    """`REPORT_DATE` + `offset`일."""
    return (date.fromisoformat(REPORT_DATE) + timedelta(days=offset)).isoformat()


def _days_db(
    cfg: config.Config,
    offsets: list[int],
    *,
    history_start: str | None = None,
    payloads: Callable[[int, str], dict[str, object]] | None = None,
) -> None:
    """`offsets`(오늘 기준 일수)의 원본 6종을 넣어 정규화한다. `payloads(offset, day)`가 원문을 바꾸고
    `DROP`이면 그 원문을 넣지 않는다.

    `history_start`를 주지 않으면 가장 이른 날이다.
    """
    rows: list[tuple[str, str, str, object]] = []
    for offset in offsets:
        day = _day(offset)
        raws = _today_raws(day, **(payloads(offset, day) if payloads else {}))
        rows += [raw for raw in raws if raw[3] is not DROP]
    _put(cfg, rows, now_ms=TODAY_FETCHED)
    _normalize(cfg)
    _set_history_start(cfg, history_start or _day(min(offsets)))


def _hrv_avg(day: str, value: float | None) -> dict[str, object]:
    return {"hrv_data": _hrv_data(day, lastNightAvg=value)}


def _listings(
    offsets: list[int], ids: dict[int, list[int]]
) -> list[tuple[str, str, str, object]]:
    """`offsets`마다 활동 목록 원문(`ids`에 없는 날은 빈 목록이라 `empty`, 동기화 실패가 아니다)."""
    return [
        (
            "day",
            _day(offset),
            "activities_by_date",
            [
                {"activityId": i, "startTimeLocal": f"{_day(offset)} 07:30:00"}
                for i in ids.get(offset, [])
            ],
        )
        for offset in offsets
    ]


def _forty_five_days_db(cfg: config.Config) -> None:
    """45일 합성 DB(the chart tests의 손 계산 근거).

    D−i(i = 1…45): 수면 25200 + 60·i 초, 안정 심박 40 + i, HRV 40 + (i mod 5). 오늘은 수면 26100, 안정 심박 52,
    HRV 39다. 다른 지표는 날마다 같다(수면 점수 82, 기상 값 61, 스트레스 40, 준비도 81). 활동 목록은 D−45…D
    모두 받았고(활동 없는 날은 빈 목록), 활동은 아래 일곱이다(`zones`의 `None`·빠진 존은 NULL).
    체성분 사이드카는 D−40, D−20, D−3이다.

    하루 지표(5.10 후속 2): D−i(i = 0…45, 오늘 포함)의 `user_summary`는 걸음 5000 + 100·i, 활동 칼로리 300 + i,
    중강도 20·(i mod 3)분, 고강도 30·(i mod 2)분이다. 스트레스 최대(50)·Body Battery 최고 70·최저 20·충전 45·
    소모 38은 날마다 같다(`_today_raws`). 근력 세트 원문은 101(고블릿 스쿼트 12회 × 20 kg, 휴식, 10회 × 22.5 kg),
    102(푸시업 15회, 무게 없음), 104(5회 × 25 kg), 106(1회 × 40 kg, 5회 × 30 kg), 107(10회 × 20 kg)이다.
    활동끼리 2분 안에 이어진 것은 없어 세션 수는 활동 수와 같다.
    """

    def payloads(offset: int, day: str) -> dict[str, object]:
        i = -offset
        summary = {
            "user_summary": _user_summary(day, 5000 + 100 * i)
            | {
                "activeKilocalories": 300 + i,
                "moderateIntensityMinutes": 20 * (i % 3),
                "vigorousIntensityMinutes": 30 * (i % 2),
            }
        }
        if offset == 0:
            return summary
        return (
            {
                "sleep_data": _sleep_data(day, sleepTimeSeconds=25200 + 60 * i),
                "rhr_day": _rhr_day(day, [{"value": 40.0 + i, "calendarDate": day}]),
            }
            | _hrv_avg(day, 40 + i % 5)
            | summary
        )

    activities = {
        -1: [101],
        -3: [102, 103],
        -10: [104],
        -20: [105],
        -40: [106],
        0: [107],
    }
    rows = [
        *_act(
            101,
            _day(-1),
            duration=1800,
            zones={1: 120, 2: None, 3: 600, 4: 900, 5: 180},
        ),
        *_act(
            102, _day(-3), duration=2700, zones={1: 300, 2: 1200, 3: 1200, 4: 0, 5: 0}
        ),
        *_act(103, _day(-3), "18:00", duration=None),
        *_act(104, _day(-10), duration=3600, zones={1: 600, 2: 1800, 3: 1200}),
        *_act(105, _day(-20), duration=1200),
        *_act(
            106,
            _day(-40),
            duration=5400,
            zones={1: 1000, 2: 2000, 3: 1500, 4: 700, 5: 200},
        ),
        *_act(107, REPORT_DATE, "05:00", duration=1500, zones={1: 500, 2: 1000}),
        _sets_raw(101, [_goblet(12, 20000.0), _rest(60.0), _goblet(10, 22500.0)]),
        _sets_raw(102, [_gym_set("PUSH_UP", "PUSH_UP", reps=15, weight=-1.0)]),
        _sets_raw(104, [_goblet(5, 25000.0)]),
        _sets_raw(106, [_goblet(1, 40000.0), _goblet(5, 30000.0)]),
        _sets_raw(107, [_goblet(10, 20000.0)]),
    ]
    offsets = list(range(-45, 1))
    _put(cfg, _listings(offsets, activities) + rows)
    _days_db(cfg, offsets, payloads=payloads)
    _put_sidecar(
        cfg,
        _day(-40),
        {"weight_kg": 72.4, "skeletal_muscle_mass_kg": 31.0, "body_fat_percent": 20.1},
    )
    _put_sidecar(cfg, _day(-20), {"weight_kg": 71.8, "body_fat_percent": 19.5})
    _put_sidecar(
        cfg,
        _day(-3),
        {
            "inbody_score": 80,
            "weight_kg": 71.1,
            "body_fat_percent": 19.0,
            "skeletal_muscle_mass_kg": 31.4,
        },
    )


def _local_ms(day: str, hhmm: str) -> int:
    """Asia/Seoul `day hhmm`(`HH:MM` 또는 `HH:MM:SS`)의 UTC epoch ms."""
    clock = hhmm if hhmm.count(":") == 2 else f"{hhmm}:00"
    moment = datetime.fromisoformat(f"{day}T{clock}").replace(
        tzinfo=ZoneInfo("Asia/Seoul")
    )
    return int(moment.timestamp() * 1000)


def _gmt_text(epoch_ms: int) -> str:
    """`summaryDTO.startTimeGMT` 모양(시간대 표기 없는 UTC)."""
    moment = datetime.fromtimestamp(epoch_ms / 1000, UTC)
    return moment.strftime("%Y-%m-%dT%H:%M:%S.0")


def _activity_summary(
    activity_id: int,
    start_ms: int | None,
    type_key: str = "running",
    **overrides: object,
) -> dict[str, object]:
    """`summaryDTO` 값은 `overrides`로 바꾸고 `DROP`이면 키를 뺀다."""
    summary: dict[str, object] = {
        "startTimeGMT": None if start_ms is None else _gmt_text(start_ms),
        "duration": 1800.4,
        "distance": 5012.6,
        "averageHR": 141.5,
        "maxHR": 170,
        "calories": 400,
    } | overrides
    return {
        "activityId": activity_id,
        "activityTypeDTO": {"typeId": 1, "typeKey": type_key},
        "summaryDTO": {
            key: value for key, value in summary.items() if value is not DROP
        },
    }


def _hr_zones(seconds: dict[int, object]) -> list[dict[str, object]]:
    return [
        {"zoneNumber": zone, "secsInZone": secs, "zoneLowBoundary": 100}
        for zone, secs in seconds.items()
    ]


def _activity_details(
    activity_id: int,
    samples: list[tuple[int, int | None]],
    body_battery: list[object] | None = None,
) -> dict[str, object]:
    """활동 심박 샘플 원문. `body_battery`(샘플마다 값 하나)를 주면 `directBodyBattery` 채널을 더한다."""
    descriptors = [
        {"metricsIndex": 0, "key": "directTimestamp"},
        {"metricsIndex": 1, "key": "directHeartRate"},
    ]
    metrics = [[ts, bpm] for ts, bpm in samples]
    if body_battery is not None:
        descriptors.append({"metricsIndex": 2, "key": "directBodyBattery"})
        for row, level in zip(metrics, body_battery, strict=True):
            row.append(level)
    return {
        "activityId": activity_id,
        "metricDescriptors": descriptors,
        "activityDetailMetrics": [{"metrics": row} for row in metrics],
    }


def _heart_rates(samples: list[tuple[int, int | None]]) -> dict[str, object]:
    return {
        "heartRateValueDescriptors": [
            {"key": "timestamp", "index": 0},
            {"key": "heartrate", "index": 1},
        ],
        "heartRateValues": [[ts, bpm] for ts, bpm in samples],
    }


def _act(
    activity_id: int,
    day: str,
    hhmm: str | None = "07:30",
    *,
    type_key: str = "running",
    zones: dict[int, object] | None = None,
    details: list[tuple[int, int | None]] | None = None,
    body_battery: list[object] | None = None,
    **summary: object,
) -> list[tuple[str, str, str, object]]:
    """활동 하나의 activity-scope 원문(요약, `zones`·`details`를 주면 그 원문도). `hhmm`은 로컬 시작 시각.

    `body_battery`를 주면 details에 운동 중 Body Battery 채널을 더한다(`details`와 길이가 같다).
    """
    start = None if hhmm is None else _local_ms(day, hhmm)
    key = str(activity_id)
    rows: list[tuple[str, str, str, object]] = [
        (
            "activity",
            key,
            "activity",
            _activity_summary(activity_id, start, type_key, **summary),
        )
    ]
    if zones is not None:
        rows.append(("activity", key, "activity_hr_in_timezones", _hr_zones(zones)))
    if details is not None:
        rows.append(
            (
                "activity",
                key,
                "activity_details",
                _activity_details(activity_id, details, body_battery),
            )
        )
    return rows


def _gym_set(
    category: object = None,
    name: object = None,
    *,
    reps: object = None,
    weight: object = None,
    duration: object = 30.0,
    set_type: str = "ACTIVE",
    exercises: list[dict[str, object]] | None = None,
) -> dict[str, object]:
    """세트 원소 하나. `category`가 있으면 후보 하나(확률 90.0)를 담고, REST·후보 없음은 `exercises` `[]`다."""
    if exercises is None:
        exercises = (
            []
            if category is None
            else [{"category": category, "name": name, "probability": 90.0}]
        )
    return {
        "exercises": exercises,
        "duration": duration,
        "repetitionCount": reps,
        "weight": weight,
        "setType": set_type,
        "startTime": "2026-10-18T06:00:00.0",
        "wktStepIndex": None,
        "messageIndex": None,
        "avgConcentricMeanVelocity": None,
        "maxConcentricRom": None,
    }


def _rest(duration: object) -> dict[str, object]:
    return _gym_set(set_type="REST", duration=duration)


def _sets_raw(activity_id: int, sets: object) -> tuple[str, str, str, object]:
    """세트 원문(`activity_exercise_sets`) 행 하나."""
    return (
        "activity",
        str(activity_id),
        EXERCISE_SETS,
        {"activityId": activity_id, "exerciseSets": sets},
    )


def _goblet(reps: int, weight: float, duration: float = 40.0) -> dict[str, object]:
    return _gym_set(
        "SQUAT", "GOBLET_SQUAT", reps=reps, weight=weight, duration=duration
    )


def synthetic(cfg):
    _forty_five_days_db(cfg)
    # Add graph channels using raw payloads and the production normalizer.
    rows = [
        (
            "day",
            D1,
            "heart_rates",
            _heart_rates(
                [
                    (_local_ms(D1, "12:00"), 62),
                    (_local_ms(D1, "23:30"), 48),
                ]
            ),
        )
    ]
    for i, day, clock in [(101, D1, "07:30"), (107, REPORT_DATE, "05:00")]:
        rows.append(
            (
                "activity",
                str(i),
                "activity_details",
                _activity_details(
                    i,
                    [
                        (_local_ms(day, clock), 110),
                        (_local_ms(day, clock) + 60000, 120),
                    ],
                    [63, 61],
                ),
            )
        )
    stress = _stress_data(D1)
    stress["bodyBatteryValuesArray"] = [[_local_ms(D1, "12:00"), 55]]
    stress["bodyBatteryValueDescriptorsDTOList"] = _body_battery()[0][
        "bodyBatteryValueDescriptorDTOList"
    ]
    rows.append(("day", D1, "stress_data", stress))
    rows.append(
        _sets_raw(
            101,
            [
                _goblet(12, 20000.0),
                _rest(60.0),
                _goblet(10, 22500.0),
                _gym_set("PUSH_UP", "PUSH_UP", reps=15, weight=-1.0),
            ],
        )
    )

    _put(cfg, rows)
    _normalize(cfg)
