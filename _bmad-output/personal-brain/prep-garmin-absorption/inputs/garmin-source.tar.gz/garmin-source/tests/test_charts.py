"""그래프 실제 렌더링·시계열 그대로 사용·입력/경고/파일 격리."""

import copy
import logging
import math
import os
import stat
import struct
import subprocess
import sys
import warnings
from datetime import date

import chart_db as base
import pytest

from garmin_pipeline import charts, config, dates, store

TREND_NAMES = [
    "50-sleep-30d.png",
    "51-hrv-30d.png",
    "52-heart-30d.png",
    "53-workouts-30d.png",
    "54-sleep-all.png",
    "55-hrv-all.png",
    "56-heart-all.png",
    "57-workouts-all.png",
    "58-strength-all.png",
    "59-body.png",
]


@pytest.fixture
def cfg(write_config, monkeypatch):
    monkeypatch.setattr(dates, "_utc_now", lambda: base.CLOCK)
    return config.load(write_config(lock_wait_seconds=0))


@pytest.fixture
def inputs(cfg, tmp_path, monkeypatch):
    base.synthetic(cfg)
    samples = charts._read_chart_data(cfg, date.fromisoformat(base.REPORT_DATE))
    monkeypatch.setattr(charts, "_read_chart_data", lambda *args: samples)
    output = tmp_path / "png"
    output.mkdir()
    return {}, samples, None, None, output


def test_real_png_album_limits_permissions_and_text(
    cfg, inputs, monkeypatch, capsys, caplog
):
    from matplotlib.figure import Figure
    from matplotlib.text import Text

    _, samples, _fp, _sp, output = inputs
    texts = []
    real_save = Figure.savefig

    def record(self, *args, **kwargs):
        texts.extend(text.get_text() for text in self.findobj(Text))
        return real_save(self, *args, **kwargs)

    monkeypatch.setattr(Figure, "savefig", record)
    with caplog.at_level(logging.INFO, logger=charts.__name__):
        names = charts.render(cfg, date.fromisoformat(base.REPORT_DATE), output)
    assert [g.name for g in names] == [
        "01-yesterday.png",
        "02-session-1.png",
        "03-session-2.png",
        *[
            f"{k + 3:02d}-strength-{k}.png"
            for k in range(1, len(samples["strength_progress"]["items"]) + 1)
        ],
        *TREND_NAMES,
    ]
    assert sorted(p.name for p in output.iterdir()) == [g.name for g in names]
    assert all(g.title in texts for g in names)
    for name, title in names:
        data = (output / name).read_bytes()
        assert data[:8] == b"\x89PNG\r\n\x1a\n"
        width, height = struct.unpack(">II", data[16:24])
        assert (width, height) == tuple(
            int(n * charts.DPI) for n in charts.FIGURE_SIZE_IN
        )
        assert width + height <= 10000 and max(width, height) / min(width, height) <= 20
        assert len(data) <= 10_000_000
        assert stat.S_IMODE((output / name).stat().st_mode) == 0o600
    assert "어제 하루" in texts
    assert any(text.startswith("운동 세션 1 · ") for text in texts)
    assert f"근력 진행 · {samples['strength_progress']['items'][0]['label']}" in texts
    assert not any(
        ord(char) >= 0x1F000 or 0x2600 <= ord(char) <= 0x27BF
        for text in texts
        for char in text
    )
    assert os.environ["MPLCONFIGDIR"] == str(cfg.data_dir / ".matplotlib")
    assert stat.S_IMODE((cfg.data_dir / ".matplotlib").stat().st_mode) == 0o700
    assert capsys.readouterr().err == ""
    assert f"charts 끝: drawn={len(names)}" in caplog.text


def test_configuration():
    assert charts.BACKEND == "Agg"
    assert charts.FONT_FAMILY == ["Apple SD Gothic Neo", "DejaVu Sans"]


@pytest.mark.parametrize("failed", [False, True])
def test_empty_or_failed_parts_produce_no_png(cfg, inputs, failed):
    _, samples, _fp, _sp, output = inputs
    for part in (
        "yesterday",
        "sessions",
        "daily",
        "all",
        "strength_progress",
        "body_measurements",
    ):
        if failed or part in ("daily", "all"):
            samples[part] = {"reason": "failed"}
        elif part == "yesterday":
            samples[part]["hr"] = []
            samples[part]["body_battery"] = []
        else:
            samples[part]["items"] = []
    assert charts.render(cfg, date.fromisoformat(base.REPORT_DATE), output) == []
    assert list(output.iterdir()) == []


def test_one_graph_failure_removes_partial_and_captures_warning(
    cfg, inputs, monkeypatch, caplog, capsys
):
    from matplotlib.figure import Figure

    _, _, _fp, _sp, output = inputs
    real_save = Figure.savefig

    def fail_one(self, path, **kwargs):
        if path.name == "02-session-1.png":
            path.write_bytes(b"partial")
            warnings.warn("private warning", RuntimeWarning)
            raise RuntimeError("private label 12345")
        return real_save(self, path, **kwargs)

    monkeypatch.setattr(Figure, "savefig", fail_one)
    names = charts.render(cfg, date.fromisoformat(base.REPORT_DATE), output)
    assert [g.name for g in names] == [
        "01-yesterday.png",
        "03-session-2.png",
        "04-strength-1.png",
        "05-strength-2.png",
        *TREND_NAMES,
    ]
    assert not (output / "02-session-1.png").exists()
    assert (
        "charts 그래프 실패: graph=02-session-1.png error=RuntimeError" in caplog.text
    )
    assert "charts 경고: graph=02-session-1.png count=" in caplog.text
    assert "private" not in caplog.text
    assert capsys.readouterr().err == ""


def test_last_two_sessions_chronological_and_missing_hr_skipped(
    cfg, inputs, monkeypatch
):
    _, samples, _fp, _sp, output = inputs
    item = samples["sessions"]["items"][-1]
    items = []
    for start in (300, 100, 200):
        session = copy.deepcopy(item)
        session["start_ms"] = start
        session["activity_ids"] = [start]
        items.append(session)
    samples["sessions"]["items"] = items
    seen = []

    def record(fig, item, number):
        seen.append((item["start_ms"], number))
        return False

    real_session = charts._session
    monkeypatch.setattr(charts, "_session", record)
    charts.render(cfg, date.fromisoformat(base.REPORT_DATE), output)
    assert seen == [(200, 1), (300, 2)]
    from matplotlib.figure import Figure

    assert real_session(Figure(), {"hr": []}, 1) is False


@pytest.mark.parametrize(
    ("metric", "label"), [("hr", "심박"), ("body_battery", "Body Battery")]
)
def test_yesterday_single_metric_is_drawn(inputs, metric, label):
    from matplotlib.figure import Figure

    _doc, samples, _, _, _ = inputs
    part = samples["yesterday"]
    missing = "body_battery" if metric == "hr" else "hr"
    part[missing] = []
    part["sleep"] = part["activities"] = []
    fig = Figure()
    assert charts._yesterday(fig, samples)
    ax = fig.axes[0]
    assert len(fig.axes) == 2
    plotted = ax if metric == "hr" else fig.axes[1]
    assert len(plotted.lines) == 1
    assert list(plotted.lines[0].get_ydata()) == [v for _, v in part[metric]]
    assert list(plotted.lines[0].get_xdata()) == [
        (ts - part["from_ms"]) / 3_600_000 for ts, _ in part[metric]
    ]
    assert [text.get_text() for text in ax.get_legend().get_texts()] == [label]
    if metric == "body_battery":
        assert not ax.lines
    else:
        assert not fig.axes[1].lines


def test_plot_values_shading_and_strength_fallback(cfg, inputs):
    import matplotlib
    from matplotlib.figure import Figure

    _doc, samples, _, _, _ = inputs
    with matplotlib.rc_context({"axes.unicode_minus": False}):
        fig = Figure()
        assert charts._yesterday(fig, samples)
        ax, right = fig.axes
        assert list(ax.lines[0].get_ydata()) == [
            v for _, v in samples["yesterday"]["hr"]
        ]
        part = samples["yesterday"]
        assert any(ts != part["from_ms"] for ts, _ in part["hr"])
        assert any(ts != part["from_ms"] for ts, _ in part["body_battery"])
        assert list(ax.lines[0].get_xdata()) == [
            (ts - part["from_ms"]) / 3_600_000 for ts, _ in part["hr"]
        ]
        assert list(right.lines[0].get_xdata()) == [
            (ts - part["from_ms"]) / 3_600_000 for ts, _ in part["body_battery"]
        ]
        assert ax.get_xlim() == (0, 24)
        assert {t.get_text() for t in ax.get_legend().get_texts()} == {
            "심박",
            "Body Battery",
            "수면",
            "운동",
        }
        assert right.get_ylim() == (0, 100)
        part = samples["yesterday"]
        part["sleep"] = [
            {"start_ms": part["from_ms"] - 100, "end_ms": part["to_ms"] + 100}
        ]
        part["activities"] = []
        fig = Figure()
        charts._yesterday(fig, samples)
        patch = fig.axes[0].patches[0]
        assert patch.get_x() == 0 and patch.get_width() == 24
        item = samples["sessions"]["items"][0]
        fig = Figure()
        charts._session(fig, item, 1)
        assert fig.axes[0].get_title() == f"운동 세션 1 · {item['start_local']}"
        assert list(fig.axes[0].lines[0].get_xdata()) == [
            (ts - item["start_ms"]) / 60000 for ts, _ in item["hr"]
        ]
        strength = samples["strength_progress"]["items"][0]
        for day in strength["days"]:
            day["best_weight_kg"] = day["volume_kg"] = None
        samples["strength_progress"]["items"] = [strength]
        fig = Figure()
        charts._strength(fig, strength, samples["report_date"])
        assert fig.axes[0].get_ylabel() == "세트 수"
        assert [p.get_height() for p in fig.axes[0].patches[1:]] == [
            d["sets"] for d in strength["days"]
        ]
        assert {t.get_text() for t in fig.axes[0].get_legend().get_texts()} == {
            "최근 30일",
            "세트 수",
        }


@pytest.mark.parametrize("count", [9, 47])
def test_strength_one_per_exercise_and_limit(cfg, inputs, caplog, count):
    _, samples, _fp, _sp, output = inputs
    item = samples["strength_progress"]["items"][0]
    items = [copy.deepcopy(item) for _ in range(count)]
    for k, exercise in enumerate(items, 1):
        exercise["label"] = f"종목 {k}"
    samples["strength_progress"]["items"] = items
    samples["yesterday"] = samples["sessions"] = {"reason": "failed"}
    for key in ("daily", "all", "body_measurements"):
        samples[key] = {"reason": "failed"}
    with caplog.at_level(logging.INFO):
        graphs = charts.render(cfg, date.fromisoformat(base.REPORT_DATE), output)
    assert graphs == [
        charts.Graph(f"{k + 3:02d}-strength-{k}.png", f"근력 진행 · 종목 {k}")
        for k in range(1, min(count, 46) + 1)
    ]
    assert sorted(p.name for p in output.iterdir()) == [g.name for g in graphs]
    if count > 46:
        assert "charts 근력 초과: count=1" in caplog.text


def test_empty_strength_keeps_item_number_and_isolates_failure(
    cfg, inputs, monkeypatch
):
    _, samples, _fp, _sp, output = inputs
    item = samples["strength_progress"]["items"][0]
    empty = copy.deepcopy(item)
    empty["days"] = []
    samples["strength_progress"]["items"] = [empty, item, item]
    samples["yesterday"] = samples["sessions"] = {"reason": "failed"}
    for key in ("daily", "all", "body_measurements"):
        samples[key] = {"reason": "failed"}
    real = charts._strength
    calls = []

    def draw(fig, exercise, report_date):
        calls.append(exercise)
        if len(calls) == 2:
            raise RuntimeError
        return real(fig, exercise, report_date)

    monkeypatch.setattr(charts, "_strength", draw)
    graphs = charts.render(cfg, date.fromisoformat(base.REPORT_DATE), output)
    assert graphs == [charts.Graph("06-strength-3.png", f"근력 진행 · {item['label']}")]
    assert [p.name for p in output.iterdir()] == ["06-strength-3.png"]


def test_session_activity_zone_ranges_labels_and_battery():
    from matplotlib.figure import Figure

    item = {
        "start_ms": 1_000_000,
        "activity_ids": [1, 2],
        "hr": [[1_000_000, 90], [1_600_000, 190]],
        "body_battery": [[1_000_000, 65], [1_600_000, 55]],
        "activities": [
            {
                "start_ms": 1_000_000,
                "end_ms": 1_120_000,
                "label": "걷기",
                "zone_low_bpm": [80, 100, 120, 140, 160],
            },
            {
                "start_ms": 1_180_000,
                "end_ms": 1_600_000,
                "label": "달리기",
                "zone_low_bpm": [100, 110, None, 150, 170],
            },
        ],
    }
    fig = Figure()
    assert charts._session(fig, item, 1)
    ax, right = fig.axes
    assert list(ax.lines[0].get_ydata()) == [value for _, value in item["hr"]]
    assert [text.get_text() for text in ax.texts] == ["걷기", "달리기"]
    assert [list(line.get_xdata()) for line in ax.lines[1:]] == [
        [0, 0],
        [2, 2],
        [3, 3],
        [10, 10],
    ]
    assert list(right.lines[0].get_ydata()) == [65, 55]
    assert {t.get_text() for t in ax.get_legend().get_texts()} == {
        "심박",
        "Body Battery",
        *[f"존 {k}" for k in range(1, 6)],
    }
    assert len(ax.collections) == 8  # five valid bands, then three valid bands
    top = ax.get_ylim()[1]
    first_bounds = [(80, 100), (100, 120), (120, 140), (140, 160), (160, top)]
    for band, bounds in zip(ax.collections[:5], first_bounds, strict=True):
        vertices = band.get_paths()[0].vertices
        assert set(vertices[:, 0]) == {0, 2}
        assert set(vertices[:, 1]) == set(bounds)
    # Missing zone 3's low boundary suppresses zones 2 and 3 only.
    second_bounds = [(100, 110), (150, 170), (170, top)]
    for band, bounds in zip(ax.collections[5:], second_bounds, strict=True):
        vertices = band.get_paths()[0].vertices
        assert set(vertices[:, 0]) == {3, 10}
        assert set(vertices[:, 1]) == set(bounds)


def test_strength_uses_exact_weights_and_volume_and_recent_window(inputs):
    from datetime import date, timedelta

    import matplotlib.dates as mdates
    from matplotlib.figure import Figure

    _, samples, _, _, _ = inputs
    item = samples["strength_progress"]["items"][0]
    samples["strength_progress"]["items"] = [item]
    fig = Figure()
    assert charts._strength(fig, item, samples["report_date"])
    left, right = fig.axes
    assert list(left.lines[0].get_ydata()) == [
        d["best_weight_kg"] for d in item["days"]
    ]
    assert [bar.get_height() for bar in right.patches] == [
        d["volume_kg"] for d in item["days"]
    ]
    end = date.fromisoformat(samples["report_date"])
    patch = left.patches[0]
    assert patch.get_x() == mdates.date2num(end - timedelta(days=30))
    assert patch.get_width() == 30

    assert {t.get_text() for t in left.get_legend().get_texts()} == {
        "최고 무게",
        "볼륨",
        "최근 30일",
    }


def test_strength_mixed_null_metrics_remain_gaps():
    from datetime import date

    import matplotlib.dates as mdates
    from matplotlib.figure import Figure

    item = {
        "label": "스쿼트",
        "days": [
            {"day_key": "2026-10-01", "best_weight_kg": 50, "volume_kg": 1000},
            {"day_key": "2026-10-03", "best_weight_kg": None, "volume_kg": 1200},
            {"day_key": "2026-10-07", "best_weight_kg": 55, "volume_kg": None},
            {"day_key": "2026-10-10", "best_weight_kg": None, "volume_kg": None},
            {"day_key": "2026-10-15", "best_weight_kg": 60, "volume_kg": 1500},
        ],
    }
    fig = Figure()
    assert charts._strength(fig, item, "2026-10-18")
    left, right = fig.axes
    expected_dates = [date.fromisoformat(day["day_key"]) for day in item["days"]]
    assert list(left.lines[0].get_xdata()) == expected_dates
    assert [bar.get_x() + bar.get_width() / 2 for bar in right.patches] == [
        mdates.date2num(day) for day in expected_dates
    ]
    for day, weight, bar in zip(
        item["days"], left.lines[0].get_ydata(), right.patches, strict=True
    ):
        if day["best_weight_kg"] is None:
            assert math.isnan(weight)
        else:
            assert weight == day["best_weight_kg"]
        if day["volume_kg"] is None:
            assert math.isnan(bar.get_height())
        else:
            assert bar.get_height() == day["volume_kg"]


def test_null_start_session_does_not_lose_other_graphs(cfg, inputs, caplog):
    _, samples, _fp, _sp, output = inputs
    samples["sessions"]["items"][0]["start_ms"] = None
    with caplog.at_level(logging.INFO):
        graphs = charts.render(cfg, date.fromisoformat(base.REPORT_DATE), output)
    assert [g.name for g in graphs] == [
        "01-yesterday.png",
        "02-session-1.png",
        "04-strength-1.png",
        "05-strength-2.png",
        *TREND_NAMES,
    ]
    assert caplog.text.count("charts 세션 제외: count=1") == 1


def test_yesterday_dst_25_hours_shows_last_hour(inputs):
    from matplotlib.figure import Figure

    _doc, samples, _, _, _ = inputs
    part = samples["yesterday"]
    part["to_ms"] = part["from_ms"] + 25 * 3_600_000
    part["hr"] = [[part["from_ms"] + 24.5 * 3_600_000, 80]]
    fig = Figure()
    assert charts._yesterday(fig, samples)
    assert fig.axes[0].get_xlim() == (0, 25)
    assert list(fig.axes[0].lines[0].get_xdata()) == [24.5]


def test_first_matplotlib_import_uses_private_config_and_agg(cfg, inputs):
    _, _, _fp, _sp, output = inputs
    script = """
import os
import stat
import sys
from pathlib import Path
from datetime import date
from garmin_pipeline import charts, cli, config
assert 'matplotlib' not in sys.modules
cfg = config.load(Path(sys.argv[1]))
with cli._block_library_logs():
    from datetime import date
    assert charts.render(cfg, date.fromisoformat(sys.argv[2]), Path(sys.argv[3]))
import matplotlib
cache = cfg.data_dir / '.matplotlib'
assert matplotlib.get_configdir() == str(cache)
assert matplotlib.get_backend().lower() == 'agg'
assert stat.S_IMODE(cache.stat().st_mode) == 0o700
"""
    result = subprocess.run(
        [sys.executable, "-c", script, str(cfg.path), base.REPORT_DATE, str(output)],
        env={**os.environ, "MPLCONFIGDIR": str(output / "wrong"), "MPLBACKEND": "svg"},
        capture_output=True,
        text=True,
        check=False,
    )
    assert result.returncode == 0, result.stderr
    assert result.stderr == ""


def _trend_only(samples):
    for key in ("yesterday", "sessions", "strength_progress"):
        samples[key] = {"reason": "failed"}


def test_daily_values_gaps_baseline_and_axes(inputs):
    from datetime import date

    from matplotlib.dates import date2num
    from matplotlib.figure import Figure

    _, samples, *_ = inputs
    days = samples["daily"]["days"]
    days[1]["hrv_ms"] = None
    fig = Figure()
    assert charts._daily_trend(fig, samples, charts._HRV, "HRV 30일", "HRV (ms)")
    ax = fig.axes[0]
    assert list(ax.lines[0].get_xdata()) == [
        date.fromisoformat(d["day_key"]) for d in days
    ]
    assert math.isnan(ax.lines[0].get_ydata()[1])
    assert ax.lines[0].get_marker() == "o" and ax.lines[0].get_markersize() == 3
    assert ax.lines[0].get_ydata()[0] == days[0]["hrv_ms"]
    vertices = ax.collections[0].get_paths()[0].vertices
    assert vertices[:, 1].min() == min(d["hrv_baseline_low_ms"] for d in days)
    assert vertices[:, 1].max() == max(d["hrv_baseline_high_ms"] for d in days)
    assert list(ax.get_xlim()) == [
        date2num(date.fromisoformat(samples["daily"][k])) + padding
        for k, padding in (("from", -0.5), ("to", 0.5))
    ]
    fig = Figure()
    assert charts._daily_trend(fig, samples, charts._SLEEP, "수면 30일", "시간", "점수")
    ax, right = fig.axes
    assert [p.get_height() for p in ax.patches] == [d["sleep_s"] / 3600 for d in days]
    assert list(right.lines[0].get_ydata()) == [d["sleep_score"] for d in days]
    assert right.get_ylim() == (0, 100)
    assert all(
        line.get_marker() == "o" and line.get_markersize() == 3
        for axis in fig.axes
        for line in axis.lines
    )
    days[2]["resting_hr"] = None
    fig = Figure()
    assert charts._daily_trend(fig, samples, charts._HEART, "심박", "bpm", "스트레스")
    ax, right = fig.axes
    assert math.isnan(ax.lines[0].get_ydata()[2])
    assert list(ax.lines[1].get_ydata()) == [d["sleep_min_hr"] for d in days]
    assert list(right.lines[0].get_ydata()) == [d["stress_avg"] for d in days]
    assert right.get_ylim() == (0, 100)
    assert all(
        line.get_marker() == "o" and line.get_markersize() == 3
        for axis in fig.axes
        for line in axis.lines
    )


def test_workouts_stacked_minutes_missing_days_and_file_labels(inputs):
    from datetime import date

    from matplotlib.dates import date2num
    from matplotlib.figure import Figure

    _, samples, *_ = inputs
    days = samples["daily"]["days"]
    for day in days:
        day["workouts"] = {"sessions": [], "by_type": []}
    days[0]["workouts"] = {
        "sessions": [{}],
        "by_type": [
            {"type_key": "one", "label": "파일의 이름", "duration_s": 120},
            {"type_key": None, "label": None, "duration_s": 180},
        ],
    }
    days[1]["workouts"] = None
    fig = Figure()
    assert charts._daily_workouts(fig, samples)
    ax, right = fig.axes
    first, second = ax.containers
    assert len(first) == len(second) == 29
    assert first[0].get_height() == 2
    assert second[0].get_height() == 3 and second[0].get_y() == 2
    assert len(ax.patches) == 59  # 58 bars and one unavailable-day span
    assert ax.patches[-1].get_width() == 1
    assert list(right.lines[0].get_ydata())[:1] == [1]
    assert math.isnan(right.lines[0].get_ydata()[1])
    assert right.lines[0].get_linestyle() == "None"
    assert right.get_ylim()[0] == 0
    assert all(tick >= 0 and float(tick).is_integer() for tick in right.get_yticks())
    assert list(ax.get_xlim()) == [
        date2num(date.fromisoformat(samples["daily"][k])) + padding
        for k, padding in (("from", -0.5), ("to", 0.5))
    ]
    assert {t.get_text() for t in ax.get_legend().get_texts()} == {
        "파일의 이름",
        "종류 미상",
        "세션 수",
        "기록 못 받음",
    }


@pytest.mark.parametrize("unit", ["week", "month"])
@pytest.mark.parametrize(
    "metrics",
    [charts._SLEEP, charts._HRV, charts._HEART, charts._WORKOUTS, charts._VOLUME],
)
def test_all_uses_file_means_midpoints_and_monthly_bounds(unit, metrics):
    from datetime import date

    from matplotlib.dates import date2num
    from matplotlib.figure import Figure

    buckets = [
        {
            "from": "2026-01-01",
            "to": "2026-01-31",
            "days": 17,
            "mean": 7200,
            "min": 3600,
            "max": 10800,
        },
        {
            "from": "2026-02-01",
            "to": "2026-02-28",
            "days": 9,
            "mean": None,
            "min": None,
            "max": None,
        },
        {
            "from": "2026-03-01",
            "to": "2026-03-31",
            "days": 1,
            "mean": 14400,
            "min": 12000,
            "max": 18000,
        },
    ]
    samples = {
        "all": {
            "reason": None,
            "from": "2025-12-01",
            "to": "2026-04-30",
            "unit": unit,
            "metrics": {key: copy.deepcopy(buckets) for key, *_ in metrics},
        }
    }
    fig = Figure()
    assert charts._all_trend(fig, samples, metrics, "전체", "왼쪽", "오른쪽")
    for i, (key, label, divisor, secondary) in enumerate(metrics):
        target = fig.axes[1] if secondary else fig.axes[0]
        line = next(line for line in target.lines if line.get_label() == label)
        assert list(line.get_xdata()) == [
            date(2026, 1, 16),
            date(2026, 2, 14),
            date(2026, 3, 16),
        ]
        ys = line.get_ydata()
        assert ys[0] == 7200 / divisor and ys[2] == 14400 / divisor
        assert math.isnan(ys[1])
        assert line.get_marker() == "o" and line.get_markersize() == 3
        assert target.get_xlim() == (
            date2num(date(2025, 12, 1)),
            date2num(date(2026, 4, 30)),
        )
        if unit == "month":
            # Each finite bucket is a distinct band path; no recomputation from days.
            collection = target.collections[
                [line.get_label() for line in target.lines].index(label)
            ]
            assert len(collection.get_paths()) == 2
            assert collection.get_paths()[0].vertices[:, 1].min() == 3600 / divisor
            assert collection.get_paths()[0].vertices[:, 1].max() == 10800 / divisor
            assert collection.get_paths()[1].vertices[:, 1].max() == 18000 / divisor
    assert sum(len(ax.collections) for ax in fig.axes) == (
        len(metrics) if unit == "month" else 0
    )


def test_render_all_period_axes_preserve_bounds_and_fractional_averages(
    cfg, inputs, monkeypatch
):
    from datetime import date

    from matplotlib.dates import date2num
    from matplotlib.figure import Figure

    _, samples, _fp, _sp, output = inputs
    _trend_only(samples)
    for buckets in samples["all"]["metrics"].values():
        buckets[0]["mean"] = buckets[-1]["mean"] = None
    for bucket in samples["all"]["metrics"]["sessions"][1:-1]:
        bucket["mean"] = 0.25
    captured = {}

    def save(fig, path, **kwargs):
        captured[path.name] = [
            (axis.get_xlim(), axis.get_ylim(), axis.get_yticks()) for axis in fig.axes
        ]

    monkeypatch.setattr(Figure, "savefig", save)
    graphs = charts.render(cfg, date.fromisoformat(base.REPORT_DATE), output)
    assert [g.name for g in graphs] == TREND_NAMES
    for name in ("54-sleep-all.png", "56-heart-all.png"):
        assert captured[name][1][1] == (0, 100)
    expected = tuple(
        date2num(date.fromisoformat(samples["all"][key])) for key in ("from", "to")
    )
    for name in TREND_NAMES[4:9]:
        assert all(xlim == expected for xlim, _, _ in captured[name])
    assert any(
        not float(tick).is_integer() for tick in captured["57-workouts-all.png"][1][2]
    )


def test_body_sparse_values_join_only_measurements_and_use_labels(inputs):
    from datetime import date

    from matplotlib.figure import Figure

    _, samples, *_ = inputs
    body = samples["body_measurements"]
    for key in body["labels"]:
        body["labels"][key] = f"파일 {key}"
    fig = Figure()
    assert charts._body_trend(fig, samples)
    ax, right = fig.axes
    assert [line.get_label() for line in ax.lines] == [
        "파일 weight_kg",
        "파일 skeletal_muscle_mass_kg",
    ]
    muscle = ax.lines[1]
    assert list(muscle.get_xdata()) == [
        date.fromisoformat(body["items"][i]["measured_on"]) for i in (0, 2)
    ]
    assert list(muscle.get_ydata()) == [31.0, 31.4]
    assert list(right.lines[0].get_ydata()) == [20.1, 19.5, 19.0]
    assert all(line.get_marker() == "o" for axis in fig.axes for line in axis.lines)
    body["items"][1]["values"]["body_fat_mass_kg"] = 14.2
    body["labels"]["body_fat_mass_kg"] = "파일 지방"
    fig = Figure()
    assert charts._body_trend(fig, samples)
    assert list(fig.axes[0].lines[2].get_ydata()) == [14.2]
    assert "파일 inbody_score" not in [
        t.get_text() for t in fig.axes[0].get_legend().get_texts()
    ]


@pytest.mark.parametrize(
    ("scenario", "missing"),
    [
        ("short_hrv", ["51-hrv-30d.png"]),
        ("no_workouts", ["53-workouts-30d.png"]),
        ("single_body", ["59-body.png"]),
        ("body_unselected_only", ["59-body.png"]),
        ("daily_failed", TREND_NAMES[:4]),
        ("all_failed", TREND_NAMES[4:9]),
        ("body_failed", ["59-body.png"]),
        ("short_all_hrv", ["55-hrv-all.png"]),
        ("short_daily_sleep", ["50-sleep-30d.png"]),
        ("split_daily_sleep", []),
        ("split_all_heart", []),
        ("single_all_heart", ["56-heart-all.png"]),
        ("single_workouts_day", ["53-workouts-30d.png"]),
    ],
)
def test_trend_skips_only_affected_graphs(
    cfg, inputs, monkeypatch, caplog, scenario, missing
):
    from matplotlib.figure import Figure

    _, samples, _fp, _sp, output = inputs
    _trend_only(samples)
    if scenario == "short_hrv":
        for day in samples["daily"]["days"][1:]:
            day["hrv_ms"] = None
    elif scenario == "short_daily_sleep":
        for day in samples["daily"]["days"][1:]:
            day["sleep_s"] = day["sleep_score"] = None
    elif scenario == "split_daily_sleep":
        for i, day in enumerate(samples["daily"]["days"]):
            day["sleep_s"] = 27000 if i == 1 else None
            day["sleep_score"] = 80 if i == 3 else None
    elif scenario in ("split_all_heart", "single_all_heart"):
        for key, *_ in charts._HEART:
            for i, bucket in enumerate(samples["all"]["metrics"][key]):
                position = (
                    3 if scenario == "split_all_heart" and key == "stress_avg" else 1
                )
                bucket["mean"] = 50 if i == position else None
                if scenario == "split_all_heart" and key == "sleep_min_hr":
                    bucket["mean"] = None
    elif scenario == "single_workouts_day":
        known = next(
            day["workouts"]
            for day in samples["daily"]["days"]
            if day["workouts"]["sessions"]
        )
        for i, day in enumerate(samples["daily"]["days"]):
            day["workouts"] = known if i == 1 else None
    elif scenario == "no_workouts":
        for day in samples["daily"]["days"]:
            day["workouts"] = {"sessions": [], "by_type": []}
    elif scenario in ("single_body", "body_unselected_only"):
        samples["body_measurements"]["items"] = samples["body_measurements"]["items"][
            :1
        ]
        if scenario == "body_unselected_only":
            samples["body_measurements"]["items"] *= 3
            samples["body_measurements"]["items"][0]["values"] = {"inbody_score": 80}
    elif scenario == "short_all_hrv":
        for bucket in samples["all"]["metrics"]["hrv_ms"][1:]:
            bucket["mean"] = None
    else:
        samples[
            scenario.removesuffix("_failed").replace("body", "body_measurements")
        ] = {"reason": "failed"}
    monkeypatch.setattr(Figure, "savefig", lambda *args, **kwargs: None)
    with caplog.at_level(logging.INFO):
        graphs = charts.render(cfg, date.fromisoformat(base.REPORT_DATE), output)
    assert [g.name for g in graphs] == [n for n in TREND_NAMES if n not in missing]
    for name in missing:
        assert f"charts 그래프 없음: graph={name}" in caplog.text


def test_trend_failure_isolated_and_partial_deleted(cfg, inputs, monkeypatch, caplog):
    from matplotlib.figure import Figure

    _, samples, _fp, _sp, output = inputs
    _trend_only(samples)

    def save(fig, path, **kwargs):
        if path.name == "52-heart-30d.png":
            path.write_bytes(b"partial")
            warnings.warn("private", RuntimeWarning)
            raise RuntimeError("private")

    monkeypatch.setattr(Figure, "savefig", save)
    assert [
        g.name for g in charts.render(cfg, date.fromisoformat(base.REPORT_DATE), output)
    ] == [n for n in TREND_NAMES if n != "52-heart-30d.png"]
    assert not (output / "52-heart-30d.png").exists()
    assert "graph=52-heart-30d.png error=RuntimeError" in caplog.text
    assert (
        "charts 경고: graph=52-heart-30d.png count=1 category=RuntimeWarning"
        in caplog.text
    )
    assert "private" not in caplog.text


def test_db_render_reads_one_snapshot_and_closes_before_drawing(
    cfg, tmp_path, monkeypatch
):
    import socket
    import sqlite3

    from matplotlib.figure import Figure

    base.synthetic(cfg)
    real_read = store.read_connection
    connections, sql = [], []

    def read(actual_cfg):
        conn = real_read(actual_cfg)
        conn.set_trace_callback(sql.append)
        connections.append(conn)
        return conn

    def no_network(*args, **kwargs):
        pytest.fail("graph rendering attempted a network connection")

    real_save = Figure.savefig

    def save(figure, *args, **kwargs):
        assert len(connections) == 1
        with pytest.raises(sqlite3.ProgrammingError):
            connections[0].execute("SELECT 1")
        return real_save(figure, *args, **kwargs)

    monkeypatch.setattr(store, "read_connection", read)
    monkeypatch.setattr(socket, "create_connection", no_network)
    monkeypatch.setattr(Figure, "savefig", save)
    out = tmp_path / "db-png"
    out.mkdir()
    graphs = charts.render(cfg, date.fromisoformat(base.REPORT_DATE), out)
    assert [graph.name for graph in graphs] == [
        "01-yesterday.png",
        "02-session-1.png",
        "03-session-2.png",
        "04-strength-1.png",
        "05-strength-2.png",
        *TREND_NAMES,
    ]
    assert len(connections) == 1
    assert sum(statement == "BEGIN" for statement in sql) == 1
    assert sum(statement == "COMMIT" for statement in sql) == 1
    assert not any("raw_response" in statement.lower() for statement in sql)


def test_missing_db_does_not_block_body_and_bad_sidecars_are_isolated(cfg, tmp_path):
    base._put_sidecar(cfg, base._day(-2), {"weight_kg": 70})
    base._put_sidecar(cfg, base._day(-1), {"weight_kg": 69})
    base._put_sidecar(cfg, base._day(1), {"weight_kg": 68})
    base._put_sidecar(cfg, base._day(-3), {"weight_kg": 72}, name=".hidden.json")
    (cfg.data_dir / "body" / "2026-10-10.json").write_text("bad")
    (cfg.data_dir / "body" / "2026-02-30.json").write_text("{}")
    out = tmp_path / "body-png"
    out.mkdir()
    assert [
        g.name for g in charts.render(cfg, date.fromisoformat(base.REPORT_DATE), out)
    ] == ["59-body.png"]
    assert not cfg.db_path.exists()


def test_short_history_skips_all_trend_files(cfg, tmp_path):
    base._put(cfg, base._today_raws())
    base._normalize(cfg)
    base._put_sidecar(cfg, base.REPORT_DATE, {"weight_kg": 70})
    out = tmp_path / "short-png"
    out.mkdir()
    assert not charts.render(cfg, date.fromisoformat(base.REPORT_DATE), out)
    assert not list(out.iterdir())


def test_day_values_and_missing_workout_day(cfg):
    base.synthetic(cfg)
    # Entirely absent input date versus a received day with an empty activity list.
    base._put(
        cfg, [("day", base._day(2), "user_summary", base._user_summary(base._day(2)))]
    )
    base._normalize(cfg)
    with store.read_connection(cfg) as conn:
        part = charts._read_daily(
            conn, date.fromisoformat(base._day(-1)), date.fromisoformat(base._day(2))
        )
        source = conn.execute(
            "SELECT sleep_total_s, sleep_score, hrv_avg, resting_hr, sleep_hr_min, stress_avg FROM day_summary WHERE date=?",
            (base.REPORT_DATE,),
        ).fetchone()
    yesterday, today, missing, empty = part["days"]
    assert [today[key] for key in charts._METRIC_COLUMNS] == list(source)
    assert yesterday["workout_duration_s"] == 1800
    assert missing["workouts"] is None and missing["sessions"] is None
    assert empty["workouts"] == {"sessions": [], "by_type": []}
    assert empty["workout_duration_s"] == 0


@pytest.mark.parametrize(
    "starts,expected",
    [
        (["07:30", "08:05"], [[801, 802]]),
        (["07:30", "12:00", "18:00"], [[802], [803]]),
    ],
)
def test_sessions_follow_persisted_ten_minute_groups(cfg, starts, expected):
    rows = [
        (
            "day",
            base.D1,
            "activities_by_date",
            [
                {"activityId": i, "startTimeLocal": f"{base.D1} {clock}:00"}
                for i, clock in enumerate(starts, 801)
            ],
        )
    ]
    for i, clock in enumerate(starts, 801):
        rows += base._act(
            i,
            base.D1,
            clock,
            duration=1800,
            details=[(base._local_ms(base.D1, clock), 110)],
        )
    base._put(cfg, rows)
    base._normalize(cfg)
    with store.read_connection(cfg) as conn:
        items = charts._read_sessions(conn, cfg, date.fromisoformat(base.REPORT_DATE))[
            "items"
        ]
    assert [item["activity_ids"] for item in items] == expected
    assert [len(item["activities"]) for item in items] == [len(ids) for ids in expected]
    assert [item["start_local"] for item in items] == [
        dates.local_minute(item["start_ms"], cfg) for item in items
    ]


def test_duplicate_samples_prefer_local_day_before_discarding_null(cfg):
    timestamp = base._local_ms(base.D1, "23:59")
    end = base._local_ms(base.REPORT_DATE, "00:00")
    base._put(
        cfg,
        [
            (
                "day",
                base.D1,
                "heart_rates",
                base._heart_rates([(timestamp, None), (end, 99)]),
            ),
            (
                "day",
                base.REPORT_DATE,
                "heart_rates",
                base._heart_rates([(timestamp, 70)]),
            ),
        ],
    )
    base._normalize(cfg)
    with store.read_connection(cfg) as conn:
        assert (
            charts._read_yesterday(conn, cfg, date.fromisoformat(base.REPORT_DATE))[
                "hr"
            ]
            == []
        )


def test_removed_cli_command_exits_with_argument_error():
    from garmin_pipeline import cli

    with pytest.raises(SystemExit) as error:
        command = "fa"
        command += "cts"
        cli.main([command])
    assert error.value.code == 2


def test_bucket_calendar_null_exclusion_and_half_up_rounding():
    from datetime import timedelta

    def daily(first, last):
        start, end = date.fromisoformat(first), date.fromisoformat(last)
        rows = []
        while start <= end:
            rows.append(
                {
                    "day_key": start.isoformat(),
                    **dict.fromkeys(
                        (
                            *charts._METRIC_COLUMNS,
                            "workout_duration_s",
                            "sessions",
                            "strength_volume_kg",
                        )
                    ),
                }
            )
            start += timedelta(days=1)
        return {"from": first, "to": last, "days": rows}

    weekly = daily("2026-10-16", "2026-10-20")
    weekly["days"][0].update(sleep_s=1, hrv_ms=1.1)
    weekly["days"][1].update(sleep_s=2, hrv_ms=1.2)
    result = charts._bucket(weekly)
    assert result["unit"] == "week"
    assert result["metrics"]["sleep_s"] == [
        {"from": "2026-10-16", "to": "2026-10-18", "days": 2, "mean": 2},
        {"from": "2026-10-19", "to": "2026-10-20", "days": 0, "mean": None},
    ]
    assert result["metrics"]["hrv_ms"][0]["mean"] == 1.2
    assert charts._bucket(daily("2026-01-31", "2026-07-31"))["unit"] == "week"
    monthly = daily("2026-01-31", "2026-08-01")
    monthly["days"][0]["sessions"] = 2
    monthly["days"][1]["sessions"] = 3
    monthly["days"][2]["sessions"] = 6
    result = charts._bucket(monthly)
    assert result["unit"] == "month"
    assert result["metrics"]["sessions"][:2] == [
        {
            "from": "2026-01-31",
            "to": "2026-01-31",
            "days": 1,
            "mean": 2.0,
            "min": 2,
            "max": 2,
        },
        {
            "from": "2026-02-01",
            "to": "2026-02-28",
            "days": 2,
            "mean": 4.5,
            "min": 3,
            "max": 6,
        },
    ]


def test_strength_uses_translated_exercises_and_derived_aggregates(cfg):
    base.synthetic(cfg)
    with store.read_connection(cfg) as conn:
        result = charts._read_strength(conn, date.fromisoformat(base.REPORT_DATE))
    squat, pushup = result["items"]
    assert squat["label"] == "고블릿 스쿼트"
    assert squat["days"][0] == {
        "day_key": base._day(-40),
        "sets": 2,
        "best_weight_kg": 40.0,
        "volume_kg": 190.0,
    }
    assert squat["days"][-2] == {
        "day_key": base.D1,
        "sets": 2,
        "best_weight_kg": 22.5,
        "volume_kg": 465.0,
    }
    assert pushup["label"] == "푸시업"
    assert pushup["days"][-1] == {
        "day_key": base.D1,
        "sets": 1,
        "best_weight_kg": None,
        "volume_kg": 0.0,
    }
