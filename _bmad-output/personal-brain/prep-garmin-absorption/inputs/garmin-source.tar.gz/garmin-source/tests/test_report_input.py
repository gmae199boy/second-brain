"""Read snapshot exports, cutoff boundaries, privacy, and sidecar validation."""

import json
from datetime import date, datetime
from zoneinfo import ZoneInfo

from garmin_pipeline import config, report_input, store

DAY = date(2026, 10, 27)


def ms(text):
    return int(
        datetime.fromisoformat(text).replace(tzinfo=ZoneInfo("Asia/Seoul")).timestamp()
        * 1000
    )


def raw(conn, scope, key, endpoint, payload):
    store.upsert_raw(
        conn,
        scope=scope,
        key=key,
        endpoint=endpoint,
        payload=payload,
        library_version="test",
        now_ms=ms("2026-10-27 11:00"),
    )


def test_snapshot_filters_unfinished_activities_and_identifiers(write_config):
    cfg = config.load(write_config())
    cutoff = ms("2026-10-27 11:00")
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO run(local_date, started_at, status, detail) VALUES (?, ?, 'success', '')",
            (str(DAY), cutoff),
        )
        conn.execute(
            "INSERT INTO run(local_date, started_at, status, detail) VALUES ('2026-10-26', ?, 'success', '')",
            (ms("2026-10-26 10:58"),),
        )
        for ident, start, duration in [
            (1, cutoff - 10000, 9),
            (2, cutoff - 10000, 10),
            (3, cutoff - 10000, 11),
        ]:
            conn.execute(
                "INSERT INTO activity(activity_id, day_key, start_ms, duration_s) VALUES (?, ?, ?, ?)",
                (ident, str(DAY), start, duration),
            )
            raw(
                conn,
                "activity",
                str(ident),
                "activity",
                {"ownerId": 1, "nested": [{"PROFILEID": 3, "keep": 4}]},
            )
        raw(
            conn,
            "day",
            str(DAY),
            "stress_data",
            {
                "email": "secret",
                "stressValuesArray": [[cutoff - 1, 22], [cutoff, 99], [cutoff + 1, 88]],
            },
        )
        raw(
            conn,
            "day",
            str(DAY),
            "heart_rates",
            {"heartRateValues": [[cutoff - 1, 70], [cutoff, 90]]},
        )
        raw(conn, "day", str(DAY), "user_summary", {"totalSteps": 999})
    result = report_input.build(cfg, DAY)
    assert result.manifest["workouts"] == ["1"]
    assert list(result.activities) == ["1"]
    assert result.activities["1"]["activity"] == {"nested": [{"keep": 4}]}
    assert result.days[str(DAY)]["stress_data"]["stressValuesArray"] == [
        [cutoff - 1, 22]
    ]
    assert result.days[str(DAY)]["heart_rates"]["heartRateValues"] == [[cutoff - 1, 70]]
    assert "user_summary" not in result.days[str(DAY)]
    assert result.manifest["data_cutoff"] == "2026-10-27T11:00:00.000+09:00"
    assert result.manifest["workout_window"]["from"] == "2026-10-26T10:58:00.000+09:00"
    assert result.manifest["weekday"] == "화"
    assert result.manifest["yesterday"] == "2026-10-26"
    assert result.manifest["baseline_days"] == [f"2026-10-{i}" for i in range(20, 27)]
    assert result.manifest["sleep_night"]["file"] == "days/2026-10-27/sleep_data.json"
    assert result.manifest["period_windows"]["7d"]["from"] == "2026-10-21"
    assert (result.path / "scratch").is_dir()


def test_fresh_folder_missing_profile_invalid_sidecar_and_previous_report(write_config):
    cfg = config.load(write_config())
    old = cfg.data_dir / "report-input/2026-10-26"
    old.mkdir(parents=True)
    (old / "stale").write_text("old")
    bad = cfg.data_dir / "body/2026-10-27.json"
    bad.parent.mkdir()
    bad.write_text('{"measured_on":"2026-10-27","values":{"weight_kg":9999}}')
    cfg.reports_dir.mkdir()
    (cfg.reports_dir / "2026-10-26.md").write_text("previous")
    result = report_input.build(cfg, DAY, started_at=ms("2026-10-27 11:30"))
    assert not old.exists()
    assert result.body == []
    assert any("profile" in note for note in result.manifest["notes"])
    assert any("무효 사이드카" in note for note in result.manifest["notes"])
    assert result.manifest["workout_window"]["from"] == "2026-10-26T11:00:00.000+09:00"
    assert (result.path / "previous_report.md").read_text() == "previous"
    (result.path / "stale").write_text("stale")
    result = report_input.build(cfg, DAY)
    assert not (result.path / "stale").exists()
    assert json.loads((result.path / "manifest.json").read_text()) == result.manifest


def test_config_timezone_and_profile_path(write_config, tmp_path):
    cfg = config.load(write_config(timezone="UTC", profile_path="my-profile.md"))
    cfg.profile_path.write_text("my preferences")
    result = report_input.build(cfg, DAY, started_at=ms("2026-10-27 11:30"))
    assert result.manifest["data_cutoff"] == "2026-10-27T02:30:00.000+00:00"
    assert (result.path / "profile.md").read_text() == "my preferences"


def test_subminute_cutoff_is_preserved_in_export_and_digest(write_config):
    from garmin_pipeline import digest

    cfg = config.load(write_config())
    cutoff = ms("2026-10-27 11:00:30.500")
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO run(local_date, started_at, status, detail) VALUES (?, ?, 'success', '')",
            (str(DAY), cutoff),
        )
        raw(
            conn,
            "day",
            str(DAY),
            "stress_data",
            {
                "stressValueDescriptorsDTOList": [
                    {"key": "timestamp", "index": 0},
                    {"key": "stressLevel", "index": 1},
                ],
                "stressValuesArray": [[cutoff - 1000, 40], [cutoff, 90]],
            },
        )
    result = report_input.build(cfg, DAY)
    assert result.manifest["data_cutoff"] == "2026-10-27T11:00:30.500+09:00"
    doc = digest.build(
        result.manifest, result.days, result.activities, result.labels, result.body
    )
    assert doc["day"]["today_morning"]["stress_avg_samples"] == 40


def test_unfinished_workout_start_stops_prior_recovery_without_exporting_results(
    write_config,
):
    from garmin_pipeline import digest

    cfg = config.load(write_config())
    cutoff = ms("2026-10-27 11:00")
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO run(local_date, started_at, status, detail) VALUES (?, ?, 'success', '')",
            (str(DAY), cutoff),
        )
        for ident, start, duration in [
            (1, "2026-10-27 09:00", 1800),
            (2, "2026-10-27 10:50", 1800),
        ]:
            conn.execute(
                "INSERT INTO activity(activity_id, day_key, start_ms, duration_s) VALUES (?, ?, ?, ?)",
                (ident, str(DAY), ms(start), duration),
            )
            raw(
                conn,
                "activity",
                str(ident),
                "activity",
                {
                    "summaryDTO": {"startTimeGMT": ms(start), "duration": duration},
                    "activityTypeDTO": {"typeKey": "strength_training"},
                },
            )
        raw(
            conn,
            "day",
            str(DAY),
            "heart_rates",
            {
                "heartRateValueDescriptors": [
                    {"key": "timestamp", "index": 0},
                    {"key": "heartrate", "index": 1},
                ],
                "heartRateValues": [
                    [ms("2026-10-27 09:45"), 90],
                    [ms("2026-10-27 10:49"), 70],
                    [ms("2026-10-27 10:50"), 150],
                    [ms("2026-10-27 10:59"), 170],
                ],
            },
        )
    exported = report_input.build(cfg, DAY)
    assert exported.manifest["workouts"] == ["1"]
    assert list(exported.activities) == ["1"]
    assert not (exported.path / "activities/2").exists()
    doc = digest.build(
        exported.manifest,
        exported.days,
        exported.activities,
        exported.labels,
        exported.body,
    )
    assert len(doc["workouts"]) == 1
    recovery = doc["workouts"][0]["after"]
    assert recovery["samples"] == 2
    assert recovery["at_15m"] == 90
    assert recovery["lowest"]["bpm"] == 70


def test_period_windows_evaluation_selection_month_aggregation_and_short_history(
    write_config,
):
    cfg = config.load(write_config())
    with store.write_session(cfg) as conn:
        raw(conn, "day", "2026-09-30", "user_summary", {})
        for day, steps in [
            ("2026-09-30", 100),
            ("2026-10-20", 200),
            ("2026-10-21", 300),
            ("2026-10-27", 400),
        ]:
            conn.execute(
                "INSERT INTO day_summary(date,steps) VALUES (?,?)", (day, steps)
            )
        for scope, days in [
            ("day", ["2026-10-20", "2026-10-21", "2026-10-27", "2026-10-28"]),
            (
                "7d",
                [
                    "2026-10-01",
                    "2026-10-05",
                    "2026-10-10",
                    "2026-10-15",
                    "2026-10-20",
                    "2026-10-27",
                    "2026-10-28",
                ],
            ),
            (
                "30d",
                ["2026-09-01", "2026-09-30", "2026-10-01", "2026-10-27", "2026-10-28"],
            ),
        ]:
            for day in days:
                conn.execute(
                    "INSERT INTO evaluation VALUES (?,?,?,?,?,?,?,?,?)",
                    (
                        day,
                        scope,
                        day,
                        '["판단"]',
                        "[]",
                        '["확인"]',
                        "private report body",
                        "model",
                        1,
                    ),
                )
        conn.execute(
            "INSERT INTO evaluation VALUES ('2026-10-26','day','yesterday','[]','[]','[]','private','model',1)"
        )
        conn.execute(
            "INSERT INTO evaluation VALUES ('2026-10-26','7d','yesterday week','[]','[]','[]','private','model',1)"
        )
        conn.execute(
            "INSERT INTO workout(activity_id,date,duration_s) VALUES (1,'2026-10-21',300)"
        )
        conn.execute(
            "INSERT INTO exercise_log(activity_id,exercise,max_kg,volume_kg) VALUES (1,'스쿼트',20,200)"
        )
    exported = report_input.build(cfg, DAY)
    assert (
        json.loads((exported.path / "previous_evaluations/day.json").read_text())[
            "summary"
        ]
        == "yesterday"
    )
    assert (
        json.loads((exported.path / "previous_evaluations/7d.json").read_text())[
            "summary"
        ]
        == "yesterday week"
    )
    folder = report_input.build_period(cfg, exported.path, DAY, "7d")
    scope = json.loads((folder / "scope.json").read_text())
    assert scope["from"] == "2026-10-21" and scope["to"] == str(DAY)
    assert scope["actual_days"] == 2
    assert scope["partial_date"]["date"] == str(DAY)
    values = json.loads((folder / "day_values.json").read_text())
    assert [r["date"] for r in values["day_summary"]] == ["2026-10-21", "2026-10-27"]
    evaluations = json.loads((folder / "evaluations.json").read_text())
    assert [e["report_date"] for e in evaluations] == [
        "2026-10-21",
        "2026-10-26",
        "2026-10-27",
    ]
    assert all("report_md" not in e for e in evaluations)
    assert (
        json.loads((folder / "previous.json").read_text())["report_date"]
        == "2026-10-26"
    )
    folder = report_input.build_period(cfg, exported.path, DAY, "30d")
    assert len(json.loads((folder / "evaluations.json").read_text())) == 5
    assert (
        json.loads((folder / "evaluations.json").read_text())[0]["report_date"]
        == "2026-10-27"
    )
    folder = report_input.build_period(cfg, exported.path, DAY, "all")
    values = json.loads((folder / "day_values.json").read_text())
    assert [(r["month"], r["days"], r["steps"]) for r in values["months"]] == [
        ("2026-09", 1, 100),
        ("2026-10", 3, 300),
    ]
    assert values["workouts"][0]["duration_s"] == 300
    assert values["exercises"][0]["max_kg"] == 20
    assert [
        e["report_date"] for e in json.loads((folder / "evaluations.json").read_text())
    ] == ["2026-09-30", "2026-10-27"]


def test_previous_evaluations_are_exactly_yesterday_and_absence_is_noted(write_config):
    cfg = config.load(write_config())
    with store.write_session(cfg) as conn:
        conn.execute(
            "INSERT INTO evaluation VALUES ('2026-10-25','day','old','[]','[]','[]','private','m',1)"
        )
    exported = report_input.build(cfg, DAY)
    assert not (exported.path / "previous_evaluations/day.json").exists()
    assert "어제 day 평가가 없다" in exported.manifest["notes"]
    assert "어제 7d 평가가 없다" in exported.manifest["notes"]


def test_weight_lifestyle_raws_export_through_day_folder(write_config):
    cfg = config.load(write_config())
    payloads = {
        "daily_weigh_ins": {
            "dateWeightList": [
                {"timestampGMT": ms("2026-10-27 08:00"), "weight": 80000}
            ]
        },
        "lifestyle_logging_data": {
            "dailyLogsReport": [
                {
                    "name": "Alcohol",
                    "logStatus": "YES",
                    "measurementType": "QUANTITY",
                    "details": [{"subTypeName": "WINE", "amount": 2}],
                }
            ]
        },
    }
    with store.write_session(cfg) as conn:
        for endpoint, payload in payloads.items():
            raw(conn, "day", str(DAY), endpoint, payload)
    result = report_input.build(cfg, DAY)
    for endpoint, payload in payloads.items():
        assert result.days[str(DAY)][endpoint] == payload
        assert (
            json.loads(
                (result.path / "days" / str(DAY) / f"{endpoint}.json").read_text()
            )
            == payload
        )
