"""원본 응답 보존: 마이그레이션 `0002_raw_response`와 `store.upsert_raw`(FR6·7, AD-3).

모두 패키지의 실제 마이그레이션 위에서 `write_session`으로 돈다.
"""

import json
import sqlite3
from collections.abc import Callable
from pathlib import Path

import pytest
import schema_version

from garmin_pipeline import config, garmin, store

T1 = 1_760_000_000_000
T2 = T1 + 86_400_000
V1 = "0.3.17"
V2 = "0.3.18"
WHERE = {"scope": "day", "key": "2026-10-16", "endpoint": "sleep_data"}
# 한글과 일부러 정렬하지 않은 키 순서: 원문은 `ensure_ascii=False`로 키 순서 그대로 저장한다.
PAYLOAD = {"zeta": 1, "alpha": [1, 2], "메모": "수면", "nested": {"b": None, "a": 1.5}}
OTHER = {"zeta": 2, "alpha": [], "메모": "수면", "nested": {"b": None, "a": 1.5}}
COLUMNS = "scope, key, endpoint, raw, fetched_at, checked_at, library_version"


@pytest.fixture
def cfg(write_config: Callable[..., Path]) -> config.Config:
    return config.load(write_config(lock_wait_seconds=0))


def _upsert(
    conn: sqlite3.Connection,
    payload: object,
    now_ms: int,
    library_version: str = V1,
    **where: str,
) -> None:
    store.upsert_raw(
        conn,
        **(WHERE | where),
        payload=payload,
        library_version=library_version,
        now_ms=now_ms,
    )


def _rows(conn: sqlite3.Connection) -> list[tuple[object, ...]]:
    return conn.execute(
        f"SELECT {COLUMNS} FROM raw_response ORDER BY scope, key, endpoint"
    ).fetchall()


def _row(raw: str, fetched_at: int, checked_at: int, version: str = V1) -> tuple:
    return (*WHERE.values(), raw, fetched_at, checked_at, version)


def _raw(payload: object) -> str:
    return json.dumps(payload, ensure_ascii=False)


def test_migration_creates_raw_response_table(cfg: config.Config):
    with store.write_session(cfg) as conn:
        columns = conn.execute("PRAGMA table_info(raw_response)").fetchall()

    assert [(name, kind, notnull, pk) for _, name, kind, notnull, _, pk in columns] == [
        ("scope", "TEXT", 1, 1),
        ("key", "TEXT", 1, 2),
        ("endpoint", "TEXT", 1, 3),
        ("raw", "TEXT", 1, 0),
        ("fetched_at", "INTEGER", 1, 0),
        ("checked_at", "INTEGER", 1, 0),
        ("library_version", "TEXT", 1, 0),
    ]


def test_version_1_db_migrates_to_latest_and_keeps_auth_event(cfg: config.Config):
    # 1.7까지의 DB: 0001만 적용되고 auth_event 행이 있다.
    sql_0001 = (
        Path(store.__file__).parent / "migrations" / "0001_auth_event.sql"
    ).read_text(encoding="utf-8")
    cfg.data_dir.mkdir(parents=True)
    conn = sqlite3.connect(cfg.db_path)
    try:
        conn.executescript(sql_0001)
        conn.execute("INSERT INTO auth_event VALUES (1, '2026-10-15', ?)", (T1,))
        conn.execute("PRAGMA user_version = 1")
        conn.commit()
    finally:
        conn.close()

    with store.write_session(cfg) as conn:
        assert conn.execute("PRAGMA user_version").fetchone() == (
            schema_version.LATEST,
        )
        assert _rows(conn) == []

    reader = store.read_connection(cfg)
    try:
        assert reader.execute("PRAGMA user_version").fetchone() == (
            schema_version.LATEST,
        )
        assert reader.execute("SELECT * FROM auth_event").fetchall() == [
            (1, "2026-10-15", T1)
        ]
    finally:
        reader.close()


def test_first_save_inserts_one_row(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(conn, PAYLOAD, T1)

        assert _rows(conn) == [_row(_raw(PAYLOAD), T1, T1)]


def test_raw_text_keeps_key_order_and_non_ascii(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(conn, PAYLOAD, T1)
        (raw,) = conn.execute("SELECT raw FROM raw_response").fetchone()

    assert (
        raw
        == '{"zeta": 1, "alpha": [1, 2], "메모": "수면", "nested": {"b": null, "a": 1.5}}'
    )
    assert json.loads(raw) == PAYLOAD


def test_same_raw_only_updates_checked_at(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(conn, PAYLOAD, T1, V1)
        # 내용이 같으면 버전이 달라도 원문을 받은 버전은 그대로다.
        _upsert(conn, json.loads(_raw(PAYLOAD)), T2, V2)

        assert _rows(conn) == [_row(_raw(PAYLOAD), T1, T2, V1)]


def test_different_raw_replaces_raw_times_and_version(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(conn, PAYLOAD, T1, V1)
        _upsert(conn, OTHER, T2, V2)

        assert _rows(conn) == [_row(_raw(OTHER), T2, T2, V2)]


def test_reordered_keys_count_as_different_raw(cfg: config.Config):
    reordered = dict(reversed(PAYLOAD.items()))
    assert reordered == PAYLOAD

    with store.write_session(cfg) as conn:
        _upsert(conn, PAYLOAD, T1)
        _upsert(conn, reordered, T2)

        assert _rows(conn) == [_row(_raw(reordered), T2, T2)]


def test_no_data_over_data_only_updates_checked_at(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(conn, PAYLOAD, T1, V1)
        _upsert(conn, None, T2, V2)

        assert _rows(conn) == [_row(_raw(PAYLOAD), T1, T2, V1)]


@pytest.mark.parametrize(
    "payload", [[], {}, 0, ""], ids=["list", "dict", "zero", "str"]
)
def test_empty_but_not_none_payload_is_data(cfg: config.Config, payload: object):
    # NoData는 `None`뿐이다. 빈 리스트 같은 값은 원문이 바뀐 것으로 본다.
    with store.write_session(cfg) as conn:
        _upsert(conn, PAYLOAD, T1, V1)
        _upsert(conn, payload, T2, V2)

        assert _rows(conn) == [_row(_raw(payload), T2, T2, V2)]


def test_first_no_data_stores_null(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(conn, None, T1)

        assert _rows(conn) == [_row("null", T1, T1)]


def test_no_data_over_null_only_updates_checked_at(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(conn, None, T1, V1)
        _upsert(conn, None, T2, V2)

        assert _rows(conn) == [_row("null", T1, T2, V1)]


def test_data_over_null_replaces_raw_and_times(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(conn, None, T1, V1)
        _upsert(conn, PAYLOAD, T2, V2)

        assert _rows(conn) == [_row(_raw(PAYLOAD), T2, T2, V2)]


# 짝 없는 UTF-16 surrogate: `ensure_ascii=False` 텍스트는 UTF-8로 인코딩되지 않아 sqlite가 받지 못한다.
LONE_SURROGATE = {"note": "\ud83d", "메모": "수면"}


def test_unencodable_raw_is_stored_ascii_escaped(cfg: config.Config):
    with pytest.raises(UnicodeEncodeError):
        _raw(LONE_SURROGATE).encode("utf-8")
    escaped = json.dumps(LONE_SURROGATE, ensure_ascii=True)

    with store.write_session(cfg) as conn:
        _upsert(conn, LONE_SURROGATE, T1)

        assert _rows(conn) == [_row(escaped, T1, T1)]
        (raw,) = conn.execute("SELECT raw FROM raw_response").fetchone()
    assert raw == '{"note": "\\ud83d", "\\uba54\\ubaa8": "\\uc218\\uba74"}'
    assert json.loads(raw) == LONE_SURROGATE


def test_same_unencodable_payload_only_updates_checked_at(cfg: config.Config):
    escaped = json.dumps(LONE_SURROGATE, ensure_ascii=True)

    with store.write_session(cfg) as conn:
        _upsert(conn, LONE_SURROGATE, T1, V1)
        _upsert(conn, dict(LONE_SURROGATE), T2, V2)

        assert _rows(conn) == [_row(escaped, T1, T2, V1)]


def test_encodable_payload_keeps_non_ascii_text(cfg: config.Config):
    # 예외는 UTF-8로 인코딩되지 않는 원문뿐이다. 짝이 맞는 이모지·한글은 그대로 저장한다.
    payload = {"note": "\U0001f600", "메모": "수면"}

    with store.write_session(cfg) as conn:
        _upsert(conn, payload, T1)

        assert _rows(conn) == [_row('{"note": "\U0001f600", "메모": "수면"}', T1, T1)]


def test_invalid_scope_is_integrity_error_and_writes_nothing(cfg: config.Config):
    with store.write_session(cfg) as conn:
        with pytest.raises(sqlite3.IntegrityError):
            _upsert(conn, PAYLOAD, T1, scope="week")

        assert _rows(conn) == []


def test_rows_are_separate_per_scope_key_endpoint(cfg: config.Config):
    with store.write_session(cfg) as conn:
        _upsert(conn, PAYLOAD, T1)
        _upsert(conn, OTHER, T1, endpoint="hrv_data")
        _upsert(conn, OTHER, T1, key="2026-10-17")
        _upsert(conn, None, T1, scope="activity", key="2026-10-16")
        _upsert(conn, None, T2)

        rows = _rows(conn)

    assert [row[:3] for row in rows] == [
        ("activity", "2026-10-16", "sleep_data"),
        ("day", "2026-10-16", "hrv_data"),
        ("day", "2026-10-16", "sleep_data"),
        ("day", "2026-10-17", "sleep_data"),
    ]
    assert rows[2] == _row(_raw(PAYLOAD), T1, T2)


def test_upsert_does_not_open_a_transaction(cfg: config.Config):
    # 호출자가 연 트랜잭션 안에서 부르고, 롤백하면 함께 사라진다.
    with store.write_session(cfg) as conn:
        with pytest.raises(RuntimeError), store.transaction(conn):
            _upsert(conn, PAYLOAD, T1)
            assert conn.in_transaction
            raise RuntimeError
        assert _rows(conn) == []

        _upsert(conn, PAYLOAD, T1)
        assert not conn.in_transaction

    reader = store.read_connection(cfg)
    try:
        assert len(reader.execute("SELECT * FROM raw_response").fetchall()) == 1
    finally:
        reader.close()


def test_adapter_raw_response_fits_upsert(cfg: config.Config):
    response = garmin.RawResponse("activity", {"activityId": 1}, garmin.LIBRARY_VERSION)

    with store.write_session(cfg) as conn:
        store.upsert_raw(
            conn,
            scope="activity",
            key=str(1),
            endpoint=response.endpoint,
            payload=response.payload,
            library_version=response.library_version,
            now_ms=T1,
        )

        assert _rows(conn) == [
            (
                "activity",
                "1",
                "activity",
                '{"activityId": 1}',
                T1,
                T1,
                garmin.LIBRARY_VERSION,
            )
        ]
