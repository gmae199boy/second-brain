"""Trial measurement parity and regression coverage for the five corrected bugs."""

import copy
import json
import subprocess
import sys
from datetime import UTC, date, datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

import pytest

from garmin_pipeline import config, digest, normalize, report_input, store

DAY = "2026-10-27"


def ms(text):
    return int(
        datetime.fromisoformat(text).replace(tzinfo=ZoneInfo("Asia/Seoul")).timestamp()
        * 1000
    )


def manifest(**overrides):
    return {
        "report_date": DAY,
        "yesterday": "2026-10-26",
        "weekday": "화",
        "timezone": "Asia/Seoul",
        "data_cutoff": "2026-10-27T11:00:30.500+09:00",
        "baseline_days": [],
        "workouts": [],
        "notes": [],
        **overrides,
    }


def activity(start, duration=60, points=(), sets=()):
    return {
        "activity": {
            "summaryDTO": {"startTimeGMT": ms(start), "duration": duration},
            "activityTypeDTO": {"typeKey": "strength_training"},
        },
        "activity_details": {
            "metricDescriptors": [
                {"key": "directTimestamp", "metricsIndex": 0},
                {"key": "directHeartRate", "metricsIndex": 1},
            ],
            "activityDetailMetrics": [{"metrics": [ms(t), v]} for t, v in points],
        },
        "activity_exercise_sets": {"exerciseSets": list(sets)},
    }


def heart(points):
    return {
        "heartRateValueDescriptors": [
            {"key": "timestamp", "index": 0},
            {"key": "heartrate", "index": 1},
        ],
        "heartRateValues": [[ms(t), v] for t, v in points],
    }


def test_set_peak_includes_42_seconds_after_end_but_excludes_next_start():
    sets = [
        {
            "setType": "ACTIVE",
            "startTime": ms("2026-10-27 08:00"),
            "duration": 30,
            "repetitionCount": 8,
            "weight": 16000,
        },
        {"setType": "ACTIVE", "startTime": ms("2026-10-27 08:01:20"), "duration": 30},
    ]
    acts = {
        "1": activity(
            "2026-10-27 08:00",
            duration=120,
            points=[
                ("2026-10-27 08:00:10", 110),
                ("2026-10-27 08:01:12", 155),
                ("2026-10-27 08:01:20", 190),
            ],
            sets=sets,
        )
    }
    out = digest.build(manifest(workouts=["1"]), {}, acts, {}, [])
    first = out["workouts"][0]["detail"][0]["sets"][0]
    assert first["set_peak_hr"] == 155
    assert first["set_peak_after_end_s"] == 42
    assert first["next_start_hr"] == 190
    assert (first["reps"], first["weight_kg"], first["duration_s"]) == (8, 16, 30)


def test_morning_uses_only_awake_before_precise_cutoff_and_keeps_inputs_pure():
    days = {
        DAY: {
            "sleep_data": {
                "dailySleepDTO": {
                    "sleepTimeSeconds": 8 * 3600,
                    "sleepStartTimestampGMT": ms("2026-10-26 23:00"),
                    "sleepEndTimestampGMT": ms("2026-10-27 07:00"),
                }
            },
            "stress_data": {
                "stressValueDescriptorsDTOList": [
                    {"key": "timestamp", "index": 0},
                    {"key": "stressLevel", "index": 1},
                ],
                "stressValuesArray": [
                    [ms("2026-10-27 06:59"), 99],
                    [ms("2026-10-27 07:00"), 20],
                    [ms("2026-10-27 11:00:15"), 40],
                    [ms("2026-10-27 11:00:30.500"), 90],
                    [ms("2026-10-27 11:01"), 100],
                ],
            },
        }
    }
    before = copy.deepcopy(days)
    first = digest.build(manifest(), days, {}, {}, [])
    assert first["day"]["today_morning"]["stress_avg_samples"] == 30
    assert first["day"]["today_morning"]["stress_high_samples"] == "0:00"
    assert days == before
    second = digest.build(manifest(), {}, {}, {}, [])
    assert first["notes"] is not second["notes"]
    assert not any("sleep_for:" in n for n in second["notes"])


@pytest.mark.parametrize("stress_data", [None, {}, {"stressValuesArray": []}])
def test_morning_without_stress_samples_has_no_high_stress_value(stress_data):
    doc = digest.build(manifest(), {DAY: {"stress_data": stress_data}}, {}, {}, [])

    morning = doc["day"]["today_morning"]
    assert morning["stress_high_samples"] is None
    assert morning["stress_measured_samples"] == "0:00"


def test_previous_evening_session_and_recovery_cross_midnight_stop_at_next_workout():
    acts = {
        "1": activity("2026-10-26 23:50", duration=5 * 60),
        "2": activity("2026-10-27 00:20", duration=60),
    }
    days = {
        "2026-10-26": {"heart_rates": heart([("2026-10-26 23:56", 120)])},
        DAY: {
            "heart_rates": heart(
                [
                    ("2026-10-27 00:10", 90),
                    ("2026-10-27 00:20", 180),
                    ("2026-10-27 11:00:30.500", 40),
                ]
            )
        },
    }
    out = digest.build(manifest(workouts=["1", "2"]), days, acts, {}, [])
    first, second = out["workouts"]
    assert first["date"] == "2026-10-26"
    assert first["after"]["samples"] == 2
    assert first["after"]["at_15m"] == 90
    assert first["after"]["lowest"]["bpm"] == 90
    assert second["after"]["samples"] == 0


def test_bad_shapes_become_null_and_notes():
    out = digest.build(
        manifest(),
        {DAY: {"sleep_data": {"dailySleepDTO": [1]}, "stress_data": []}},
        {},
        {},
        [],
    )
    assert out["sleep"]["last_night"] is None
    assert out["notes"]


def test_import_does_not_load_services_or_plotting():
    proc = subprocess.run(
        [
            sys.executable,
            "-c",
            "import sys; import garmin_pipeline.digest; assert not {'garminconnect','requests','matplotlib','sqlite3'} & sys.modules.keys()",
        ],
        capture_output=True,
        check=False,
        text=True,
    )
    assert proc.returncode == 0, proc.stderr


def test_real_fixture_measurements_match_normalized_tables(write_config):
    fixture = Path(__file__).parent / "fixtures/garmin"
    sleep_files = sorted((fixture / "sleep_data").glob("*.json"))
    if not sleep_files:
        pytest.skip("local Garmin fixtures unavailable")
    cfg = config.load(write_config())
    with store.write_session(cfg) as conn:
        for endpoint_dir in sorted(fixture.iterdir()):
            if not endpoint_dir.is_dir():
                continue
            scope = (
                "activity"
                if endpoint_dir.name.startswith("activity")
                and endpoint_dir.name != "activities_by_date"
                else "day"
            )
            for path in sorted(endpoint_dir.glob("*.json")):
                store.upsert_raw(
                    conn,
                    scope=scope,
                    key=path.stem,
                    endpoint=endpoint_dir.name,
                    payload=json.loads(path.read_text()),
                    library_version="test",
                    now_ms=1,
                )
        normalize.run(conn)
    # Pick a recorded day and export the following date so user_summary is complete.
    report_day = date.fromisoformat(sleep_files[-1].stem) + timedelta(days=1)
    exported = report_input.build(cfg, report_day, started_at=ms(f"{report_day} 11:00"))
    inp = digest._Digest(
        exported.manifest, exported.days, exported.activities, exported.labels, []
    )
    checked_sleep = checked_bb = checked_sets = 0
    with store.read_connection(cfg) as conn:
        for day_key, sleep_s, deep, light, rem, awake, score in conn.execute(
            "SELECT day_key, sleep_s, deep_sleep_s, light_sleep_s, rem_sleep_s, awake_sleep_s, sleep_score FROM daily_metric"
        ):
            measured = inp.sleep_for(inp, day_key)
            if measured:
                assert [
                    measured[k]
                    for k in (
                        "total_s",
                        "deep_s",
                        "light_s",
                        "rem_s",
                        "awake_s",
                        "score",
                    )
                ] == [sleep_s, deep, light, rem, awake, score]
                stored = conn.execute(
                    "SELECT sleep_total_s,sleep_deep_s,sleep_light_s,sleep_rem_s,sleep_awake_s,sleep_score FROM day_summary WHERE date=?",
                    (day_key,),
                ).fetchone()
                assert list(stored) == [sleep_s, deep, light, rem, awake, score]
                checked_sleep += 1
        # Compare stress_data samples with stress_bb_sample: same source. bb_charged,
        # bb_drained/high/low in daily_metric come from body_battery, so omit them.
        for day_key, ts, value in conn.execute(
            "SELECT day_key, ts_ms, level FROM stress_bb_sample WHERE level IS NOT NULL"
        ):
            _, points = inp.stress_points(inp.day(day_key, "stress_data"))
            if points:
                assert dict(points)[datetime.fromtimestamp(ts / 1000, UTC)] == value
                checked_bb += 1
        for ident in inp.activity_ids():
            rec = inp.activity_record(inp, ident)
            if rec is None:
                continue
            calculated = inp.sets_for(inp, rec)
            recorded = conn.execute(
                "SELECT reps, weight_g, duration_s FROM exercise_set WHERE activity_id=? AND is_rest=0 ORDER BY set_index",
                (ident,),
            ).fetchall()
            for measured, (reps, grams, duration) in zip(
                calculated, recorded, strict=True
            ):
                assert measured["reps"] == reps
                # Trial treats zero/-1 as unrecorded/bodyweight; compare positive weights.
                if grams and grams > 0:
                    assert measured["weight_kg"] == round(grams / 1000, 1)
                assert measured["duration_s"] == duration
                checked_sets += 1
    assert checked_sleep > 0
    assert checked_bb > 0
    assert checked_sets > 0


def test_missing_endpoint_notes_are_deduplicated_and_empty_optional_data_is_not_missing():
    inp = digest._Digest(
        manifest(),
        {DAY: {"activities_by_date": None, "training_readiness": []}},
        {},
        {},
        [],
    )
    for _ in range(3):
        assert inp.day(DAY, "rhr_day") is None
        assert inp.day(DAY, "activities_by_date") is None
        assert inp.day(DAY, "training_readiness") == []
    assert inp.notes == [f"{DAY} rhr_day: 원본이 없다"]


def test_gmt_parser_preserves_fractional_milliseconds():
    inp = digest._Digest(manifest(), {}, {}, {}, [])
    parsed = inp.to_utc("2026-10-27T02:00:30.500")
    assert parsed.microsecond == 500000
    assert parsed == datetime(2026, 10, 27, 2, 0, 30, 500000, tzinfo=UTC)


def test_malformed_set_reps_are_null_without_losing_other_sets_or_measurements():
    sets = [
        {
            "setType": "ACTIVE",
            "startTime": ms("2026-10-27 08:00"),
            "duration": 30,
            "repetitionCount": "eight",
            "weight": 16000,
        },
        {
            "setType": "ACTIVE",
            "startTime": ms("2026-10-27 08:02"),
            "duration": 40,
            "repetitionCount": 10,
            "weight": 20000,
        },
    ]
    acts = {
        "1": activity(
            "2026-10-27 08:00",
            duration=180,
            points=[("2026-10-27 08:00:10", 120)],
            sets=sets,
        )
    }
    before = copy.deepcopy(acts)
    doc = digest.build(manifest(workouts=["1"]), {}, acts, {}, [])
    measured = doc["workouts"][0]["detail"][0]["sets"]
    assert measured[0]["reps"] is None
    assert measured[0]["weight_kg"] == 16
    assert measured[0]["duration_s"] == 30
    assert measured[0]["set_peak_hr"] == 120
    assert measured[1]["reps"] == 10
    assert measured[1]["weight_kg"] == 20
    totals = doc["workouts"][0]["detail"][0]["exercise_totals"][0]
    assert totals["reps"] is None
    assert totals["volume_kg"] is None
    assert acts == before
    notes = [n for n in doc["notes"] if "repetitionCount" in n]
    assert len(notes) == 1


def test_malformed_daily_numeric_values_are_null_and_unaffected_values_survive():
    summary = {
        "totalSteps": "many",
        "activeKilocalories": 450,
        "highStressDuration": "bad",
        "mediumStressDuration": 600,
        "bodyBatteryHighestValue": True,
        "vigorousIntensityMinutes": float("inf"),
        "bodyBatteryChargedValue": 40,
    }
    days = {"2026-10-26": {"user_summary": summary}}
    before = copy.deepcopy(days)
    doc = digest.build(manifest(baseline_days=["2026-10-26"]), days, {}, {}, [])
    yesterday = doc["day"]["yesterday"]
    assert yesterday["steps"] is None
    assert yesterday["stress_high_s"] is yesterday["stress_high"] is None
    assert yesterday["bb_high"] is None
    assert yesterday["vigorous_min"] is None
    assert yesterday["active_kcal"] == 450
    assert yesterday["stress_medium"] == "0:10"
    assert yesterday["bb_charged"] == 40
    assert doc["day"]["baseline"]["active_kcal"]["mean"] == 450
    assert days == before
    for field in (
        "totalSteps",
        "highStressDuration",
        "bodyBatteryHighestValue",
        "vigorousIntensityMinutes",
    ):
        assert len([n for n in doc["notes"] if field in n]) == 1


def test_day_values_share_digest_measurements_and_session_numbering():
    raw = {
        "sleep_data": {
            "dailySleepDTO": {
                "sleepTimeSeconds": 7200,
                "deepSleepSeconds": 1200,
                "lightSleepSeconds": 4800,
                "remSleepSeconds": 1200,
                "awakeSleepSeconds": 60,
            },
            "avgOvernightHrv": 44,
        },
        "user_summary": {
            "totalSteps": 8123,
            "activeKilocalories": 420,
            "averageStressLevel": 23,
        },
    }
    acts = {
        "1": activity("2026-10-27 08:00"),
        "2": activity("2026-10-27 08:05"),
        "3": activity("2026-10-27 09:00"),
    }
    values = digest.day_values(DAY, raw, acts, {}, "Asia/Seoul")
    built = digest.build(manifest(workouts=list(acts)), {DAY: raw}, acts, {}, [])
    assert (
        values["day_summary"]["sleep_total_s"]
        == built["sleep"]["last_night"]["total_s"]
    )
    next_day = digest.build(
        manifest(report_date="2026-10-28", yesterday=DAY), {DAY: raw}, acts, {}, []
    )
    assert values["day_summary"]["steps"] == next_day["day"]["yesterday"]["steps"]
    for saved, session in zip(
        values["workouts"],
        [part for group in built["workouts"] for part in group["detail"]],
        strict=True,
    ):
        assert saved["duration_s"] == session["duration_s"]
    engine = digest._Digest(manifest(), {DAY: raw}, acts, {}, [])
    sleep = engine.sleep_for(engine, DAY)
    full = engine.full_day(engine, DAY)
    assert values["day_summary"]["sleep_total_s"] == sleep["total_s"]
    assert values["day_summary"]["sleep_deep_s"] == sleep["deep_s"]
    assert values["day_summary"]["hrv_avg"] == sleep["hrv_avg"]
    assert values["day_summary"]["active_kcal"] == full["active_kcal"]
    assert values["day_summary"]["steps"] == full["steps"]
    assert values["day_summary"]["weight_kg"] is None
    assert values["day_summary"]["drinks_json"] is None
    assert [w["session_no"] for w in values["workouts"]] == [1, 1, 2]
    for workout in values["workouts"]:
        rec = engine.activity_record(engine, str(workout["activity_id"]))
        assert workout["duration_s"] == rec["duration_s"]
