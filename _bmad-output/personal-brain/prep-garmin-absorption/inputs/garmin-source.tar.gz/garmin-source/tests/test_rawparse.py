"""`rawparse.activity_refs`: 보존된 `activities_by_date` 원문에서 (activityId, 일 키, 세트 필요) 목록(AD-4).

입력은 합성한 활동 목록이다(실제 계정 응답은 `tests/fixtures/garmin/`에만 두고 커밋하지 않는다).
"""

import json
from pathlib import Path

import pytest

from garmin_pipeline import rawparse
from garmin_pipeline.rawparse import ActivityRef, RawParseError

# 합성 활동 목록. 실제 응답처럼 다른 키가 섞여 있고, 마지막 활동은 23:50 로컬에 시작했다.
# GMT 시각으로는 다음 날이 아니라 앞 날이지만 일 키는 `startTimeLocal`의 날짜만 본다.
ACTIVITIES = [
    {
        "activityId": 20_000_000_001,
        "activityName": "아침 달리기",
        "startTimeLocal": "2026-10-16 06:30:00",
        "startTimeGMT": "2026-10-15 21:30:00",
        "activityType": {"typeKey": "running"},
        "duration": 1800.5,
    },
    {
        "activityId": 20_000_000_002,
        "activityName": "저녁 걷기",
        "startTimeLocal": "2026-10-16 23:50:00",
        "startTimeGMT": "2026-10-16 14:50:00",
        "activityType": {"typeKey": "walking"},
    },
]
# 원문과 같은 꼴: 키 순서 그대로, 한글 그대로.
RAW = json.dumps(ACTIVITIES, ensure_ascii=False)
SECRET = "비밀메모-7f3a"


def _raw(items: object) -> str:
    return json.dumps(items, ensure_ascii=False)


def test_activity_list_gives_id_and_local_start_day():
    assert rawparse.activity_refs(RAW) == [
        ActivityRef(20_000_000_001, "2026-10-16"),
        ActivityRef(20_000_000_002, "2026-10-16"),
    ]


def test_activity_ref_is_a_named_tuple():
    (ref, _) = rawparse.activity_refs(RAW)

    assert isinstance(ref, tuple)
    assert ref.activity_id == 20_000_000_001
    assert ref.day_key == "2026-10-16"
    assert type(ref.activity_id) is int


def test_late_night_activity_keeps_its_local_start_day():
    raw = _raw(
        [
            {"activityId": 7, "startTimeLocal": "2026-10-15 23:50:00"},
            {"activityId": 8, "startTimeLocal": "2026-10-16 00:05:00"},
        ]
    )

    assert rawparse.activity_refs(raw) == [
        ActivityRef(7, "2026-10-15"),
        ActivityRef(8, "2026-10-16"),
    ]


@pytest.mark.parametrize("raw", ["null", "[]"])
def test_null_and_empty_list_are_empty(raw: str):
    assert rawparse.activity_refs(raw) == []


def test_duplicate_ids_keep_first_and_order():
    raw = _raw(
        [
            {"activityId": 3, "startTimeLocal": "2026-10-16 09:00:00"},
            {"activityId": 1, "startTimeLocal": "2026-10-16 10:00:00"},
            {"activityId": 3, "startTimeLocal": "2026-10-17 11:00:00"},
            {"activityId": 2, "startTimeLocal": "2026-10-16 12:00:00"},
        ]
    )

    assert rawparse.activity_refs(raw) == [
        ActivityRef(3, "2026-10-16"),
        ActivityRef(1, "2026-10-16"),
        ActivityRef(2, "2026-10-16"),
    ]


@pytest.mark.parametrize(
    "start",
    ["2026-10-16", "2026-10-16T23:50:00", "2026-10-16 23:50:00.0"],
    ids=["date-only", "iso-t", "fraction"],
)
def test_start_time_variants_with_valid_date_part(start: str):
    raw = _raw([{"activityId": 1, "startTimeLocal": start}])

    assert rawparse.activity_refs(raw) == [ActivityRef(1, "2026-10-16")]


def test_raw_parse_error_is_value_error():
    assert issubclass(RawParseError, ValueError)


@pytest.mark.parametrize(
    ("items", "position"),
    [
        pytest.param({"activityId": 1, "memo": SECRET}, None, id="dict-top-level"),
        pytest.param(SECRET, None, id="str-top-level"),
        pytest.param(
            [{"activityId": 1, "startTimeLocal": "2026-10-16 06:00:00"}, SECRET],
            "[1]",
            id="item-not-dict",
        ),
        pytest.param(
            [{"startTimeLocal": "2026-10-16 06:00:00", "memo": SECRET}],
            "[0]",
            id="missing-id",
        ),
        pytest.param(
            [{"activityId": True, "startTimeLocal": "2026-10-16 06:00:00"}],
            "[0]",
            id="bool-id",
        ),
        pytest.param(
            [{"activityId": "123", "startTimeLocal": "2026-10-16 06:00:00"}],
            "[0]",
            id="str-id",
        ),
        pytest.param(
            [{"activityId": 1.0, "startTimeLocal": "2026-10-16 06:00:00"}],
            "[0]",
            id="float-id",
        ),
        pytest.param(
            [{"activityId": None, "startTimeLocal": "2026-10-16 06:00:00"}],
            "[0]",
            id="null-id",
        ),
        pytest.param(
            [
                {"activityId": 1, "startTimeLocal": "2026-10-16 06:00:00"},
                {"activityId": 2, "memo": SECRET},
            ],
            "[1]",
            id="missing-start",
        ),
        pytest.param(
            [{"activityId": 1, "startTimeLocal": SECRET}], "[0]", id="start-not-date"
        ),
        pytest.param(
            [{"activityId": 1, "startTimeLocal": "2026-13-01 06:00:00"}],
            "[0]",
            id="start-bad-month",
        ),
        pytest.param(
            [{"activityId": 1, "startTimeLocal": "2026-02-30 06:00:00"}],
            "[0]",
            id="start-bad-day",
        ),
        pytest.param(
            [{"activityId": 1, "startTimeLocal": "20261016 060000"}],
            "[0]",
            id="start-basic-format",
        ),
        pytest.param(
            [{"activityId": 1, "startTimeLocal": "2026-W42-5 06:00"}],
            "[0]",
            id="start-week-date",
        ),
        pytest.param(
            [{"activityId": 1, "startTimeLocal": "2026-10-1606:00:00"}],
            "[0]",
            id="start-no-separator",
        ),
        pytest.param(
            [{"activityId": 1, "startTimeLocal": 1_760_000_000_000}],
            "[0]",
            id="start-number",
        ),
        pytest.param(
            [{"activityId": 1, "startTimeLocal": None}], "[0]", id="start-null"
        ),
    ],
)
def test_malformed_list_raises_without_raw_content(items: object, position: str | None):
    with pytest.raises(RawParseError) as caught:
        rawparse.activity_refs(_raw(items))

    message = str(caught.value)
    assert SECRET not in message
    if position is not None:
        assert position in message
    # 원문 조각을 담은 다른 예외가 원인으로 붙지 않는다.
    assert caught.value.__cause__ is None
    assert caught.value.__context__ is None


def test_non_json_raw_raises_without_raw_content():
    with pytest.raises(RawParseError) as caught:
        rawparse.activity_refs(f'[{{"activityId": 1, "memo": "{SECRET}"')

    assert SECRET not in str(caught.value)
    assert caught.value.__cause__ is None
    assert caught.value.__context__ is None


def test_malformed_item_after_valid_ones_fails_whole_list():
    # 조용히 건너뛰면 활동이 사라지므로 앞 항목이 맞아도 목록 전체가 실패한다.
    raw = _raw([*ACTIVITIES, {"activityId": False, "startTimeLocal": "2026-10-16"}])

    with pytest.raises(RawParseError, match=r"\[2\]"):
        rawparse.activity_refs(raw)


# ---- 세트 필요 판정(needs_sets) ----

REAL_LISTS = Path(__file__).parent / "fixtures" / "garmin" / "activities_by_date"
STRENGTH_LIST_DAYS = ("2026-10-15", "2026-10-19")
"""세트가 있는 실제 활동 목록(hiit `totalSets` 4·strength 19, strength 34)."""


def _with(**fields: object) -> list[dict[str, object]]:
    return [{"activityId": 1, "startTimeLocal": "2026-10-16 06:00:00", **fields}]


def test_needs_sets_defaults_to_false_for_two_argument_ref():
    assert ActivityRef(1, "2026-10-16").needs_sets is False
    assert ActivityRef._fields == ("activity_id", "day_key", "needs_sets")


@pytest.mark.parametrize(
    ("fields", "needs_sets"),
    [
        pytest.param({"totalSets": 19}, True, id="total-sets"),
        pytest.param(
            {"totalSets": 0, "summarizedExerciseSets": [{"category": "SQUAT"}]},
            True,
            id="summarized-only",
        ),
        pytest.param(
            {"summarizedExerciseSets": [{"category": "SQUAT"}]},
            True,
            id="summarized-without-total",
        ),
        pytest.param(
            {"totalSets": 4, "summarizedExerciseSets": []}, True, id="total-with-empty"
        ),
        pytest.param({}, False, id="both-missing"),
        pytest.param(
            {"totalSets": None, "summarizedExerciseSets": None}, False, id="both-null"
        ),
        pytest.param(
            {"totalSets": 0, "summarizedExerciseSets": []}, False, id="zero-and-empty"
        ),
        pytest.param({"totalSets": -1}, False, id="negative-total"),
    ],
)
def test_needs_sets(fields: dict[str, object], needs_sets: bool):
    (ref,) = rawparse.activity_refs(_raw(_with(**fields)))

    assert ref == ActivityRef(1, "2026-10-16", needs_sets)


@pytest.mark.parametrize(
    "fields",
    [
        pytest.param({"totalSets": "4"}, id="total-str"),
        pytest.param({"totalSets": True}, id="total-bool"),
        pytest.param({"totalSets": 4.0}, id="total-float"),
        pytest.param({"totalSets": {"n": 4}}, id="total-object"),
        pytest.param({"summarizedExerciseSets": {}}, id="summarized-object"),
        pytest.param({"summarizedExerciseSets": "SQUAT"}, id="summarized-str"),
        pytest.param({"summarizedExerciseSets": 0}, id="summarized-number"),
    ],
)
def test_malformed_sets_fields_fail_whole_list_without_raw_content(
    fields: dict[str, object],
):
    secret_fields = {
        key: (SECRET if isinstance(value, str) else value)
        for key, value in fields.items()
    }
    raw = _raw(
        [
            {"activityId": 9, "startTimeLocal": "2026-10-16 05:00:00"},
            *_with(**secret_fields),
        ]
    )

    with pytest.raises(RawParseError) as caught:
        rawparse.activity_refs(raw)

    message = str(caught.value)
    assert "[1]" in message
    assert SECRET not in message
    for value in fields.values():
        assert repr(value) not in message
    assert caught.value.__cause__ is None
    assert caught.value.__context__ is None


@pytest.mark.parametrize("day", STRENGTH_LIST_DAYS)
def test_real_strength_activities_need_sets(day: str):
    path = REAL_LISTS / f"{day}.json"
    if not path.exists():
        pytest.skip(
            f"실제 fixture(tests/fixtures/garmin/activities_by_date/{day}.json)가 없다"
        )

    refs = rawparse.activity_refs(path.read_text(encoding="utf-8"))

    assert refs
    assert all(ref.needs_sets for ref in refs)
