"""연결 점검(`auth.smoke`·`garmin-pipeline smoke`): 단계 출력, 사유·안내, 종료 코드, 당일 차단,
명령 로그, 프롬프트·본문 위생."""

import builtins
import fcntl
import getpass
import inspect
import json
import logging
import os
import re
from collections.abc import Callable, Iterator
from datetime import UTC, date, datetime
from pathlib import Path

import garminconnect
import pytest
from garmin_fakes import (
    FAKE_DISPLAY_NAME,
    FakeGarmin,
    GarminTransport,
    ScriptedPrompts,
    StubGarminClient,
    StubLoginClient,
    http_error,
    transport_client,
)

from garmin_pipeline import auth, cli, config, dates, errors, garmin
from garmin_pipeline.errors import AuthFailedReason, RunStatus

AuthError = garminconnect.GarminConnectAuthenticationError
ConnError = garminconnect.GarminConnectConnectionError
TooMany = garminconnect.GarminConnectTooManyRequestsError

# 서울 2026-10-16 10:00. 어제는 2026-10-15다.
NOW = datetime(2026, 10, 16, 1, 0, tzinfo=UTC)
TODAY = "2026-10-16"
YESTERDAY = date(2026, 10, 15)
DATA_LINE = "데이터 호출(user_summary, 2026-10-15)"
SUMMARY_PATH = f"/usersummary-service/usersummary/daily/{FAKE_DISPLAY_NAME}"
MARKER = "payload-marker-3f9a"
PAYLOAD = {"calendarDate": "2026-10-15", "totalSteps": 8123, "note": MARKER}
LOG_PREFIX = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z ")


@pytest.fixture(autouse=True)
def clock(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(dates, "_utc_now", lambda: NOW)


@pytest.fixture(autouse=True)
def no_prompts(monkeypatch: pytest.MonkeyPatch) -> list[str]:
    """실제 `input`·`getpass.getpass`를 "부르면 기록하고 실패"로 바꾼다. 부른 목록을 준다."""
    asked: list[str] = []

    def refuse(prompt: object = "", *args: object) -> str:
        asked.append(str(prompt))
        raise AssertionError("smoke가 프롬프트를 띄웠다")

    monkeypatch.setattr(builtins, "input", refuse)
    monkeypatch.setattr(getpass, "getpass", refuse)
    return asked


@pytest.fixture
def make_cfg(write_config: Callable[..., Path]) -> Callable[..., config.Config]:
    """`write_config`로 쓴 설정을 읽는다. tokenstore(`tmp_path/tokens`)는 만들지 않는다."""

    def make(**overrides: object) -> config.Config:
        values = {
            "lock_wait_seconds": 0,
            "call_pause_min_seconds": 0,
            "call_pause_max_seconds": 0,
            **overrides,
        }
        return config.load(write_config(**values))

    return make


@pytest.fixture
def cfg(make_cfg: Callable[..., config.Config]) -> config.Config:
    return make_cfg()


@pytest.fixture
def stubs(monkeypatch: pytest.MonkeyPatch) -> Callable[..., list[object]]:
    """`garmin._new_client`를 `factory()` 생성으로 바꾸고 만든 클라이언트 목록을 준다."""

    def install(factory: Callable[[], object]) -> list[object]:
        created: list[object] = []

        def new_client() -> object:
            client = factory()
            created.append(client)
            return client

        monkeypatch.setattr(garmin, "_new_client", new_client)
        return created

    return install


@pytest.fixture
def transport(
    cfg: config.Config, stubs: Callable[..., list[object]]
) -> Iterator[tuple[GarminTransport, list[object]]]:
    """tokenstore를 만들고 `_new_client`를 전송 stub을 낀 실제 라이브러리 클라이언트로 바꾼다."""
    cfg.tokenstore.mkdir()
    stub = GarminTransport()
    yield stub, stubs(lambda: transport_client(stub))


@pytest.fixture
def library_logger_state() -> Iterator[None]:
    library = logging.getLogger("garminconnect")
    saved = (library.propagate, library.level, list(library.handlers))
    yield
    library.propagate = saved[0]
    library.setLevel(saved[1])
    library.handlers[:] = saved[2]


def _block_path(cfg: config.Config) -> Path:
    return cfg.tokenstore / garmin.BLOCK_FILENAME


def _write_block(cfg: config.Config, local_date: str, reason: str) -> None:
    cfg.tokenstore.mkdir(parents=True, exist_ok=True)
    payload = {"schema_version": 1, "local_date": local_date, "reason": reason}
    _block_path(cfg).write_text(json.dumps(payload), encoding="utf-8")


def _outputs(capsys: pytest.CaptureFixture[str]) -> tuple[list[str], str]:
    out, err = capsys.readouterr()
    assert MARKER not in out
    assert MARKER not in err
    return out.splitlines(), err


def _header(cfg: config.Config) -> list[str]:
    cffi = "true" if cfg.cffi_api_session else "false"
    return [f"cffi_api_session: {cffi}", f"garminconnect: {garmin.LIBRARY_VERSION}"]


def _assert_failed(err: str, *needles: str, absent: tuple[str, ...] = ()) -> None:
    lines = err.splitlines()
    assert len(lines) == 1, err
    assert lines[0].startswith("smoke 실패: ")
    for needle in needles:
        assert needle in lines[0], (needle, lines[0])
    for needle in absent:
        assert needle not in lines[0], (needle, lines[0])


# --- 정상·데이터 없음 ----------------------------------------------------------------------


@pytest.mark.parametrize("cffi", [False, True])
def test_success_prints_four_stage_lines(
    make_cfg: Callable[..., config.Config],
    capsys: pytest.CaptureFixture[str],
    no_prompts: list[str],
    cffi: bool,
):
    cfg = make_cfg(cffi_api_session=cffi)
    fake = FakeGarmin(responses={("user_summary", YESTERDAY): PAYLOAD})

    assert auth.smoke(cfg, fake) == 0

    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 성공", f"{DATA_LINE}: 성공"]
    assert err == ""
    assert fake.calls == ["open_session", ("user_summary", YESTERDAY), "close_session"]
    assert no_prompts == []
    assert not cfg.db_path.exists()
    assert not cfg.tokenstore.exists()


@pytest.mark.parametrize(
    "outcome",
    [None, [], {}, errors.NoData("user_summary: HTTP 404")],
    ids=["missing", "empty-list", "empty-dict", "404"],
)
def test_no_data_is_success(
    cfg: config.Config, capsys: pytest.CaptureFixture[str], outcome: object
):
    responses = {} if outcome is None else {("user_summary", YESTERDAY): outcome}
    fake = FakeGarmin(responses=responses)

    assert auth.smoke(cfg, fake) == 0

    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 성공", f"{DATA_LINE}: 데이터 없음"]
    assert err == ""


def test_yesterday_follows_config_timezone(
    make_cfg: Callable[..., config.Config],
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
):
    # UTC로는 10월 15일 15:30이지만 서울로는 10월 16일 00:30이다.
    monkeypatch.setattr(
        dates, "_utc_now", lambda: datetime(2026, 10, 15, 15, 30, tzinfo=UTC)
    )
    fake = FakeGarmin()

    assert auth.smoke(make_cfg(), fake) == 0

    assert fake.calls[1] == ("user_summary", YESTERDAY)
    assert DATA_LINE in capsys.readouterr().out


# --- 실제 어댑터 ---------------------------------------------------------------------------


def test_real_adapter_success_without_prompts(
    cfg: config.Config,
    transport: tuple[GarminTransport, list[object]],
    capsys: pytest.CaptureFixture[str],
    no_prompts: list[str],
):
    stub, created = transport
    stub.reply(SUMMARY_PATH, PAYLOAD)

    assert auth.smoke(cfg) == 0

    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 성공", f"{DATA_LINE}: 성공"]
    assert err == ""
    assert len(created) == 1
    assert stub.calls == [(SUMMARY_PATH, {"calendarDate": "2026-10-15"})]
    assert no_prompts == []
    assert not _block_path(cfg).exists()
    assert not cfg.db_path.exists()


def test_real_adapter_404_is_no_data(
    cfg: config.Config,
    transport: tuple[GarminTransport, list[object]],
    capsys: pytest.CaptureFixture[str],
):
    # 경로를 주입하지 않으면 전송 stub이 404다.
    assert auth.smoke(cfg) == 0

    out, _ = _outputs(capsys)
    assert out[-1] == f"{DATA_LINE}: 데이터 없음"


# --- 토큰 없음·만료 ------------------------------------------------------------------------


def test_missing_tokenstore_asks_to_login_without_prompt_or_client(
    cfg: config.Config,
    stubs: Callable[..., list[object]],
    capsys: pytest.CaptureFixture[str],
    no_prompts: list[str],
):
    created = stubs(StubGarminClient)

    assert auth.smoke(cfg) == 1

    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 실패"]
    _assert_failed(err, "token_invalid", "`garmin-pipeline login`을 다시 실행하라")
    assert no_prompts == []
    assert created == []
    assert not cfg.tokenstore.exists()
    assert not cfg.db_path.exists()


def test_expired_token_login_failure_asks_to_login(
    cfg: config.Config,
    stubs: Callable[..., list[object]],
    capsys: pytest.CaptureFixture[str],
    no_prompts: list[str],
):
    cfg.tokenstore.mkdir()
    created = stubs(lambda: StubGarminClient(login_error=ConnError("API Error 401")))

    assert auth.smoke(cfg) == 1

    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 실패"]
    _assert_failed(err, "`garmin-pipeline login`을 다시 실행하라")
    assert len(created) == 1
    assert no_prompts == []
    assert not _block_path(cfg).exists()
    assert sorted(p.name for p in cfg.tokenstore.iterdir()) == [
        garmin.SESSION_LOCK_FILENAME
    ]


def test_data_401_asks_to_login(cfg: config.Config, capsys: pytest.CaptureFixture[str]):
    fake = FakeGarmin(
        responses={
            ("user_summary", YESTERDAY): errors.AuthFailed(
                AuthFailedReason.TOKEN_INVALID
            )
        }
    )

    assert auth.smoke(cfg, fake) == 1

    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 성공", f"{DATA_LINE}: 실패"]
    _assert_failed(err, "`garmin-pipeline login`을 다시 실행하라")


def test_privacy_protected_does_not_ask_to_login(
    cfg: config.Config,
    transport: tuple[GarminTransport, list[object]],
    capsys: pytest.CaptureFixture[str],
):
    stub, _ = transport
    stub.reply(SUMMARY_PATH, {"privacyProtected": True, "note": MARKER})

    assert auth.smoke(cfg) == 1

    out, err = _outputs(capsys)
    assert out[-1] == f"{DATA_LINE}: 실패"
    _assert_failed(err, "비공개", absent=("login",))


# --- #444 ----------------------------------------------------------------------------------


def test_rejected_without_cffi_suggests_enabling_it(
    cfg: config.Config,
    transport: tuple[GarminTransport, list[object]],
    capsys: pytest.CaptureFixture[str],
):
    stub, _ = transport
    stub.reply(SUMMARY_PATH, http_error(403, MARKER))

    assert auth.smoke(cfg) == 1

    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 성공", f"{DATA_LINE}: 실패"]
    _assert_failed(
        err, "#444", "cffi_api_session = true", "다시 `smoke`", str(cfg.path)
    )
    assert not _block_path(cfg).exists()


def test_rejected_with_cffi_suggests_network_check(
    make_cfg: Callable[..., config.Config], capsys: pytest.CaptureFixture[str]
):
    cfg = make_cfg(cffi_api_session=True)
    fake = FakeGarmin(
        responses={
            ("user_summary", YESTERDAY): errors.Rejected("user_summary: HTTP 403")
        }
    )

    assert auth.smoke(cfg, fake) == 1

    out, err = _outputs(capsys)
    assert out[0] == "cffi_api_session: true"
    assert out[-1] == f"{DATA_LINE}: 실패"
    _assert_failed(
        err, "#444", "curl_cffi로도", "VPN", absent=("cffi_api_session = true",)
    )


# --- 로그인 429·403 → 같은 날 smoke·login ---------------------------------------------------


@pytest.mark.parametrize(
    ("make_error", "reason", "status", "hint"),
    [
        pytest.param(lambda: TooMany("429"), "rate_limited", "429", True, id="429"),
        pytest.param(
            lambda: ConnError("All login strategies exhausted: API Error 403"),
            "blocked_403",
            "403",
            False,
            id="403",
        ),
    ],
)
def test_login_429_403_blocks_today_for_smoke_and_login(
    cfg: config.Config,
    stubs: Callable[..., list[object]],
    capsys: pytest.CaptureFixture[str],
    no_prompts: list[str],
    make_error: Callable[[], BaseException],
    reason: str,
    status: str,
    hint: bool,
):
    cfg.tokenstore.mkdir()
    created = stubs(lambda: StubGarminClient(login_error=make_error()))

    assert auth.smoke(cfg) == 1

    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 실패"]
    _assert_failed(err, "로그인을 거부", f"HTTP {status}", "당일 차단", "내일")
    assert ("#453" in err) is hint
    assert json.loads(_block_path(cfg).read_text("utf-8")) == {
        "schema_version": 1,
        "local_date": TODAY,
        "reason": reason,
    }
    assert len(created) == 1

    # 같은 날 다시 smoke: 클라이언트를 만들지 않는다.
    assert auth.smoke(cfg) == 1
    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 실패"]
    _assert_failed(err, "당일 차단", reason)
    assert len(created) == 1

    # 같은 날 login: 프롬프트·클라이언트 없이 실패한다.
    login_clients = stubs(StubLoginClient)
    prompts = ScriptedPrompts()
    assert auth.login(cfg, prompts) == 1
    assert capsys.readouterr().err.startswith("login 실패: ")
    assert prompts.calls == []
    assert login_clients == []
    assert no_prompts == []
    assert not cfg.db_path.exists()


# --- 데이터 429·403 ------------------------------------------------------------------------


def test_data_429_records_block_and_says_tomorrow(
    cfg: config.Config,
    transport: tuple[GarminTransport, list[object]],
    capsys: pytest.CaptureFixture[str],
):
    stub, _ = transport
    stub.reply(SUMMARY_PATH, http_error(429))

    assert auth.smoke(cfg) == 1

    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 성공", f"{DATA_LINE}: 실패"]
    _assert_failed(
        err, "데이터 호출을 거부", "HTTP 429", "당일 차단", "내일", absent=("#453",)
    )
    assert json.loads(_block_path(cfg).read_text("utf-8"))["reason"] == "rate_limited"


def test_data_blocked_403_says_tomorrow(
    cfg: config.Config, capsys: pytest.CaptureFixture[str]
):
    fake = FakeGarmin(
        responses={
            ("user_summary", YESTERDAY): errors.Blocked403("user_summary: HTTP 403")
        }
    )

    assert auth.smoke(cfg, fake) == 1

    out, err = _outputs(capsys)
    assert out[-1] == f"{DATA_LINE}: 실패"
    _assert_failed(
        err, "데이터 호출을 거부", "HTTP 403", "당일 차단", "내일", absent=("#444",)
    )
    assert fake.blocked is RunStatus.BLOCKED_403


@pytest.mark.parametrize("cffi", [False, True])
def test_login_403_hints_444(
    make_cfg: Callable[..., config.Config],
    capsys: pytest.CaptureFixture[str],
    cffi: bool,
):
    cfg = make_cfg(cffi_api_session=cffi)
    fake = FakeGarmin(open_error=errors.Blocked403("login 단계: HTTP 403"))

    assert auth.smoke(cfg, fake) == 1

    _, err = _outputs(capsys)
    _assert_failed(err, "로그인을 거부", "HTTP 403", "#444", "내일", absent=("#453",))
    assert ("`cffi_api_session = true`" in err) is not cffi


# --- 이미 차단·환경 오류 --------------------------------------------------------------------


@pytest.mark.parametrize("reason", ["rate_limited", "blocked_403"])
def test_block_today_fails_without_client(
    cfg: config.Config,
    stubs: Callable[..., list[object]],
    capsys: pytest.CaptureFixture[str],
    reason: str,
):
    _write_block(cfg, TODAY, reason)
    created = stubs(StubGarminClient)

    assert auth.smoke(cfg) == 1

    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 실패"]
    _assert_failed(err, "당일 차단", reason, "내일")
    assert created == []


def test_fake_block_is_reported(cfg: config.Config, capsys: pytest.CaptureFixture[str]):
    fake = FakeGarmin(blocked=RunStatus.RATE_LIMITED)

    assert auth.smoke(cfg, fake) == 1

    _, err = _outputs(capsys)
    _assert_failed(err, "당일 차단", "rate_limited")
    assert fake.calls == ["open_session"]


@pytest.mark.parametrize(
    ("stage", "error", "needles"),
    [
        (
            "open",
            errors.Transient("login 단계: HTTP 503"),
            ("일시적인 오류", "세션을 열지", "HTTP 503"),
        ),
        (
            "data",
            errors.Transient("user_summary: HTTP 503"),
            ("일시적인 오류", "데이터를 받지"),
        ),
        ("open", garmin.SessionLockTimeout("락 대기 초과"), ("다른 명령",)),
        ("open", garmin.BlockFileInvalid("깨진 파일"), ("당일 차단 파일",)),
    ],
    ids=["open-transient", "data-transient", "lock-timeout", "block-invalid"],
)
def test_other_failures_exit_1(
    cfg: config.Config,
    capsys: pytest.CaptureFixture[str],
    stage: str,
    error: Exception,
    needles: tuple[str, ...],
):
    if stage == "open":
        fake = FakeGarmin(open_error=error)
        expected = [*_header(cfg), "세션 열기: 실패"]
    else:
        fake = FakeGarmin(responses={("user_summary", YESTERDAY): error})
        expected = [*_header(cfg), "세션 열기: 성공", f"{DATA_LINE}: 실패"]

    assert auth.smoke(cfg, fake) == 1

    out, err = _outputs(capsys)
    assert out == expected
    _assert_failed(err, *needles)


def test_real_session_lock_timeout(
    cfg: config.Config,
    stubs: Callable[..., list[object]],
    capsys: pytest.CaptureFixture[str],
):
    cfg.tokenstore.mkdir()
    created = stubs(StubGarminClient)
    fd = os.open(
        cfg.tokenstore / garmin.SESSION_LOCK_FILENAME, os.O_RDWR | os.O_CREAT, 0o600
    )
    fcntl.flock(fd, fcntl.LOCK_EX)
    try:
        assert auth.smoke(cfg) == 1
    finally:
        os.close(fd)

    _, err = _outputs(capsys)
    _assert_failed(err, "다른 명령")
    assert created == []


def test_invalid_block_file(
    cfg: config.Config,
    stubs: Callable[..., list[object]],
    capsys: pytest.CaptureFixture[str],
):
    cfg.tokenstore.mkdir()
    _block_path(cfg).write_text("{oops", encoding="utf-8")
    created = stubs(StubGarminClient)

    assert auth.smoke(cfg) == 1

    _, err = _outputs(capsys)
    _assert_failed(err, "당일 차단 파일")
    assert created == []


@pytest.mark.parametrize("stage", ["open", "data"])
def test_unknown_error_propagates_after_logging_its_name(
    cfg: config.Config, caplog: pytest.LogCaptureFixture, stage: str
):
    original = TypeError("unexpected secret-41c0")
    if stage == "open":
        fake = FakeGarmin(open_error=original)
    else:
        fake = FakeGarmin(responses={("user_summary", YESTERDAY): original})

    with pytest.raises(TypeError) as excinfo:
        auth.smoke(cfg, fake)

    assert excinfo.value is original
    messages = [
        r.getMessage() for r in caplog.records if r.name == "garmin_pipeline.auth"
    ]
    assert f"smoke 중단(예상하지 못한 오류): stage={stage} error=TypeError" in messages
    assert "secret-41c0" not in caplog.text


# --- 공개 API·소스 위생 ---------------------------------------------------------------------


def test_smoke_signature_takes_no_credentials():
    params = inspect.signature(auth.smoke).parameters
    assert list(params) == ["cfg", "port"]
    for function in (auth.smoke, auth._smoke_failure_message):
        source = inspect.getsource(function)
        for banned in ("interactive_login", "input(", "getpass", "prompt", "password"):
            assert banned not in source, (function.__name__, banned)


# --- cli -----------------------------------------------------------------------------------


def test_cli_smoke_writes_log_without_dates_or_payload(
    cfg: config.Config,
    transport: tuple[GarminTransport, list[object]],
    capsys: pytest.CaptureFixture[str],
    no_prompts: list[str],
    library_logger_state: None,
):
    stub, created = transport
    stub.reply(SUMMARY_PATH, PAYLOAD)

    assert cli.main(["smoke", "--config", str(cfg.path)]) == 0

    out, err = _outputs(capsys)
    assert out == [*_header(cfg), "세션 열기: 성공", f"{DATA_LINE}: 성공"]
    assert err == ""
    assert no_prompts == []
    assert len(created) == 1
    assert not cfg.db_path.exists()

    log_path = cfg.data_dir / "logs" / "smoke.log"
    assert log_path.is_file()
    bodies = [
        LOG_PREFIX.sub("", line, count=1)
        for line in log_path.read_text("utf-8").splitlines()
    ]
    text = "\n".join(bodies)
    assert "cffi_api_session=false" in text
    assert "result=ok" in text
    assert MARKER not in text
    assert "2026-10-15" not in text
    assert "2026-10-16" not in text
    assert FAKE_DISPLAY_NAME not in text


def test_cli_smoke_failure_logs_stage_error_and_reason(
    cfg: config.Config,
    capsys: pytest.CaptureFixture[str],
    library_logger_state: None,
):
    assert cli.main(["smoke", "--config", str(cfg.path)]) == 1

    _, err = _outputs(capsys)
    _assert_failed(err, "`garmin-pipeline login`")
    text = (cfg.data_dir / "logs" / "smoke.log").read_text("utf-8")
    assert (
        "smoke 실패: stage=open error=AuthFailed reason=token_invalid "
        "cffi_api_session=false"
    ) in text


@pytest.mark.parametrize("problem", ["missing", "runtime"])
def test_cli_config_error_exits_2(
    write_config: Callable[..., Path],
    tmp_path: Path,
    capsys: pytest.CaptureFixture[str],
    problem: str,
):
    if problem == "missing":
        path = tmp_path / "nowhere.toml"
    else:
        path = write_config(environment="runtime")

    assert cli.main(["smoke", "--config", str(path)]) == 2

    assert capsys.readouterr().err.startswith("설정 오류: ")
    assert not (tmp_path / "data").exists()


def test_cli_log_dir_failure_exits_1(
    make_cfg: Callable[..., config.Config],
    tmp_path: Path,
    stubs: Callable[..., list[object]],
    capsys: pytest.CaptureFixture[str],
):
    (tmp_path / "data").write_text("", encoding="utf-8")
    cfg = make_cfg()
    created = stubs(StubGarminClient)

    assert cli.main(["smoke", "--config", str(cfg.path)]) == 1

    assert capsys.readouterr().err.startswith("smoke 실패: 로그 파일")
    assert created == []


def test_cli_smoke_help_offers_only_config(capsys: pytest.CaptureFixture[str]):
    with pytest.raises(SystemExit) as excinfo:
        cli.main(["smoke", "--help"])

    assert excinfo.value.code == 0
    out = capsys.readouterr().out
    assert set(re.findall(r"--[a-z][a-z-]*", out)) == {"--help", "--config"}
