"""여러 테스트 파일이 같이 쓰는 fixture."""

import json
from collections.abc import Callable
from datetime import date, time
from pathlib import Path

import pytest

from garmin_pipeline import garmin, report


@pytest.fixture(autouse=True)
def _refuse_real_garmin_client(monkeypatch: pytest.MonkeyPatch) -> None:
    """모든 테스트에서 `garmin._new_client` seam을 "호출되면 실패"로 바꿔 실제 Garmin을 막는다.

    curl_cffi는 Python 소켓을 거치지 않으므로 소켓 차단으로는 막을 수 없다. 어댑터 단위 시험은
    이 seam을 `tests/garmin_fakes.py`의 `StubGarminClient`로 다시 바꾼다.
    """

    def refuse() -> None:
        pytest.fail("테스트에서 실제 Garmin 클라이언트를 만들었다(garmin._new_client)")

    monkeypatch.setattr(garmin, "_new_client", refuse)


@pytest.fixture(autouse=True)
def _refuse_real_codex(
    monkeypatch: pytest.MonkeyPatch, tmp_path_factory: pytest.TempPathFactory
) -> None:
    """모든 테스트에서 `report.CODEX_EXECUTABLE`을 없는 경로로 바꿔 실제 `codex` 실행을 막는다.

    `CodexWriter`를 쓰는 시험은 `tests/test_report_codex.py`의 가짜 codex 스크립트로 다시 바꾼다.
    """
    missing = tmp_path_factory.getbasetemp() / "no-real-codex" / "codex"
    monkeypatch.setattr(report, "CODEX_EXECUTABLE", str(missing))


def _toml_value(value: object) -> str:
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, int | float):
        return repr(value)
    if isinstance(value, date | time):
        return value.isoformat()
    if isinstance(value, str | Path):
        # JSON 문자열 이스케이프는 TOML 기본 문자열에서도 유효하다.
        return json.dumps(str(value), ensure_ascii=False)
    raise TypeError(f"TOML로 쓸 수 없는 값: {value!r}")


@pytest.fixture
def write_config(tmp_path: Path) -> Callable[..., Path]:
    """`tmp_path/config.toml`을 쓰고 경로를 돌려주는 함수를 준다.

    기본은 `environment = "dev"`와 `tmp_path/tokens` tokenstore라 pytest 가드를 통과한다.
    `write_config(key=value)`로 값을 바꾸고, 값이 `None`이면 그 키를 빼며, dict는 `[key]`
    테이블로 쓴다. 다시 부르면 같은 파일을 덮어쓴다.
    """

    def write(**overrides: object) -> Path:
        values: dict[str, object] = {
            "environment": "dev",
            "tokenstore": str(tmp_path / "tokens"),
        }
        values |= overrides
        lines: list[str] = []
        tables: list[str] = []
        for key, value in values.items():
            if value is None:
                continue
            if isinstance(value, dict):
                tables.append(f"\n[{key}]")
                tables.extend(f"{k} = {_toml_value(v)}" for k, v in value.items())
            else:
                lines.append(f"{key} = {_toml_value(value)}")
        path = tmp_path / "config.toml"
        path.write_text("\n".join([*lines, *tables]) + "\n", encoding="utf-8")
        return path

    return write
