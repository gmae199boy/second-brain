# garmin-pipeline

Garmin 건강 데이터를 매일 무인으로 수집해 일일 리포트를 만드는 개인용 파이프라인.

## 개발 준비

- [uv](https://docs.astral.sh/uv/) 0.13.1 이상이 필요하다(`pyproject.toml`의 `required-version`). 0.12.22 미만은 Python 3.14.8을 받지 못한다. Homebrew로 설치했다면 `brew upgrade uv`를 쓴다.

  ```sh
  uv self update
  ```

- 의존성과 Python을 맞춘다. `.python-version`이 `3.14.8`이라 로컬에 없으면 uv가 관리형 Python을 받는다. 패키지는 `>=3.12`를 지원한다.

  ```sh
  uv sync
  ```

- 명령줄 진입점은 `garmin-pipeline`이다.

  ```sh
  uv run garmin-pipeline --help
  ```

## 검사

```sh
uv lock --check      # uv.lock이 pyproject.toml과 맞는지
uv run ruff check    # 기본 규칙 + DTZ·TID251(시스템 로컬 시각 금지)
uv run lint-imports  # import-linter 의존 방향 계약
uv run pytest        # 골격·계약 검사를 포함한 전체 테스트(인수 테스트는 빠진다)
```

실제 codex로 `report`를 돌리는 인수 테스트(`tests/test_acceptance_report.py`, 마커 `acceptance`)는 기본 실행에서 빠진다(`pyproject.toml`의 `addopts = ["-m", "not acceptance"]`). 로그인된 codex가 PATH에 있을 때 모델을 지정해 따로 돌린다. 환경변수가 없으면 skip이 아니라 실패한다. 명령줄 `-m`은 `addopts`의 `-m`을 덮으므로, 다른 `-m` 식을 줄 때는 `and not acceptance`를 붙인다(예: `-m "not slow and not acceptance"`). 아래 "report"의 "인수 테스트"를 본다.

```sh
GARMIN_ACCEPTANCE_REPORT_MODEL=<모델> uv run pytest -m acceptance -v
```

## 설정

설정은 `config.toml` 하나이고 `garmin_pipeline.config.load()`가 읽는다. 비밀은 넣지 않는다.

- **탐색 순서:** `--config` 값(`load(path)` 인자) > 환경변수 `GARMIN_PIPELINE_CONFIG`(빈 문자열은 없는 것으로 본다) > 현재 폴더의 `config.toml`. 고른 파일이 없거나 TOML이 깨졌으면 다음 순위로 넘어가지 않고 `ConfigError`다.
- **`--config` 옵션:** 하위 명령의 `--config PATH`(예: `garmin-pipeline login --config PATH`)가 `load(path)` 인자로 들어간다. 설정 오류는 stderr에 `설정 오류: …` 한 줄을 쓰고 종료 코드 2다.
- **경로:** 상대 config 경로는 현재 폴더 기준이고, config 안의 상대경로는 config 파일이 있는 폴더 기준이다. 경로는 `~`를 풀어(`expanduser`) 결합만 하고 `resolve`하지 않는다.
- **부작용 없음:** `load`는 config 파일을 읽고 tokenstore 심링크를 검사(`lstat`)할 뿐, 디렉터리를 만들거나 존재를 확인하거나 쓰지 않는다. 그 밖에는 `timezone` 검증(`ZoneInfo`)이 시스템 tzdata를 읽는 것뿐이다.
- **검증:** 아래 표 밖의 키(`[테이블]` 포함), 타입 오류(정수 자리의 `true`·`10.0`·`"10"` 등), 값 오류(한도 < 1, 대기·간격 < 0이나 무한대·NaN, `call_pause_min_seconds` > `call_pause_max_seconds`, `HH:MM`이 아닌 시각, 모르는 시간대, 빈 경로)는 `ConfigError`이고 `.key`와 메시지에 키 이름이 들어간다.
- **tokenstore:** 경로 자신이나 부모 중 하나라도 심링크면 거부한다. 부모는 정규화 전 경로(`..` 포함)로 따진다. `GARMINTOKENS` 환경변수는 읽지 않는다.

| 키 | 기본값 | 설명 |
|----|--------|------|
| `environment` | (필수) | `"runtime"` 또는 `"dev"` |
| `tokenstore` | `~/.garmin-pipeline/tokens` | Garmin 토큰과 당일 차단(`block.json`) 폴더 |
| `data_dir` | `data` | DB(`<data_dir>/garmin.db`)·원본·로그 |
| `reports_dir` | `reports` | 일일 리포트 |
| `inbox_dir` | `inbox` | 인바디 스크린샷·수치 입력 |
| `timezone` | `Asia/Seoul` | 일 키와 "오늘"의 기준 시간대 |
| `collect_time`·`retry_time`·`report_time` | `"11:00"`·`"11:15"`·`"11:30"` | 예약 시각(`"HH:MM"` 문자열) |
| `report_wait_minutes` | `30` | 리포트가 수집을 기다리는 최대 분(0 이상 정수) |
| `report_codex_timeout_minutes` | `20` | `codex exec` 시간 제한 분(1 이상 정수) |
| `report_model` | 없음 | 리포트 모델 이름(문자열). 기본값은 Epic 4가 정한다 |
| `date_pause_seconds` | `5` | 날짜 사이 대기 초(0 이상, 정수·실수) |
| `call_pause_min_seconds`·`call_pause_max_seconds` | `1`·`2` | 호출 사이 대기 초 범위(0 이상, 정수·실수) |
| `max_dates_per_run` | `10` | 한 실행에서 수집할 최대 날짜 수(3 이상 정수) |
| `max_rejected_attempts` | `3` | 거부된 항목을 계획에서 빼기 전 최대 시도 수(1 이상 정수) |
| `max_consecutive_403` | `3` | 연속 403을 차단으로 승격하는 횟수(1 이상 정수) |
| `lock_wait_seconds` | `60` | 쓰기 락·Garmin 세션 락 대기 초(0 이상, 정수·실수) |
| `cffi_api_session` | `false` | curl_cffi API 세션 사용 여부(1.7 `smoke`가 정한다) |

저장소 루트의 `config.toml`은 개발용(`environment = "dev"`)이다. 경로 키는 기본값을 그대로 적었고 모두 `.gitignore` 대상이다. tokenstore는 적지 않는다. 당일 차단이 계정 단위라 운영과 같은 기본 tokenstore를 함께 써야 한다.

**pytest 가드:** `config.under_pytest()`는 `PYTEST_CURRENT_TEST` 환경변수가 있거나 `pytest`가 import돼 있으면 참이다. 참이면 `load`는 `environment = "runtime"`인 설정과 tokenstore를 적지 않은 설정을 거부한다. 그래서 테스트는 저장소 루트 `config.toml`로 실제 토큰에 닿지 못하고, `tests/conftest.py`의 `write_config` fixture로 `tmp_path`에 만든 설정을 쓴다. `store`·`install-schedule`도 같은 함수를 쓴다.

## 날짜와 시각

시간대 변환과 "오늘" 계산은 `garmin_pipeline.dates`만 한다. 일 키는 config `timezone` 기준 `YYYY-MM-DD`이고, 시각은 UTC epoch ms(`dates.now_ms()`)다. 현재 시각은 `dates._utc_now()` 하나에서만 읽고, 테스트는 이 함수만 바꾼다.

시스템 로컬 시각은 쓰지 않는다. 다음 세 수단으로 막는다.

- ruff `DTZ`: 시간대 없는 `datetime`(`datetime.now()`, `fromtimestamp()` 등)
- ruff `TID251`(`pyproject.toml`의 banned-api): `time`의 `localtime`·`mktime`·`ctime`·`asctime`·`strftime`·`timezone`·`tzname`·`altzone`·`daylight`
- `tests/test_skeleton.py`의 AST 검사: `src/` 안의 인자 없는 `.astimezone()`과 `.astimezone(None)`(ruff가 잡지 못한다)

`dates.system_timezone()`은 시스템 시간대의 이름만 돌려준다(시각 변환에는 쓰지 않는다). 비어 있지 않은 `TZ` 환경변수(앞 `:` 하나를 뗀 값)가 먼저이고, 없으면 `/etc/localtime` 실제 경로의 마지막 `zoneinfo/` 뒤 부분(예: `Asia/Seoul`), 알 수 없으면 `None`이다. `collect`가 config `timezone`과 다른지 확인하는 데 쓴다.

## 저장소

SQLite DB(`<data_dir>/garmin.db`)는 `garmin_pipeline.store`로만 연다. `store`는 stdlib과 `config`·`errors`만 import한다.

| 함수 | 하는 일 |
|------|---------|
| `store.report_session(cfg, blocking)` | 리포트 명령 전체의 `.report.lock`. 예약은 끝까지 기다리고 재생성은 한 번 시도 후 `ReportLockBusy`(경로 포함). 나갈 때 예외여도 해제하며 DB는 열지 않는다 |
| `store.write_session(cfg)` | 쓰기 락을 잡고 밀린 마이그레이션을 적용한 연결을 내주는 context manager. 블록을 나가면 정상이든 예외든 연결을 먼저 닫고(열린 트랜잭션은 롤백) 락을 푼다 |
| `store.read_connection(cfg)` | 읽기 전용(`mode=ro`) 연결. 닫기는 호출자가 한다. DB 파일이 없으면 `DbMissing`(파일을 만들지 않는다), `user_version`이 코드의 최신 번호와 다르면 `SchemaMismatch`다. 마이그레이션하지 않는다 |
| `store.write_lock_held(cfg)` | 누군가(이 프로세스의 세션 포함) 쓰기 락을 쥐고 있으면 참. 기다리지 않고, 락 파일이나 `data_dir`이 없으면 아무것도 만들지 않고 거짓이다 |
| `store.insert_run_unlocked(cfg, *, local_date, started_at, finished_at, status, detail)` | 쓰기 락 없이 `run`에 끝난 행 하나를 autocommit INSERT 한 문장으로 남긴다. 쓰기 락을 잡지 못한 `collect`의 `error`(`lock_timeout`) 행에만 쓴다(AD-8). 기존 DB에 `mode=rw`로 붙어 락·마이그레이션·`journal_mode` 변경을 하지 않는다. DB 파일이 없으면 `DbMissing`(파일을 만들지 않는다), `user_version`이 코드의 최신 번호와 다르면 `SchemaMismatch`이고 둘 다 쓰지 않는다 |
| `store.transaction(conn)` | `BEGIN` → `COMMIT`. 예외가 나면 `ROLLBACK`하고 다시 던진다 |
| `store.savepoint(conn)` | 열린 트랜잭션 안의 `SAVEPOINT` → `RELEASE`. 예외가 나면 `ROLLBACK TO` + `RELEASE`로 그 안의 쓰기만 되돌리고 다시 던진다(바깥 트랜잭션은 그대로). 이름이 고정 상수라 중첩해 부르지 않는다. `normalize` 재구성의 항목 격리에 쓴다 |
| `store.upsert_raw(conn, *, scope, key, endpoint, payload, library_version, now_ms)` | Garmin 응답 원문 하나를 `raw_response`의 `(scope, key, endpoint)` 행에 보존한다. 원문은 `json.dumps(payload, ensure_ascii=False)` 텍스트(키 순서 그대로)이고 `payload is None`은 `NoData`다. 그 텍스트가 UTF-8로 인코딩되지 않을 때(짝 없는 surrogate, 예: `"\ud83d"`)만 그 원문을 `ensure_ascii=True`로 만들어 저장·비교한다(`json.loads`하면 같은 값이다). 행이 없으면 원문(`NoData`면 `'null'`)을 넣고 두 시각을 `now_ms`로, 원문이 다르면 `raw`·`fetched_at`·`checked_at`·`library_version`을 바꾸고, 원문이 같거나 `NoData`면 `checked_at`만 바꾼다(일시적인 빈 응답이 받은 원문을 지우지 않는다). 트랜잭션을 열지 않으므로 쓰기 세션 안에서 호출자가 묶는다. `store`는 `dates`를 쓰지 못하므로 `now_ms`(UTC epoch ms)는 호출자가 준다. 잘못된 `scope`는 `sqlite3.IntegrityError`다 |

- **autocommit:** 연결은 모두 `autocommit=True`로 연다. 단일 문장은 바로 영속되고, 여러 문장을 묶는 쓰기와 `charts`의 읽기 트랜잭션은 `store.transaction(conn)`을 쓴다. autocommit 연결에서 `conn.commit()`·`conn.rollback()`은 아무것도 하지 않는다.

  ```python
  with store.write_session(cfg) as conn:  # 락 + 마이그레이션
      conn.execute("INSERT ...")  # 단일 insert는 바로 영속
      with store.transaction(conn):  # 여러 문장은 하나로
          conn.execute("DELETE ...")
          conn.execute("INSERT ...")
  ```

- **순서:** `write_session`은 pytest 가드 → 마이그레이션 목록 로드·검증 → `data_dir` 생성(새로 만드는 `data_dir`은 `0700`, 이미 있는 폴더와 부모는 그대로) → 락 → DB 연결 → DB가 코드보다 새로우면 `SchemaMismatch` → `journal_mode=WAL`(결과가 `wal`이 아니면 `StoreError`) → 밀린 마이그레이션 적용 → `PRAGMA foreign_keys = ON` 순서로 진행한다.
- **외래 키:** 쓰기 연결은 마이그레이션을 마친 뒤 `PRAGMA foreign_keys = ON`을 켜고 내주므로 없는 `run_id`를 가리키는 `fetch_error`는 `sqlite3.IntegrityError`다. 마이그레이션은 FK가 꺼진 채 돌아 이후 마이그레이션이 테이블을 재구성할 수 있다. 읽기 연결(`read_connection`)은 바꾸지 않는다(FK 꺼짐).
- **리포트 락:** `<data_dir>/.report.lock`(새 파일 0600, 새 data_dir 0700), pytest 가드에는 락의 resolve 경로도 포함한다. 락 순서는 `.report.lock` → `.write.lock` → `.session.lock`이다. `report_session` 안에서 `write_session`은 허용하며, 쓰기 락을 쥔 프로세스의 `report_session` 진입이나 같은 스레드의 리포트 세션 중첩은 락을 잡기 전에 `RuntimeError`다. 다른 스레드의 예약 리포트는 기다린다. fd는 하위 프로세스에 상속되지 않는다.
- **쓰기 락:** `<data_dir>/.write.lock`에 `flock(LOCK_EX)`을 잡는다. 못 잡으면 0.1초 간격으로 다시 시도하고 `lock_wait_seconds`가 지나면 락 경로와 대기 초를 담은 `LockTimeout`이다. `0`이면 한 번만 시도한다. 락 fd는 하위 프로세스(`codex` 등)에 상속되지 않는다.
- **중첩 금지:** 같은 프로세스에서 `write_session` 안에서 다시 `write_session`을 열면(심링크로 같은 락 파일에 닿는 경우 포함) 기다리지 않고 바로 `RuntimeError`다. 두 번째 fd의 `flock`은 자기 프로세스와도 충돌해 스스로 막히기 때문이다. 열린 세션의 연결을 넘겨받아 쓴다.
- **WAL과 읽기:** 읽기 연결도 `-shm`·`-wal` 파일을 만들므로 `data_dir`은 쓰기 가능해야 한다. `immutable=1`은 쓰지 않는다. 쓰기 세션이 커밋한 행은 체크포인트 전이어도 읽기 연결에 보인다.
- **마이그레이션:** `src/garmin_pipeline/store/migrations/`의 `NNNN_<name>.sql`(이름은 `^[0-9]{4}_[a-z0-9_]+\.sql$`) 하나의 순서 목록이고, 번호는 `0001`부터 빈틈없이 이어진다. `.`으로 시작하는 이름(`.gitkeep` 등)은 무시하고, 그 밖의 이름·번호 중복·`0000`·빈틈·폴더 없음은 `MigrationError`다. 코드의 최신 번호는 마지막 번호(목록이 비면 0)이고 DB의 `PRAGMA user_version`과 비교한다.
  - `write_session`은 밀린 파일만 파일 하나를 트랜잭션 하나로 적용하고, 그 안에서 `user_version`을 그 번호로 올린다. 실패하면 그 파일만 롤백되어 DB는 직전 번호에 남고, 파일 이름을 담은 `MigrationError`(원인 연결)가 난다.
  - DB가 코드보다 새로우면 `write_session`도 아무것도 바꾸지 않고 `SchemaMismatch`를 낸다.
  - DDL은 마이그레이션 파일에만 쓴다. 지금은 `0001_auth_event.sql`(1.6 `login`), `0002_raw_response.sql`(2.1 원본 보존), `0003_run_fetch_error.sql`(2.2 실행·실패 기록), `0004_meta.sql`(2.3 수집 메타데이터), `0005_notification.sql`(2.7 알림 기록), `0006_normalize.sql`(3.1 정규화 결과·일일 요약 지표), `0007_sleep_stress_body_battery.sql`(3.2 수면·스트레스·Body Battery 열과 샘플), `0008_hr_sample.sql`(3.3 일일 심박 샘플), `0009_activity.sql`(3.4 활동 요약·존별 시간·활동 심박 샘플), `0010_activity_recovery.sql`(3.5 심박 회복 HRR, 5.7에서 테이블은 drop), `0011_exercise_set.sql`(5.4 근력 세트), `0012_drop_activity_recovery.sql`(5.7 HRR 테이블 제거), `0013_activity_body_battery.sql`(5.9 운동 중 Body Battery 열) 열셋이라 코드의 최신 번호는 13이다. 밀린 DB(예: 2.6까지의 `user_version = 4`)는 다음 `write_session`(예: `collect`)에서 밀린 파일만 적용되고 기존 행은 그대로다.

    | 마이그레이션 | 테이블 |
    |--------------|--------|
    | `0001_auth_event` | `auth_event(id INTEGER PRIMARY KEY, local_date TEXT NOT NULL, logged_in_at INTEGER NOT NULL)`. `login` 성공 한 번에 한 행(`local_date`: config `timezone` 기준 날, `logged_in_at`: UTC epoch ms) |
    | `0002_raw_response` | `raw_response(scope TEXT NOT NULL CHECK (scope IN ('day','activity')), key TEXT NOT NULL, endpoint TEXT NOT NULL, raw TEXT NOT NULL, fetched_at INTEGER NOT NULL, checked_at INTEGER NOT NULL, library_version TEXT NOT NULL, PRIMARY KEY (scope, key, endpoint))`. 응답 원문 하나에 한 행(`key`: `day`면 일 키 `YYYY-MM-DD`, `activity`면 `str(activityId)`. `fetched_at`: 원문이 마지막으로 바뀐 시각, `checked_at`: 마지막으로 확인한 시각, 둘 다 UTC epoch ms. `library_version`: 원문을 받은 `garminconnect` 버전). 지우는 경로는 없다 |
    | `0003_run_fetch_error` | `run(id INTEGER PRIMARY KEY, local_date TEXT NOT NULL, started_at INTEGER NOT NULL, finished_at INTEGER, status TEXT NOT NULL CHECK (status IN <RunStatus 8종>), detail TEXT NOT NULL DEFAULT '')`, 인덱스 `(local_date)`. 실행 한 번에 한 행(`finished_at`은 `running` 동안 NULL). `fetch_error(id INTEGER PRIMARY KEY, run_id INTEGER NOT NULL REFERENCES run(id), scope TEXT NOT NULL CHECK (scope IN ('day','activity')), key TEXT NOT NULL, endpoint TEXT NOT NULL, kind TEXT NOT NULL CHECK (kind IN ('transient','rejected')), local_date TEXT NOT NULL, occurred_at INTEGER NOT NULL, error_code TEXT NOT NULL)`, 인덱스 `(scope, key, endpoint)`. 항목 호출 실패 한 번에 한 행(`local_date`: 시도한 날의 일 키, `error_code`: `kind`와 같은 값). 시각은 모두 UTC epoch ms다. 두 테이블은 `collect`만 쓴다 |
    | `0004_meta` | `meta(key TEXT PRIMARY KEY, value TEXT NOT NULL)`. key 하나에 값 하나. 지금 쓰는 key는 둘이다. `history_start`(수집 대상의 첫 일 키 `YYYY-MM-DD`)는 첫 `collect`가 그날 `today − 30일`을 `INSERT OR IGNORE`로 한 번만 쓴다. `normalize_version`(정규화 규칙 버전 `str(store.NORMALIZE_VERSION)`)은 `normalize.run`의 전체 재구성이 끝에 upsert한다(아래 "normalize"). 마이그레이션 주석의 "쓰는 곳은 collect뿐"은 적용된 파일이라 고치지 않았다 |
    | `0005_notification` | `notification(local_date TEXT NOT NULL, event TEXT NOT NULL CHECK (event IN <NotifyEvent 7종>), detail TEXT NOT NULL DEFAULT '', at INTEGER NOT NULL, UNIQUE (local_date, event))`. 사람에게 알릴 사건 하나에 한 행(`local_date`: 그 실행의 날, `detail`: 그 실행의 `run.detail`, `at`: 처음 기록한 시각 UTC epoch ms). 같은 날 같은 사건은 처음 기록한 행이 남는다(`INSERT OR IGNORE`). 쓰는 곳은 `ports.TableNotifier`뿐이고 쓰기 락 안에서만 쓴다 |
    | `0006_normalize` | `normalize_result(scope TEXT NOT NULL CHECK (scope IN ('day','activity')), key TEXT NOT NULL, endpoint TEXT NOT NULL, ok INTEGER NOT NULL CHECK (ok IN (0,1)), error_code TEXT, raw_fetched_at INTEGER NOT NULL, normalized_at INTEGER NOT NULL, PRIMARY KEY (scope, key, endpoint))`, `ok = 1`이면 `error_code`가 NULL, `ok = 0`이면 NOT NULL(CHECK). 정규화한 원문 항목 하나에 마지막 결과 한 행(`raw_fetched_at`: 정규화한 원문의 `fetched_at`, `normalized_at`: 기록 시각, 둘 다 UTC epoch ms). `daily_metric(day_key TEXT NOT NULL PRIMARY KEY, …)`: 일 키 하나에 한 행이고 열은 모두 NULL 허용이다(열과 원본 필드는 아래 "normalize"). 두 테이블은 `normalize.run`만 쓴다(쓰기 락 안) |
    | `0007_sleep_stress_body_battery` | `daily_metric`에 `ALTER TABLE … ADD COLUMN`으로 수면·스트레스·Body Battery 열 14개(모두 INTEGER, NULL 허용)를 더한다(열과 원본 필드는 아래 "normalize"). `body_battery_sample(day_key TEXT NOT NULL, ts_ms INTEGER NOT NULL, level INTEGER, PRIMARY KEY (day_key, ts_ms))`: 일 키별 Body Battery 샘플 한 개에 한 행(`ts_ms`: UTC epoch ms, `level`: null·음수면 NULL). `normalize.run`만 쓴다(쓰기 락 안) |
    | `0008_hr_sample` | `hr_sample(day_key TEXT NOT NULL, ts_ms INTEGER NOT NULL, bpm INTEGER, PRIMARY KEY (day_key, ts_ms))`: 일 키별 심박 샘플 한 개에 한 행(`ts_ms`: UTC epoch ms, `bpm`: null·음수거나 반올림 결과가 0이면 NULL). `daily_metric`에는 열을 더하지 않는다. `normalize.run`만 쓴다(쓰기 락 안). 마이그레이션 주석의 "읽는 쪽(HRR)"은 적용된 파일이라 고치지 않았다(HRR은 5.7에서 없앴다) |
    | `0009_activity` | `activity(activity_id INTEGER PRIMARY KEY, day_key TEXT, type_key TEXT, start_ms INTEGER, duration_s INTEGER, distance_m INTEGER, avg_hr INTEGER, max_hr INTEGER, hr_zone1_s INTEGER, hr_zone2_s INTEGER, hr_zone3_s INTEGER, hr_zone4_s INTEGER, hr_zone5_s INTEGER)`: activityId 하나에 한 행이고 키 밖의 열은 모두 NULL 허용이다(`day_key`: 활동 목록의 로컬 날짜, `start_ms`: UTC epoch ms. 열과 원본 필드는 아래 "normalize"). `activity_hr_sample(activity_id INTEGER NOT NULL, ts_ms INTEGER NOT NULL, bpm INTEGER, PRIMARY KEY (activity_id, ts_ms))`: 활동별 심박 샘플 한 개에 한 행(`ts_ms`: UTC epoch ms, `bpm`: null·음수거나 반올림 결과가 0이면 NULL). `daily_metric`·`hr_sample`은 바꾸지 않는다. `normalize.run`만 쓴다(쓰기 락 안) |
    | `0010_activity_recovery` | 3.5의 HRR 테이블 `activity_recovery`를 만들었지만 0012가 drop했다(적용된 기록이라 파일은 그대로 둔다). 남는 것은 인덱스 `hr_sample_ts_ms ON hr_sample (ts_ms)`(시각 범위 조회용, `hr_sample`의 열·PK는 그대로)뿐이다 |
    | `0011_exercise_set` | `exercise_set(activity_id INTEGER NOT NULL, set_index INTEGER NOT NULL, category TEXT, exercise_name TEXT, reps INTEGER, weight_g INTEGER, duration_s INTEGER, is_rest INTEGER NOT NULL CHECK (is_rest IN (0,1)), PRIMARY KEY (activity_id, set_index))`: `activity_exercise_sets` 원문의 `exerciseSets` 한 원소(REST 포함)에 한 행이다. 무게는 g 정수, 시간은 정수 초, 결측·음수 센티넬은 NULL이다(무게는 0도 NULL. 규칙은 아래 "normalize"의 세트). FK는 없다. `normalize.run`만 쓰고(쓰기 락 안) 한 활동의 행을 항목 트랜잭션 하나로 통째 교체한다. 5.10 후속에서 무게 0을 NULL로 바꾸며 `store.NORMALIZE_VERSION`을 5 → 6으로 올렸다(마이그레이션 없음. 다음 `normalize`(또는 `collect`)가 한 번 전체 재구성해 무게 0 행을 NULL로 바꾼다) |
    | `0012_drop_activity_recovery` | `DROP TABLE activity_recovery`(5.7, FR47·AD-13). 2분 간격 일일 심박으로는 HRR이 꾸준히 계산되지 않아 facts v2가 읽지 않으므로 normalize도 더는 계산하지 않는다. 인덱스 `hr_sample_ts_ms`와 `hr_sample`은 그대로다(5.11이 시각 범위 조회에 쓴다). 파생 테이블 모양이 바뀌어 `store.NORMALIZE_VERSION`도 3 → 4로 올렸으므로, 이 마이그레이션 뒤 첫 `normalize`(또는 `collect`)가 한 번 전체 재구성한다(남은 테이블 값은 같다) |
    | `0013_activity_body_battery` | `ALTER TABLE activity_hr_sample ADD COLUMN body_battery INTEGER`(5.9, AD-13): `activity_details` 원문의 `directBodyBattery` 채널(운동 중 Body Battery)을 같은 샘플 행에 둔다(규칙은 아래 "normalize"). 기존 행은 NULL로 남고, 파생 열 모양이 바뀌어 `store.NORMALIZE_VERSION`을 4 → 5로 올렸으므로 이 마이그레이션 뒤 첫 `normalize`(또는 `collect`)가 한 번 전체 재구성해 값을 채운다. 운동 세션과 소모는 facts가 매번 계산하고 저장하지 않는다(세션 테이블 없음) |
    | `0014_zone_bounds_stress_bb` | `activity`에 `hr_zone1_low_bpm`…`hr_zone5_low_bpm`(INTEGER, NULL 허용)을 더한다(`activity_hr_in_timezones`의 존별 `zoneLowBoundary`). `stress_bb_sample(day_key TEXT NOT NULL, ts_ms INTEGER NOT NULL, level INTEGER, PRIMARY KEY (day_key, ts_ms))`와 시각 인덱스 `stress_bb_sample_ts_ms(ts_ms)`를 만든다(`stress_data`의 3분 Body Battery 샘플). `NORMALIZE_VERSION` 7의 전체 재구성이 과거 원문도 채운다 |
  - 테스트는 `store._migrations_dir()`만 monkeypatch해 `tmp_path`의 `.sql`을 쓴다(`dates._utc_now`와 같은 방식).
- **오류:** `store`가 정의한다. `StoreError(Exception)`와 그 하위 `LockTimeout`·`SchemaMismatch`(`.found`·`.expected`)·`DbMissing`·`MigrationError`다. `collect`가 Garmin 실패를 `errors.DomainError`로 분류할 때 락 실패가 섞이지 않도록 `DomainError` 밖에 둔다.
- **pytest 가드:** `config.under_pytest()`가 참이고 `data_dir`(그대로, 그리고 `resolve()` 뒤)이나 `resolve()`한 DB·락 파일 경로의 구성요소 중 `runtime`이 있으면(대소문자 무시) 세 공개 함수 모두 아무것도 만들지 않고 `StoreError`를 낸다. `data_dir`·`garmin.db`·`.write.lock`이 심링크로 `runtime/`에 닿아도 막는다.

## 커버리지

`garmin_pipeline.coverage`는 저장된 데이터(`raw_response`·`fetch_error`·`run`)만 읽어 "무엇을 받았고 무엇이 빠졌는지"를 판정한다. `collect`의 계획이 이 기준을 쓴다. 쓰기·트랜잭션·시계 읽기를 하지 않으므로 일관된 한 시점이 필요하면 호출자가 `store.transaction(conn)`으로 묶는다. 쓰기·읽기 연결 어느 쪽이든 받는다.

| 이름 | 뜻 |
|------|----|
| `DAY_ENDPOINTS`·`ACTIVITY_ENDPOINTS` | `garmin`의 같은 이름 튜플과 같다(순서 포함, 테스트가 고정한다). `coverage`는 `garmin`을 import할 수 없어 따로 둔다 |
| `CoverageState` | `data`·`empty`·`failed`·`missing` |
| `FetchErrorKind` | `fetch_error.kind`: `transient`·`rejected` |
| `NOT_RUN` | `"not_run"`. 그날 실행 기록이 없을 때의 `DayStatus.status` |
| `CoverageItem(scope, key, endpoint, day_key, state, final, checked_at, plannable, fresh)` | 항목 하나의 판정 |
| `DayStatus(status, detail, finished_at)` | 그날 마지막 실행의 상태 |
| `items(conn, cfg, start, end)` | [start, end]의 모든 `CoverageItem`. `start > end`면 `ValueError` |
| `incomplete(item)` | 아직 받을 항목인지. `collect`의 계획과 재시도 계획이 함께 쓰는 유일한 미완료 판정 |
| `day_status(conn, day)` | 그날의 `DayStatus` |

- **항목:** 일 키마다 day-scope 9종(`day_key = key`)이다. activity-scope는 저장된 **모든** `activities_by_date` 원문(범위 밖 key 포함)을 `rawparse.activity_refs`로 읽어, 활동의 일 키(`startTimeLocal` 날짜)가 범위 안인 activityId마다 기본 3종(`activity`·`activity_details`·`activity_hr_in_timezones`, `key = str(id)`)이고, 목록 항목의 `rawparse.ActivityRef.needs_sets`(`totalSets > 0`이거나 `summarizedExerciseSets`가 비어 있지 않음)가 참인 활동만 그 뒤에 `activity_exercise_sets`(세트 상세)가 붙는다. 같은 id가 여러 목록에 나오면 목록 key 오름차순으로 처음 것(소속 목록)을 쓰고, `needs_sets`도 그 목록의 값이다. 순서는 일 키 오름차순, 그 안에서 day 9종(`DAY_ENDPOINTS` 순) → 활동(목록 순)별 3종(`ACTIVITY_ENDPOINTS` 순) 다음 세트 상세다.
- **상태:** 원문 행이 있으면 `raw == 'null'`이면 `empty`, 아니면 `data`이고 `checked_at`은 그 행 값이다. 원문이 실패 기록을 이긴다. 원문이 없고 `fetch_error`가 있으면 `failed`, 둘 다 없으면 `missing`이고 두 경우 `checked_at = None`이다.
- **확정(`final`):** `checked_at`이 있고 `dates.day_key(checked_at, cfg) > day_key`일 때만 참이다(두 scope 같음). 그날이 지난 뒤 다시 확인한 원문만 확정이다.
- **최신(`fresh`):** `activity_exercise_sets`이고 원문이 있으면 `checked_at >= 소속 목록 원문의 fetched_at`일 때 참이다. 그 밖의 항목(다른 endpoint, 원문 없음)은 늘 참이다. `state`는 바꾸지 않는다. 목록 원문은 내용이 바뀔 때만 `fetched_at`이 바뀌므로, 앱에서 세트를 고쳐 목록이 바뀐 날의 근력 활동만 `fresh=False`가 되어 세트를 다시 받는다.
- **미완료(`incomplete`):** `plannable`이 아니면 거짓, `data`·`empty`가 아니면 참이다. 그 밖에는 day-scope는 `final`이 아니면, activity-scope는 `fresh`가 아니면 참이다.
- **계획 가능(`plannable`):** 그 항목의 `kind = 'rejected'` 실패가 난 서로 다른 `local_date` 수가 `max_rejected_attempts` 미만이면 참이다. 같은 날 반복한 거부와 `transient`는 날 수에 세지 않는다.
- **형식이 틀린 활동 목록:** 목록 원문이 `rawparse.RawParseError`면 전파하지 않는다. 그 key의 `activities_by_date` 항목은 상태를 그대로 두고 `final=False`로 내며 그 목록의 활동은 내지 않는다. key와 오류 메시지(원문 내용 없음)만 WARNING 로그로 남긴다. 그래서 `collect`가 그날 목록을 다시 받고, 응답이 고쳐지면 저절로 풀리며, 다른 날 수집은 멈추지 않는다.
- **`day_status`:** `local_date = day.isoformat()`이고 `status != 'skipped_blocked'`인 `run` 행 중 `started_at`이 가장 늦은(같으면 rowid가 큰) 행의 (`RunStatus(status)`, `detail`, `finished_at`)이다. 단 lock_timeout 행(`status = 'error'`이고 `detail`의 첫 토큰이 `lock_timeout`, 예: `lock_timeout`·`lock_timeout timezone_mismatch`)은 그날 `skipped_blocked`도 lock_timeout도 아닌 행이 하나도 없을 때만 고르고, 그때는 lock_timeout 행 중 같은 순서로 가장 늦은 행이다. 같은 `started_at`이어도 lock_timeout 행이 진다. 락을 못 잡아 수집하지 않은 실행이 그날 실제 수집 결과(락을 쥔 `collect`의 결과 포함)를 가리지 않게 한다. 행이 없으면 `DayStatus(NOT_RUN, "", None)`이다.

## Garmin 어댑터

Garmin에는 `garmin_pipeline.garmin`으로만 닿는다. 어댑터가 무인 세션 열기, 대화형 로그인, 계정 단위 당일 차단 파일, 로그인·데이터 단계 예외의 도메인 오류 변환, 데이터 호출(원문 그대로)과 호출 간격을 맡는다. 어느 공개 API에도 비밀번호·이메일 파라미터가 없다. 무인 세션은 tokenstore(`config.tokenstore`)로만 로그인하고, 대화형 로그인은 자격 증명을 `LoginPrompts`로 그때그때 묻는다.

| 이름 | 하는 일 |
|------|---------|
| `GarminPort` | 호출자가 쓰는 Protocol. `blocked_today() -> RunStatus \| None`, `open_session(*, first_call_endpoints: Collection[str] = ()) -> AbstractContextManager[GarminSession]`(`first_call_endpoints`는 아래 "연속 403"의 첫 호출 보호 대상) |
| `GarminSession` | 열린 세션 Protocol. `fetch_day(endpoint, day: date) -> RawResponse`, `fetch_activity(endpoint, activity_id: int) -> RawResponse` |
| `GarminAdapter(cfg, *, sleep=time.sleep)` | 실제 구현. `sleep`은 호출 간격을 쉬는 함수(테스트가 주입) |
| `RawResponse` | frozen dataclass `(endpoint: str, payload: object, library_version: str)` |
| `DAY_ENDPOINTS`·`ACTIVITY_ENDPOINTS` | endpoint 이름 튜플(아래 표 순서) |
| `LIBRARY_VERSION` | `importlib.metadata.version("garminconnect")`(지금 0.3.17) |
| `GarminAdapterError` | 어댑터 실행 환경 오류의 바탕. 하위는 `SessionLockTimeout`(`.reason = "session_lock_timeout"`)·`SessionBlocked`(`.reason: RunStatus`)·`BlockFileInvalid` |
| `LoginPrompts` | 대화형 로그인 프롬프트 Protocol. `credentials() -> tuple[str, str]`(이메일, 비밀번호), `mfa_code() -> str` |
| `interactive_login(cfg, prompts) -> None` | 자격 증명(과 MFA 코드)으로 새로 로그인해 `<tokenstore>/garmin_tokens.json`(0600)을 쓴다. 아래 "대화형 로그인" |
| `MFA_MAX_ATTEMPTS` | 틀린 MFA 코드를 같은 인스턴스로 다시 묻는 최대 횟수(3, 첫 시도 포함) |
| `TOKEN_FILENAME`·`token_saved_at(cfg) -> int \| None` | 토큰 파일 이름(`garmin_tokens.json`, 라이브러리 `token_file_path(<폴더>)`와 같다고 테스트가 고정)과 그 mtime(UTC epoch ms, `st_mtime_ns // 1_000_000`). 내용은 읽지 않는다. 파일이 없거나 읽지 못하면 `None`(없음이 아닌 `OSError`는 errno만 WARNING). `collect`의 재로그인 판정이 쓴다 |

```python
port: GarminPort = GarminAdapter(cfg)  # 테스트는 FakeGarmin()
if (reason := port.blocked_today()) is not None:
    ...  # skipped_blocked, 네트워크 0회
with port.open_session() as session:  # 세션 락은 블록 끝까지
    raw = session.fetch_day("sleep_data", day)  # raw.payload를 그대로 저장
```

- **열기 순서:** tokenstore가 디렉터리가 아니면(없음 포함) 아무것도 만들지 않고 `AuthFailed(token_invalid)` → `<tokenstore>/.session.lock`(0600)에 `flock(LOCK_EX)` → `block.json` 확인 → 라이브러리 클라이언트 생성 → (`cffi_api_session`이면 API 세션 교체) → `login(<tokenstore>)` → 블록 실행. 블록을 나가면 정상이든 예외든, 락을 잡은 뒤 실패해도 락을 푼다. `login(None)`(`GARMINTOKENS` 대체)은 부르지 않고, 자동 재로그인·재시도를 더하지 않는다.
- **세션 락:** `store`의 쓰기 락과 같은 규칙이다. 못 잡으면 0.1초 간격으로 다시 시도하고 `lock_wait_seconds`가 지나면 락 경로와 대기 초를 담은 `SessionLockTimeout`이다. `0`이면 한 번만 시도한다. 같은 프로세스에서 같은 락 파일(`st_dev`·`st_ino`)로 중첩하면 기다리지 않고 `RuntimeError`다. 락 fd는 하위 프로세스에 상속되지 않는다. 계정 단위라 같은 tokenstore를 쓰는 모든 명령·환경이 한 번에 하나만 Garmin에 닿는다.
- **당일 차단 파일:** `<tokenstore>/block.json`이고 형식은 `{"schema_version": 1, "local_date": "YYYY-MM-DD", "reason": "rate_limited" | "blocked_403"}`(`reason`은 `RunStatus` 값)이다.
  - `local_date`가 config `timezone` 기준 오늘(`dates.today(cfg)`)이면 `blocked_today()`가 그 `RunStatus`를 돌려주고, `open_session()`은 클라이언트를 만들지도 로그인하지도 않고 `SessionBlocked`를 낸다. 같은 날 두 번째 실행이 `rate_limited`가 아니라 `skipped_blocked`로 남도록 도메인 오류로 던지지 않는다.
  - 지난 날짜는 무시하고 지우지 않는다. 파일이 없으면 차단이 아니다. 어댑터는 이 파일을 지우지 않고, 다음 차단이 덮어쓴다.
  - JSON·키(정확히 세 키)·값·`schema_version`이 틀리거나 읽지 못하면 네트워크 없이 `BlockFileInvalid`다(fail-closed).
  - 쓰기는 세션 락을 쥔 채 같은 폴더 임시 파일(0600) + `os.replace`로 원자적으로 한다. 그래서 `blocked_today()`는 락 없이 읽는다.
- **로그인 예외 분류:** `login()`이 던진 것 중 `garminconnect` 예외와 `OSError`만 바꾸고, 그 밖(`TypeError` 등)은 그대로 전파한다. 예외 자신부터 `__cause__`(없으면 `__context__`)를 따라가며(순환 방지) 처음 찾은 HTTP 상태를 쓴다. 상태 원천은 `.response.status_code`(정수), `GarminConnectTooManyRequestsError`(=429), `garminconnect` 예외 메시지의 `(?:API Error|Error|HTTP)\s*(\d{3})`다.

  | 상태 | 도메인 오류 | `block.json` |
  |------|-------------|--------------|
  | 403 | `Blocked403` | 오늘·`blocked_403` 기록 |
  | 429 | `RateLimited` | 오늘·`rate_limited` 기록 |
  | 5xx | `Transient` | 안 씀 |
  | 그 밖 상태(401·기타 4xx) | `AuthFailed(token_invalid)` | 안 씀 |
  | 상태 없음, 사슬에 `OSError`(requests·curl_cffi 네트워크 오류) | `Transient` | 안 씀 |
  | 상태 없음, `OSError` 없음(토큰 파일 없음·깨짐 등) | `AuthFailed(token_invalid)` | 안 씀 |

  도메인 오류는 `from None`으로 던지고 메시지에는 단계와 상태 코드만 담는다(예: `login 단계: HTTP 503`). 차단 파일 쓰기가 실패해도 도메인 오류는 그대로 던지고 errno만 로그에 남긴다.
- **대화형 로그인:** `interactive_login(cfg, prompts)`는 tokenstore 폴더가 이미 있다고 보고(`auth.login`이 만든다) 다음 순서로 진행한다.
  1. `block.json`이 오늘 날짜면 프롬프트도 클라이언트 생성도 없이 `SessionBlocked`, 깨졌으면 `BlockFileInvalid`다.
  2. 세션 락 밖에서 `prompts.credentials()`.
  3. 세션 락 → 차단 재확인 → 클라이언트 생성(`cffi_api_session`이면 아래와 같은 교체) → `client.client.login(email, password, return_on_mfa=True)`.
  4. MFA가 필요하면 락을 놓고 `prompts.mfa_code()`를 부른 뒤 다시 락 → 차단 재확인 → 같은 인스턴스의 `client.resume_login(None, code)`(라이브러리가 프로필도 확인한다). 틀린 코드(`AuthFailed`이고 라이브러리가 아직 MFA를 기다림)는 최대 `MFA_MAX_ATTEMPTS`번까지 다시 묻고, 그 밖의 오류는 바로 중단한다. MFA가 없으면 `client._load_profile_and_settings()`로 헬스체크한다.
  5. 락을 쥔 채 `client.client.dump(<tokenstore>)`(0600 임시 파일 + 교체).

  기존 토큰 파일은 읽지 않는다(`Garmin.login(tokenstore)`는 토큰을 먼저 읽고 `GARMINTOKENS`로 폴백하므로 쓰지 않는다). 그래서 무효 토큰이 있어도 늘 다시 로그인하고, 성공할 때마다 토큰 파일 mtime이 갱신된다. 로그인 단계 예외는 아래 "로그인 예외 분류"와 같은 규칙(429·403이면 `block.json`)으로 바꾸고, 토큰 쓰기의 `OSError`와 프롬프트가 던진 예외는 바꾸지 않고 그대로 던진다. 프롬프트를 부르는 동안에는 세션 락을 쥐지 않으므로 다른 명령이 기다리지 않는다.
- **curl_cffi:** `cffi_api_session = true`면 `login()` 전에 라이브러리의 API 세션(`client.client._api_session`)을 `curl_cffi.requests.Session(impersonate="chrome", discard_cookies=True)`로 바꾼다. 원래 세션의 "쿠키 전부 거부" 정책과 같게 받은 쿠키를 버린다. `false`면 손대지 않는다. 사용 여부는 1.7 `smoke`가 정한다.
- **오류 계층:** `GarminAdapterError`는 `errors.DomainError` 밖에 둔다. `collect`가 Garmin 실패(`DomainError`)와 실행 환경 실패(락·차단 파일)를 섞지 않게 하고 1.2의 닫힌 도메인 오류 6종을 지키기 위해서다.
- **로그:** `garmin_pipeline.garmin` 로거에 단계·상태 코드·도메인 오류 이름·차단 사유(와 쓰기 실패 errno)만 남긴다(데이터 단계는 endpoint·연속 403 횟수·첫 호출 보호 여부(`first_call`), 대화형 로그인은 MFA 여부·시도 횟수도). 라이브러리 예외 문자열, 토큰, 응답 본문, 이메일, 비밀번호, MFA 코드는 남기지 않는다.
- **테스트:** 라이브러리 클라이언트는 `garmin._new_client()` 하나에서만 만든다. `tests/conftest.py`의 autouse fixture가 모든 테스트에서 이 seam을 "호출되면 실패"로 바꾼다. curl_cffi는 Python 소켓을 거치지 않아 소켓 차단으로는 실제 Garmin 호출을 막지 못하기 때문이다. 어댑터 단위 시험은 이 seam만 `tests/garmin_fakes.py`의 `StubGarminClient`(`login` 호출과 그 시점 `_api_session` 기록, 예외 주입), `StubLoginClient`(대화형 로그인: `client.login`·`resume_login`·`_load_profile_and_settings`·`client.dump` 호출 순서와 그 시점 상태 관찰, needs_mfa·코드별 결과·예외 주입, 0600 가짜 토큰), 전송 stub을 낀 클라이언트(아래 데이터 호출)로 바꾸고(프롬프트 대역은 `ScriptedPrompts`), 호출자 테스트는 `GarminPort`를 `FakeGarmin`(`calls`·`first_call_endpoints` 기록, `blocked`·`open_error`·`responses` 주입)으로 바꾼다.

### 데이터 호출

세션의 데이터 호출은 `fetch_day(endpoint, day)`와 `fetch_activity(endpoint, activity_id)`뿐이다. endpoint 이름은 라이브러리 메서드 이름에서 `get_`을 뺀 것이고, 모르는 이름은 대기·네트워크 없이 `ValueError`다(`fetch_day`의 `day`가 `date`가 아니면 `TypeError`). `payload`는 라이브러리가 디코드한 값을 복사·가공 없이 그대로 담는다. `collect`의 저장·계획·날짜 간격(`date_pause_seconds`)은 이 어댑터 밖이다.

| 범위 | endpoint | 라이브러리 호출 |
|------|----------|-----------------|
| day | `sleep_data`·`hrv_data`·`rhr_day`·`stress_data`·`training_readiness` | 같은 이름의 `get_*`(`day.isoformat()`) |
| day | `heart_rates`·`user_summary` | `connectapi(<라이브러리 메서드와 같은 URL>, params=<같은 params>)` 직접. 라이브러리 메서드가 빈 응답을 상태 없는 예외로 바꿔 `NoData`를 구별하지 못하게 하기 때문이다 |
| day | `body_battery`·`activities_by_date` | start=end. `activities_by_date`의 페이징은 라이브러리가 내부에서 한다 |
| activity | `activity`·`activity_details`·`activity_hr_in_timezones`·`activity_exercise_sets` | 같은 이름의 `get_*`. `activity_details`는 라이브러리 기본 인자로 부르고 원문을 파싱하지 않는다. `activity_exercise_sets`(`/activity-service/activity/{id}/exerciseSets`)는 `needs_sets`인 활동에만 부른다(어느 활동에 무엇을 부를지는 `coverage.items`가 정한다) |

- **결과 분류:** 데이터 단계에서도 `garminconnect` 예외와 `OSError`만 바꾸고 그 밖(`TypeError`, 날짜·ID 검증 `ValueError` 등)은 그대로 전파한다. 상태 찾기는 로그인 단계와 같다(사슬 탐색, 같은 상태 원천). 라이브러리 재시도(`5xx`·`requests` 연결 오류만 3번 더)는 바꾸지 않는다.

  | 결과 | 도메인 오류 | `block.json` |
  |------|-------------|--------------|
  | 429 | `RateLimited` | 오늘·`rate_limited` 기록 |
  | 401(라이브러리가 갱신·재요청한 뒤에도) | `AuthFailed(token_invalid)` | 안 씀 |
  | 403 | `Rejected`, `max_consecutive_403`번째 연속이면 `Blocked403` | 승격 시 오늘·`blocked_403` 기록 |
  | 404, 정상 응답이 `None`·`[]`·`{}`(204) | `NoData` | 안 씀 |
  | 그 밖 4xx | `Rejected` | 안 씀 |
  | 5xx, 상태 없음(네트워크·비JSON 본문 등) | `Transient` | 안 씀 |
  | `user_summary`가 dict이고 `privacyProtected is True` | `AuthFailed(privacy_protected)` | 안 씀 |

  호출자는 `NoData`를 원본 `null`로, `Rejected`·`Transient`를 그 항목만 실패로 남기고, `RateLimited`·`Blocked403`·`AuthFailed`면 실행을 멈춘다. 도메인 오류는 `from None`이고 메시지는 endpoint와 상태 코드뿐이다(예: `stress_data: HTTP 503`).
- **연속 403:** 세션마다 센다. 데이터 호출이 HTTP 403으로 끝나면 +1, 그 밖의 결과(성공·`NoData`·다른 도메인 오류)는 0으로 되돌린다. 분류 밖 예외(`TypeError` 등, Garmin 응답이 아님)는 늘리지도 되돌리지도 않는다.
  - **첫 호출 보호:** `open_session(first_call_endpoints=...)`로 받은 endpoint의 403은 여전히 `Rejected`지만 연속 403을 늘리지도 되돌리지도 않는다(분류 밖 예외와 같은 취급). 그래서 그 endpoint만으로는 승격하지 않고, 다른 endpoint 403 사이에 끼어도 그 연속을 끊지 않는다. 그 endpoint의 성공·`NoData`·다른 결과와 429(`RateLimited` → `block.json`)는 기존 규칙 그대로다. 어느 endpoint를 보호할지는 호출자(`collect`)가 정하고 어댑터는 저장하지 않는다. 이름이 `DAY_ENDPOINTS`·`ACTIVITY_ENDPOINTS` 밖이면 세션 락·네트워크 전에 `ValueError`다. 기본값 `()`는 보호 없음이고 `auth.smoke`는 인자 없이 부른다.
- **차단 뒤:** `RateLimited`·`Blocked403`이면 로그인 단계와 같은 방식으로 `block.json`을 쓴 뒤(쓰기 실패는 errno만 로그) 던지고, 그 세션의 이후 데이터 호출은 대기·네트워크 없이 `SessionBlocked(사유)`다.
- **호출 간격:** 매 데이터 호출 직전에 `random.uniform(call_pause_min_seconds, call_pause_max_seconds)`초를 `sleep`으로 쉰다. 로그인도 호출로 치므로 첫 데이터 호출 전에도 쉰다. `SessionBlocked`·모르는 endpoint는 쉬지 않는다. 라이브러리 재시도 백오프는 이 간격과 별개다.
- **로그:** 단계(`data`)·endpoint·상태 코드·오류 이름·연속 403 횟수·첫 호출 보호 여부(`first_call=True|False`, endpoint가 보호 대상이면 참)·차단 사유만 남긴다. 날짜·activityId·응답 본문·라이브러리 예외 문자열은 남기지 않는다. 라이브러리 로거 다섯(`garminconnect`·`curl_cffi`·`urllib3`·`requests`·`matplotlib`, 예: `garminconnect`는 재시도마다 display name이 든 URL 경로와 예외 문구를 WARNING으로 남긴다)은 명령이 수준 `CRITICAL + 1`·전파 끔으로 막는다(규칙은 아래 `login`의 "명령 로그").
- **테스트 대역:** `FakeGarmin(responses={(endpoint, key): payload 또는 예외})`(day는 `date`, activity는 activityId). 값은 실제 세션과 같은 원문 검사(빈 응답→`NoData`, `user_summary` 비공개→`AuthFailed(privacy_protected)`)를 거쳐 그대로 `RawResponse.payload`가 되고, 없으면 `NoData`, `day`가 순수 `date`가 아니면 `TypeError`, 닿은 호출은 `calls`에 `(endpoint, key)`로 남는다. `RateLimited`·`Blocked403`을 던지면 `blocked`를 그 사유로 바꿔 `block.json`을 흉내 내고 이후 호출은 `SessionBlocked`다. `open_session(first_call_endpoints=...)`의 인자는 열 때마다 `first_call_endpoints`에 `frozenset`으로 남고, 연속 403 승격과 그 첫 호출 보호 예외는 흉내 내지 않는다(주입한 예외를 그대로 던진다). 어댑터 데이터 시험은 `GarminTransport`·`transport_client`로 실제 `garminconnect.Garmin()`의 `client.connectapi`만 바꿔(백오프 0, `login` no-op, 가짜 display name) 라이브러리의 실제 메서드·데코레이터·재시도를 돌린다.

## login

Garmin에 대화형으로 로그인해 tokenstore를 만든다. 무인 세션(수집)은 이 토큰으로만 로그인하므로 처음 한 번, 그리고 토큰이 무효해졌을 때(`AuthFailed(token_invalid)`) 사람이 직접 실행한다.

```sh
uv run garmin-pipeline login [--config PATH]
```

이메일과 MFA 코드는 `input`, 비밀번호는 `getpass`(화면에 보이지 않음)로 받는다. 표준 입력이 터미널이 아니면(`< creds.txt`, 파이프) `getpass`가 stdin에서 읽게 되므로 묻기 전에 거부한다. 비밀번호·이메일은 인자·환경변수·설정·파일로 받지 않고, 출력·로그·파일 어디에도 남기지 않는다. 이메일·MFA 코드는 앞뒤 공백을 뗀다.

- **순서(`auth.login(cfg, prompts=None)`):**
  1. tokenstore와 없는 부모를 0700으로 만든다. tokenstore가 이미 있으면 `chmod 0700`한다(이미 있는 부모는 건드리지 않는다).
  2. `garmin.interactive_login`: 오늘 당일 차단이면 묻지 않고 끝 → 이메일·비밀번호 → 로그인 → (필요하면) MFA 코드(틀리면 최대 3번) → 토큰 저장. 자세한 순서와 락 구간은 위 "Garmin 어댑터"의 "대화형 로그인".
  3. 로그인이 끝난 직후 `dates.today(cfg)`·`dates.now_ms()`를 잡고, `store.write_session` 안에서 그 값으로 `auth_event` 한 행을 INSERT한다(밀린 마이그레이션도 이때 적용). 쓰기 락을 기다린 시간은 기록에 끼지 않는다.
- **늘 새로 로그인:** 기존 토큰을 읽지 않고 자격 증명으로 로그인해 덮어쓴다. 유효하거나 깨진 토큰이 있어도 같고, 성공할 때마다 `auth_event`가 한 행 늘고 토큰 파일 mtime이 갱신된다.
- **종료 코드:**

  | 코드 | 경우 | 출력 |
  |------|------|------|
  | 0 | 토큰 저장과 `auth_event` 기록까지 마침 | stdout에 저장 위치 한 줄 |
  | 1 | 당일 차단(`SessionBlocked`), 인증 실패(`AuthFailed`, 틀린 MFA 3번 포함), 429·403(`block.json` 기록), 일시 오류(`Transient`), 세션 락 시간 초과, 깨진 `block.json`, 표준 입력이 터미널이 아님(묻기 전에 거부), 빈 입력, 취소(Ctrl-C·EOF, 기록 단계 포함), tokenstore·토큰 쓰기 실패, 토큰 저장 뒤 DB 쓰기 실패(쓰기 락 시간 초과 등) | stderr에 `login 실패: <사유>` 한 줄 |
  | 2 | 설정 오류(`ConfigError`), 인자 오류 | stderr에 `설정 오류: …` 또는 argparse 사용법 |

- **만드는 파일:**

  | 경로 | 권한 | 내용 |
  |------|------|------|
  | `<tokenstore>/` (와 없던 부모) | 0700 | 토큰 폴더 |
  | `<tokenstore>/garmin_tokens.json` | 0600 | 라이브러리 토큰(`dump`). 0600 임시 파일 + 교체로 쓴다 |
  | `<tokenstore>/.session.lock` | 0600 | 세션 락 |
  | `<tokenstore>/block.json` | 0600 | 429·403일 때만 |
  | `<data_dir>/garmin.db` | — | `auth_event` 행 |
  | `<data_dir>/logs/login.log` | 폴더 0700 | 명령 로그 |

- **명령 로그:** `<data_dir>/logs/login.log`(`RotatingFileHandler`, 1 MB × 3)를 명령 동안 `garmin_pipeline` 로거(INFO)에 붙이고 끝나면 떼고 닫는다. 시각은 `time.gmtime` 기준 UTC ISO 8601(`2026-10-16T01:00:00.000Z`)이다. 단계·상태 코드·오류 이름·MFA 여부·시도 횟수만 남긴다. 라이브러리 로거 다섯(`garminconnect`·`curl_cffi`·`urllib3`·`requests`·`matplotlib`)은 명령 동안 `propagate = False`, 수준 `logging.CRITICAL + 1`로 막고(라이브러리 로그에 display name이 든 URL 경로·응답 본문·예외 문자열이 있을 수 있다) 나갈 때(예외 포함) 전파·수준을 진입 전 값으로 되돌린다. 기록을 막는 것은 수준이다. CRITICAL을 넘으므로 기록 자체가 만들어지지 않아 루트 처리기에도 `lastResort`(stderr → `launchd-*.err.log`)에도 가지 않는다. 하위 로거(`garminconnect.client` 등)는 수준을 상속한다. 전파 차단은 기록이 루트 처리기에 닿지 않게 할 뿐이라, 하위 로거가 자기 수준을 따로 두면 이 차단을 비켜 가 `lastResort`로 간다(지금 다섯 라이브러리 중 그런 것은 없다). 모든 하위 명령이 같은 규칙을 지난다. 로거 설정(`setLevel`·`addHandler`·`propagate` 등)은 `cli`만 하고, 다른 모듈은 하지 않는다(시험이 AST로 검사한다). 루트 로거·`lastResort`는 바꾸지 않고 `logging.disable`도 쓰지 않는다.
- **tokenstore 위치(A1, 2026-10-16 사용자 확인):** 기본값 `~/.garmin-pipeline/tokens` 그대로다. 당일 차단이 계정 단위라 운영과 개발이 같은 tokenstore를 공유하고, `config.py`·`config.toml`은 바꾸지 않는다.

## smoke

저장된 토큰만으로 무인 인증과 데이터 호출이 실제로 되는지 한 번 확인한다. 무인 수집을 켜기 전에 #444(데이터 403)·#453(로그인 429)를 알아내고 `cffi_api_session` 기본값을 정하는 데 쓴다.

```sh
uv run garmin-pipeline smoke [--config PATH]
```

- **하는 일(`auth.smoke(cfg, port=None)`):** `GarminPort.open_session()`으로 프롬프트 없이 세션을 열고(tokenstore 로그인 = 프로필 헬스체크), config `timezone` 기준 어제 날짜로 `user_summary`를 한 번 부른다. 기본 `port`는 `GarminAdapter(cfg)`다. 재시도·자동 재로그인·프롬프트가 없고, 비밀번호·이메일을 묻거나 받지 않는다. DB는 열지 않고(`auth_event` 없음), tokenstore 폴더는 만들거나 권한을 바꾸지 않는다(세션 락 파일, 라이브러리의 토큰 갱신 저장은 있을 수 있다). 로그인 429·403, 데이터 429(·`max_consecutive_403`번 연속 403)이면 어댑터가 `block.json`을 쓴다.
- **출력 예:**

  ```text
  cffi_api_session: false
  garminconnect: 0.3.17
  세션 열기: 성공
  데이터 호출(user_summary, 2026-10-15): 성공
  ```

  세션을 열지 못하면 `세션 열기: 실패`에서 멈춘다. 데이터 줄은 `성공`·`데이터 없음`(404·빈 응답, 인증과 API 경로는 확인된 것이다)·`실패` 중 하나다. 실패하면 stderr에 `smoke 실패: <사유와 안내>` 한 줄을 쓴다. 응답 본문·이메일·토큰은 어디에도 쓰지 않는다.
- **종료 코드:**

  | 코드 | 경우 |
  |------|------|
  | 0 | 세션 열기 성공 + 데이터 `성공` 또는 `데이터 없음` |
  | 1 | 아래 안내 표의 실패, 로그 파일을 열지 못함 |
  | 2 | 설정 오류(`ConfigError`), 인자 오류 |

- **안내 문구:**

  | 실패 | 안내 |
  |------|------|
  | `AuthFailed(token_invalid)`(tokenstore 없음, 토큰 만료, 데이터 401) | `garmin-pipeline login`을 다시 실행하라 |
  | `AuthFailed(privacy_protected)` | 계정 프로필이 비공개라 데이터를 받을 수 없다. 재로그인 안내는 하지 않는다 |
  | 데이터 `Rejected`, `cffi_api_session = false` | #444 의심. config에 `cffi_api_session = true`를 적고 다시 `smoke`하라 |
  | 데이터 `Rejected`, `cffi_api_session = true` | #444 의심. curl_cffi로도 거부됐다. VPN·회사망 등 네트워크를 확인하라 |
  | `RateLimited`·`Blocked403`(로그인·데이터) | 당일 차단을 기록했으니 내일 다시 시도하라. 로그인 단계 429면 #453 의심을, 로그인 단계 403이면 #444 의심(`cffi_api_session = false`면 내일 `true`로 다시 `smoke`하라)을 덧붙인다 |
  | `SessionBlocked`(오늘 차단 중) | 내일 다시 시도한다 |
  | `Transient`·`SessionLockTimeout`·`BlockFileInvalid` | `login`과 같은 사유 한 줄 |

  같은 날 차단이 기록되면 다시 `smoke`·`login`해도 클라이언트를 만들지 않고(프롬프트 없음) 1이다. 모르는 예외는 이름만 로그에 남기고 그대로 전파한다.
- **명령 로그:** `<data_dir>/logs/smoke.log`(`login`과 같은 회전·UTC 형식, 라이브러리 로거 다섯 차단). 단계·오류 이름·사유·`cffi_api_session` 값만 남기고 요청한 데이터 날짜·응답 본문은 남기지 않는다.
- **`cffi_api_session`:** CLI 플래그로 바꾸지 않는다. 비교는 config 값을 바꿔 가며 실행한다.
- **A4 확인 절차(사람):** 가정 네트워크에서 `cffi_api_session = false`로 `uv run garmin-pipeline smoke`를 실행하고, 이어서 `true`로 한 번 더 실행해 두 결과를 기록한다. 그 결과로 `config.py` 기본값과 위 설정 표를 정하고, #444·#453이 재현되면 `_bmad-output/specs/spec-garmin-daily-pipeline/failure-modes.md`의 "열린 breakage"에 적는다. 로그인 429·403을 맞으면 그날은 계정 단위로 차단(`block.json`)되므로 두 번째 실행은 다음 날 한다. 하루에 몰아서 반복하지 않는다.

## 배포와 예약

운영은 저장소 루트가 아니라 운영 루트 `runtime/`(`.gitignore` 대상)에서 돈다. 운영 루트에는 실사용 `config.toml`, 데이터(`data/`·`reports/`·`inbox/`), 배포된 `.venv`와 skill 복사본(`.agents/skills/garmin-daily-analysis/`·`.agents/skills/garmin-body-intake/`)이 있다. 매일 `collect_time`·`retry_time`(기본 11:00·11:15)에 `collect`, `report_time`(기본 11:30)에 `report`가 예약으로 돈다. 개발 중인 코드를 고쳐도 운영 동작은 다시 배포할 때까지 바뀌지 않는다(FR38·39, AD-11·14).

```sh
scripts/deploy.sh
```

- **하는 일(`scripts/deploy.sh`, 인자 없음, 몇 번 다시 실행해도 된다):** 저장소 루트로 `cd`한다. `runtime/`이 없으면 0700으로 만든다. 그다음 아래 순서로 한다. 한 단계라도 실패하면 멈춘다(`set -euo pipefail`).
  1. **스냅샷:** `UV_PROJECT_ENVIRONMENT=runtime/.venv uv sync --frozen --no-editable --no-dev`. `uv.lock` 그대로 개발 의존성 없이 패키지를 비편집으로 설치하므로, 배포 뒤 `src/`를 고쳐도 `runtime/.venv`는 그대로다. `runtime/.venv/bin/python`이 `3.14.8`(`.python-version`)이 아니면 멈춘다. 다시 배포하면 바뀐 코드가 반영된다. 이는 `pyproject.toml`의 `[tool.uv] cache-keys`에 `src/**/*`가 있기 때문이다. 기본값으로는 `src/`를 고쳐도 uv가 스냅샷을 다시 설치하지 않는다.
  2. **운영 config:** `runtime/config.toml`이 없을 때만 저장소 루트의 `config.runtime.example.toml`(`environment = "runtime"`, `runtime/` 기준 상대경로, 기본 예약 시각, 주석 처리된 `# report_model = "<모델 이름>"` 줄)을 복사한다. `report_model`은 예시에 값이 없으므로 복사한 뒤 주석을 풀어 모델 이름을 적는다. 적지 않으면 예약된 `report`의 하루 분석이 매일 실패 폴백(`codex_failed`, `report_model` 미설정)이다(`install-schedule`의 거부 사유는 아니다). 이미 있으면(심링크·깨진 심링크 포함) 건드리지 않는다. 예시는 tokenstore를 적지 않는다. 당일 차단(`block.json`)이 계정 단위라 개발과 같은 기본 tokenstore를 함께 쓴다.
  3. **skill 복사와 inbox:** `skill/` 아래 모든 스킬 폴더를 `runtime/.agents/`의 임시 폴더에 먼저 복사한 뒤 `runtime/.agents/skills/`의 같은 이름 폴더를 교체한다. 원본에 없는 운영 스킬은 지우므로 이전 스킬이 남지 않는다. 복사 실패 시 기존 스킬은 그대로다. 이어서 inbox·inbody·processed·unreadable 폴더 중 없는 것만 0700으로 만든다.
  4. **정규화:** `runtime/.venv/bin/garmin-pipeline normalize --config <runtime 절대경로>/config.toml`. 새 스냅샷의 정규화 버전(`store.NORMALIZE_VERSION`)이 DB의 `meta.normalize_version`과 다르면(없음 포함) 여기서 전체 재구성이 한 번 돈다(아래 "normalize"). 실패하면(종료 코드 ≠ 0) `set -e`로 예약 설치 전에 멈춘다. DB가 아직 없으면 마이그레이션한 빈 DB를 만들고 `processed=0`이다.
     - **정규화가 실패하면(예: 예약된 collect가 쓰기 락을 쥐고 있어 락 시간 초과):** `runtime/.venv`는 이미 새 스냅샷으로, skill 복사본은 새 원본으로 바뀌었고 inbox 폴더도 만들어졌다. `install-schedule`만 건너뛴다. 이전에 설치한 LaunchAgent는 그대로 돌며 이제 새 스냅샷을 실행한다(다음 `collect`가 정규화를 줍는다). 단, report 예약을 처음 넣는 배포(4.6 이후 첫 배포)라면 report LaunchAgent가 아직 없으므로 배포가 끝까지 성공할 때까지 report는 예약되지 않는다. 원인을 없앤 뒤(예약 시각을 피해) `scripts/deploy.sh`를 다시 실행한다.
  5. **예약:** `runtime/.venv/bin/garmin-pipeline install-schedule --config <runtime 절대경로>/config.toml`. `deploy.sh`를 실행하는 셸의 `PATH`에서 `codex`를 찾을 수 있어야 한다(아래 report plist).
- **`install-schedule [--config PATH]`:** collect·report LaunchAgent 두 개를 설치하거나 같은 내용으로 교체한다. 운영 루트는 config 파일이 있는 폴더다. 보통은 `deploy.sh`가 부른다.
  - **거부(종료 코드 1):** 부작용을 내기 전에 사유를 **모두** 모아 stderr에 `install-schedule 거부: …` 한 줄씩 쓴다. 사유는 pytest 안(`config.under_pytest()`), `environment`가 `"runtime"`이 아님, `collect_time` < `retry_time` < `report_time`이 아님, 시스템 시간대(`dates.system_timezone()`)가 config `timezone`과 다르거나 알 수 없음(launchd는 시스템 시각으로 예약한다), `<config 폴더>/.venv/bin/garmin-pipeline`이 없거나 실행할 수 없음, `codex`를 `PATH`에서 찾지 못함(`shutil.which`, report 예약에 필요)이다. 거부되면 로그 폴더도 plist도 만들지 않고 `launchctl`도 부르지 않는다. 설정 오류는 다른 명령처럼 2다. `report_model`이 없는 것은 거부 사유가 아니다.
  - **통과하면:** `<data_dir>/logs`를 0700으로 만들고 명령 로그 `<data_dir>/logs/install-schedule.log`를 붙인다. 두 plist를 `~/Library/LaunchAgents/local.garmin-pipeline.collect.plist`·`local.garmin-pipeline.report.plist`에 같은 폴더 임시 파일 + `os.replace`로 원자적으로 쓴다(0644). 그다음 collect, report 순으로 label마다 `launchctl print gui/<uid>/<label>`이 0이면(이미 로드됨) `launchctl bootout gui/<uid>/<label>`을 먼저 하고 `launchctl bootstrap gui/<uid> <plist>`로 로드한다. 둘 다 끝나면 stdout에 두 label과 경로를 쓰고 0이다. 폐기된 `launchctl load`/`unload`는 쓰지 않는다. `launchctl`이 실패하면 그 자리에서 멈추고 stderr에 명령·종료 코드·출력과 "`collect`(또는 `report`) 예약이 내려가 있을 수 있다"를 쓰고 1이다(collect 단계가 실패하면 report 단계는 하지 않는다). 로그에는 label별 `replaced`, 세 시각, codex 경로만 남긴다.
- **plist(`schedule.collect_plist(cfg)`·`schedule.report_plist(cfg, codex)`, 순수 함수):** 모든 경로가 절대경로다. 키를 정렬해 쓰므로 같은 입력으로 다시 실행하면 같은 바이트로 교체된다. 시각은 config 값만 쓴다.

  collect:

  | 키 | 값 |
  | --- | --- |
  | `Label` | `local.garmin-pipeline.collect` |
  | `ProgramArguments` | `<운영 루트>/.venv/bin/garmin-pipeline`, `collect`, `--config`, `<config 절대경로>` |
  | `WorkingDirectory` | `<운영 루트>` |
  | `StartCalendarInterval` | `collect_time`·`retry_time`의 `Hour`·`Minute`(기본 11:00·11:15) |
  | `StandardOutPath`·`StandardErrorPath` | `<data_dir>/logs/launchd-collect.out.log`·`launchd-collect.err.log` |

  report:

  | 키 | 값 |
  | --- | --- |
  | `Label` | `local.garmin-pipeline.report` |
  | `ProgramArguments` | `<운영 루트>/.venv/bin/garmin-pipeline`, `report`, `--config`, `<config 절대경로>` |
  | `WorkingDirectory` | `<운영 루트>` |
  | `StartCalendarInterval` | `report_time`의 `Hour`·`Minute`(기본 11:30) 한 개 |
  | `StandardOutPath`·`StandardErrorPath` | `<data_dir>/logs/launchd-report.out.log`·`launchd-report.err.log` |
  | `EnvironmentVariables` | `PATH` = `<codex 폴더>:/usr/bin:/bin:/usr/sbin:/sbin`(codex 폴더가 이 네 기본 폴더 중 하나면 중복해 넣지 않는다) |

  launchd는 셸 프로필을 읽지 않고 기본 `PATH`(`/usr/bin:/bin:/usr/sbin:/sbin`)로 실행한다. `report`는 `codex`를 `PATH`로 찾으므로, 설치할 때 `PATH`에서 찾은 codex의 폴더를 심링크를 풀지 않고 넣는다(예: Homebrew의 `/opt/homebrew/bin`. 심링크를 풀면 codex를 업그레이드할 때 예약이 깨진다). 설치 셸의 `PATH` 전체는 넣지 않는다(`uv` 같은 개발 도구가 예약 환경에 새지 않게). codex를 다른 폴더로 옮겼으면 `scripts/deploy.sh`를 다시 실행한다. collect plist에는 `EnvironmentVariables`가 없다.

- **배포 시각:** 예약된 collect·report가 도는 동안에는 배포하지 않는다. report는 수집을 기다린 뒤 체성분 입력과 네 범위 분석을 실행하므로 완료 시각을 `report.log`에서 확인한다. `bootout`은 실행 중인 작업을 멈추고, 배포는 운영 `.venv`와 스킬을 교체한다.
- **로그인 세션:** LaunchAgent(`gui/<uid>`)는 사용자가 GUI 세션에 로그인해 있는 동안만 돈다(NFR11). 로그아웃 상태에서는 예약 시각이 지나가도 실행되지 않는다.
- **저장소를 옮기면:** plist와 `runtime/.venv`에는 저장소의 절대경로가 들어 있다. 저장소를 옮기거나 이름을 바꾸면 `scripts/deploy.sh`를 다시 실행한다.
- **예약을 바꾸려면:** `runtime/config.toml`의 시각을 고치고 `scripts/deploy.sh`(또는 `install-schedule`)를 다시 실행한다. 코드를 바꿨을 때도 다시 배포해야 운영에 반영된다.
- **되돌리기:** 두 예약을 내리고 plist를 지운다. `runtime/`은 데이터가 있으므로 따로 지우지 않는다.

  ```sh
  launchctl bootout gui/$(id -u)/local.garmin-pipeline.collect
  launchctl bootout gui/$(id -u)/local.garmin-pipeline.report
  rm ~/Library/LaunchAgents/local.garmin-pipeline.collect.plist
  rm ~/Library/LaunchAgents/local.garmin-pipeline.report.plist
  ```

- **pytest 안에서는:** `install-schedule`은 언제나 거부되므로 테스트가 `launchctl`을 실행하거나 실제 `~/Library/LaunchAgents`에 쓰지 않는다. `tests/test_schedule.py`는 `HOME`을 `tmp_path`로, `subprocess.run`을 가짜로 바꾼다. `tests/test_deploy.py`는 저장소의 `deploy.sh`를 실행하지 않는다. 정적으로 검사하고, `tmp_path`에 복사한 사본(스크립트·예시 config·skill 원본)을 가짜 `uv`(가짜 `python`·`garmin-pipeline`을 만든다)로 돌린다. `tests/test_schedule.py`는 `PATH` 앞에 tmp `bin/codex`를 두어 codex 검색을 결정적으로 하고, codex를 실제로 실행하지 않는다. 배포 스크립트 자체는 임시 clone에서 `HOME=<tmp>`, `PATH=<launchctl 셔임>:$PATH`로 두 번 실행해 확인한다.
- **운영 절차:** 최초 설정, 실패·차단 대응, 상태 확인, 14일 운영 점검은 아래 "운영 안내서"를 본다. 실제 Codex 인수 테스트는 "report"의 "인수 테스트"(4.7)가 tmp 운영 루트로 배포 1·3단계를 재현해 확인한다.

## collect

웰니스 일일 응답과 활동 상세(요약·존별 시간·심박 시계열) 원문을 받아 저장한다. 수집 계획은 커서나 플래그 없이 저장된 데이터(`coverage.items`)에서 실행마다 유도하므로, 빠진 날은 스스로 메우고 첫 30일 백필은 며칠에 걸쳐 끝나며 확정되지 않은 오늘·어제는 다시 받는다. 같은 날 여러 번 떠도(11:00·11:15) 그날 실행 결과로 다시 받을지, 무엇을 다시 받을지 정한다(하루 단위 멱등).

```sh
uv run garmin-pipeline collect [--config PATH] [--force]
```

- **하는 일(`collect.collect(cfg, port=None, *, sleep=time.sleep, force=False, notifier=None)`):** 명령 시작 때 `dates.today(cfg)`·`dates.now_ms()`를 한 번 잡고, `store.write_session(cfg)` 안에서 `collect.run(conn, cfg, port, sleep, today=…, started_at=…, force=…, notifier=…)`을 부른 뒤 0을 돌려준다. 기본 `port`는 `GarminAdapter(cfg)`, 기본 `notifier`는 세션 연결의 `ports.TableNotifier(conn)`이다.
- **순서(`run`):** 남은 `running` 행 정리(`abandoned`, 행마다 `error` 알림) → 진입 표 → `meta.history_start` 확보(없으면 `today − 30일`을 `INSERT OR IGNORE`, 이후 실행은 읽기만) → `run`에 `running` 행 INSERT → 계획 → 계획이 비어 있지 않을 때만 `port.open_session()` → 날짜마다 day 항목, 이어서 그날 activity 항목 수집 → 같은 `run` 행을 `status`·`finished_at`·`detail`로 UPDATE → 끝 알림 판정(아래 "알림") → 정규화(`normalize.run(conn)`) → `normalize_failed` 판정(아래 "수집 뒤 정규화"). 진입 표가 일찍 끝낸 실행(당일 차단·"아무것도 안 함")도 마지막 두 단계는 한다.
- **`abandoned`:** 쓰기 락을 잡은 직후, 날짜와 상관없이 `status=running`인 행(중단 규칙 밖의 예외나 프로세스 종료로 끝나지 못한 실행)을 모두 `status=error`, `detail=abandoned`, `finished_at`=지금으로 바꾼다(WARNING `끝나지 않은 실행을 정리했다: rows=N …`). 그래서 `collect`가 정상으로 반환하면(진입 표의 어느 행이든) `running` 행이 없다. 중단 규칙 밖의 예외로 빠져나간 실행의 행은 `running`으로 남고 다음 실행이 정리한다. 직전 실행이 죽은 날은 그날 상태가 `error`가 되어 전체 계획으로 다시 돈다.
- **진입 표(AD-5):** `run` 행을 쓰기 전에 위에서부터 평가해 처음 맞는 행을 쓴다. "그날 상태"는 `coverage.day_status(conn, today)`다.

  | 조건 | 행동 |
  | --- | --- |
  | `port.blocked_today()`가 사유를 돌려줌(오늘 날짜 `block.json`, 다른 환경이 썼어도 같다) | `skipped_blocked` 행 하나(`detail`은 `timezone_mismatch`만 붙을 수 있다)만 쓰고 끝(앞의 `abandoned` 정리는 따로 한다). 네트워크 0회, `meta`도 쓰지 않는다 |
  | `blocked_today()`가 `garmin.BlockFileInvalid`(깨진 `block.json`) | `error`/`block_file_invalid` 행 하나로 끝(앞의 `abandoned` 정리는 따로 한다). 네트워크 0회 |
  | 그날 상태 `not_run`·`error`(`abandoned`·`lock_timeout` 포함)·`rate_limited`·`blocked_403` | 전체 계획 |
  | `auth_failed`이고 `<tokenstore>/garmin_tokens.json` mtime(`garmin.token_saved_at`)이 그 실행의 `finished_at`보다 뒤(재로그인함) | 전체 계획 |
  | `partial`이고 `detail`에 `transient=N` | 재시도 계획: 전체 계획에서 원문을 오늘(config `timezone` 날짜) 확인한 항목과 오늘 `rejected`로 `fetch_error`에 남은 항목을 뺀다. day·activity 항목 모두, 날짜별 activity 항목을 다시 구할 때도 같다. 그래서 11:15 재시도는 `transient`로 실패한 항목을 다시 요청하고, `rejected` 항목과 오늘 받은 항목은 다시 요청하지 않는다. 백필이 끝나지 않았으면 아직 한 번도 시도하지 않은 날짜도 `max_dates_per_run` 안에서 함께 받는다. 빼고 남은 것이 없으면 세션 없이 `success` 행 |
  | 그 밖(`success`, `rejected`만 있는 `partial`, 재로그인 없는 `auth_failed`) | 새 `run` 행·`meta`·네트워크 없이(앞의 `abandoned` 정리가 이전 `running` 행을 바꾸는 것은 따로다) INFO `collect 건너뜀: day_status=<status> detail=<detail>` 한 줄만 남기고 0 |

  재로그인 판정은 `started_at`이 아니라 `finished_at`과 비교한다. 무인 `login(tokenstore)`은 만료가 가까운 토큰을 갱신하며 토큰 파일을 다시 쓰므로 실패한 실행 자신이 mtime을 `started_at` 뒤로 밀 수 있고, 대화형 `login`은 세션 락을 쥐고 토큰을 쓰므로 실제 재로그인은 실패 실행이 끝난 뒤다. 토큰 파일이 없으면 다시 돌지 않는다.
- **`--force`:** 진입 표의 당일 차단 두 행(`skipped_blocked`, `block_file_invalid`)만 평가하고 나머지는 건너뛰어 전체 계획으로 돈다. 성공한 날도, 오늘 `rejected`인 항목도 다시 요청한다.
- **백필 속도:** 성공한 날은 같은 날 다시 돌지 않으므로 백필은 하루 한 번 성공 실행씩 진행된다. 기본값(`max_dates_per_run = 10`, 30일)에서는 매일 새 오늘과 확정되지 않은 어제가 두 자리를 차지해 4일이 걸린다. 앞당기려면 같은 날 `collect --force`를 더 실행한다(첫 날 4번이면 끝난다).
- **계획:** `coverage.items(conn, cfg, history_start, today)` 중 `coverage.incomplete`가 참인 항목의 일 키를 최신순(오늘, 어제, 나머지 최신순)으로 최대 `max_dates_per_run`개 고른다. `plannable`이 아니면 완료, `data`·`empty`가 아니면 미완료이고, 그 밖에는 day-scope는 `final`이 아니면, activity-scope는 `final`과 상관없이 `fresh`가 아니면(세트 상세를 받은 뒤 소속 목록이 바뀜) 미완료다. 재시도 계획도 같은 판정에 제외만 더한다. activity-scope 항목은 활동의 일 키(`startTimeLocal` 날짜)로 세므로 상한은 day·activity를 합친 일 키 수다. 각 날짜에서는 먼저 미완료 day 항목만 `DAY_ENDPOINTS` 순으로 `session.fetch_day(endpoint, date)`로 부른다. 그다음 `coverage.items(conn, cfg, day, day)`를 다시 구해 그날 미완료 activity 항목을 목록 순·`coverage.items` 순(기존 3종 다음 세트가 필요한 활동만 세트 상세)으로 `session.fetch_activity(endpoint, activityId)`로 부른다. 그래서 방금 받은 `activities_by_date`의 새 활동과 바뀐 세트도 같은 실행에서 받는다. 일 키가 [history_start, today] 안이지만 이번 계획 밖인 활동은 다음 실행이 그 날짜를 계획한다. 일 키가 그 범위 밖인 활동은 커버리지에 나오지 않으므로 받지 않는다. `history_start > today`면 계획이 없다. 계획이 없으면 세션을 열지 않고 `success`다. 오늘은 그날이 지나기 전에는 확정되지 않고 어제는 전날 받은 원문이 아직 확정되지 않아, 하루 한 번 성공 실행에서는 둘이 매 실행 두 자리를 차지한다. 그래서 `max_dates_per_run`이 2 이하면 백필과 빠진 날 메우기가 진행되지 않으므로 config가 3 미만을 거부한다.
- **첫 호출 보호:** 한 번도 성공한 적 없는 endpoint의 첫 실호출이 403을 연달아 받아 계정이 하루 막히거나, 보호하는 동안 과거 항목을 한 실행에 몰아 요청하지 않게 한다. 보호가 풀린 뒤에는 남은 항목에 일반 계획 규칙(`max_dates_per_run`)만 적용된다. 대상 후보는 `collect.FIRST_CALL_ENDPOINTS = ("activity_exercise_sets",)`이다. 실행마다 세션을 열기 전 같은 연결로 `raw_response`에 그 endpoint의 원문이 `'null'`이 아닌 행(`data`)이 하나라도 있는지 보고, 없으면 그 실행 동안 보호한다. 판정은 실행당 한 번이라 같은 실행에서 `data`가 생겨도 끝까지 보호하고, 다음 실행부터 풀린다. `null`(NoData)만 있으면 아직 보호 대상이다. 보호 상태는 저장하지 않고 config 키도 없다.
  - 보호 대상은 `port.open_session(first_call_endpoints=...)`로 세션에 알린다(없으면 `()`). 어댑터는 그 endpoint의 403을 연속 403 승격에 세지 않으므로 각각 `Rejected`(`fetch_error` `rejected`)로 남고 실행은 `partial`이다(위 어댑터 "연속 403").
  - collect는 보호 대상 endpoint의 호출 시도(결과 무관: 성공·`NoData`·`Rejected`·`Transient` 모두 1건)를 실행당 `collect.FIRST_CALL_LIMIT = 3`건으로 자른다. 3건을 채우면 그 실행의 나머지 해당 항목은 부르지 않고 건너뛴다. 건너뛴 항목은 실패가 아니라 `fetch_error`·`detail`에 남지 않고, 다음 실행이 다시 계획한다. 건너뛴 건수가 0보다 크면 INFO `collect 첫 호출 보호로 건너뜀: endpoint=<endpoint> skipped=<N>` 한 줄만 남긴다.
  - 429는 보호와 무관하다. 세트 호출의 429도 `RateLimited` → `block.json` → `rate_limited` 중단이다.
- **간격:** 날짜와 날짜 사이에만 `sleep(date_pause_seconds)`(첫 날짜 앞·마지막 날짜 뒤 없음). 같은 날짜의 activity 호출 사이에는 쉬지 않고, 호출 간 간격(`call_pause_*`)은 어댑터가 쉰다.
- **결과 처리:** 성공은 원문, `NoData`(404·`None`·`[]`·빈 응답)는 `null`로 `store.upsert_raw(scope, key, …)`(day-scope는 `scope='day'`·`key`=일 키, activity-scope는 `scope='activity'`·`key`=activityId 문자열). `Transient`·`Rejected`는 같은 `scope`·`key`로 `fetch_error` 한 행(`kind`·`error_code` = `transient`|`rejected`, `local_date` = 실행의 `today`, `occurred_at` = 그 시각)을 남기고 다음 항목으로 간다. 쓰기는 모두 autocommit 한 문장이라 도중에 멈춰도 그때까지 저장한 원본이 남는다.
- **실행 중단:** 진입 표를 지난 뒤 아래 오류가 나면 그때까지 저장한 원본은 그대로 두고, 다음 호출 없이 세션 블록을 나가 세션 락을 푼 뒤 같은 `run` 행을 그 상태로 끝내고 0으로 나간다. 세션 열기(로그인 단계)든 데이터 호출이든 같다. `block.json`(당일 차단)은 어댑터가 쓰고 `collect`는 쓰지 않는다. 중단 오류는 `fetch_error`에 남기지 않는다. 자격 증명(비밀번호) 로그인은 부르지 않는다.

  | 오류 | `status` | `detail` 맨 앞 사유 토큰 |
  | --- | --- | --- |
  | `RateLimited`(429) | `rate_limited` | 없음 |
  | `Blocked403`(로그인 403, 데이터 403 `max_consecutive_403`번 연속, 첫 호출 보호 endpoint의 403은 세지 않음) | `blocked_403` | 없음 |
  | `AuthFailed`(토큰 무효·tokenstore 없음·데이터 401, 비공개 계정) | `auth_failed` | `token_invalid` 또는 `privacy_protected` |
  | 세션 열기의 `Transient`(로그인 5xx·네트워크) | `error` | `login_transient` |
  | 세션 열기의 `garmin.SessionLockTimeout`(다른 명령이 세션 락을 쥠) | `error` | `session_lock_timeout` |
  | 세션 열기의 `garmin.BlockFileInvalid`(깨진 `block.json`, 네트워크 0회) | `error` | `block_file_invalid` |
  | 세션 열기의 `garmin.SessionBlocked`(진입 확인 뒤 다른 환경이 쓴 `block.json`, 네트워크 0회) | `skipped_blocked` | 없음 |

  다음 날 실행은 저장된 커버리지로 계획하므로 중단으로 못 받은 날짜를 저절로 다시 받는다. 위 목록 밖의 예외는 그대로 전파하고 `run` 행은 `running`으로 남는다(다음 실행이 `abandoned`로 정리한다).
- **쓰기 락 시간 초과:** `lock_wait_seconds` 안에 쓰기 락을 못 잡으면(`store.LockTimeout`) 네트워크 없이 `store.insert_run_unlocked`로 `run` 행 하나(`status=error`, `detail=lock_timeout`, 시간대가 다르면 `lock_timeout timezone_mismatch`, `started_at` = 명령 시작 시각, `finished_at` = 그때)만 남기고 0이다. DB가 없거나 `user_version`이 코드 최신과 다르거나 INSERT가 SQLite 오류(busy 대기 초과, DB가 아닌 파일 등)로 실패하면 행을 쓰지 않고(DB도 만들지 않는다) WARNING(`lock_timeout 실행 행을 남기지 못했다: error=<오류 이름>`)을 남긴 뒤 1이다.
- **`detail`:** `errors.RunDetail`·`errors.AuthFailedReason` 값만으로 만든 공백 구분 토큰열이다. 순서는 중단 사유 토큰(위 표, 쓰기 락 시간 초과는 `lock_timeout`) → 중단 전까지의 0이 아닌 항목 실패 건수 `transient=N`, `rejected=M`(이 순서) → `dates.system_timezone()`이 `None`이 아니고 config `timezone`과 다르면 `timezone_mismatch`. 예: `transient=1 rejected=1`, `timezone_mismatch`, `privacy_protected transient=1`, `rejected=2`(`blocked_403`), 빈 문자열. 중단이 없을 때 항목 실패가 0건이면 `success`, 1건 이상이면 `partial`이다.
- **종료 코드:** 0(`success`·`partial`, 실행 중단으로 끝낸 `run` 행, 진입 표의 `skipped_blocked`·`block_file_invalid` 행, 진입 표가 아무것도 하지 않음, 쓰기 락 시간 초과의 `lock_timeout` 행), 1(로그 파일을 열지 못함, 쓰기 락 시간 초과인데 DB 없음·스키마 버전 불일치·SQLite 오류로 행을 남기지 못함), 2(설정 오류·인자 오류).
- **명령 로그:** `<data_dir>/logs/collect.log`(`login`과 같은 회전·UTC 형식, 라이브러리 로거 다섯 차단). 진입(`collect 진입: plan=<full|retry> day_status=<status>`, `--force`면 `plan=full force=True`), 건너뜀(`collect 건너뜀: …`), `abandoned` 정리, 계획 날짜 수(`collect 계획: dates=N`), 항목 실패(`항목 실패: scope=<scope> key=<일 키|activityId> endpoint=<endpoint> error=<오류 이름>`), 중단(`collect 중단: stage=<entry|login|data|write_lock> error=<오류 이름>`, 진입 표의 당일 차단은 INFO `collect 중단: stage=entry blocked=<사유>`), 최종 상태(`collect 끝: status=<status> detail=<detail>`), 이어서 정규화 로그(아래 "normalize"의 명령 로그와 같은 줄)와 이번 정규화 실패(WARNING `collect 정규화 실패: <detail>`)를 남긴다. 저장된 `activities_by_date` 원문의 형식이 틀렸으면 계획을 세울 때와 날짜마다 activity 항목을 다시 구할 때마다 `coverage`의 WARNING(목록 key와 오류 메시지)도 남는다. `collect`의 항목 실패·중단 로그는 오류 이름만 남기고 오류 메시지는 남기지 않는다. 응답 본문·토큰·이메일은 남기지 않는다.
- **수집 뒤 정규화(FR9·10·22, AD-13):** 수집 판정과 끝 알림이 끝나면 같은 연결로(쓰기 락을 쥔 채) `normalize.run(conn)`을 부른다. 진입 표의 당일 차단(`skipped_blocked`·`block_file_invalid`)과 "아무것도 안 함"에서도 부르므로, 죽은 실행이 남긴 원문과 정규화 버전 변경의 재구성을 매 `collect`가 줍는다. 쓰기 락 시간 초과 경로는 정규화하지 않는다. 수집이 예상 밖 예외로 끝나지 못하면 정규화하지 않고(다음 쓰기 명령이 줍는다), `normalize.run`의 예외(`sqlite3.Error`)는 그대로 전파한다.
  - **`normalize_failed`:** 정규화 뒤 `normalize_result`에서 `ok = 0 AND normalized_at >= started_at`(이번 명령이 기록한 실패)인 행이 있으면 `notify(today, normalize_failed, detail)`이다. `detail`은 endpoint 오름차순의 `<endpoint>=<건수>` 토큰을 공백으로 이은 것이다(예: `hrv_data=1 sleep_data=2`. endpoint 이름은 코드 상수라 건강 데이터가 아니다). 원문이 그대로라 다시 정규화하지 않은 이전 실패만 있으면 알리지 않는다. 정규화 버전이 바뀌어 재구성하면 깨진 원문의 실패가 다시 기록되므로 다시 알린다. 같은 날 두 번째부터는 `notification`의 유일성으로 처음 행(`detail`)이 남는다. `normalize` 명령은 알리지 않는다(판정 주체는 `collect`, AD-10).
- **알림(FR22, AD-10):** `collect`는 `notification`을 직접 쓰지 않고 주입받은 `ports.Notifier`(`notify(local_date, event, detail)`)로만 알린다. 기본 구현 `ports.TableNotifier`는 열린 쓰기 세션 연결에 `notification` 행을 `INSERT OR IGNORE`로 쓰므로 같은 날 같은 사건은 처음 기록한 행(`at`·`detail`)이 남는다(예: 같은 날 `--force`로 두 번 `rate_limited`면 한 행). CLI가 runtime·비밀 파일·pytest 조건으로 `TelegramNotifier`를 고르면 새 행을 기록한 뒤 한 번 전송한다(아래 "Telegram 알림 설정").

  | 언제 | 사건(`event`) | `local_date` | `detail` |
  | --- | --- | --- | --- |
  | `abandoned` 정리 직후, 정리한 행마다(진입 표보다 앞이라 "아무것도 안 함"이나 당일 차단으로 끝나는 실행도 남긴다) | `error` | 그 행의 `local_date` | `abandoned` |
  | 이번 실행이 `run` 행을 `auth_failed`·`rate_limited`·`blocked_403`·`error`(진입 표의 `block_file_invalid` 포함)로 끝냄 | 상태와 같은 이름 | `today` | 그 실행의 `detail` |
  | 이번 실행이 `partial`로 끝났고 `coverage.day_status`가 오늘과 어제 모두 `partial`이며 둘 다 `detail`에 `transient=N` | `repeated_partial` | `today` | 오늘 상태의 `detail` |

  같은 날 같은 사건은 원인이 달라도 한 행으로 합쳐져 처음 `detail`만 보인다(예: 오늘 `running` 행이 `error`/`abandoned`로 정리된 뒤 이번 실행이 `error`/`login_transient`로 끝나면 `abandoned`만, 11:00 `error`/`session_lock_timeout` 뒤 11:15 `error`/`login_transient`면 `session_lock_timeout`만 남는다. 나머지 원인은 `run` 행에서 본다). `success`, `skipped_blocked`, `rejected`만 있는 `partial`, 진입 표의 "아무것도 안 함"은 알리지 않는다. `repeated_partial`은 실행 끝에 판정하므로 11:00에 기록되면 11:15 재시도로 회복해도 남는다. `abandoned` 알림은 중단 규칙 밖의 예외(실행 행이 `running`으로 남는 경우)를 알리는 유일한 경로다.
  - **쓰기 락 시간 초과는 알리지 않는다(결정, 사람):** 쓰기 락을 못 잡은 실행(`error`/`lock_timeout`)은 열린 쓰기 연결이 없고, AD-8은 `notification` 쓰기를 락 안에서만 허용한다. 락을 쥔 다른 실행이 자기 결과를 알린다.
  - `normalize_failed`는 위 "수집 뒤 정규화"가, `report_failed`는 보고서(Epic 4)가 판정한다.
- Telegram 실패 알림 설정은 "운영 안내서"를, 예약·배포는 "배포와 예약"을 본다.

## capture-fixtures

운영 DB의 `raw_response`에 보존된 실제 Venu 3 응답을 테스트 fixture 파일로 내보낸다(FR40). Epic 3 정규화를 실제 응답 구조에 맞춰 만들고 검증하는 데 쓴다. DB는 `store.read_connection`으로 읽기만 하고(쓰기·마이그레이션 없음) Garmin에 닿지 않는다(`garmin` 어댑터를 import하지 않는다).

```sh
uv run garmin-pipeline capture-fixtures [--config PATH] [--date YYYY-MM-DD]... [--activity-id N]...
```

- **출력:** 현재 폴더 기준 `tests/fixtures/garmin/<endpoint>/<key>.json`(day-scope는 `key` = 일 키, activity-scope는 `key` = activityId). 파일 내용은 `raw` 텍스트를 UTF-8로 쓴 그대로다(바이트 단위로 같다). 같은 폴더 임시 파일(0600)에 쓰고 fsync한 뒤 `os.replace`로 바꾼다. 새로 만드는 `garmin/`·`<endpoint>/` 폴더는 0700이다. 기존 파일은 덮어쓰고 지우지 않는다. 읽기는 읽기 트랜잭션 하나로 묶어 같은 시점의 상태를 본다.
- **기본 선택(옵션 없음):**
  - day-scope: `coverage.DAY_ENDPOINTS` 9종마다 `null`이 아닌 행 가운데 일 키가 가장 큰 행 하나. 최신 날이 `null`(NoData)이면 그 전 data 행을 쓴다.
  - activity-scope: 저장된 `activities_by_date` 원문에서 `rawparse.activity_refs`로 활동을 모아 일 키 내림차순(같은 날은 목록 순)으로 줄 세우고 activityId로 중복을 없앤다. 그중 activity-scope data 행이 하나라도 있는 활동을 앞에서부터 3개(`capture.RECENT_ACTIVITIES`) 고르고, 각 활동의 저장된 `ACTIVITY_ENDPOINTS` data 행(기본 3종, 근력 활동은 세트 상세까지)을 쓴다. 형식이 틀린 목록은 그 목록만 건너뛰고 WARNING(key와 오류 메시지만)을 남긴다.
- **지정 선택:** `--date`(`date.fromisoformat`)·`--activity-id`(양의 정수)는 서로 독립이고 여러 번 줄 수 있다. 하나라도 주면 기본 선택 대신 지정한 날짜의 day-scope 9종과 지정한 activityId의 저장된 activity-scope 원문만 쓴다. 이때는 `null` 원문도 그대로(`null`) 쓴다. `--date`는 그날의 활동까지 쓰지 않는다. 형식이 틀리면 인자 오류(2)다.
- **경로 검증:** endpoint는 고정 튜플의 값만 쓴다. day key는 `date.fromisoformat(k).isoformat() == k`, activity key는 `str.isdecimal()`이어야 하고, 아니면 그 행을 건너뛰고 WARNING을 남긴다.
- **거부(git 확인):** 쓰기 전에 현재 폴더에서 `git check-ignore -q <출력 폴더 절대경로>/`를 실행한다. 0이 아니면(출력 폴더가 무시되지 않음, 저장소 밖, git을 실행할 수 없음) stderr에 `capture-fixtures 거부: …`(종료 코드가 0·1이 아니면 git stderr 첫 줄을 덧붙인다)를 쓰고 1로 끝난다. 이때 로그 폴더·출력 폴더·DB 연결을 하나도 만들지 않는다. 건강 데이터가 git에 들어갈 길을 막는 장치라 저장소 루트에서 실행해야 한다(`.gitignore`의 `tests/fixtures/garmin/`, 아래 "git에서 빼는 경로").
- **stdout:** `DAY_ENDPOINTS` 다음 `ACTIVITY_ENDPOINTS` 순서로 13줄 `<endpoint>: <개수>`만 쓴다. 원문 본문·경로·날짜는 쓰지 않는다.
- **종료 코드:** 0(1개 이상 씀), 1(거부, 쓴 파일 0개 — 13줄 개수 뒤 stderr `capture-fixtures: 내보낼 원문이 없다`, DB 없음·스키마 버전 불일치·SQLite 오류(DB가 아닌 파일 등), 파일 쓰기 실패, 로그 파일을 열지 못함), 2(설정 오류·인자 오류).
- **명령 로그:** git 확인을 통과한 뒤에만 `<data_dir>/logs/capture-fixtures.log`(`login`과 같은 회전·UTC 형식)를 붙인다. endpoint별 개수(`capture-fixtures 끝: sleep_data=1 …`)와 건너뛴 행의 위치(scope·endpoint·key, 목록 형식 오류 메시지)만 남기고 원문 내용은 남기지 않는다.
- **커밋하지 않는다:** `tests/fixtures/garmin/` 아래 파일은 실제 건강 데이터라 커밋하지 않는다. `.gitignore`를 완화하지 않는다. 테스트는 이 경로를 쓰지 않고 `tmp_path`의 임시 저장소에만 쓴다.
- **사람 확인 절차:** 백필(`collect`)이 끝난 운영 DB로 저장소 루트에서 실행한다.
  1. `uv run garmin-pipeline capture-fixtures --config runtime/config.toml` — endpoint마다 최신 원문 하나와 최근 활동 3개. 13줄 개수를 보고 0인 endpoint가 없는지 확인한다(`activity_exercise_sets`는 최근 활동 3개에 근력 활동이 없으면 0이다).
  2. `uv run garmin-pipeline capture-fixtures --config runtime/config.toml --date <활동 없는 날>` — 활동이 없는 날(`activities_by_date` = `null`)과 NoData 원문을 남긴다.
  3. `uv run garmin-pipeline capture-fixtures --config runtime/config.toml --date <활동 날> --activity-id <그날 activityId>` — 활동이 있는 날과 그 활동의 상세를 같이 남긴다.
  4. `git status --porcelain` — `tests/fixtures/garmin/` 아래 파일이 나오지 않는지(무시되는지) 확인한다.

  운영 배포 전에 근력 활동의 세트 상세(`activity_exercise_sets`)를 개발 환경에서 받는 절차는 아래 "운영 안내서"의 "개발 환경 세트 fixture 확보"를 본다.

## normalize

`raw_response`에 보존된 원문을 분석용 테이블(scope `day` → `daily_metric`, scope `activity` → `activity`)과 샘플·세트 테이블로 정규화하고 항목별 결과를 `normalize_result`에 남긴다(FR9·10·11·13, NFR3·5·6, AD-13). 원문만 읽으므로 Garmin에 닿지 않는다(`garmin` 어댑터를 import하지 않는다). `raw_response`에는 쓰지 않는다.

```sh
uv run garmin-pipeline normalize [--config PATH] [--rebuild]
```

- **재구성(`--rebuild`, 정규화 버전):** `--rebuild`이거나 `meta.normalize_version`이 코드의 `str(store.NORMALIZE_VERSION)`과 다르면(키가 없음 포함) 전체 재구성이다. `store.transaction` 하나 안에서 파생 테이블(`daily_metric`·`activity`·`body_battery_sample`·`stress_bb_sample`·`hr_sample`·`activity_hr_sample`·`exercise_set`, 코드 상수 `_TARGETS`·`NORMALIZERS`에서 유도)과 `normalize_result`를 모두 `DELETE`하고, 증분과 같은 루프로 등록된 원문 전부를 다시 정규화한 뒤(결과 행이 비었으므로 전부 작업 집합이다) `meta.normalize_version`을 upsert한다. 항목·실패 기록은 각각 `store.savepoint`라 항목 실패 격리는 증분과 같다(깨진 원문 하나는 그 항목만 `ok=0`이고 나머지는 커밋된다). 그래서 파생 테이블은 같은 원문을 새 DB에서 처음 정규화한 결과와 같고, 남은 쓰레기 행과 묵은 `activity.day_key`도 바로잡힌다. 1차 테이블(`auth_event`·`raw_response`·`run`·`fetch_error`·`notification`)과 `meta`의 다른 키는 건드리지 않는다. 증분 실행은 `meta`를 건드리지 않는다. 재구성하면 INFO `normalize 재구성: reason=<flag|version> stored=<저장 값|None> code=<코드 값>` 한 줄을 남긴다. stdout 형식은 같다.
  - **원자성:** 재구성은 트랜잭션 하나다. 도중에 `sqlite3.Error`가 나면 전체가 롤백돼 파생 테이블·`normalize_result`·`meta`가 모두 이전 그대로이고 명령은 1이다. WAL이라 읽는 쪽(`store.read_connection`)은 커밋 전까지 이전 행을 본다(빈 테이블을 보지 않는다).
  - **버전 올리는 규칙과 절차:** 같은 원문에서 나오는 파생 값이나 그 모양(테이블·열·행)이 바뀌는 코드 변경이면 `store/__init__.py`의 `NORMALIZE_VERSION`을 1 올린다(마이그레이션으로 파생 테이블을 더하거나 바꿀 때도). 정의와 규칙 docstring은 `store`에 있고 `normalize`는 같은 이름으로 다시 내보낸다(`normalize.NORMALIZE_VERSION is store.NORMALIZE_VERSION`, 3.7). 그러면 배포(`scripts/deploy.sh` 4단계 `normalize`)나 다음 `collect`가 운영 DB를 한 번 전체 재구성한다. 3.5까지 정규화된 운영 DB에는 키가 없으므로 첫 배포에서 재구성이 한 번 돈다. 버전을 올리지 않고 다시 만들고 싶으면 `--rebuild`를 쓴다. 운영을 3.6 이전 코드(`meta.normalize_version`을 모르는 코드)로 되돌렸다가 다시 배포하면 파생 테이블은 옛 규칙으로 만든 그대로인데 `meta`는 코드 값과 같아 재구성이 돌지 않는다. 그런 롤백 뒤에는 다시 배포한 다음 `runtime/.venv/bin/garmin-pipeline normalize --rebuild --config runtime/config.toml`을 한 번 실행한다.

- **작업 집합:** (scope, endpoint)가 등록된 쌍(`normalize.NORMALIZERS`, `Normalizer.scope`: scope `day`의 `user_summary`·`rhr_day`·`hrv_data`·`training_readiness`·`sleep_data`·`stress_data`·`body_battery`·`heart_rates` 8종과 scope `activity`의 `activity`·`activity_hr_in_timezones`·`activity_details`·`activity_exercise_sets` 4종, 모두 12종)인 원문 중 `normalize_result` 행이 없거나 그 `raw_fetched_at`이 원문 `fetched_at`과 다른 것이다. 같은 원문을 다시 받으면 `fetched_at`이 그대로라(`checked_at`만 바뀜) 다시 처리하지 않는다. 키·`fetched_at`만 먼저 고르고 `ORDER BY scope, key, endpoint`로 처리하며, 원문은 그 항목의 트랜잭션 안에서 읽는다. 등록되지 않은 원문(`activities_by_date`)에는 결과 행을 쓰지 않으므로 endpoint를 더하면 그 원문이 자동으로 작업 집합이 된다.
- **대상 테이블:** scope마다 코드 상수다. `day` → `daily_metric`(키 열 `day_key`), `activity` → `activity`(키 열 `activity_id`, `raw_response.key`를 integer로 저장). 샘플 테이블의 키 열도 scope를 따른다. activity 항목의 key는 정규형 십진수 activityId(ASCII 숫자, 앞자리 0 없음, SQLite INTEGER 범위)여야 하고, 아니면 아무것도 쓰지 않고 `parse_error`다. 아래의 열 쓰기·샘플 교체·null 원문·실패 격리 규칙은 두 scope가 같고 대상 테이블과 키만 다르다.
- **항목 하나 = 트랜잭션 하나:** 성공하면 그 endpoint가 소유한 대상 테이블 열만 새 값으로 바꾸고(그 키 행이 없으면 만든다) `normalize_result`를 `ok=1, error_code=NULL, raw_fetched_at=<원문 fetched_at>, normalized_at=<지금>`으로 upsert한다. 다른 endpoint의 열은 건드리지 않는다. 원문이 `null`(NoData)이면 행을 만들지 않고, 있는 행의 그 endpoint 열만 NULL로 하며 `ok=1`이다.
- **샘플·세트 테이블:** 키별 행을 내는 endpoint(`Normalizer.sample_table` = `SampleTable(table, columns, parse)`, `columns`는 키 열을 뺀 열 튜플. 지금은 `stress_data` → `stress_bb_sample`(`ts_ms`·`level`), `body_battery` → `body_battery_sample`(`ts_ms`·`level`), `heart_rates` → `hr_sample`(`ts_ms`·`bpm`), `activity_details` → `activity_hr_sample`(`ts_ms`·`bpm`·`body_battery`), `activity_exercise_sets` → `exercise_set`(`set_index`·`category`·`exercise_name`·`reps`·`weight_g`·`duration_s`·`is_rest`))는 같은 항목 트랜잭션에서 그 키(일 키 또는 activityId)의 행을 모두 지우고 현재 원문의 행을 넣는다. null 원문이나 실패면 지우기만 한다. 그래서 샘플과 세트도 열처럼 현재 원문만으로 다시 만든 결과와 같다(원문이 줄면 그 키의 행이 통째로 새 목록으로 바뀐다. 한 활동의 세트는 트랜잭션 하나로 통째 교체된다). 소유 열이 없는 endpoint(`heart_rates`·`activity_details`·`activity_exercise_sets`)는 대상 테이블 행을 만들지도 바꾸지도 않는다(성공·null 원문·실패 모두).
- **열과 원본 필드:** 모든 열은 NULL을 허용한다.

    | endpoint | 열 | 원본 필드 |
    |----------|----|-----------|
    | `user_summary` | `steps`·`distance_m`·`active_kcal`·`moderate_intensity_s`·`vigorous_intensity_s`·`min_hr`·`max_hr`(INTEGER) | `totalSteps`·`totalDistanceMeters`·`activeKilocalories`·`moderateIntensityMinutes`×60·`vigorousIntensityMinutes`×60·`minHeartRate`·`maxHeartRate` |
    | `rhr_day` | `resting_hr`(INTEGER) | `allMetrics.metricsMap.WELLNESS_RESTING_HEART_RATE[]`에서 `calendarDate`가 일 키인 (첫) 항목의 `value`. 없으면 NULL. `metricsMap`이 빈 dict(`{}`, 시계를 안 찬 날 Garmin이 보내는 빈 모양)면 NULL이고 `ok=1`, 다른 키가 있는데 `WELLNESS_RESTING_HEART_RATE`가 없으면 `parse_error` |
    | `hrv_data` | `hrv_last_night_avg`·`hrv_weekly_avg`·`hrv_baseline_low`·`hrv_baseline_high`(INTEGER), `hrv_status`(TEXT) | `hrvSummary.lastNightAvg`·`weeklyAvg`·`baseline.balancedLow`·`baseline.balancedUpper`(baseline이 null이면 NULL)·`status` |
    | `training_readiness` | `readiness_score`(INTEGER), `readiness_level`(TEXT) | 아침 훈련 준비도: `inputContext == "AFTER_WAKEUP_RESET"`인 항목이 있으면 그중 `timestamp`(문자열)가 가장 이른 항목, 없으면 전체에서 가장 이른 항목(같으면 먼저 나온 항목)의 `score`·`level`. garminconnect `get_morning_training_readiness`와 같은 `AFTER_WAKEUP_RESET` 기준이지만 라이브러리처럼 리스트 순서의 첫 항목(없으면 `data[0]`)이 아니라 `timestamp`가 가장 이른 항목을 고른다. 빈 리스트면 NULL. `inputContext` 키는 펌웨어에 따라 없을 수 있어 선택이고, 있으면 문자열 또는 null이어야 한다 |
    | `sleep_data` | `sleep_s`·`deep_sleep_s`·`light_sleep_s`·`rem_sleep_s`·`awake_sleep_s`·`sleep_score`·`sleep_start_ms`·`sleep_end_ms`(INTEGER) | `dailySleepDTO`의 `sleepTimeSeconds`·`deepSleepSeconds`·`lightSleepSeconds`·`remSleepSeconds`·`awakeSleepSeconds`(초)·`sleepScores.overall.value`·`sleepStartTimestampGMT`·`sleepEndTimestampGMT`(UTC epoch ms). `sleepTimeSeconds`가 null·음수면 잠이 기록되지 않은 날로 보고 다른 키를 읽지 않고 모두 NULL. `sleepScores` 키가 없거나(어느 밤이든. 첫 밤에 관찰됨) `sleepScores`·`overall`이 null이면 `sleep_score`만 NULL |
    | `stress_data` | `stress_avg`·`stress_max`(INTEGER) | `stressValuesArray`에서 `stressValueDescriptorsDTOList`의 `key == "stressLevel"` 항목 `index` 위치의 수준 중 null·음수(−1·−2 등 센티넬)를 뺀 유효 샘플의 평균(`round()`)·최대. Garmin `avgStressLevel`·`maxStressLevel`은 쓰지 않는다. 유효 샘플이 없으면(배열 null 포함) NULL |
    | `body_battery` | `bb_charged`·`bb_drained`·`bb_high`·`bb_low`(INTEGER) | 리스트에서 `date`가 일 키인 첫 항목의 `charged`·`drained`, `bodyBatteryValuesArray`의 유효 level 최대·최소. 그런 항목이 없으면 NULL이고 샘플도 없다. 샘플은 `body_battery_sample`에 저장한다 |
    | `heart_rates` | (없음. 샘플만 `hr_sample`에 저장한다) | `heartRateValues`. 최소·최대 심박은 `user_summary`, 안정 심박은 `rhr_day`가 이미 맡으므로 다른 키(`maxHeartRate`·`restingHeartRate` 등)는 읽지 않는다 |
    | `activity`(scope `activity`) | `activity`의 `type_key`(TEXT), `start_ms`·`duration_s`·`distance_m`·`avg_hr`·`max_hr`(INTEGER) | `activityTypeDTO.typeKey`, `summaryDTO`의 `startTimeGMT`(시간대 표기 없는 `YYYY-MM-DD[ T]HH:MM:SS[.f]`를 `dates.utc_text_ms`가 UTC로 읽은 epoch ms. 날짜만 있거나 `Z`·`+09:00` 같은 표기가 있거나 형식이 틀리면 `parse_error`)·`duration`(초)·`distance`(m)·`averageHR`·`maxHR`. `elapsedDuration`·`movingDuration`은 저장하지 않는다 |
    | `activity_hr_in_timezones`(scope `activity`) | `activity`의 `hr_zone1_s`~`hr_zone5_s`·`hr_zone1_low_bpm`~`hr_zone5_low_bpm`(INTEGER) | 최상위 리스트의 `{zoneNumber, secsInZone, …}` 항목에서 존 번호(1~5의 int, bool 제외)별 `secsInZone`(초)·`zoneLowBoundary`(bpm). 두 키는 필수이고 숫자 규칙 뒤 `round()`한다. 리스트에 없는 존은 NULL. 존 5 상한은 저장하지 않는다. 범위 밖 존 번호·중복 존 번호는 조용히 버리지 않고 `parse_error`다 |
    | `activity_details`(scope `activity`) | (없음. 샘플만 `activity_hr_sample`에 저장한다) | `activityDetailMetrics[i].metrics`에서 `metricDescriptors`의 `key`가 `directTimestamp`·`directHeartRate`인 항목의 `metricsIndex` 위치. `body_battery`는 `key`가 `directBodyBattery`인 항목의 위치(5.9, 없으면 NULL) |
    | `activity_exercise_sets`(scope `activity`) | (없음. 세트만 `exercise_set`에 저장한다) | `exerciseSets[i]`의 위치 `i`·`setType`·`exercises`(최대 확률 후보의 `category`·`name`)·`repetitionCount`·`weight`(g)·`duration`(초). 목록의 `summarizedExerciseSets`는 쓰지 않는다 |

  `body_battery_sample`의 위치는 `bodyBatteryValueDescriptorDTOList`(`bodyBatteryValueDescriptorKey`가 `timestamp`·`bodyBatteryLevel`인 항목의 `bodyBatteryValueDescriptorIndex`)로 찾는다. 샘플 배열은 고정 인덱스가 아니라 descriptor로 위치를 찾으므로 키가 바뀌면 조용히 틀리지 않고 `parse_error`가 된다. timestamp는 0 이상의 정수여야 한다(bool·float·null은 오류). 같은 timestamp가 다시 나오면 원문 행 전체가 같을 때(완전 중복. `55`와 `55.0`은 같다)만 첫 샘플을 남기고, 값이나 다른 열이 다르면(null 대 숫자, −1 대 −2 포함) 그 항목은 `parse_error`다. `bodyBatteryValueDescriptorDTOList`가 null이면서 모든 행이 "0 이상 정수 timestamp + 나머지 원소 모두 null"(`[ts, null]`, 시계를 안 찬 날 Garmin이 보내는 빈 모양)이면 샘플 없이 받는다(`bb_high`·`bb_low` NULL, `ok=1`). 값이 하나라도 있는 행이 있으면(예: `[null, 55]`) descriptor null은 그대로 `parse_error`다. 이 중복·빈 모양 두 규칙은 `body_battery_sample`·`hr_sample`·`stress_bb_sample`에 있다.

  `stress_bb_sample`은 `stress_data`의 `bodyBatteryValuesArray`를 읽는다. 위치는 `bodyBatteryValueDescriptorsDTOList`(s 있음)의 `bodyBatteryValueDescriptorKey`(`timestamp`·`bodyBatteryLevel`)와 `bodyBatteryValueDescriptorIndex`로 찾는다. 두 원문 키가 모두 없으면 샘플이 없는 날로 받는다(시계를 안 찬 날의 실제 응답). 하나만 없거나 컨테이너 타입이 틀리면 `stress_data` 항목 전체가 실패한다. 배열이 null·빈 목록이면 샘플이 없다. descriptor가 null이고 행이 있으면 모든 행이 timestamp 말고는 모두 null인 빈 모양일 때만 샘플이 없고, 값이 있으면 실패한다. level이 null·음수면 NULL 행으로 남긴다. 숫자·중복 규칙은 다른 일일 샘플과 같다. 기존 `stress_avg`·`stress_max` 계산과 `body_battery_sample` 정규화는 그대로다.

  `hr_sample`은 최상위 dict의 `heartRateValues`(리스트 또는 null, 원소는 `[ts, bpm]` 같은 리스트)와 `heartRateValueDescriptors`(리스트 또는 null, 원소는 `{"key": …, "index": …}`)를 읽는다. 두 키는 반드시 있어야 한다. 샘플이 하나라도 있으면 descriptor의 `key`가 `timestamp`·`heartrate`인 항목의 `index`로 위치를 찾는다(그 항목이 없거나 샘플 길이가 모자라면 `parse_error`. descriptor가 null이면 위 빈 모양일 때만 샘플 없이 받고 아니면 `parse_error`). timestamp 규칙, 완전 중복 규칙, 빈 모양 규칙은 `body_battery_sample`과 같다. bpm은 아래 값 규칙에 더해 반올림 결과가 0이어도 NULL이다(0.4 → NULL. 살아 있는 사람에게서 나올 수 없는 값이라 읽는 쪽 계산이 조용히 틀리지 않게 한다). 결측 샘플(bpm NULL)은 생략하지 않고 NULL 행으로 남기므로 읽는 쪽은 `bpm IS NOT NULL`로 거른다. 배열이 null·빈 리스트면 샘플이 없다(`ok=1`). 일 키 범위 밖 시각도 거르지 않고 원문 샘플을 그대로 저장하므로, 같은 UTC 시각이 두 일 키에 함께 저장될 수 있고 시각 범위로 읽는 쪽(5.11 수면 중 심박·복귀 시간)이 그 중복 처리 규칙을 정한다. 응답 구조(키 이름 `timestamp`·`heartrate`)는 garminconnect 0.3.17에 응답 모델이 없어 커뮤니티 도구와 일반적인 응답 형태를 보고 가정했다. 다르면 `parse_error`로 드러난다.

  `activity_hr_sample`은 최상위 dict의 `metricDescriptors`·`activityDetailMetrics`(각각 리스트 또는 null, 두 키는 반드시 있어야 한다)를 읽는다. 샘플이 하나라도 있으면 descriptor의 `key`·`metricsIndex`로 위치를 찾는다. `directHeartRate` 항목이 없으면 심박 시계열이 없는 활동으로 보고 샘플이 없다(`ok=1`). 그 항목이 있으면 `directTimestamp` 항목도 있어야 하고, 샘플은 `{"metrics": [...]}` dict이고 `metrics`는 두 위치(`directBodyBattery` 항목이 있으면 그 위치까지)를 담는 리스트여야 한다(아니면 그 항목 전체가 `parse_error`라 심박 샘플도 남지 않는다). timestamp는 0 이상의 int 또는 유한 float이고 `round()`한다(Garmin details 값은 double일 수 있다. bool·null·문자열은 오류). 반올림 뒤 같은 timestamp가 두 번 나오면 `parse_error`다. bpm 규칙은 `hr_sample`과 같다(null·음수거나 반올림 결과가 0이면 NULL, 결측도 NULL 행으로 남긴다). 운동 중 Body Battery(`body_battery`, 5.9)는 `directBodyBattery` 항목이 있으면 그 위치의 값을 숫자 규칙(null·음수 → NULL, bool·문자열·NaN은 `parse_error`) 뒤 `round()`하고 0은 0으로 남긴다. 그 항목이 없으면 행은 그대로이고 `body_battery`만 모두 NULL이다(행이 생기는 조건은 여전히 `directHeartRate` 항목뿐이다). 실제 fixture 13개 모두에 이 채널이 있고 값은 정수 값 float, 가끔 null이다. 채널 키 `directHeartRate`·`directTimestamp`와 존 응답 형태(`{zoneNumber, secsInZone, zoneLowBoundary}` 리스트, 커뮤니티 도구 garmin-grafana의 사용 방식)는 garminconnect 0.3.17에 응답 모델이 없어 가정했다. 존 형태가 다르면 `parse_error`로 드러나지만 심박 키 이름이 틀리면 조용히 "시계열 없음"이 되므로, 실제 fixture 시험이 같은 id의 `activity` fixture에 `averageHR`가 있고 details에 샘플이 있으면 시계열이 비어 있지 않은지 본다. 파서는 `normalize/activity.py`의 순수 함수이고 `garminconnect`·`parse_activity_detail_metrics`를 쓰지 않는다.

  `exercise_set`(5.4)은 최상위 dict의 `exerciseSets`(리스트 또는 null, 키는 반드시 있어야 한다. null·빈 리스트면 행 없이 `ok=1`)를 읽고 원소는 dict여야 한다. 규칙은 5.3에서 얻은 실제 세트 fixture로 정했다. `set_index`는 `exerciseSets` 안 위치(0부터, REST 포함)다. `messageIndex`는 fixture 여럿에서 전부 null이고 `startTime`은 몇 개에서 순서가 뒤집혀 쓰지 않는다. `setType`은 `"ACTIVE"` 또는 `"REST"`여야 하고(그 밖·null·키 없음은 `parse_error`) REST면 `is_rest = 1`이다. 휴식 세트는 `exercises`가 빈 리스트이고 반복·무게가 null이며 시간만 있다. 종목은 `exercises`(리스트 또는 null, 후보는 `category`·`name`(문자열 또는 null)·`probability`(숫자 규칙) 세 키가 모두 있는 dict) 중 `probability`가 가장 큰 후보(같으면 앞의 것, null·음수 확률은 어느 숫자보다 낮다)의 `category` → `category`, `name` → `exercise_name`이고, 후보가 없으면 둘 다 NULL이다. `repetitionCount` → `reps`, `weight` → `weight_g`(원문 단위가 g다), `duration` → `duration_s`(초)는 아래 값 규칙(null·음수 → NULL, bool·문자열·NaN은 `parse_error`) 뒤 `round()`다. 무게 `-1.0`(무게 없는 세트의 센티넬)은 음수라 NULL이다. 무게는 `round()` 결과가 0이어도 NULL이다(0.4 g처럼 0으로 반올림되는 값 포함). 반복·시간의 0은 0이다. 근거: 실제 세트 fixture에서 무게 0은 0 kg일 수 없는 바벨 힙 스러스트·바벨 데드리프트·슈러그 세트에도 나와 "입력 안 함"이고, 0 kg로 두면 리포트에 `0.0 kg`·최고 `0.0 kg`·볼륨 `0.0 kg`이 나온다(사용자 결정 2026-10-21, `store.NORMALIZE_VERSION` 6). 무게 0 세트는 볼륨에 0을 더했으므로 Garmin 요약 교차 확인은 그대로 맞다. `startTime`·`messageIndex`·`wktStepIndex`·속도·파워·ROM 키와 후보 확률은 저장하지 않는다. 근거: 무게는 정수 값 float이고 최대값을 kg으로 읽으면 사람이 들 수 없는 크기이며, 위 규칙으로 고른 (`category`, `exercise_name`)로 REST가 아닌 행을 묶은 세트 수·Σ반복·Σ반복×무게가 같은 활동의 목록 `summarizedExerciseSets`(Garmin 앱 요약과 같은 출처)의 (`category`, `subCategory`)별 `sets`·`reps`·`volume`과 같다. `test_real_sets_match_garmin_summary`가 실제 fixture(세트와 같은 활동의 목록)로 이를 보고(없으면 skip), 실제 세트 fixture마다 행 수 = `len(exerciseSets)`, REST 행은 반복·무게 NULL, ACTIVE 행은 `category` 있음, 무게는 NULL 또는 양수(0·음수 없음)를 본다. 앱 화면과의 대조는 사람이 5.3 기록에 적는다(5.4 spec deferred의 "무게 0 처리 결정"은 2026-10-21 사용자 결정으로 닫혔다: 무게 0은 무게 없음이다. 앱 대조 자체는 사람 단계로 남는다).
- **활동 일 키(`activity.day_key`):** 이번 실행에 activity-scope 항목이 있으면 저장된 모든 `activities_by_date` 원문(scope `day`, key 오름차순)을 한 번 `rawparse.activity_refs`로 읽어 `{activityId: 일 키}`를 만든다(일 키는 목록 항목 `startTimeLocal`의 날짜 부분, 같은 id는 처음 것. 형식이 틀린 목록은 WARNING `활동 목록 원문 형식 오류: key=…`를 남기고 건너뛴다. coverage와 같은 규칙). activity-scope 항목이 성공해 `activity` 행을 만들거나 고칠 때마다(`activity`·`activity_hr_in_timezones`) `day_key`를 그 값으로 쓰고, 어느 목록에도 없으면 NULL이다(삭제된 활동이나 목록 없는 fixture도 실패 없이 값이 남는다). null 원문·실패 경로·`activity_details`는 `day_key`를 건드리지 않는다. 목록 원문만 바뀌면 다시 계산하지 않는다(`startTimeLocal`은 바뀌지 않는 값이다. `--rebuild`나 정규화 버전 변경의 재구성이 바로잡는다). 읽는 쪽(3.11)은 `day_key`로 활동을 고른다.
- **날짜 기준 확인(사람 확인 필요):** 활동 목록이 로컬 날짜 기준인지는 실제 fixture가 없어 아직 확인하지 못했다. 규칙은 합성 시험으로 고정했다: D1 목록 항목이 `startTimeLocal "D1 07:30:00"`·`startTimeGMT "D0 22:30:00"`이면 `activity.day_key`는 D1이고, `start_ms`는 D0 22:30 UTC이며 `dates.day_key(start_ms)`(Asia/Seoul)도 D1이다. 실제 fixture로 확인하는 절차:
  1. "capture-fixtures"의 절차대로 활동이 있는 날(`--date`)과 그 활동(`--activity-id`)의 원문을 `tests/fixtures/garmin/`에 남긴다. 자정 근처(로컬과 UTC 날짜가 다른 시각)에 시작한 활동이면 더 좋다.
  2. `uv run pytest tests/test_normalize.py -k real -v` — `test_real_activity_lists_use_local_date`가 `activities_by_date/<day>.json`의 모든 ref 일 키가 파일 이름의 day와 같은지, 같은 id의 `activity/<id>.json`의 `summaryDTO.startTimeLocal` 날짜도 그 day인지, 정규화한 `activity.day_key`가 그 day인지 본다. `test_real_activity_heart_rate_samples_is_not_empty`는 심박 채널 키 가정을 본다. 폴더가 없으면 skip이다.
  3. 둘이 통과하면 목록은 로컬 날짜 기준이고 위 규칙이 맞다. 실패하면 일 키 규칙(AD-7)을 다시 정한다.

  열은 실제 Venu 3 fixture 없이 garminconnect 응답 구조를 보고 최소한으로 정했다. 실제 fixture(`tests/fixtures/garmin/<위 12종>/*.json`, "capture-fixtures")가 있으면 `tests/test_normalize.py`가 그것으로도 돌고(없으면 skip), 값 대조는 사람이 확인한다. 열을 바꾸면 새 마이그레이션을 더한다.
- **값 규칙(`normalize/daily.py`·`normalize/activity.py`의 순수 함수):** 읽는 키는 반드시 있어야 하고 값은 null이어도 된다(예외: `summaryDTO`의 `distance`·`averageHR`·`maxHR`는 키가 없어도 NULL이다. Garmin은 거리 없는 근력 운동처럼 값이 없는 필드를 응답에서 뺀다고 보고, 필수로 하면 그런 활동 전체가 실패하기 때문이다. `startTimeGMT`·`duration`·`typeKey`는 반드시 있어야 한다). 키가 없거나 컨테이너 타입(dict·list)이 다르면 `NormalizeParseError`다(null 컨테이너도 오류이고, 예외는 `hrvSummary.baseline`, `dailySleepDTO.sleepScores`와 그 `overall`, 리스트 또는 null인 `stressValuesArray`·`stressValueDescriptorsDTOList`·`bodyBatteryValuesArray`·`bodyBatteryValueDescriptorDTOList`·`bodyBatteryValueDescriptorsDTOList`·`heartRateValues`·`heartRateValueDescriptors`·`metricDescriptors`·`activityDetailMetrics`다. 키를 읽지 않아도 되는 예외는 null·음수 `sleepTimeSeconds` 뒤의 수면 키, 준비도의 `inputContext`, `dailySleepDTO.sleepScores`(어느 밤이든 없어도 된다. 첫 밤에 관찰됨), stress Body Battery의 배열·descriptor 키가 모두 없는 경우다. 실제 응답의 빈 모양인 `rhr_day`의 빈 `metricsMap`과, `body_battery`·`heart_rates`·stress Body Battery에서 descriptor가 null인 `[ts, null]` 샘플 배열은 값 없음으로 받는다. `stress_data`의 스트레스 배열(`stressValuesArray`)에서 같은 모양은 그대로 `parse_error`다). 키 이름이 바뀌면 조용히 NULL이 되지 않고 실패로 드러난다. 숫자는 int·float만 받고(bool·문자열·NaN·무한대는 오류) 음수는 Garmin 센티넬로 보고 NULL, 나머지는 `round()`한 int다(분→초는 곱한 뒤 반올림. Python `round`는 짝수 쪽 반올림이라 52.5 → 52, 53.5 → 54). 문자열 필드는 str 또는 null이다. 오류 메시지에는 원문 값 없이 endpoint와 키 경로만 담는다.
- **실패 격리:** 항목이 파싱 오류(`NormalizeParseError` → `parse_error`)나 그 밖의 예외(`sqlite3.Error` 제외 → `internal`)로 실패하면 그 항목을 롤백한 뒤 새 트랜잭션에서 그 endpoint 열을 NULL로 비우고(행은 만들지 않는다. 샘플·세트 테이블이 있으면 그 키의 행도 지운다. activity key가 잘못됐으면 결과 행만 쓴다) `ok=0`·`error_code`를 기록하고 다음 항목으로 넘어간다. 그래서 대상 테이블의 열 값은 언제나 현재 원문만으로 다시 만든 결과와 같다. 예외는 `activity.day_key`다: 작업 집합 밖의 `activities_by_date` 원문에 기대고 activity-scope 항목이 행을 쓸 때만 갱신되므로, 목록만 바뀌면 그 활동 행을 다시 쓰거나 전체 재구성(3.6)할 때까지 이전 값으로 남는다. 행이 있는지는 뜻이 없다(실패·null 원문 뒤에도 행이 남고, 빈 준비도·그날 항목 없는 `rhr_day`처럼 값이 모두 NULL이어도 행이 생긴다). 읽는 쪽은 열의 NULL 여부로 판단한다. `ok=0`인 항목은 원문 `fetched_at`이 바뀔 때까지 실패로 남고 다시 처리되지 않는다(코드를 고친 뒤에는 `--rebuild`나 `normalize_version`을 올려 다시 만든다). 원문이 바뀌어 성공하면 `ok=1`로 값이 채워진다. `error_code`는 `normalize.NormalizeErrorCode`(`parse_error`·`internal`)이고 `errors`의 닫힌 어휘는 늘리지 않았다. `sqlite3.Error`는 환경 문제로 보고 그대로 전파한다(이미 커밋한 항목은 남는다).
- **stdout:** `normalize: processed=<N> failed=<M>` 한 줄이다. `processed`는 처리한 작업 항목 수(실패 포함), `failed`는 그중 실패한 수다. 바뀐 원문이 없으면 `processed=0 failed=0`이다.
- **종료 코드:** 0(항목 실패가 있어도 0. 실패는 `normalize_result`와 로그에 남는다), 1(쓰기 락 시간 초과·스키마 버전 불일치 등 `StoreError`, SQLite 오류, 로그 파일을 열지 못함 — stderr `normalize 실패: …`), 2(설정 오류).
- **명령 로그:** `<data_dir>/logs/normalize.log`(`login`과 같은 회전·UTC 형식). 항목 실패는 WARNING `정규화 실패: scope=… key=… endpoint=… error_code=…`, 끝에 INFO `normalize 끝: processed=… failed=…`만 남기고 원문 내용·예외 메시지는 남기지 않는다.
- **기상 값:** 파생 `day_summary.wake_bb`와 digest가 같은 정의로 계산한다. `body_battery_sample`과 `daily_metric.sleep_start_ms`·`sleep_end_ms`는 원문 정규화 필드로 유지한다.

    ```sql
    SELECT s.level FROM body_battery_sample s JOIN daily_metric d ON d.day_key = s.day_key
    WHERE s.day_key = :day AND s.level IS NOT NULL AND s.ts_ms <= d.sleep_end_ms
    -- 수면 창 안의 샘플을 찾으려면 AND s.ts_ms >= d.sleep_start_ms를 더한다.
    ORDER BY s.ts_ms DESC LIMIT 1
    ```

- **A3 결과(잠정, 실제 fixture 없이 판단):** Body Battery 기상 값과 아침 훈련 준비도는 둘 다 수집 8종에서 유도할 수 있다고 본다. 아침 훈련 준비도는 `training_readiness`의 `inputContext == "AFTER_WAKEUP_RESET"` 항목 중 `timestamp`가 가장 이른 것이다(garminconnect 0.3.17 `get_morning_training_readiness`와 같은 기준이지만 리스트 순서 대신 가장 이른 `timestamp`로 고르고, 없으면 `data[0]`이 아니라 전체에서 가장 이른 항목이다. 위 표). Body Battery 기상 값은 위 후보 쿼리다. 그래서 spine 변경은 제안하지 않는다. 사람이 실제 fixture로 유도할 수 없다고 확인하면 `body_battery_events` day-scope endpoint 추가를 AD-4 변경으로 제안하고, 그 값은 "유도 불가"로 남긴다.
- **심박 샘플 간격(사람 확인):** 실제 샘플 간격은 아직 측정하지 않았다(가정: 약 2분). 실제 데이터를 정규화한 뒤 아래 쿼리로 유효 샘플 사이 간격의 빈도 상위 5개를 본다. 첫 행이 가장 흔한 간격(ms)과 그 수다. 이 쿼리는 하루 전체에서 가장 흔한 간격만 보여 주고 활동 종료 직후 구간의 간격은 따로 보지 않는다(그 구간 간격이 다를 수 있다).

    ```sql
    SELECT gap_ms, COUNT(*) AS n FROM (
      SELECT ts_ms - LAG(ts_ms) OVER (PARTITION BY day_key ORDER BY ts_ms) AS gap_ms
      FROM hr_sample WHERE bpm IS NOT NULL
    ) WHERE gap_ms IS NOT NULL GROUP BY gap_ms ORDER BY n DESC, gap_ms LIMIT 5
    ```

- **샘플 간격 결론(잠정, 실제 fixture 없이 판단):** 간격이 2분(120000 ms)이면 활동 종료 후 1·2분 지점에서 가장 가까운 샘플은 최대 1분 떨어져 있어 1분·2분 심박 회복 값을 꾸준히 읽을 수 없다. 그래서 HRR은 5.7에서 없앴다(위 `0012_drop_activity_recovery`). 수면 중 심박과 운동 뒤 평상시 심박 복귀 시간(참고값)은 5.11이 이 샘플을 시각 범위(`hr_sample_ts_ms`)로 읽어 계산한다.
- **활동 목록:** `activities_by_date`는 일 키 지도로만 읽는다. 정규화 결과의 하루 값·운동·종목은 `day_summary`·`workout`·`exercise_log`에 두고 분석과 그래프가 함께 읽는다.

## sync

운동을 뒤늦게 동기화했거나 Garmin 앱에서 세트를 고쳤다면 수집부터 리포트 재전송까지 한 번에 실행한다.

```sh
uv run garmin-pipeline sync --config PATH
```

`collect --force` 전체 계획에 최근 7일(오늘 포함, `history_start` 이후)의 `activities_by_date` 목록을 더해 최신순으로 `max_dates_per_run`개 날짜까지 받는다. 다른 일일 항목은 미완료인 것만 받고, 오늘 `rejected`인 항목은 제외한다. 목록이 바뀐 날의 근력 세트만 다시 받는다. `collect --force`에는 이 7일 목록 재수집이 없다. 두 수동 명령은 이번 수집 행 `detail` 맨 뒤에 `manual`을 남긴다.

수집 쓰기 세션을 닫은 뒤 `report --regenerate`로 다시 만들어 Telegram으로 보낸다. Codex 세션 넷을 다시 실행하므로 약 10분이 걸린다. 리포트 락이 바쁘면 거부하며, 당일 차단 중에는 Garmin 호출 없이 저장 데이터로만 다시 만든다. 수집 행 기록과 이번 리포트 파일 쓰기가 모두 성공하면 0, 그 밖에는 1이다. 로그는 `<data_dir>/logs/sync.log`다.

## report

AI가 작성한 하루·7일·30일·전체 분석과 DB 그래프를 `reports/<report_date>.md`로 조립한다. 날짜는 설정의 timezone을 따른다.

```sh
uv run garmin-pipeline report [--config PATH] [--regenerate]
```

리포트 락을 잡고 수집 종료를 기다린 뒤 체성분 입력(`garmin-body-intake`)과 분석(`garmin-daily-analysis`)을 실행한다. 분석 입력은 `report_input`과 `digest`가 만들고, 작성기는 `DailyAnalysis(status, report_md, summary)`를 반환한다. 이미 완성된 오늘 리포트는 건너뛰며 `--regenerate`는 오늘만 다시 만든다. 락·전송·실패 알림 규칙은 기존과 같다. 분석 실패는 리포트에 사유를 남긴다.

분석 뒤 `charts.render(cfg, report_date, out_dir)`를 항상 호출한다. 그래프는 읽기 연결 하나·트랜잭션 하나로 파생 테이블을 읽고 연결을 닫은 뒤 그린다. 원문·네트워크를 읽지 않는다. 체성분 장부 `data/body/`는 별도로 읽어 DB 실패에도 인바디 그래프를 만들 수 있다.

- 01은 어제 심박·Body Battery·수면·운동 구간, 02·03은 어제·오늘의 마지막 두 운동 세션이다. 세션은 `workout`의 날짜·`session_no`를 따른다.
- 04~49는 어제·오늘 근력 종목의 전체 진행이며, 종목·세트·무게·볼륨은 `exercise_log`에서 읽는다.
- 50~53은 오늘 포함 30일(`[D−29, D]`), 54~58은 첫 기록부터 오늘까지의 추세다. 하루 값은 분석과 같은 `day_summary`를 쓴다. 전체 기간이 6개월 이하면 주(일요일 끝), 넘으면 월 평균·최저·최고를 그린다. 묶음 값은 저장하지 않는다.
- `day_summary` 행이 없는 날은 운동 기록을 못 받은 음영, 행이 있고 운동이 없으면 0이다. 활동 목록만 실패한 날은 0으로 보일 수 있다.
- 59는 유효한 체성분 장부의 추이다. 미래·숨김·잘못된 파일은 제외하며 파일마다 실패를 격리한다.

그리는 함수·번호·제목·건너뛰기 규칙을 유지하고, 그래프별 오류는 로그에 남겨 다른 그래프와 리포트 전송을 계속한다. matplotlib은 그리기 직전에 Agg로 로드한다. PNG는 0600, 임시 날짜 폴더는 0700이며 완성 뒤 교체하고 실패하면 이전 폴더를 복구한다. 리포트의 `## 그래프`에는 실제 생성된 파일만 참조한다. Telegram 앨범은 01~49와 50~59로 나누며 `ReportBundle`로 전달한다.

원본 스킬은 `skill/garmin-daily-analysis/SKILL.md`와 `skill/garmin-body-intake/SKILL.md`다. 배포가 운영 스킬을 설치한다. 스킬의 최종 출력은 `daily_analysis_output.schema.json`·`body_intake_output.schema.json`을 따른다.

## 운영 안내서

배포 뒤 사용자가 하는 일을 한 곳에 모은 절이다(NFR1·7·11). 명령의 세부 동작은 각 절("login"·"smoke"·"배포와 예약"·"collect"·"report")을 본다. 아래 명령은 모두 저장소 루트에서 실행한다. 운영 루트 `runtime/`에서 사람이 손대는 것은 `runtime/config.toml`과 `runtime/inbox/`뿐이다.

### 최초 설정

1. 그날 report가 끝날 수 있는 시각(기본값으로 12:40) 뒤(예: 오후)에 `scripts/deploy.sh`를 실행하고(위 "배포와 예약"), 아래 `login`·`smoke`까지 같은 날 끝낸다. 토큰 없이 다음 예약 `collect`가 돌면 `auth_failed`가 남는다. `codex`가 `PATH`에 있어야 한다. 예약을 멈추려면 위 "배포와 예약"의 "되돌리기"를 따른다.
2. `runtime/config.toml`의 `# report_model = "<모델 이름>"` 줄 주석을 풀고 모델 이름을 적는다. 적지 않으면 매일 하루 분석이 폴백(`codex_failed`)이다. 다시 배포할 필요는 없다(`report`가 실행 때 읽는다).
3. 운영 config로 Garmin에 로그인하고 같은 config로 무인 인증을 점검한다.

   ```sh
   runtime/.venv/bin/garmin-pipeline login --config runtime/config.toml
   runtime/.venv/bin/garmin-pipeline smoke --config runtime/config.toml
   ```

   `smoke`가 0이 아니면 그 안내 문구를 따른다(위 "smoke"의 안내 문구 표). 운영 config로 로그인하는 이유는 `auth_event`가 운영 DB(`runtime/data/garmin.db`)에 남아야 아래 토큰 수명 쿼리로 토큰 수명을 볼 수 있기 때문이다(tokenstore는 개발과 같아서 개발 config로 로그인해도 수집은 되지만 기록이 개발 DB에 남는다).
4. `codex login status`가 ChatGPT 로그인(`Logged in using ChatGPT`)인지 확인한다. API 키 로그인은 쓰지 않는다.

### 매일 무엇이 도는가

- 11:00 `collect`, 11:15 `collect`(재시도), 11:30 `report`가 LaunchAgent로 돈다(시각은 config `collect_time`·`retry_time`·`report_time`). 결과는 `runtime/reports/<날짜>.md`다.
- Mac이 켜져 있고 사용자가 GUI 세션에 로그인해 있어야 돈다(NFR11). 꺼져 있거나 로그아웃한 동안 지나간 예약은 돌지 않고(잠자기 중이었으면 깨어날 때 한 번 돈다), 빠진 날은 다음 `collect`가 커버리지로 메운다.
- 로그는 `runtime/data/logs/`에 있다: `collect.log`·`report.log`(명령 로그), `launchd-collect.*.log`·`launchd-report.*.log`(launchd 표준 출력·오류), `login.log`·`smoke.log`.
- 사람에게 알릴 실패는 DB `notification` 표에 남는다. Telegram을 설정한 운영 환경에서는 같은 날 같은 사건을 처음 기록할 때 한 번 전송하고 결과는 `delivery`에 남는다. 아래 "상태 확인"의 최근 알림 쿼리로 본다.

#### 즉시 갱신

예약 뒤 동기화한 운동이나 수정한 세트를 반영하려면 다음 명령을 실행한다. 최근 7일 활동 목록을 날짜 상한 안에서 다시 수집하고 리포트를 재전송한다.

```sh
runtime/.venv/bin/garmin-pipeline sync --config runtime/config.toml
```

수집 없이 저장 데이터로 오늘 리포트만 다시 만들려면 다음 명령을 실행한다.

```sh
runtime/.venv/bin/garmin-pipeline report --regenerate --config runtime/config.toml
```

두 명령 모두 Codex 세션 넷을 다시 실행해 약 10분이 걸린다. 리포트 락이 바쁘면 기다리지 않고 거부한다. 당일 차단 중에는 수집을 기다리지 않으며 저장 데이터로만 리포트를 다시 만든다.

### Telegram 알림 설정

1. Telegram의 BotFather에서 `/newbot`으로 봇을 만들고 봇 토큰을 받는다. 토큰은 비밀번호처럼 다룬다.
2. 만든 봇에게 Telegram 앱에서 메시지를 먼저 보낸다. @userinfobot에게 메시지를 보내고 응답의 `Id`를 chat id로 사용한다. 이 값은 만든 봇과의 개인 채팅에서 사용할 chat id다. 이 프로그램은 `getUpdates`나 webhook으로 메시지를 받지 않는다.
3. `<tokenstore>/telegram.json`을 비어 있는 0600 파일로 먼저 만든 뒤 편집기로 비밀을 입력한다(기본 `~/.garmin-pipeline/tokens/telegram.json`). 파일 자신과 부모 경로에 심링크가 있으면 거부한다. 아래 값은 예시이며 실제 비밀은 로그·DB·셸 명령 기록에 남기지 않는다.

   ```sh
   install -m 600 /dev/null ~/.garmin-pipeline/tokens/telegram.json
   ```

   편집기로 다음 JSON의 값을 입력한다.

   ```json
   {"bot_token": "BotFather에서 받은 토큰", "chat_id": "확인한 chat id"}
   ```

   `bot_token`은 비어 있지 않은 문자열, `chat_id`는 정수 또는 비어 있지 않은 문자열이다. 파일 권한은 정확히 0600이어야 한다.

runtime config이고 파일이 있으며 pytest 밖일 때만 보낸다. dev config·pytest에서는 보내지 않는다. 매 전송마다 파일을 다시 읽으므로 토큰 교체는 다음 알림부터 반영된다. 설정이 잘못되면 네트워크 없이 `invalid_config`로 남는다. 전송 실패는 수집·리포트 종료 코드를 바꾸지 않으며 재전송하지 않는다. 실패 원인을 고친 뒤 다음 새로운 사건을 확인한다. 리포트도 같은 조건으로 요약 → 앨범 "오늘·운동"(01~49) → "추세"(50~99) → 전문 `.md` 순서로 보낸다. 빈 앨범은 빼고 10장씩 나누며, 1장은 `sendPhoto`, 2~10장은 `sendMediaGroup`이다. 캡션·parse_mode 없이 첫 호출 뒤부터 1초 간격, 호출 timeout은 30초다. 리포트의 429는 정수 `retry_after`가 0~30초면 한 번만 기다려 같은 요청을 다시 보낸다(알림은 기다리지 않음). 실패 항목 다음에도 계속 보내며 전송 중 쓰기 락을 잡지 않는다.

아래 SQL은 "상태 확인"의 읽기 전용 실행 명령에 넣는다.

```sql
SELECT local_date, kind, event, ok, reason, at FROM delivery ORDER BY at DESC, id DESC LIMIT 20;
```

`kind`는 `notify`, `report_text`, `report_album`(묶음마다), `report_document`이고, 리포트 전송에는 event가 없다. `ok=1`이면 성공이다. 실패 사유는 `network`, `rate_limited`, `http_4xx`, `http_5xx`, `invalid_config`, `too_large`다. 수집 알림의 timeout 합은 `lock_wait_seconds / 2`까지이며 예산이 부족하면 보내지 않고 `network`를 기록한다. `report_failed`는 쓰기 락을 놓은 뒤 보낸다.

### `auth_failed` 알림이 왔을 때

`detail`의 첫 토큰이 사유다(위 "collect"의 실행 중단 표).

- **`token_invalid`(토큰 만료·무효):** 같은 운영 config로 다시 로그인한다. 재로그인 뒤의 다음 `collect`가 전체 계획으로 돌아 빠진 날을 메운다.

  ```sh
  runtime/.venv/bin/garmin-pipeline login --config runtime/config.toml
  ```

- **`privacy_protected`(계정 프로필 비공개):** 재로그인으로는 풀리지 않는다. Garmin Connect의 개인정보(프로필 공개 범위) 설정을 고친다. 다음 날 `collect`가 빠진 날을 메운다.

### 차단(`rate_limited`·`blocked_403`)

- Garmin이 429·403을 주면 그날은 계정 단위로 차단되고 tokenstore에 `block.json`이 남는다. `block.json`은 지우지 않는다. 날짜가 바뀌면 저절로 풀리고, 빠진 날은 다음 `collect`가 메운다.
- 같은 날 `smoke`·`login`을 다시 실행해도 Garmin에 닿지 않고 아무것도 하지 않는다(종료 코드 1). 예약된 `collect`도 `skipped_blocked`로 건너뛴다.
- 차단이 며칠 이어지면 `_bmad-output/specs/spec-garmin-daily-pipeline/failure-modes.md`의 "열린 breakage"에서 #444(데이터 403)·#453(로그인 429)을 보고, 위 "smoke"의 안내(`cffi_api_session`)를 따른다.

### 의존성 업그레이드

순서를 바꾸지 않는다. `garminconnect`는 `pyproject.toml`의 `<0.4` 제약 안에서만 올린다.

1. `uv lock --upgrade-package garminconnect`
2. 개발 환경에서 실제 Garmin 점검: `uv run garmin-pipeline smoke`. 그날 report가 끝난 뒤(기본값으로 12:40 이후)에 실행한다. 운영과 tokenstore를 같이 쓰므로 여기서 429·403을 맞으면 `block.json`이 그날 예약된 `collect`를 막는다.
3. `uv run pytest`
4. 예약된 collect·report가 도는 시간(기본값으로 11:00~12:40)을 피해 `scripts/deploy.sh`

2단계나 3단계가 실패하면 배포하지 않고 lock을 되돌린다(`git restore uv.lock`).

codex를 업그레이드해 다른 폴더로 옮겼으면 `scripts/deploy.sh`를 다시 실행한다(report plist의 `PATH`, 위 "배포와 예약"). codex나 `report_model`을 바꾸면 위 "report"의 "인수 테스트"를 다시 돌린다.

### 인바디 입력

- 결과지 스크린샷(`.png`·`.jpg`·`.jpeg`)이나 측정일과 수치를 적은 Markdown(`.md`·`.txt`)을 `runtime/inbox/inbody/`에 넣는다. 측정일은 입력 안에 연·월·일이 모두 있는 완전한 날짜로 있어야 한다.
- 다음 `report`가 장부(`runtime/data/body/`)에 반영하고 섹션 5에 쓴다. 처리된 입력은 `inbox/inbody/processed/`로, 읽지 못한 입력은 `inbox/inbody/unreadable/`로 옮겨진다. `unreadable/`로 간 입력은 고쳐서 다시 `inbox/inbody/`에 넣는다.
- `.heic`·`.webp`는 codex에 첨부되지 않아 반영되지 않고, 남아 있는 동안 매일 하루 분석 `체성분 입력` 줄에 `첨부되지 않음`으로 나온다. PNG·JPEG로 다시 저장해 넣고 `.heic`·`.webp` 원본은 `inbox/inbody/`에서 치운다.
- `body write`가 거부된 입력은 `inbox/inbody/`에 그대로 남아 매일 다시 시도되고, 하루 분석 `체성분 입력` 줄에 `쓰지 못함(그대로 둠)`으로 나온다. 그 줄이 보이면 입력을 고치거나 `inbox/inbody/` 밖으로 옮긴다.

### 상태 확인

저장소 루트에서 운영 venv의 Python으로 DB를 읽기 전용(`mode=ro`)으로 연다. 파이프라인이 쓰는 연결과 같아 예약 실행 중에도 읽을 수 있다. 아래 SQL을 하나씩 `<SQL>` 자리에 그대로 붙여 표준 입력으로 넘긴다. 열은 `|`로 나뉘고 NULL은 빈 칸이다. macOS 기본 `sqlite3 -readonly`는 쓰지 않는다. 파이프라인이 닫을 때 `-wal`·`-shm`을 지운 DB를 열지 못하고 `unable to open database file (14)`로 끝난다. 일별 요약 SQL은 `group_concat(… ORDER BY …)` 때문에 SQLite 3.44 이상이 필요하다. 운영 venv의 SQLite는 `runtime/.venv/bin/python -c 'import sqlite3; print(sqlite3.sqlite_version)'`로 본다.

```sh
runtime/.venv/bin/python -I -c '
import sqlite3, sys
db = sqlite3.connect("file:runtime/data/garmin.db?mode=ro", uri=True)
for row in db.execute(sys.stdin.read()):
    print(*("" if v is None else v for v in row), sep="|")
' <<'SQL'
<SQL>
SQL
```

```sql
-- 일별 요약(최근 14일): 실행 순서와 그날 알림
SELECT r.local_date AS day,
       group_concat(r.status || iif(r.detail = '', '', ' ' || r.detail), ' → ' ORDER BY r.started_at, r.id) AS runs,
       (SELECT group_concat(n.event || iif(n.detail = '', '', ' ' || n.detail), ', ' ORDER BY n.at)
          FROM notification n WHERE n.local_date = r.local_date) AS notifications
FROM run r
GROUP BY r.local_date
ORDER BY r.local_date DESC
LIMIT 14;
```

```sql
-- 최근 알림
SELECT local_date, event, detail FROM notification ORDER BY at DESC LIMIT 20;
```

```sql
-- 토큰 수명: 로그인마다 다음 로그인 전 첫 token_invalid 실패까지의 일수(NULL이면 다음 로그인 전까지, 또는 지금까지 token_invalid 실패 없음)
WITH a AS (
  SELECT id, local_date, logged_in_at,
         LEAD(logged_in_at) OVER (ORDER BY logged_in_at, id) AS next_at
  FROM auth_event)
SELECT a.local_date AS logged_in,
       min(r.local_date) AS token_failed,
       CAST(julianday(min(r.local_date)) - julianday(a.local_date) AS INTEGER) AS lifetime_days
FROM a LEFT JOIN run r
  ON r.status = 'auth_failed' AND r.detail LIKE 'token_invalid%'
 AND r.started_at > a.logged_in_at
 AND (a.next_at IS NULL OR r.started_at < a.next_at)
GROUP BY a.id
ORDER BY a.logged_in_at;
```

- **일별 요약:** `runs`는 그날 `run` 행의 `status`와 `detail`을 시각 순으로 `→`로 이은 것이고, `notifications`는 그날 알림(없으면 빈 칸)이다. 실행이 없는 날은 행이 없다. `LIMIT 14`는 실행이 있는 최근 14개 날짜라 점검 기간과 다를 수 있다. 점검은 기간이 끝난 다음 날 하거나 `LIMIT`을 기간에 맞게 늘린다. 그날 마지막 수집을 읽을 때 `skipped_blocked`와 `lock_timeout` 토큰(`error lock_timeout`)은 수집이 아니므로 건너뛴다. `run` 행이 없는 날의 알림은 여기 나오지 않으니 최근 알림 쿼리로 본다.
- **예약:** 두 LaunchAgent가 로드돼 있는지 본다(0이 아니면 로드되지 않은 것이다. `scripts/deploy.sh`를 다시 실행한다).

  ```sh
  launchctl print gui/$(id -u)/local.garmin-pipeline.collect
  launchctl print gui/$(id -u)/local.garmin-pipeline.report
  ```

- **리포트:** `ls runtime/reports/`로 날짜별 파일을 보고, 하루 분석이 폴백인 리포트는 `grep -l '몸상태 종합을 쓰지 못했다' runtime/reports/*.md`로 찾는다. 그날 `report_failed` 알림의 `detail`이 사유다(위 "report"의 사유 표).
- **알림별 대응:** `detail`의 첫 토큰으로 고른다. 세부는 위 "collect"의 실행 중단 표·알림 표와 "report"의 사유 표다. 폴백 리포트는 같은 날 `runtime/.venv/bin/garmin-pipeline report --config runtime/config.toml`을 다시 실행하면 하루 분석을 다시 쓴다.

  | 알림 | 대응 |
  | --- | --- |
  | `auth_failed` | 위 "`auth_failed` 알림이 왔을 때" |
  | `rate_limited`·`blocked_403` | 위 "차단" |
  | `error` `login_transient`·`session_lock_timeout`·`lock_timeout`·`abandoned` | 대개 다음 실행(11:15 재시도나 다음 날)이 메운다. 며칠 이어지면 `collect.log`를 본다 |
  | `error` `block_file_invalid` | tokenstore의 `block.json`이 깨져 매 실행이 네트워크 없이 멈춘다. 저절로 풀리지 않으니 사람이 그 파일을 지운다 |
  | `repeated_partial` | 이틀 연속 일시 오류(`transient=N`)가 남았다. 다음 실행이 다시 받는다. 며칠 이어지면 `collect.log`의 `항목 실패` 줄을 본다 |
  | `normalize_failed` | 원문 구조가 바뀌어 그 항목만 정규화하지 못했다(원문은 남아 있다). failure-modes "정규화 실패"를 보고 코드를 고친 뒤 정규화 버전을 올려 배포하거나 `runtime/.venv/bin/garmin-pipeline normalize --config runtime/config.toml --rebuild`로 다시 만든다(위 "normalize"). 원문이 그대로면 `--rebuild` 없는 `normalize`는 다시 처리하지 않는다 |
  | `report_failed` `codex_failed` | 먼저 `codex login status`(ChatGPT 로그인인지)와 `runtime/config.toml`의 `report_model`(주석이 풀렸는지, 모델 이름이 맞는지)을 본다. 그다음 `report.log` |
  | `report_failed` `codex_timeout` | 분석이 `report_codex_timeout_minutes`를 넘었다. 폴백 리포트가 남는다. 이어지면 `report.log`의 걸린 시간을 본다 |
  | `report_failed` `skill_failed` | skill이 절차를 끝내지 못했다. 폴백 섹션 셋째 줄 `> skill 메시지:`를 본다 |
  | `report_failed` `output_invalid` | codex 최종 메시지가 스키마에 맞지 않았다. 이어지면 "report"의 "인수 테스트"를 다시 돌린다 |
  | `report_failed` `write_failed` | 그날 리포트 파일이 없다. `report.log`(또는 `runtime/reports/` 쓰기 권한·디스크)를 보고 고친 뒤 `report`를 다시 실행한다 |

### 14일 운영 점검

배포 뒤 무인 운영(NFR7)을 사람이 이 체크리스트로 판정한다. 모두 맞으면 통과다.

- [ ] 기간은 배포 다음 날부터 연속 14일이다. 첫 30일 백필(약 4일) 동안 리포트의 빈 항목은 정상이다.
- [ ] 일별 요약에 14개 날짜가 빠짐없이 이어진다. 날마다 마지막 수집이 `success`·`partial`이거나, 실패로 끝났으면 `runs`에 사유 토큰이 있고 다음 날 마지막 수집이 `success`·`partial`이다.
- [ ] `runtime/reports/`에 14일치 `<날짜>.md`가 있다. 폴백 리포트가 있으면 그날 `report_failed`의 `detail`로 원인을 본다.
- [ ] 하루 분석이 폴백(`report_failed`)인 날이 없다. 있으면 날짜와 `detail`을 판정과 함께 적고, `codex_failed`·`codex_timeout`이 이틀 이상이거나 `report_model 미설정`이면 실패로 본다(하루 분석을 매일 Codex가 쓰는 것이 목표다). `skill_failed`·`output_invalid`가 하루뿐이면 원인을 적고 통과로 볼 수 있다.
- [ ] 마지막 날 리포트 섹션 1에 날짜별 표(`날짜 | 빠짐 | 수집 실패`)가 없거나 그 표의 `빠짐` 칸이 모두 `-`이고, 섹션 3의 `리포트가 빠진 날`이 `없음`이다(`grep -n '리포트가 빠진 날' runtime/reports/<마지막 날>.md`). 빠진 날이 커버리지 기준으로 메워졌다는 뜻이다. `수집 실패` 칸은 Garmin이 거부해(`max_rejected_attempts`일 뒤 계획에서 빠짐) 메울 수 없는 항목이므로 실패로 보지 않고, 일별 요약 `runs`의 `rejected=N`과 맞는지만 본다.
- [ ] 기간 중 사람이 실행한 명령이 없다. 허용하는 사람 개입은 `token_invalid` 뒤의 재로그인(`login`) 하나뿐이다. 있었으면 그 날짜와 토큰 수명 쿼리 결과를 판정과 함께 적는다. 아래 "개발 환경 세트 fixture 확보"의 개발 config 명령은 `runtime/`을 건드리지 않으므로(그 6단계로 확인) 세지 않고, 그 날짜만 판정과 함께 적는다.

결과(통과·실패, 기간, 토큰 수명)는 `_bmad-output/specs/spec-garmin-daily-pipeline/SPEC.md`의 `## Success signal` 확인 상태 줄에 적는다.

### 개발 환경 세트 fixture 확보

5.4(세트 정규화)·5.10(세트 표)에 쓸 실제 `activity_exercise_sets` 원문을 14일 점검을 깨지 않고 개발 코드로 받는 절차다(FR64). 운영 스냅샷(`runtime/.venv`)에는 세트 수집이 없고 점검 기간(~2026-11-02)에는 다시 배포하지 않으므로, 운영 DB를 개발 DB로 복사해 개발 코드로 받는다. 운영 DB는 읽기 전용(`mode=ro`) 연결의 SQLite 백업(`Connection.backup`)으로만 읽는다. 실제 Garmin 호출과 앱 대조는 사람이 한다. 점검 기간 중 하루, 아래 순서대로 저장소 루트에서 실행한다.

**왜 안전한가:** 11:30 report가 끝나면 그날 남은 운영 예약이 없다. 개발 실행이 429·403으로 tokenstore에 `block.json`(계정 단위, 개발과 운영이 같은 tokenstore를 쓴다)을 남겨도 날짜가 바뀌면 풀리므로 다음 날 11:00 수집에 영향이 없다. 개발 `collect`는 저장소 루트의 개발 config(`config.toml`, `data_dir = "data"`)로 돌아 `runtime/`(DB, `reports/`, `.venv`)을 쓰지 않는다. 세트 첫 호출은 첫 호출 보호(위 "collect")로 실행당 3건이고 그 403은 연속 403 승격에 세지 않는다.

**1. 시작 조건.** 그날 리포트 파일이 있고 운영 쓰기 락이 비어 있어야(`False`) 시작한다. 파일이 없거나 `True`면 예약 실행이 아직 돌고 있으니 기다린다. 개발 명령(`uv run garmin-pipeline …`)도 돌고 있지 않아야 한다.

```sh
ls runtime/reports/"$(date +%F)".md
runtime/.venv/bin/python -I -c '
from garmin_pipeline import config, store
print(store.write_lock_held(config.load("runtime/config.toml")))
'
```

이어서 운영 DB의 `run` 행 수를 위 "상태 확인"의 실행 명령(운영 DB)으로 보고 적어 둔다. `<SQL>` 자리에 아래 SQL을 붙인다.

```sql
SELECT count(*) FROM run;
```

**2. 기존 개발 DB 옮기기.** `data/garmin.db`와 있으면 `-wal`·`-shm`을 `data/before-5-3/`으로 옮긴다. 폴더가 이미 있으면 `mkdir`이 실패하고 아무것도 옮기지 않는다(이전 백업을 덮지 않는다). 개발 DB를 되돌릴 때는 이 폴더의 파일을 다시 `data/`로 옮긴다. 3단계가 도중에 실패했거나 다른 날 절차를 다시 할 때 `data/before-5-3/`에 원래 개발 DB가 이미 있으면, 이 단계를 건너뛰고 복사본(`data/garmin.db`와 그 `-wal`·`-shm`)만 지운 뒤 3단계부터 다시 한다.

```sh
mkdir data/before-5-3 && for f in garmin.db garmin.db-wal garmin.db-shm; do
  if [ -e "data/$f" ]; then mv -n "data/$f" data/before-5-3/; fi
done
```

**3. 운영 DB 백업 복사.** 운영 venv의 Python으로 `runtime/data/garmin.db`를 `mode=ro`로 열어 `data/garmin.db`에 백업한다. `data/garmin.db`나 그 `-wal`·`-shm`이 이미 있으면 쓰지 않고 한 줄 메시지와 함께 0이 아닌 종료 코드로 끝난다(2단계를 먼저 한다). 운영 DB 본 파일은 바뀌지 않는다. 읽기 전용 연결도 `runtime/data/`에 빈 `-wal`·`-shm`을 남길 수 있는데, 위 "상태 확인"의 읽기 연결과 같고 `-wal`에는 아무것도 쓰지 않는다. 복사본의 마이그레이션은 다음 개발 `collect`가 적용한다.

```sh
runtime/.venv/bin/python -I -c '
import os, sqlite3, sys
if any(os.path.lexists("data/garmin.db" + s) for s in ("", "-wal", "-shm")):
    sys.exit("data/garmin.db가 이미 있다. 쓰지 않는다(2단계를 먼저 한다)")
src = sqlite3.connect("file:runtime/data/garmin.db?mode=ro", uri=True)
os.close(os.open("data/garmin.db", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600))
dst = sqlite3.connect("data/garmin.db")
src.backup(dst)
dst.close()
src.close()
'
```

**4. 개발 `collect --force` 두 번.** 그날 운영이 이미 성공했고 복사본에 그 `run` 행이 있으므로 `--force`가 있어야 돈다(위 "collect"의 `--force`). 개발 config는 `--config config.toml`로 명시한다. 그래서 환경변수 `GARMIN_PIPELINE_CONFIG`가 설정돼 있어도 운영 config가 골라지지 않는다(위 "설정"의 탐색 순서). 첫 실행은 첫 호출 보호로 세트 상세를 3건만 요청하고 나머지는 건너뛴다(`data/logs/collect.log`의 `collect 첫 호출 보호로 건너뜀` 줄).

```sh
uv run garmin-pipeline collect --config config.toml --force
```

실행이 끝날 때마다 근력 활동의 세트 원문을 개발 DB에서 본다. 아래 실행 명령의 `<SQL>` 자리에 세트 확인 SQL을 붙인다. 근력 판정은 형식이 맞는 목록에서는 `rawparse`의 `needs_sets`와 같다(`totalSets > 0`이거나 `summarizedExerciseSets`가 비어 있지 않음). `sets`는 세트 원문이 있으면 `data`, NoData면 `null`, 아직 받지 않았으면 빈 칸이고, `errors`는 그 활동의 세트 호출 실패 종류(`rejected`·`transient`)다.

```sh
.venv/bin/python -I -c '
import sqlite3, sys
db = sqlite3.connect("file:data/garmin.db?mode=ro", uri=True)
for row in db.execute(sys.stdin.read()):
    print(*("" if v is None else v for v in row), sep="|")
' <<'SQL'
<SQL>
SQL
```

```sql
-- 근력 활동의 세트 원문: sets = data·null(NoData)·빈 칸(아직 안 받음), errors = 세트 호출 실패 종류
WITH a AS (
  SELECT substr(j.value ->> '$.startTimeLocal', 1, 10) AS day,
         CAST(j.value ->> '$.activityId' AS TEXT) AS activity_id,
         r.key AS list_key, j.key AS pos
  FROM raw_response r, json_each(r.raw) j
  WHERE r.scope = 'day' AND r.endpoint = 'activities_by_date'
    AND json_type(r.raw) = 'array' AND j.type = 'object'
    AND (coalesce(j.value ->> '$.totalSets', 0) > 0
         OR coalesce(json_array_length(j.value -> '$.summarizedExerciseSets'), 0) > 0))
SELECT a.day, a.activity_id,
       (SELECT iif(s.raw = 'null', 'null', 'data') FROM raw_response s
         WHERE s.scope = 'activity' AND s.endpoint = 'activity_exercise_sets'
           AND s.key = a.activity_id) AS sets,
       (SELECT group_concat(kind, ',') FROM (
          SELECT DISTINCT e.kind FROM fetch_error e
           WHERE e.scope = 'activity' AND e.endpoint = 'activity_exercise_sets'
             AND e.key = a.activity_id
           ORDER BY e.kind)) AS errors
FROM a
ORDER BY a.day DESC, a.list_key DESC, a.pos;
```

첫 실행 뒤 `sets`가 `data`인 행이 하나도 없고 `errors`에 `rejected`·`transient`가 있거나 실행이 `rate_limited`·`blocked_403`으로 중단됐으면 둘째 실행을 하지 않고 아래 "폴백"으로 간다. 403을 더 부르지 않는다. `data`는 없지만 행이 `null`·빈 칸뿐이고 `errors`가 없으며 실행이 중단되지 않았으면 보호가 그대로이니 `collect --force`를 다시 돌린다(여전히 3건 상한). 하나라도 `data`면 다음 실행부터 보호가 풀리므로 둘째 실행이 나머지를 받는다.

```sh
uv run garmin-pipeline collect --config config.toml --force
```

둘째 실행 뒤에도 같은 세트 확인 SQL을 돌린다. `errors` 없이 `sets`가 빈 칸인 행이 남아 있으면(실행당 날짜 상한 밖) 남지 않을 때까지 `collect --force`를 다시 돌린 뒤 5단계로 간다.

**5. fixture 내보내기.** 개발 DB에서 `tests/fixtures/garmin/`(git이 무시한다)으로 내보낸다. 기본 선택은 최근 활동 3개뿐이라, 세트 확인 SQL에서 `sets`가 `data`인 근력 활동은 `--activity-id`로 모두 지정해 한 번 더 실행한다(위 "capture-fixtures").

```sh
uv run garmin-pipeline capture-fixtures --config config.toml
uv run garmin-pipeline capture-fixtures --config config.toml --activity-id <id> --activity-id <id>
```

**6. 운영이 그대로인지 확인.** 1단계의 SQL로 본 운영 DB `run` 행 수가 1단계와 같고, `git status --porcelain`이 비어 있다(fixture와 개발 DB가 git에 잡히지 않는다).

```sh
git status --porcelain
```

**7. 앱 대조와 기록.** 근력 활동 하나 이상에서 `tests/fixtures/garmin/activity_exercise_sets/<id>.json`을 Garmin Connect 앱의 그 활동 세트 화면과 대조해 종목, 세트 수, 반복 수, 무게가 원문에 있는지 확인한다. 무게 단위(g·kg 단서)와 휴식 세트가 원문에서 어떻게 나오는지도 본다. 결과는 `_bmad-output/implementation-artifacts/spec-5-3-개발-환경에서-세트-fixture-확보.md`에 `## 사람 확인 기록`을 만들어 적는다. 커밋되는 파일이므로 날짜, 세트 fixture를 얻었는지, 키 이름, 단위, 휴식 세트 표현, 앱과의 일치 여부만 적고 실제 무게·반복 값과 activityId는 적지 않는다(아래 "git에서 빼는 경로").

**폴백:** 세트 fixture를 하나도 얻지 못했으면(403 등) 그 결과(`sets`·`errors`, 그날 개발 `run` 행의 상태와 `detail`)를 같은 `## 사람 확인 기록`에 적고, `bmad-correct-course`로 두 단계 배포 폴백(FR64)을 연다. 1단계는 원문 보존 등록과 나머지 Epic 5, 운영 첫 `collect` 뒤 fixture 확보, 2단계는 `exercise_set` 정규화와 `normalize_version` 올림이다. 5.4와 5.10은 배포 뒤로 미룬다. 개발 `run` 행은 위 개발 DB 실행 명령에 "상태 확인"의 일별 요약 SQL을 붙여 본다(세트 확인 SQL에는 실행 중단이 나오지 않는다).

### 재확인 일정

- **2026-11-15:** `garminconnect` 최신 릴리스와 #444·#453이 고쳐졌는지, `login` 시그니처·토큰 파일 구조, `codex exec` 플래그를 다시 확인한다. 바뀌었으면 위 "의존성 업그레이드" 순서를 따른다.
- 원본과 그 뒤 일정은 `_bmad-output/specs/spec-garmin-daily-pipeline/failure-modes.md`의 "재확인 일정"이다.

### 비밀

- `~/.codex/auth.json`(codex ChatGPT 로그인)과 tokenstore(`~/.garmin-pipeline/tokens`)는 비밀번호처럼 다룬다. 커밋·복사·공유하지 않는다.
- Telegram 봇 토큰·chat id는 `telegram.json`에만 두고 로그·DB·리포트·공유 자료에 적지 않는다. 파일 권한과 심링크 금지는 위 "Telegram 알림 설정"을 따른다.
- Garmin 비밀번호는 어디에도 적지 않는다(`login`이 화면에서만 받는다).
- 운영 루트 이름 `runtime`은 바꾸지 않는다. skill이 작업 폴더 이름 `runtime`에 기댄다(위 "report"의 "인수 테스트").

## 의존 방향 계약

`uv run lint-imports`가 24개 계약을 검사한다. 새 모듈은 관련 금지 목록에도 추가한다.

- `garmin-libs-only-in-adapter`: garminconnect·curl_cffi는 garmin_pipeline.garmin 안에서만 직접 import한다.
- `no-garth-openai`: garth·openai는 패키지 어디서도 import하지 않는다.
- `common-layer-imports-no-upper-modules`: 공통 계층(config·dates·errors)은 cli 같은 상위 모듈을 import하지 않는다.
- `store-imports-no-upper-modules`: store는 cli 같은 상위 모듈과 dates를 import하지 않는다.
- `garmin-only-imported-by-auth-collect`: garmin_pipeline.garmin은 auth·collect만 import한다.
- `garmin-imports-no-upper-modules`: garmin은 cli 같은 상위 모듈과 store를 import하지 않는다.
- `auth-imports-no-cli`: auth는 cli·rawparse·coverage·collect·ports·schedule·capture·normalize·body·report를 import하지 않는다.
- `rawparse-is-pure`: rawparse는 패키지의 다른 모듈과 Garmin 라이브러리·DB·네트워크를 import하지 않는다.
- `coverage-imports-no-upper-modules`: coverage는 cli·garmin·auth·collect·ports·schedule·capture·normalize·body·report와 Garmin 라이브러리를 import하지 않는다.
- `collect-imports-no-upper-modules`: collect는 cli·auth·schedule·capture·body·report를 import하지 않는다.
- `ports-imports-no-upper-modules`: ports는 cli·garmin·auth·collect·coverage·rawparse·schedule·capture·normalize·body·report·store와 Garmin 라이브러리를 import하지 않는다.
- `schedule-imports-no-upper-modules`: schedule은 cli·garmin·auth·collect·coverage·rawparse·ports·store·capture·normalize·body·report와 Garmin 라이브러리를 import하지 않는다.
- `capture-imports-no-upper-modules`: capture는 cli·garmin·auth·collect·ports·schedule·normalize·body·report와 Garmin 라이브러리를 import하지 않는다.
- `normalize-imports-no-upper-modules`: normalize는 cli·garmin·auth·coverage·collect·ports·schedule·capture·body·report와 Garmin 라이브러리를 import하지 않는다.
- `body-imports-no-upper-modules`: body는 cli·garmin·auth·collect·coverage·rawparse·ports·schedule·capture·normalize·report·store와 Garmin 라이브러리·sqlite3를 import하지 않는다.
- `report-imports-no-upper-modules`: report는 cli·garmin·auth·collect·rawparse·schedule·capture·normalize와 Garmin 라이브러리를 import하지 않는다.
- `matplotlib-only-in-charts`: matplotlib은 charts만 직접 import한다.
- `charts-only-imported-by-report`: charts는 report만 import한다.
- `charts-imports-no-upper-modules`: charts는 네트워크·상위 모듈을 import하지 않는다.
- `requests-only-in-telegram`: requests는 telegram만 직접 import한다.
- `telegram-only-imported-by-ports`: telegram은 ports만 import한다.
- `telegram-imports-no-upper-modules`: telegram은 errors 외 패키지 모듈을 import하지 않는다.
- `digest-imports-no-upper-modules`: digest imports only its allowed dependencies.
- `report-input-imports-no-upper-modules`: report_input imports only its allowed dependencies.

`charts`는 `store`·`body`·`sqlite3`를 사용할 수 있고 원문 파서·커버리지·정규화·digest·네트워크·상위 명령 모듈은 금지한다. `digest`는 DB·네트워크·matplotlib을 import하지 않는다. matplotlib은 charts만, charts는 report만 import한다.

## git에서 빼는 경로

건강 데이터와 그 파생물은 이 컴퓨터에만 두므로 첫 커밋 전부터 `.gitignore`에 둔다. 커밋하는 테스트 데이터는 합성했거나 익명화한 것만이다.

| 경로 | 이유 |
|------|------|
| `runtime/` | 운영 루트. 실사용 `config.toml`, DB, 리포트, 입력, 배포된 `.venv`가 모두 여기 있다 |
| `data/` | SQLite DB, 수집 원본, 체성분 JSON, 로그 |
| `reports/` | 건강 데이터로 만든 일일 리포트 |
| `inbox/` | 사용자가 넣는 인바디 스크린샷·수치 입력 |
| `tests/fixtures/garmin/` | 실제 계정 응답으로 만든 테스트 픽스처 |
| `*.db`·`*.db-wal`·`*.db-shm`·`*.db-journal`·`.write.lock`·`.report.lock` | 백스톱. 경로 설정을 잘못해 위 경로 밖(예: 저장소 루트)에 생긴 SQLite DB·WAL·롤백 저널·쓰기 락·리포트 락 |

앞의 네 경로와 백스톱 패턴은 앵커가 없어 어느 깊이에 있어도 무시된다(예: `scratch/data/`, `exports/inbox/`, `scratch/copy.db`). 그래서 인수 테스트의 DB는 커밋하지 않고 테스트가 마이그레이션으로 만든다. 확인:

```sh
git check-ignore -v runtime/ data/ reports/ inbox/ tests/fixtures/garmin/ garmin.db garmin.db-journal .write.lock .report.lock
```
