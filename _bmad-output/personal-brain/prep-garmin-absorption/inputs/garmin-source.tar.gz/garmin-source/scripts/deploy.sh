#!/usr/bin/env bash
# 운영 루트(<저장소>/runtime) 배포: lock 기준 비편집 스냅샷을 설치하고, skill을 복사하고, 정규화한 뒤
# collect·report 예약을 건다(FR10·38·39, AD-11·14).
#
# 인자는 받지 않는다. 운영 루트는 언제나 이 저장소의 runtime/이다. 몇 번 다시 실행해도 된다.
#   1. 스냅샷: uv.lock 그대로(--frozen) 개발 의존성 없이 비편집(--no-editable)으로 runtime/.venv에
#      설치한다. 그래서 배포 뒤 src/를 고쳐도 운영 동작은 바뀌지 않는다. Python이 3.14.8이 아니면 멈춘다.
#   2. runtime/config.toml이 없을 때만(심링크도 "있음"이다) config.runtime.example.toml을 복사한다.
#   3. skill 복사: skill/ 아래의 모든 스킬을 runtime/.agents/skills/로 통째로
#      교체한다(runtime/.agents/ 아래 임시 폴더에 복사한 뒤 rm -rf + mv라 원본에 없는 옛 파일이 남지
#      않고, 복사가 실패하면 기존 skill이 그대로 남는다). 이어서 runtime/inbox/inbody/{processed,
#      unreadable}/ 중 없는 폴더만 0700으로 만든다(있는 폴더의 권한·내용은 건드리지 않는다).
#   4. normalize: 새 스냅샷으로 runtime/config.toml의 DB를 정규화한다. 정규화 버전이 바뀌었으면 여기서
#      전체 재구성이 한 번 돈다. 실패하면(set -e) 예약 설치 전에 멈춘다.
#   5. install-schedule: runtime/config.toml로 collect·report LaunchAgent를 설치하거나 같은 내용으로
#      교체한다. report plist의 PATH에는 지금 PATH에서 찾은 codex의 폴더가 들어간다(없으면 거부).
#
# 실행: scripts/deploy.sh
set -euo pipefail

REPO="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO"

RUNTIME="$REPO/runtime"
CONFIG="$RUNTIME/config.toml"
EXAMPLE="$REPO/config.runtime.example.toml"
EXPECTED_PYTHON="3.14.8"

# runtime/에는 건강 데이터가 쌓이므로 새로 만들 때 0700이다(이미 있으면 그대로).
if [ ! -d "$RUNTIME" ]; then
  mkdir -m 700 "$RUNTIME"
fi

# 1. 스냅샷(AD-14)
UV_PROJECT_ENVIRONMENT=runtime/.venv uv sync --frozen --no-editable --no-dev

actual_python="$(runtime/.venv/bin/python -c 'import platform; print(platform.python_version())')"
if [ "$actual_python" != "$EXPECTED_PYTHON" ]; then
  echo "deploy 실패: runtime/.venv의 Python이 ${actual_python}이다(${EXPECTED_PYTHON}이어야 한다)." >&2
  exit 1
fi

# 2. 운영 config: 없을 때만 예시를 복사한다. 이미 있는 파일·심링크(깨진 심링크 포함)는 건드리지 않는다.
if [ ! -e "$CONFIG" ] && [ ! -L "$CONFIG" ]; then
  cp "$EXAMPLE" "$CONFIG"
  echo "runtime/config.toml을 예시에서 만들었다. 필요하면 고친 뒤 scripts/deploy.sh를 다시 실행한다."
fi

# 3. skill 복사(AD-14): runtime/.agents/ 아래(skills/ 밖) 임시 폴더에 복사한 뒤 통째로 교체한다.
#    실패로 끝나면 EXIT trap이 임시 폴더를 지운다. mv 뒤에는 그 경로가 없어 trap은 아무것도 지우지 않는다.
SKILLS="$RUNTIME/.agents/skills"
mkdir -p "$SKILLS"
staging="$(mktemp -d "$RUNTIME/.agents/.skill-staging.XXXXXX")"
trap 'rm -rf "$staging"' EXIT
staged_count=0
for source in "$REPO"/skill/*; do
  [ -d "$source" ] || continue
  name="$(basename "$source")"
  mkdir "$staging/$name"
  cp -R "$source/." "$staging/$name/"
  staged_count=$((staged_count + 1))
done
if [ "$staged_count" -eq 0 ]; then
  echo "deploy 실패: skill/ 아래에 배포할 스킬 폴더가 없다." >&2
  exit 1
fi
# All sources have staged successfully before replacing any installed skill.
for installed in "$SKILLS"/*; do
  [ -e "$installed" ] || [ -L "$installed" ] || continue
  name="$(basename "$installed")"
  if [ ! -d "$staging/$name" ]; then
    rm -rf "$installed"
  fi
done
for staged in "$staging"/*; do
  [ -d "$staged" ] || continue
  name="$(basename "$staged")"
  rm -rf "$SKILLS/$name"
  mv "$staged" "$SKILLS/$name"
done

#    inbox: 체성분 입력 폴더. 없는 것만 0700으로 만들고, 이미 있으면 권한·내용을 건드리지 않는다.
for dir in "$RUNTIME/inbox" "$RUNTIME/inbox/inbody" "$RUNTIME/inbox/inbody/processed" "$RUNTIME/inbox/inbody/unreadable"; do
  if [ ! -d "$dir" ]; then
    mkdir -m 700 "$dir"
  fi
done

# 4. normalize: 버전이 바뀌었으면 전체 재구성(실패하면 여기서 멈춘다)
runtime/.venv/bin/garmin-pipeline normalize --config "$CONFIG"

# 5. 예약(마지막 단계)
runtime/.venv/bin/garmin-pipeline install-schedule --config "$CONFIG"
