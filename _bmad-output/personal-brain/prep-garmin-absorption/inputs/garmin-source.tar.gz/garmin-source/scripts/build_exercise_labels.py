"""Garmin Connect 공식 한국어 운동 이름 번역 파일에서 운동 종목 라벨 데이터 파일을 만든다.

사용: `uv run python scripts/build_exercise_labels.py <properties 경로> <출력 경로>`

네트워크에 닿지 않는다. 미리 받은 properties 파일만 읽는다(Garmin Connect 한국어 번역 원본).
properties 줄은 `key=value`(첫 `=`로 나눔)이고 빈 줄과 `#`·`!` 주석은 건너뛴다.

출력 JSON(UTF-8, 키 정렬, `ensure_ascii=False`):
- `source`·`fetched_on`: 원문 URL과 받은 날(아래 상수).
- `categories`: `category_type_<CATEGORY>` 키에서 접두어를 뗀 `<CATEGORY>` → 문구.
- `exercises`: 이름이 `^[A-Z0-9_]+$`이고 `categories`의 어떤 `<CATEGORY>_`로 시작하는 키 → 문구(값 그대로).
  `exercise_type_<NAME>`·소문자·UI 문구 키는 넣지 않는다(`category_type_` 키가 없는 `MOVE_*`·`POSE_*`도 빠진다).
- `categories`나 `exercises`가 비면(받은 파일이 오류 페이지 등) 쓰지 않고 종료 코드 1이다.

패키지 밖 도구라 `src/`가 import하지 않는다.
"""

import json
import re
import sys
from pathlib import Path

SOURCE = "https://connect.garmin.com/web-translations/exercise_types/exercise_types_ko.properties"
FETCHED_ON = "2026-10-21"
_CATEGORY_PREFIX = "category_type_"
_EXERCISE_KEY = re.compile(r"[A-Z0-9_]+")


def parse_properties(text: str) -> dict[str, str]:
    """`key=value` 줄을 dict로. 빈 줄·`#`·`!` 주석·`=` 없는 줄은 건너뛴다. 같은 키는 뒤의 것이 남는다."""
    pairs: dict[str, str] = {}
    for line in text.splitlines():
        stripped = line.strip()
        if not stripped or stripped.startswith(("#", "!")) or "=" not in line:
            continue
        key, value = line.split("=", 1)
        pairs[key.strip()] = value.strip()
    return pairs


def build_labels(
    pairs: dict[str, str], *, source: str = SOURCE, fetched_on: str = FETCHED_ON
) -> dict[str, object]:
    """properties 키·값에서 라벨 데이터(모양은 모듈 docstring)를 만든다."""
    categories = {
        key.removeprefix(_CATEGORY_PREFIX): value
        for key, value in pairs.items()
        if key.startswith(_CATEGORY_PREFIX) and len(key) > len(_CATEGORY_PREFIX)
    }
    prefixes = tuple(f"{category}_" for category in categories)
    exercises = {
        key: value
        for key, value in pairs.items()
        if _EXERCISE_KEY.fullmatch(key) and key.startswith(prefixes)
    }
    return {
        "categories": dict(sorted(categories.items())),
        "exercises": dict(sorted(exercises.items())),
        "fetched_on": fetched_on,
        "source": source,
    }


def render(labels: dict[str, object]) -> str:
    """데이터 파일 텍스트(키 정렬, 한글 그대로, 끝 줄바꿈)."""
    return json.dumps(labels, ensure_ascii=False, sort_keys=True, indent=2) + "\n"


def main(argv: list[str]) -> int:
    if len(argv) != 2:
        print(
            "사용: build_exercise_labels.py <properties 경로> <출력 경로>",
            file=sys.stderr,
        )
        return 2
    source_path, output_path = Path(argv[0]), Path(argv[1])
    labels = build_labels(parse_properties(source_path.read_text(encoding="utf-8")))
    if not labels["categories"] or not labels["exercises"]:
        # 받은 파일이 오류 페이지 등이면 커밋된 데이터 파일을 빈 표로 덮지 않는다.
        print(
            f"오류: {source_path}에서 categories·exercises를 얻지 못했다(쓰지 않음)",
            file=sys.stderr,
        )
        return 1
    output_path.write_text(render(labels), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
